# SONGDNA SMART STUDIO 6.1.0 — Android / Web / Gemini

SONGDNA SMART STUDIO, Suno için özgün şarkı sözleri ve Styles komutları hazırlayan bir yardımcı uygulamadır. Ses oynatıcı veya ses üretim motoru değildir. Suno akışı iki çıktı alanını korur: **Styles** ve **Lyrics**.

## Proje yapısı
- `www/`: web çalışma zamanı.
- `android-wrapper/`: Android WebView uygulaması ve Gradle projesi.
- `backend/`: Node.js Gemini API servisi.
- `scripts/` ve `tests/`: kaynak doğrulama ve regresyon testleri.
- `BUILD_MANIFEST.json`: sürüm ve derleme metaverisi.

## Sürüm
- Uygulama: **6.1.0**
- Android versionCode: **32**
- Application ID: `com.songdna.studio`
- Minimum SDK: 23 · Hedef SDK: 35

Bu sürüm, 5.7.0 kaynak tabanındaki son Stage 145–149 güncellemelerini ve Stage 150 yerel doğrulama sonuçlarını koruyarak sürüm kimliğini 6.1.0'a taşır. Bu yükseltmede yeni üretim özelliği eklenmemiştir.

## APK derleme
GitHub Actions'ta **SONGDNA SMART STUDIO 6.1.0 - Current Source APK Build** iş akışını çalıştırın. Başarılı derleme sonrası `SONGDNA-Studio-6.1.0-current-source-debug-APK` artifact'ini indirin. İş akışı debug APK üretir; imzalı release APK değildir.

## Gemini / Render
Backend Render üzerinde ayrı dağıtılır. `GEMINI_API_KEY` yalnızca sunucuda tutulur; uygulama `APP_ACCESS_TOKEN` ile backend'e erişir. Canlı Gemini/Render bağlantısı ve fiziksel Android kurulumu bu kaynak paketi oluşturulurken doğrulanmış değildir.

## Yerel doğrulama
```bash
python3 scripts/verify-source.py
npm --prefix backend run check
```
Tam regresyon testleri için `.github/workflows/build.yml` içindeki test adımlarını çalıştırın.
