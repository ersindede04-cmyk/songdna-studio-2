#!/usr/bin/env python3
"""Strict Stage 60.1 source and Android asset integrity checks."""
from pathlib import Path
import json, re, shutil, subprocess, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
WEB=ROOT/"www"
ANDROID=ROOT/"android-wrapper/app/src/main/assets/www"
ANDROID_ROOT=ROOT/"android-wrapper/app/src/main/assets"
RUNTIME=["index.html","app.js","saved-library.js","production-history.js","adlib-catalog.js","scene-jargon-catalog.js","global-cultural-adlib.js","genre-adlib-engine.js","production-preset-engine.js","emotion-engine.js","production-adaptation-engine.js","energy-engine.js","adlib-intelligence-engine.js","atmosphere-engine.js","section-arrangement-engine.js","vocal-identity-engine.js","music-compatibility-engine.js","integrated-production-engine.js","manual-override-engine.js","profile-snapshot-engine.js","production-model-library.js","dynamic-creativity-engine.js","production-history-storage.js","three-layer-production-orchestrator.js","production-element-library-data.js","production-element-library.js"]
REQUIRED=["BUILD_MANIFEST.json","index.html","app.js","backend/server.js","backend/package.json","android-wrapper/app/build.gradle.kts","android-wrapper/app/src/main/AndroidManifest.xml","android-wrapper/app/src/main/java/com/songdna/studio/MainActivity.kt","scripts/test-stage29-client-api-contract.js","tests/test-stage29-api-contract.js","CHANGELOG_5_2_0_STAGE60_1_PRODUCTION_PROMPT_HOTFIX_TR.md","QA_REPORT_5_2_0_STAGE60_1_SOURCE_SYNC.md"]
for folder in [WEB,ANDROID]:
    REQUIRED += [str(Path(folder.relative_to(ROOT))/n) for n in RUNTIME]
missing=[x for x in REQUIRED if not (ROOT/x).is_file()]
if missing: raise SystemExit("FAIL missing files: "+", ".join(missing))
for name in RUNTIME:
    a=(WEB/name).read_bytes(); b=(ANDROID/name).read_bytes()
    if a!=b: raise SystemExit(f"FAIL WebView asset mismatch: {name}")
    if name.endswith(".js") and (ROOT/name).exists() and (ROOT/name).read_bytes()!=a:
        raise SystemExit(f"FAIL root runtime mismatch: {name}")
    if name.endswith(".js") and (ANDROID_ROOT/name).exists() and (ANDROID_ROOT/name).read_bytes()!=a:
        raise SystemExit(f"FAIL Android root asset mismatch: {name}")
if (ROOT/"index.html").read_bytes()!=(WEB/"index.html").read_bytes(): raise SystemExit("FAIL root index.html mismatch")
if (ANDROID_ROOT/"index.html").read_bytes()!=(WEB/"index.html").read_bytes(): raise SystemExit("FAIL Android root index.html mismatch")
print("PASS: root, web and Android WebView runtime assets are synchronized")
manifest_paths=[ROOT/"BUILD_MANIFEST.json",WEB/"BUILD_MANIFEST.json",ANDROID_ROOT/"BUILD_MANIFEST.json",ANDROID/"BUILD_MANIFEST.json"]
manifests=[json.loads(p.read_text(encoding="utf-8")) for p in manifest_paths]
if any(m!=manifests[0] for m in manifests[1:]): raise SystemExit("FAIL BUILD_MANIFEST.json copies differ")
m=manifests[0]
if m.get("version")!="6.1.0" or m.get("stage")!=151: raise SystemExit("FAIL expected SONGDNA 6.1.0 Stage 151 manifest")
if not any(str(x).startswith("Stage 60.1:") for x in m.get("completed_stages",[])): raise SystemExit("FAIL Stage 60.1 completion marker missing")
print("PASS: all four manifests match and identify SONGDNA 6.1.0 Stage 151")
js=(WEB/"app.js").read_text(encoding="utf-8")
for token in ["SONGDNA_GEMINI_INSTRUCTIONS_2","profileSnapshot:c.profileSnapshot?{version:c.profileSnapshot.version,id:c.profileSnapshot.id}:null","Üretim istemi "]:
    if token not in js: raise SystemExit("FAIL Stage 60.1 prompt hotfix marker missing: "+token)
if "prompt=buildGeminiInstructionEnvelope('lyrics',currentContext,makeLyricsPrompt(currentContext))" not in js: raise SystemExit("FAIL lyrics production envelope route missing")
print("PASS: Stage 60.1 compact profile metadata and prompt preflight markers present")
html=(WEB/"index.html").read_text(encoding="utf-8")
for src in re.findall(r'<script[^>]+src="([^"]+)"',html):
    if not (WEB/src).is_file(): raise SystemExit("FAIL missing HTML script dependency: "+src)
for p in (ROOT/"android-wrapper/app/src/main").rglob("*.xml"): ET.parse(p)
print("PASS: HTML dependencies and Android XML")
node=shutil.which("node")
if not node: raise SystemExit("FAIL Node.js is required")
for p in [WEB/n for n in RUNTIME if n.endswith(".js")]+[ROOT/"backend/server.js"]:
    r=subprocess.run([node,"--check",str(p)],capture_output=True,text=True)
    if r.returncode: raise SystemExit(f"FAIL JS syntax {p}: {r.stderr}")
print("PASS: JavaScript syntax")
backend=(ROOT/"backend/server.js").read_text(encoding="utf-8")
for endpoint in ["/api/lyrics","/api/style","/api/command"]:
    if endpoint not in js or endpoint not in backend: raise SystemExit("FAIL API endpoint contract: "+endpoint)
if "APP_ACCESS_TOKEN" not in backend: raise SystemExit("FAIL backend auth contract")
if "Styles" not in html or "Lyrics" not in html: raise SystemExit("FAIL Styles/Lyrics output fields missing")
print("ALL STAGE 60.1 SOURCE CHECKS PASSED. Live Gemini, Render and physical Android tests remain pending.")
