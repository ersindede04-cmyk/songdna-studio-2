# Stage197 — ZIP üzerinden Render dağıtımı

## Amaç
Stage196 uygulama kaynakları ve üretim davranışı korunarak, kullanıcının telefondan yalnızca tek bir kaynak ZIP dosyasını GitHub deposuna yükleyebilmesi için Render dağıtım yolu eklendi.

## Değişiklikler
- Stage196 uygulama arayüzü, Music DNA kataloğu, tema/konu kütüphaneleri, otomatik seçim sırası ve üretim motoru korundu.
- Backend sağlık yanıtı ve başlangıç kaydı Stage197 olarak güncellendi.
- Render, GitHub depo köküne yüklenen Stage197 kaynak ZIP dosyasını build sırasında `render-stage197-source` klasörüne açacak şekilde yapılandırıldı.
- Başlatma komutu, çıkarılan ZIP içindeki Stage197 backend klasörünü kullanır; eski depo dosyaları silinmez veya üzerine yazılmaz.
- Node.js sürümü Render Environment içindeki `NODE_VERSION=22.16.0` ile sabitlenir.
- `GEMINI_API_KEY` ve `APP_ACCESS_TOKEN` değişkenleri korunur; API anahtarı kaynak pakete eklenmez.

## Render ayarları
Root Directory boş bırakılmalı. Build Command ve Start Command için `backend/DEPLOY_TR.md` dosyasındaki Stage197 komutları kullanılmalı. Environment içinde `NODE_VERSION=22.16.0` eklenmeli.

## Doğrulama sınırı
Kaynak paketinin yerel doğrulamaları ayrıca raporlanır. GitHub'a yükleme, Render dağıtımı, canlı Gemini kimlik bilgisi ve fiziksel cihaz testi bu paket oluşturulurken yapılmamıştır.
