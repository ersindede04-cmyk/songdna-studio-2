# Stage187 GitHub yükleme

1. `SONGDNA_SMART_STUDIO_7_5_0_STAGE187_KAYNAK_PAKETI.zip` dosyasını GitHub deposunun ana dizinine, adını değiştirmeden yükleyin.
2. `.github/workflows/build.yml` dosyasının tamamını bu paketteki `STAGE187_BUILD_FULL.yml` içeriğiyle değiştirin.
3. Actions sekmesinden **SONGDNA SMART STUDIO 7.5.0 - Stage187 Android Build** iş akışını çalıştırın.
4. İş akışı ZIP'in CRC bütünlüğünü, beklenen kök klasörünü ve Stage187 manifestini APK derlemesinden önce doğrular.
5. Başarılı çalışmada APK ve SHA-256 dosyası Actions > Artifacts bölümünde bulunur.

Önemli: ZIP dosyasını yalnızca GitHub'a yüklemek Render kaynaklarını güncellemez. Render dağıtımı için proje dosyalarının açılmış hâli de deponun kökünde bulunmalıdır. Bu aşama canlı Render dağıtımını otomatik olarak değiştirmez.
