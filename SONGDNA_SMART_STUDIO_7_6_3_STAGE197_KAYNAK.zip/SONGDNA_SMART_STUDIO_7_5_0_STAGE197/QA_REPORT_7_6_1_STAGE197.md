# QA — SONGDNA SMART STUDIO 7.6.1 / Stage197

- Release identity: 7.6.1; Android versionCode 46.
- Change: regression contract now expects the primary Lyrics endpoint call plus the conditional Turkish-language repair retry.
- Workflow: Gradle forced dependency refresh removed; cached dependencies retained; bounded retries with backoff added to reduce Maven HTTP 429 risk.
- Render deployment commands and archive root path unchanged.
- External GitHub Actions APK build, live Render/Gemini and physical-device tests pending.
