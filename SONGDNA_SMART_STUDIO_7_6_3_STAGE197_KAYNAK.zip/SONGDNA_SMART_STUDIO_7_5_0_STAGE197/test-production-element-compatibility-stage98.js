const lib=require('./production-element-library.js');
const fake={items:[
{id:'PE-001',name:'Four-on-the-floor kick pulse'},
{id:'PE-003',name:'Broken-beat syncopation'},
{id:'PE-010',name:'808 glide bass'},
{id:'PE-011',name:'Rolling bassline'}
]};
const out=lib.analyze(fake);
if(out.notes.length!==2||out.level!=='conflict'||!out.canProceed||out.selectionChanged)throw Error('compatibility advisory contract failed');
console.log(JSON.stringify({level:out.level,notes:out.notes.length,canProceed:out.canProceed,selectionChanged:out.selectionChanged}));
