# SONGDNA SMART STUDIO 7.6.0 — Stage197 dağıtım altyapısı üzerinde

## Kapsam
- Stage197 ZIP tabanlı Render dağıtım altyapısı, tek Gemini API anahtarı ve Node 22 çalışma ortamı korunmuştur.
- Mevcut Music DNA kataloğu, üretim profilleri, Styles/Lyrics kimlik sözleşmesi, geleneksel üretim ve otomatik Music DNA sıralaması korunmuştur.

## Hikâye kütüphanesi
- Sabit 30 otomatik konu seçimi yerine genişletilebilir, bileşen tabanlı hikâye çekirdeği üretimi eklendi.
- Başlangıç kütüphanesi 24 tema, 36 karakter rolü, 36 mekân, 36 olay tetikleyicisi, 24 çatışma, 20 dönüm noktası ve 19 final seçeneği içerir. Bu katmanların teorik kombinasyon alanı 10.212.065.280 yapılandırılmış çekirdektir; katalog üst sınıra kilitlenmemiştir.
- Her üretim için yeni bir yapılandırılmış hikâye çekirdeği oluşturulur ve Gemini'ye neden-sonuç omurgasıyla aktarılır.
- Hikâye çeşitlilik hafızası 40 başarılı üretime çıkarıldı; son 36 üretim tekrar önleme rehberliğinde kullanılır.
- Stage178/190 döneminden kalan v1 hikâye hafızası v2 yapısına geriye dönük aktarılır.
- Kullanıcıya gösterilen tema, konu, olay ve anlatım biçimi giriş paneli gizlendi; otomatik üretim esas alındı.

## Dil güvenliği
- Seçilen ana şarkı dili prompt içinde kesin dil kilidi olarak belirtilir.
- Türkçe seçiliyken Devanagari veya belirgin transliterasyonlu Hintçe işaretleri algılanırsa bir defalık Türkçe yeniden yazım çağrısı yapılır.
- Styles, Lyrics ve Suno bölüm etiketleri ayrımı korunur.

## Arayüz
- Modern Üretim ve Geleneksel Üretim sekmelerinin yanına doğrudan LYRICS bağlantısı eklendi.
- LYRICS bağlantısı şarkı sözleri alanına gider ve Styles kartını geçici olarak gizleyerek sözleri tek sütunda gösterir.
- Modern/Geleneksel sekmesine dönüldüğünde Lyrics odak görünümü kapanır.
- Web ve Android WebView kaynak kopyaları eşitlendi.

## Sürüm
- Uygulama: 7.6.0
- Stage/dağıtım tabanı: Stage197
- Android versionCode: 45
- Backend Node: 22.x
- Gemini anahtar mimarisi: yalnızca GEMINI_API_KEY

## Doğrulama
- JavaScript regresyon testleri: 99/99 başarılı.
- Stage170 Chromium telefon/tablet çalışma alanı testleri: 67/67 başarılı.
- `scripts/verify-source.py`: başarılı.
- `npm --prefix backend run check`: başarılı.
- Canlı Gemini üretimi, Render dağıtımı ve fiziksel Android APK testi bu yerel doğrulama aşamasında yapılmamıştır.
