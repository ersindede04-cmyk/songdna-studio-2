# SONGDNA SMART STUDIO 7.5.0 — Stage188

## Kapsam
Stage187 kaynak kodu ve ürün davranışı korunmuştur. Bu aşamanın odağı GitHub Actions derleme hattının kararlılığıdır.

## CI/Derleme düzenlemeleri
- ZIP dosyası depo ana dizininde aranır; `-1`, `-4` gibi ekler kabul edilir.
- ZIP CRC ve Stage188 manifest kimliği çıkarma öncesinde doğrulanır.
- Node.js kurulumu lockfile önbelleği kullanmaz.
- Android SDK kurulumunda eski `tools` paketi istenmez.
- Android projesinde `gradlew` bulunmadığından Gradle 8.9 Actions üzerinden kurulur.
- APK çıktısı ve SHA-256 doğrulanır.

## Korunan alanlar
- Lyrics ve Styles üretim akışları
- Story Blending endpoint kaynak kodu
- Music DNA ve tema/konu kütüphaneleri
- Otomatik seçim sırası

## Doğrulama sınırları
Paketleme sırasında kaynak ZIP bütünlüğü ve YAML sözdizimi kontrol edilir. GitHub Actions, Render, canlı Gemini, fiziksel Android cihazı ve Suno doğrulamaları henüz yapılmamıştır.
