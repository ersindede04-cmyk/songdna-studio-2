# SONGDNA SMART STUDIO 7.5.0 — Stage189 Render dağıtımı

## Bu paketteki backend
- Render Root Directory: `backend`
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check Path: `/health`
- Uygulamanın çağırdığı `POST /api/story-blend` endpoint'i `backend/server.js` içinde mevcut.
- Yanıt sözleşmesi `{ story: ... }`; uygulama `response.story || response.text` okur.
- `/api/lyrics`, `/api/style`, `/api/command` ve `/api/lyrics-audit` korunmuştur.

## GitHub'a aktarım
1. ZIP'i bilgisayarda/telefonda aç.
2. Depodaki `backend/server.js` dosyasını bu paketteki `backend/server.js` ile tamamen değiştir.
3. Depodaki `backend/package.json` dosyasını bu pakettekiyle karşılaştır; farklıysa tam dosyayı güncelle.
4. `render.yaml` dosyasını depo kökünde güncelle (Root Directory `backend` olmalı).
5. GitHub `main` dalına kaydet. Render servisi `songdna-ai-api` aynı depoya ve `main` dalına bağlıysa Auto-Deploy yeni commit'i dağıtır.

## Render'da doğrulama
`https://songdna-ai-api.onrender.com/health` aç. JSON yanıtında `stage: 189`, `capabilities.storyBlend: true` ve `apiVersion: 7.5.0` aranmalı.

Not: Bu paket Render hesabına kendiliğinden yüklenmez. GitHub deposuna commit ve Render dağıtımı kullanıcı hesabında yapılmalıdır. Canlı dağıtım bu üretim ortamından doğrulanmamıştır.
