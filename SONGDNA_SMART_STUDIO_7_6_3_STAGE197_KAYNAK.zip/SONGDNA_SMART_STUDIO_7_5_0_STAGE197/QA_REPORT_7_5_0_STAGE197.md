# Stage197 QA raporu

- Temel: Stage196 kaynak paketi.
- Uygulama motoru ve kullanıcı arayüzü: korunmuştur.
- Backend kimliği: Stage197.
- Render dağıtım modeli: GitHub deposunda tek kaynak ZIP dosyası; Render build aşamasında arşivi açar ve çıkarılan backend'i başlatır.
- Render Root Directory: boş.
- Node.js: `NODE_VERSION=22.16.0`.
- Gemini anahtarı: `GEMINI_API_KEY`; `GEMINI_API_KEY_2` kullanılmaz.
- `APP_ACCESS_TOKEN` zorunludur.
- Canlı Render dağıtımı: doğrulanmadı.
- Canlı Gemini anahtarı: doğrulanmadı.
- APK derlemesi ve fiziksel Android kurulumu: bu aşamada doğrulanmadı.
