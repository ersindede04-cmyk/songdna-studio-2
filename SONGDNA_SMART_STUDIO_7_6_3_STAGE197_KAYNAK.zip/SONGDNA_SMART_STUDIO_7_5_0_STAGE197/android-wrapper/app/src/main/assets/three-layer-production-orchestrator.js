/* SONGDNA SMART STUDIO — Stage 95: Three-Layer Production Orchestrator
 * Coordinates the three user-selected production roles through one shared context.
 * Advisory/prompt planning only. It does not process audio or silently alter selections.
 */
(function(root){
 'use strict';
 const ROLES = Object.freeze([
  {key:'main', label:'Ana Prodüksiyon', priority:'primary',
   instruction:'Establish the song’s main musical identity. This layer may stand alone and must remain the dominant identity.'},
  {key:'secondary', label:'Alt Katman 2', priority:'secondary',
   instruction:'Add only the explicitly selected second musical influence. Support the main identity; do not replace it.'},
  {key:'helper', label:'Yardımcı Prodüksiyon', priority:'support',
   instruction:'Add complementary production texture or elements. Do not introduce an unselected genre or compete with the lead identity.'}
 ]);
 const clean = v => String(v == null ? '' : v).trim();
 const copy = v => { try { return JSON.parse(JSON.stringify(v)); } catch (_) { return {}; } };
 const hasSelection = layer => !!(clean(layer?.id) || clean(layer?.name) || clean(layer?.profileName) || clean(layer?.promptText));
 function normalizeLayer(role, value){
  const layer = value && typeof value === 'object' ? copy(value) : {};
  const selected = hasSelection(layer);
  return {
   role: role.key, label: role.label, priority: role.priority,
   selected,
   id: clean(layer.id) || null,
   name: clean(layer.name || layer.profileName) || null,
   family: clean(layer.family) || null,
   promptText: clean(layer.promptText || layer.description || layer.styleText),
   elements: Array.isArray(layer.elements) ? layer.elements.map(clean).filter(Boolean) : [],
   musicalTraits: Array.isArray(layer.musicalTraits) ? layer.musicalTraits.map(clean).filter(Boolean) : [],
   genreTags: Array.isArray(layer.genreTags) ? layer.genreTags.map(clean).filter(Boolean) : [],
   arrangementGuidance: clean(layer.arrangementGuidance),
   source: clean(layer.source) || 'user-selection'
  };
 }
 function analyze(input={}){
  const built=build(input);
  const layers=built.layers;
  const main=layers.find(x=>x.role==='main');
  const secondary=layers.find(x=>x.role==='secondary');
  const helper=layers.find(x=>x.role==='helper');
  const notes=[];
  const alternatives=[];
  const selected=layers.filter(x=>x.selected);
  const identity=x=>clean(x?.id)||clean(x?.name).toLocaleLowerCase('tr-TR');
  // Extract only explicit, high-confidence musical characteristics from catalog text.
  const describe=x=>{
   const text=[x?.family,x?.name,x?.promptText,x?.arrangementGuidance,...(x?.elements||[]),...(x?.musicalTraits||[]),...(x?.genreTags||[])].join(' ').toLocaleLowerCase('tr-TR');
   const has=re=>re.test(text);
   return {
    pulse: has(/unmetered|free compositional|free[- ]time|unmeasured|serbest ritim|ölçüsüz/) ? 'free' :
     has(/four[- ]on[- ]the[- ]floor|four on floor/) ? 'four-on-floor' :
     has(/broken[- ]beat|breakbeat|break beats|shuffled|shuffle|swing pocket/) ? 'broken-or-shuffled' :
     has(/half[- ]time/) ? 'half-time' :
     has(/straight (?:4\/4|four|pulse)|rigid (?:4\/4|four)|steady dance pulse|fixed (?:meter|pulse)/) ? 'straight-pulse' : null,
    vocal: has(/multiple independent vocal lines|independent vocal lines|polyphonic vocal|four[- ]part.*vocal|three[- ]part.*vocal/) ? 'polyphonic' :
     has(/single lead vocalist|solo lead vocal|one lead vocalist|lead vocal(?:ist)? as the sole/) ? 'solo-lead' : null,
    bass: has(/sliding 808|808 glide/) ? 'sliding-808' : has(/log[- ]drum/) ? 'log-drum' : null
   };
  };
  const descriptors=Object.fromEntries(selected.map(x=>[x.role,describe(x)]));
  // Stage 122: flag exact repeated production elements across selected roles.
  // This is deliberately conservative: similar wording is not treated as a match.
  const normalizeElement=value=>clean(value).toLowerCase().replace(/\s+/g,' ').replace(/[.!?,;:]+$/g,'');
  const compare=(left,right)=>{
   if(!left?.selected||!right?.selected)return;
   const a=descriptors[left.role]||{},b=descriptors[right.role]||{};
   const add=(code,message,alternative)=>{notes.push({code,severity:'warning',message,roles:[left.role,right.role]});alternatives.push(alternative);};
   if(a.pulse&&b.pulse&&a.pulse!==b.pulse){
    const pair=[a.pulse,b.pulse].sort().join('|');
    const known=[ 'broken-or-shuffled|four-on-floor','broken-or-shuffled|straight-pulse','free|straight-pulse','free|half-time','four-on-floor|free','four-on-floor|half-time' ];
    if(known.includes(pair))add('RHYTHMIC_FOUNDATION_DIFFERENCE',`${left.label} ve ${right.label} farklı ritmik temel/pulse yaklaşımları taşıyor (${a.pulse} / ${b.pulse}); bunlar aynı anda tek ana groove gibi uygulanırsa yön belirsizleşebilir.`, 'Ana katmanın pulse kimliğini koru; farklı ritmik yaklaşımı ayrı bölüm, geçiş veya kontrollü kontrast olarak kullan.');
   }
   if(a.vocal&&b.vocal&&a.vocal!==b.vocal)add('VOCAL_ARRANGEMENT_ROLE_DIFFERENCE',`${left.label} ve ${right.label} farklı vokal düzeni beklentileri içeriyor (${a.vocal} / ${b.vocal}); vokal rolleri üst üste bindirilmeden düzenlenmeli.`, 'Ana vokal düzenini koru; diğer vokal yaklaşımını cevap, arka plan veya ayrı bölüm olarak konumlandır.');
   if(a.bass&&b.bass&&a.bass!==b.bass)add('BASS_IDENTITY_OVERLAP',`${left.label} ve ${right.label} farklı belirgin bas karakterleri içeriyor (${a.bass} / ${b.bass}); iki bas motifi aynı anda baskınlaşabilir.`, 'Bir bas karakterini ana taşıyıcı yap; diğerini seyrek cevap veya ayrı bölümde kullan.');
   const leftElements=new Set(left.elements.map(normalizeElement).filter(Boolean));
   const repeated=[...new Set(right.elements.map(normalizeElement).filter(x=>x&&leftElements.has(x)))];
   if(repeated.length)add('REPEATED_PRODUCTION_ELEMENTS',`${left.label} ve ${right.label} katmanlarında aynı üretim öğeleri tekrar ediyor: ${repeated.join(', ')}. Bu tekrar bilinçli olabilir; gereksiz çift kullanım kontrol edilmeli.`, 'Tekrarlanan öğeyi tek bir katmanda ana unsur olarak tut; diğer katmanda farklı bir tamamlayıcı görev kullan veya tekrarın bilinçli olduğunu koru.');
  };
  compare(main,secondary); compare(main,helper); compare(secondary,helper);
  if(secondary.selected&&helper.selected&&identity(secondary)===identity(helper)){
   notes.push({code:'DUPLICATE_LAYER_PROFILE',severity:'conflict',message:'Alt Katman 2 ve Yardımcı Prodüksiyon aynı profili kullanıyor; iki katmanda aynı kimlik tekrar ediyor.'});
   alternatives.push('Yardımcı katmanda farklı ve tamamlayıcı bir profil seçilebilir.');
  }
  if(main.selected&&secondary.selected&&identity(main)===identity(secondary)){
   notes.push({code:'MAIN_SECONDARY_DUPLICATE',severity:'warning',message:'Ana Prodüksiyon ve Alt Katman 2 aynı profili kullanıyor; ikinci katman yeni bir katkı sağlamayabilir.'});
   alternatives.push('Alt Katman 2 için farklı bir müzikal etki değerlendirilebilir.');
  }
  if(main.selected&&helper.selected&&identity(main)===identity(helper)){
   notes.push({code:'MAIN_HELPER_DUPLICATE',severity:'warning',message:'Yardımcı Prodüksiyon ana profili tekrar ediyor; tamamlayıcı katman işlevi zayıflayabilir.'});
   alternatives.push('Yardımcı katmanda ana kimliği destekleyen farklı bir profil veya doku kullanılabilir.');
  }
  if(!main.selected&&selected.length>1){
   notes.push({code:'MISSING_PRIMARY_IDENTITY',severity:'warning',message:'Ana Music DNA seçilmedi; yalnızca açıkça seçilmiş geleneksel teknik kimliği ana dayanak olarak kullanılabilir. Alt ve yardımcı katmanlar kendiliğinden ana kimliğe dönüşmez.'});
  }
  const level=notes.some(n=>n.severity==='conflict')?'conflict':notes.length?'experimental':'compatible';
  const uniqueNotes=notes.filter((n,i,a)=>a.findIndex(x=>x.code===n.code&&JSON.stringify(x.roles||[])===JSON.stringify(n.roles||[]))===i);
  const finalLevel=uniqueNotes.some(n=>n.severity==='conflict')?'conflict':uniqueNotes.length?'experimental':'compatible';
  // Stage 123/124: map conflicts only onto section names explicitly present in the arrangement.
  // Candidate windows are suggestions, never instructions to create or force a section.
  const suppliedSections=Array.isArray(input.existingSections)?input.existingSections:[];
  const sectionNames=suppliedSections.map(section=>clean(typeof section==='string'?section:(section?.name||section?.label))).filter(Boolean);
  const sectionRules={
   RHYTHMIC_FOUNDATION_DIFFERENCE:{candidates:['breakdown','bridge','instrumental break','contrast section','gecis bolumu','kopru','enstrumantal ara'],role:'secondary'},
   VOCAL_ARRANGEMENT_ROLE_DIFFERENCE:{candidates:['response gap','call and response','chorus response','backing vocal section','chorus','verse','nakarat','kita','vokal cevap boslugu','nakarat cevabi','arka vokal bolumu'],role:'secondary'},
   BASS_IDENTITY_OVERLAP:{candidates:['breakdown','transition','drop','bass break','gecis','ara bolum','bas arasi'],role:'secondary'},
   REPEATED_PRODUCTION_ELEMENTS:{candidates:['transition','instrumental break','contrast section','gecis','enstrumantal ara','kontrast bolumu'],role:'helper'}
  };
  const temporalSeparationPlans=uniqueNotes.filter(n=>sectionRules[n.code]).map(n=>{
   const rule=sectionRules[n.code];
   const matchedExistingSections=sectionNames.filter(name=>rule.candidates.some(candidate=>name.toLocaleLowerCase('tr-TR').includes(candidate)));
   return {
    code:n.code,roles:[...(n.roles||[])],primaryRole:main?.selected?'main':null,
    suggestedRole:rule.role,
    strategy:'Keep the primary layer as the song-wide foundation. Use the suggested role only in a matching section that already exists in the supplied arrangement; otherwise leave the arrangement unchanged.',
    candidateSectionTypes:[...rule.candidates],
    matchedExistingSections,
    sectionSource:sectionNames.length?'user_or_arrangement_supplied':'none_supplied',
    requiresExistingSection:true,
    constraints:['Do not invent or force a new song section.','Do not change or delete manual selections.','Do not move the primary identity out of its dominant role.','Keep intentional simultaneous layering when it is explicitly selected and musically appropriate.','If no matching existing section is supplied, make no placement assumption.'],
    advisoryOnly:true,automaticReassignment:false
   };
  });
  return {level:finalLevel,label:finalLevel==='conflict'?'ÇATIŞMA':finalLevel==='experimental'?'DİKKAT':'UYUMLU',notes:uniqueNotes,alternatives:[...new Set(alternatives)].slice(0,5),characteristics:descriptors,temporalSeparationPlans,canProceed:true,advisoryOnly:true,selectionChanged:false,selectedRoles:built.selectedRoles};
 }
 function build(input={}){
  const layers = ROLES.map(role => normalizeLayer(role, input[role.key]));
  const rawIdentity=input.identity&&typeof input.identity==='object'?copy(input.identity):{};
  const cleanList=value=>Array.isArray(value)?value.map(clean).filter(Boolean):[];
  const identityProfile={
   version:'SONGDNA_MUSIC_IDENTITY_1',
   profileId:clean(rawIdentity.profileId)||layers[0].id||null,
   name:clean(rawIdentity.name)||layers[0].name||layers[0].id||null,
   primaryGenre:clean(rawIdentity.primaryGenre)||layers[0].family||null,
   domain:clean(rawIdentity.domain)||'unclassified',
   region:clean(rawIdentity.region)||null,
   language:clean(rawIdentity.language)||null,
   definingTraits:cleanList(rawIdentity.definingTraits).length?cleanList(rawIdentity.definingTraits):[...layers[0].musicalTraits],
   profileGuidance:clean(rawIdentity.profileGuidance),
   performanceGuidance:clean(rawIdentity.performanceGuidance),
   productionGuidance:clean(rawIdentity.productionGuidance),
   vocalGuidance:clean(rawIdentity.vocalGuidance),
   arrangementGuidance:clean(rawIdentity.arrangementGuidance)||layers[0].arrangementGuidance,
   selectedLayers:layers.filter(x=>x.selected).map(x=>({role:x.role,id:x.id,name:x.name,family:x.family,elements:[...x.elements],musicalTraits:[...x.musicalTraits]})),
   manualSelectionWins:true
  };
  const identityPrompt=[
   'ONE SHARED MUSIC IDENTITY PROFILE — authoritative for all three production layers and both Suno outputs.',
   `Primary identity: ${identityProfile.name||'not selected'}.`,
   `Domain: ${identityProfile.domain}; genre: ${identityProfile.primaryGenre||'catalogue-defined'}.`,
   identityProfile.region?`Cultural/scene region: ${identityProfile.region}.`:'',
   identityProfile.language?`Song language: ${identityProfile.language}; do not infer a different language from genre alone.`:'',
   identityProfile.definingTraits.length?`Defining musical traits: ${identityProfile.definingTraits.join(', ')}.`:'',
   identityProfile.profileGuidance?`Primary profile guidance: ${identityProfile.profileGuidance}`:'',
   identityProfile.performanceGuidance?`Performance technique: ${identityProfile.performanceGuidance}`:'',
   identityProfile.productionGuidance?`Production character: ${identityProfile.productionGuidance}`:'',
   identityProfile.vocalGuidance?`Vocal identity: ${identityProfile.vocalGuidance}`:'',
   identityProfile.arrangementGuidance?`Arrangement: ${identityProfile.arrangementGuidance}`:'',
   'All three layers must serve this same primary identity. Secondary/helper layers may add only their explicitly selected role; they must not redefine the primary genre. Styles and Lyrics must derive from this exact profile. Do not invent undocumented cultural or technical details.'
  ].filter(Boolean).join(' ');
  const main = layers[0];
  const selected = layers.filter(x => x.selected);
  const warnings = [];
  if(!main.selected && selected.length){
   warnings.push({code:'MISSING_MAIN',severity:'warning',message:'Ana Prodüksiyon seçilmeden alt katmanlar tek başına ana kimlik olarak yorumlanmaz.'});
  }
  if(!selected.length){
   warnings.push({code:'NO_SELECTION',severity:'info',message:'Henüz prodüksiyon katmanı seçilmedi; hiçbir katman otomatik eklenmedi.'});
  }
  const identity = main.selected ? (main.name || main.id || 'Kullanıcının ana prodüksiyonu') : null;
  const sharedContext = {
   version:'1.1', primaryIdentity:identity, musicIdentityProfile:identityProfile,
   selectedRoles:selected.map(x=>x.role),
   selectedLayers:selected.map(x=>({role:x.role,id:x.id,name:x.name,family:x.family,elements:[...x.elements]})),
   manualSelectionWins:true,
   autoFilled:false,
   blankLayersRemainBlank:true
  };
  const promptSections = layers.filter(x=>x.selected).map(layer=>{
   const role=ROLES.find(r=>r.key===layer.role);
   // The primary layer's complete profile guidance is already carried once by
   // identityPrompt. Repeating its promptText/arrangement text here used to
   // duplicate long profile, preset and vocal instructions in both Gemini calls.
   // Secondary/helper guidance remains explicit because it is not in identityPrompt.
   const primary = layer.role === 'main';
   const primaryTraits = new Set(identityProfile.definingTraits);
   const elements = primary ? layer.elements.filter(x=>!primaryTraits.has(x)) : layer.elements;
   const content=[role.instruction, layer.name ? `Selected profile: ${layer.name}.` : '',
    layer.family ? `Profile family: ${layer.family}.` : '',
    primary ? '' : layer.promptText,
    elements.length ? `Selected production elements: ${elements.join(', ')}.` : ''
   ].filter(Boolean).join(' ');
   return {role:layer.role,label:layer.label,text:content};
  });
  const sharedPrompt = [
   identityPrompt,
   'THREE-LAYER PRODUCTION CONTEXT:',
   main.selected ? `Primary musical identity: ${identity}. Preserve this identity as the dominant foundation.` : 'No main production identity was selected. Do not invent one.',
   ...promptSections.map(x=>`${x.label}: ${x.text}`),
   'All selected layers share one production context. Resolve overlaps and contradictions through advisory compatibility checks; never silently replace, delete, or rewrite a user selection.',
   'Keep unselected layers empty. Do not auto-fill missing layers.',
   'Styles and Lyrics must use this same final production context while retaining their own output purpose.'
  ].join(' ');
  // Stage 121: translate layer roles separately for sound design and lyric performance.
  // A secondary/helper layer affects Lyrics only when its own selected data explicitly
  // describes vocal, phrasing, delivery, chant or call/response behavior.
  const lyricEvidence=/\b(vocal|voice|singer|singing|lyrics?|phrasing|phrase|delivery|chant|call[- ]and[- ]response|call[- ]response|backing vocal|ad[- ]?lib|vocalist|lead vocal)\b|vokal|seslendirme|söyleyiş|nida|karşılıklı söyleyiş/i;
  const lyricEligible=layer=>layer.role==='main' || lyricEvidence.test([layer.promptText,layer.arrangementGuidance,...layer.musicalTraits,...layer.genreTags].join(' '));
  const outputPlans={
   styles:{includedRoles:selected.map(x=>x.role),primaryRole:main.selected?'main':null,rule:'All selected layers may shape audible sound; secondary/helper remain subordinate to main identity.'},
   lyrics:{includedRoles:selected.filter(lyricEligible).map(x=>x.role),excludedRoles:selected.filter(x=>!lyricEligible(x)).map(x=>x.role),primaryRole:main.selected?'main':null,rule:'Only explicit vocal/performance/phrasing evidence may shape lyric delivery; instrumental-only secondary/helper layers do not rewrite lyrics.'}
  };
  return {
   version:'1.2', layers, selectedRoles:sharedContext.selectedRoles,
   musicIdentityProfile:identityProfile, identityPrompt, sharedContext, promptSections, sharedPrompt,
   stylesContext:sharedPrompt,
   lyricsContext:sharedPrompt,
   outputPlans,
   warnings, canProceed:true
  };
 }
 root.SongDnaThreeLayerProductionOrchestrator={version:'1.2',roles:ROLES,build,analyze};
 if(typeof module!=='undefined'&&module.exports) module.exports=root.SongDnaThreeLayerProductionOrchestrator;
})(typeof globalThis!=='undefined'?globalThis:this);
