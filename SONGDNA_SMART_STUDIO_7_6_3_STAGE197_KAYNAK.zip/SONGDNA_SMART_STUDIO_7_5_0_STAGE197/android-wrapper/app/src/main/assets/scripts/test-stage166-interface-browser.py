#!/usr/bin/env python3
"""Stage 166 mobile UI: accessible switch behavior, language default and drawer layout."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from browser_test_utils import launch_chromium
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def record(name,ok,detail=''):
    checks.append(bool(ok)); print(('PASS' if ok else 'FAIL')+' '+name+(f' — {detail}' if detail else ''))
with sync_playwright() as p:
    browser=launch_chromium(p,headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    context=browser.new_context(viewport={'width':390,'height':844},locale='tr-TR')
    page=context.new_page()
    
    html=(ROOT/'index.html').read_text(encoding='utf-8')
    script_sources=__import__('re').findall(r'<script\b[^>]*src=[\"\']([^\"\']+)[\"\'][^>]*></script>', html, flags=__import__('re').I)
    html=__import__('re').sub(r'<script\b[^>]*src=[\"\'][^>]*></script>', '', html, flags=__import__('re').I)
    shim='<script>(()=>{const data={};Object.defineProperty(window,\"localStorage\",{value:{getItem:k=>data[k]??null,setItem:(k,v)=>data[k]=String(v),removeItem:k=>delete data[k]}})})()</script>'
    html=html.replace('</head>',shim+'</head>')
    html=html.replace('</head>',shim+'</head>')
    page.set_content(html,wait_until='domcontentloaded')
    for src in script_sources:
        page.add_script_tag(content=(ROOT/src).read_text(encoding='utf-8'))
    page.wait_for_timeout(500)
    record('default interface language follows Turkish device locale',page.locator('html').get_attribute('lang')=='tr')
    for selector in ['#traditionalMusicEnabled','#modernMusicEnabled','#pureTraditionalProduction']:
        loc=page.locator(selector)
        record(f'{selector} exposed as accessible switch',loc.get_attribute('role')=='switch')
        style=loc.evaluate('(e)=>({appearance:getComputedStyle(e).appearance,width:getComputedStyle(e).width,height:getComputedStyle(e).height})')
        record(f'{selector} rendered as phone toggle',style['appearance']=='none' and style['width']=='48px' and style['height']=='28px',str(style))
    trad=page.locator('#traditionalMusicEnabled')
    before=trad.is_checked();trad.click(force=True)
    record('traditional switch changes underlying checkbox state',trad.is_checked()!=before)
    page.locator('#menuOpen').click()
    for target in ['generalPanel','appearancePanel','aiPanel','introPanel','vocalPanel','archivePanel','aboutPanel']:
        record(f'{target} menu entry available',page.locator(f'[data-drawer-target="{target}"]').count()==1)
    # The settings sequence is stable and ordered in the actual drawer.
    order=page.locator('[data-drawer-target="generalPanel"], [data-drawer-target="appearancePanel"], [data-drawer-target="aiPanel"], [data-drawer-target="introPanel"], [data-drawer-target="vocalPanel"], [data-drawer-target="archivePanel"], [data-drawer-target="aboutPanel"]').evaluate_all('(es)=>es.map(e=>e.getAttribute("data-drawer-target"))')
    record('settings, themes, AI, intro, vocal, projects and about are ordered',order==['generalPanel','appearancePanel','aiPanel','introPanel','vocalPanel','archivePanel','aboutPanel'],str(order))
    page.locator('#generalPanel').evaluate('(e)=>e.classList.add("active")')
    record('app language selector offers automatic, Turkish and English',page.locator('#appLanguage option').evaluate_all('(es)=>es.map(e=>e.value)')==['auto','tr','en'])
    record('app language selector defaults to automatic',page.locator('#appLanguage').input_value()=='auto')
    record('Turkish labels are preserved',page.get_by_text('Geleneksel müzik',exact=True).count()>=1)
    page.locator('#menuClose').click()  # Close the drawer before testing sticky production tabs.
    record('Stage76 has two production modes plus a direct Lyrics tab',page.locator('.production-mode-tabs [data-production-mode]').count()==2 and page.locator('#lyricsModeTab').count()==1)
    record('Stage76 three top tabs are side by side',page.locator('.production-mode-tabs').evaluate('(e)=>getComputedStyle(e).display')=='grid' and page.locator('.production-mode-tabs').evaluate('(e)=>getComputedStyle(e).gridTemplateColumns.split(" " ).length')==3)
    record('Standard production is selected by default',page.locator('#standardModeTab').get_attribute('aria-pressed')=='true' and page.locator('#dnaPanel').evaluate('(e)=>!e.classList.contains("active")'))
    page.locator('#globalModeTab').click()
    record('Global tab activates existing regional panel and shared generator',page.locator('#dnaPanel').evaluate('(e)=>e.classList.contains("active")') and page.locator('#generatorPanel').evaluate('(e)=>e.classList.contains("active")'))
    # Turkish lead language and English ad-lib source are independent. This block
    # also verifies that additional culture sources reach the phrase bank and ranker.
    page.locator('#language').evaluate("e=>{e.value='0';e.dispatchEvent(new Event('change',{bubbles:true}))}")
    page.locator('#dna').evaluate("e=>{e.value='5';e.dispatchEvent(new Event('change',{bubbles:true}))}")
    page.locator('#adlib').evaluate("e=>{e.value='2';e.dispatchEvent(new Event('change',{bubbles:true}))}")
    page.locator('#energy').evaluate("e=>{e.value='3';e.dispatchEvent(new Event('change',{bubbles:true}))}")
    page.locator('#bpm').evaluate("e=>{e.value='140';e.dispatchEvent(new Event('input',{bubbles:true}))}")
    page.locator('#menuOpen').click(); page.wait_for_timeout(150)
    page.locator('[data-drawer-target="vocalPanel"]').evaluate('(e)=>e.click()')
    page.locator('#adlibCultureSources').evaluate("e=>{for(const o of e.options)o.selected=o.value.startsWith('US Hip-Hop / English');e.dispatchEvent(new Event('change',{bubbles:true}))}")
    pattern_ids=page.locator('#adlibPhraseBank option').evaluate_all('(es)=>es.map(e=>e.value)')
    record('Turkish main language exposes English documented phonetic ad-libs','us-woo-triplet' in pattern_ids and 'us-skrrt-double' in pattern_ids)
    preview=page.locator('#adlibRecommendationPreview').inner_text()
    record('English repeated-vocable recommendation appears for Turkish Trap','Skrrt-skrrt!' in preview or 'Woo, woo, woo!' in preview,preview)
    selected_source=page.locator('#adlibCultureSources').evaluate('(e)=>Array.from(e.selectedOptions).map(o=>o.value)')
    record('main Turkish lyrics remain separate from English ad-lib language',page.locator('#language').input_value()=='0' and any(x.startswith('US Hip-Hop / English') for x in selected_source) and 'Ana şarkı dili değişmez' in page.locator('#adlibCultureSources').locator('xpath=..').inner_text())
    page.locator('#applyAdlibRecommendations').click()
    selected_patterns=page.locator('#adlibPhraseBank').evaluate('(e)=>Array.from(e.selectedOptions).map(x=>x.value)')
    record('applying suggestions selects only the shown catalog patterns',any(x in selected_patterns for x in ['us-woo-triplet','us-skrrt-double']))
    record('manual phrase selection disables automatic recommendation','Manuel ifade seçimin etkin' in page.locator('#adlibRecommendationPreview').inner_text())
    page.locator('#adlibPhraseBank').evaluate("e=>{for(const o of e.options)o.selected=false;e.dispatchEvent(new Event('change',{bubbles:true}))}")
    page.locator('#adlibCultureSources').evaluate("e=>{for(const o of e.options)o.selected=['US Hip-Hop / English','French Rap / France','Deutschrap / German','Spanish Trap / Spanish'].some(prefix=>o.value.startsWith(prefix));e.dispatchEvent(new Event('change',{bubbles:true}))}")
    multilingual_ids=page.locator('#adlibPhraseBank option').evaluate_all('(es)=>es.map(e=>e.value)')
    record('English, French, German and Spanish ad-lib catalogs can coexist with Turkish lyrics',all(x in multilingual_ids for x in ['us-woo-triplet','fr-eh','de-ey','es-eh']) and page.locator('#language').input_value()=='0')
    page.locator('#menuClose').evaluate('(e)=>e.click()')
    page.wait_for_function("!document.body.classList.contains('drawer-open')")
    record('Shared song generation action is present',page.locator('#aiGenerate').count()==1 and 'ŞARKIYI OLUŞTUR' in page.locator('#aiGenerate').inner_text())
    page.locator('#standardModeTab').click()
    record('Standard tab returns to standard-only view',page.locator('#generatorPanel').evaluate('(e)=>e.classList.contains("active")') and page.locator('#dnaPanel').evaluate('(e)=>!e.classList.contains("active")'))
    record('Traditional menu label is consistent','Geleneksel Üretim' in page.locator('[data-open-screen="dnaPanel"]').inner_text())
    page.evaluate("document.body.classList.remove('drawer-open')")
    page.locator('#globalModeTab').click()
    page.locator('[data-screen="resultsPanel"]').click()
    page.locator('[data-screen="generatorPanel"]').click()
    record('Global panel remains available after output-tab navigation',page.locator('#dnaPanel').evaluate('(e)=>e.classList.contains("active")'))
    page.locator('#standardModeTab').click()
    context.close()
    # A separate English-device context verifies the automatic fallback path.
    en_context=browser.new_context(viewport={'width':390,'height':844},locale='en-US')
    en_page=en_context.new_page()
    en_html=(ROOT/'index.html').read_text(encoding='utf-8')
    en_sources=__import__('re').findall(r'<script\b[^>]*src=[\"\']([^\"\']+)[\"\'][^>]*></script>', en_html, flags=__import__('re').I)
    en_html=__import__('re').sub(r'<script\b[^>]*src=[\"\'][^>]*></script>', '', en_html, flags=__import__('re').I)
    en_html=en_html.replace('</head>',shim+'</head>')
    en_page.set_content(en_html,wait_until='domcontentloaded')
    for src in en_sources:
        en_page.add_script_tag(content=(ROOT/src).read_text(encoding='utf-8'))
    en_page.wait_for_timeout(300)
    record('automatic mode follows English device locale',en_page.locator('html').get_attribute('lang')=='en')
    record('English labels are translated',en_page.get_by_text('Traditional Music',exact=True).count()>=1)
    en_context.close()
    # Isolated mocked Gemini flow verifies the non-destructive meaning audit end to end.
    audit_context=browser.new_context(viewport={'width':390,'height':844},locale='tr-TR')
    audit_page=audit_context.new_page()
    audit_errors=[]
    audit_page.on('pageerror',lambda e:audit_errors.append(str(e)))
    audit_html=(ROOT/'index.html').read_text(encoding='utf-8')
    audit_re=__import__('re')
    audit_sources=audit_re.findall(r'<script\b[^>]*src=[\"\']([^\"\']+)[\"\'][^>]*></script>',audit_html,flags=audit_re.I)
    audit_html=audit_re.sub(r'<script\b[^>]*src=[\"\'][^\"\']+[\"\'][^>]*></script>','',audit_html,flags=audit_re.I)
    audit_shim='''<script>(()=>{const storage={};Object.defineProperty(window,"localStorage",{value:{getItem:k=>storage[k]??null,setItem:(k,v)=>storage[k]=String(v),removeItem:k=>delete storage[k]}});window.mockFetchLog=[];window.confirmCalled=false;window.confirm=()=>{window.confirmCalled=true;return true};window.fetch=async(url,options)=>{const path=new URL(url,'https://mock.local').pathname;window.mockFetchLog.push(path);const body=JSON.parse(options?.body||'{}');let data={model:'mock-gemini',usage:{}};if(path==='/health')data={status:'ok'};else if(path==='/api/lyrics')data.lyrics='[Verse 1]\\nGeceye seslendim, sesin dönmedi\\n[Chorus]\\nDönmeni değil, gerçeği istedim';else if(path==='/api/style')data.style='Turkish melodic trap, warm piano motif, deep 808 bass, crisp hi-hats, intimate male lead vocal, 140 BPM';else if(path==='/api/lyrics-audit'&&String(body.prompt||'').includes('FOCUSED LYRIC CORRECTION'))data.audit=JSON.stringify({replacement:'Karanlığa seslendim',rationale:'Bağlamı koruyan daha doğal bir ifade'});else if(path==='/api/lyrics-audit')data.audit=JSON.stringify({overall:'review',summary:'Bir ifade bağlam açısından incelenmeli.',issues:[{severity:'medium',category:'meaning',section:'Verse 1',line_number:2,exact_quote:'Geceye seslendim',reason:'Anlatımın bağlamla uyumu kullanıcı tarafından kontrol edilmeli.',confidence:'medium'}]});else return {ok:false,status:404,json:async()=>({error:'mock route not found'})};return {ok:true,status:200,json:async()=>data}}})()</script>'''
    audit_html=audit_html.replace('</head>',audit_shim+'</head>')
    audit_page.set_content(audit_html,wait_until='domcontentloaded')
    for src in audit_sources:
        audit_page.add_script_tag(content=(ROOT/src).read_text(encoding='utf-8'))
    audit_page.wait_for_timeout(350)
    audit_page.locator('#apiBase').evaluate("e=>{e.value='https://mock.local';e.dispatchEvent(new Event('change',{bubbles:true}))}")
    audit_page.locator('#appToken').evaluate("e=>{e.value='test-token';e.dispatchEvent(new Event('change',{bubbles:true}))}")
    audit_page.locator('#aiGenerate').click(timeout=5000)
    try:
        audit_page.wait_for_function("window.mockFetchLog.includes('/api/lyrics-audit') && document.querySelector('#lyricsCoherenceResults')?.innerText.includes('Bir ifade bağlam açısından incelenmeli.')",timeout=20000)
    except Exception:
        print('AUDIT DEBUG status:',audit_page.locator('#aiStatus').inner_text())
        print('AUDIT DEBUG fetches:',audit_page.evaluate('window.mockFetchLog'))
        print('AUDIT DEBUG errors:',audit_errors)
        raise
    record('generated lyrics automatically receive a Gemini coherence audit',audit_page.evaluate("window.mockFetchLog.filter(x=>x==='/api/lyrics-audit').length")==1)
    record('audit pinpoints the exact phrase and section','Geceye seslendim' in audit_page.locator('#lyricsCoherenceResults').inner_text() and 'Verse 1' in audit_page.locator('#lyricsCoherenceResults').inner_text())
    before_correction=audit_page.locator('#lyricsResult').input_value()
    audit_page.locator('#lyricsCoherenceResults button').filter(has_text='Yalnızca bu ifadeyi Gemini').click(timeout=5000)
    audit_page.wait_for_function("document.querySelector('#lyricsCoherenceResults')?.innerText.includes('Öneri: Karanlığa seslendim')",timeout=15000)
    record('Gemini correction requires explicit user confirmation',audit_page.evaluate('window.confirmCalled'))
    record('Gemini suggestion does not overwrite lyrics automatically',audit_page.locator('#lyricsResult').input_value()==before_correction)
    audit_page.locator('#lyricsCoherenceResults button').filter(has_text='Bu ifadeyi uygula').click(timeout=5000)
    corrected=audit_page.locator('#lyricsResult').input_value()
    expected_corrected='[Verse 1]\nKaranlığa seslendim, sesin dönmedi\n[Chorus]\nDönmeni değil, gerçeği istedim'
    record('approved correction changes only the flagged phrase',corrected==expected_corrected,repr(corrected))
    record('changed lyrics invalidate the previous audit report','Şarkı sözleri değişti.' in audit_page.locator('#lyricsCoherenceResults').inner_text())
    record('mocked Gemini audit flow has no browser runtime errors',not audit_errors,str(audit_errors))
    audit_context.close();browser.close()
print(f'\nSTAGE 166 + 7.0 COHERENCE AUDIT RESULT: {sum(checks)}/{len(checks)} passed')
if not all(checks): raise SystemExit(1)
