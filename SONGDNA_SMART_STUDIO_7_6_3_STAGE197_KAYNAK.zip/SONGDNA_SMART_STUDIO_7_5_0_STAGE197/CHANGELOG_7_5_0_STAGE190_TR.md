# SONGDNA SMART STUDIO 7.5.0 — Stage190 Değişiklik Kaydı

## Amaç
Mevcut üretim sistemini ve katalogları koruyarak otomatik hikâye tekrarını azaltmak, isteğe bağlı hikâye harmanlamasını üretim türüne duyarlı hale getirmek ve yaratıcı arayüzde nadir kullanılan ayrıntıları sadeleştirmek.

## Değişiklikler
- Otomatik konu seçimi, son kullanılan aynı başlıkları dışladıktan sonra `SongDnaStoryDiversityEngine.choose()` üzerinden sahne ailesi çeşitliliğini de kullanır.
- Sahne hafızası; iş/mesai, ulaşım, ev, aşk, aile, anı, yolculuk, arkadaşlık, gizem, mücadele, pazar/esnaf, doğa/hava, deniz/kıyı, eğitim, kutlama, topluluk, zanaat/üretim, kayıp/yas, keşif/değişim, gece şehri, çocukluk, sosyal adalet, fantastik/rüya, yemek/sofra ve performans/sahne ailelerini tanıyacak şekilde genişletildi.
- Hikâye harmanlama isteği artık üretim alanını, seçili Music DNA'yı, stil bilgisini ve füzyon bilgisini taşır.
- Backend bu alanları sınırlandırarak doğrular ve geleneksel/modern/füzyon kimliğini koruyan ayrı harmanlama talimatı uygular.
- Manuel harmanlama çıktısı otomatik çeşitlilik hafızasına yazılmaz; böylece isteğe bağlı işlem otomatik döngüyü etkilemez.
- Harmanlama düğmesi “Seçimi Harmanla” olarak adlandırıldı.
- Nadir kullanılan yaratıcı ayrıntılar ve gelişmiş komut alanı arayüzde gruplandı; mevcut alan kimlikleri ve işlevleri korundu.
- Root, web ve Android WebView HTML/JS kaynakları eşitlendi.
- Render health kimliği Stage190 olarak güncellendi; normal Lyrics/Styles/Command endpoint'leri korunmuştur.
- GitHub Actions iş akışı Stage190 kimliğine taşındı ve JavaScript regresyon testlerini dinamik olarak çalıştıracak hale getirildi.

## Kapsam dışı / korunmuş
- Music DNA, Intro DNA, tema ve konu kataloglarının içeriği değiştirilmedi.
- Styles/Lyrics üretim akışı, otomatik Music DNA sırası ve manuel seçim önceliği korunmuştur.
- Harmanlama bağımsız endpoint ve kullanıcı tetiklemeli işlem olarak kalır.
