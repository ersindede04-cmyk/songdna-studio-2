# Stage 192 — İkinci Gemini anahtarı ve AI Configuration görünürlüğü

- Ana üretim motoru `GEMINI_API_KEY` ile korunmuştur.
- Bağımsız hikâye harmanlama motoru yalnızca `GEMINI_API_KEY_2` kullanır; anahtara geri dönüş yoktur.
- İkinci anahtar eksik olduğunda `/api/story-blend` açık `503 STORY_BLEND_KEY_MISSING` hatası verir.
- AI Configuration bölümüne ikinci Gemini anahtarı için ayrı, maskeli ve salt okunur sunucu-durum alanı eklenmiştir. Gizli anahtar uygulama cihazına aktarılmaz.
- Hikâye harmanlama motoru için bağımsız aç/kapat anahtarı eklenmiştir. Kapalı olması otomatik konu döngüsünü ve ana üretimi etkilemez.
- Render yapılandırmasına `GEMINI_API_KEY_2` ortam değişkeni eklenmiştir.
- Android `versionCode` 42'den 43'e yükseltilmiştir; uygulama sürümü 7.5.0 olarak kalır.
- Yeni çift anahtar ve AI Configuration tarayıcı testleri eklenmiştir.
