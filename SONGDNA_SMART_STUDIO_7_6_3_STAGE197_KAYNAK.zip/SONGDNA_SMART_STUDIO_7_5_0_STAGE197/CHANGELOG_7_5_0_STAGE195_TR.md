# Stage195 — Kararlı tek anahtarlı üretim ve yenilenebilir hikâye anlatımı

- Stage194 arayüzü, tema/konu seçimi, yaratıcı alanlar, Music DNA/Intro DNA ve Styles/Lyrics üretim akışı korundu.
- İkinci Gemini anahtarı (`GEMINI_API_KEY_2`) bağımlılığı kaldırıldı; tüm Gemini işlemleri tek `GEMINI_API_KEY` kullanır. `APP_ACCESS_TOKEN` uygulama erişim doğrulaması için korunur.
- Bağımsız hikâye harmanlama düğmesi, ayarı, ikinci anahtar durumu ve `/api/story-blend` endpoint'i kaldırıldı.
- Mevcut Story DNA çeşitlilik motoru ve otomatik konu yenileme akışı korundu.
- Normal Lyrics üretim talimatları; olayların neden-sonuç ilişkisi, karakter motivasyonları, ilişkilerin davranışlarla gösterilmesi, bölümden bölüme hikâye ilerlemesi ve her üretimde anlatı yaklaşımının yenilenmesi için güçlendirildi.
- Gereksiz çift anahtarlı/harmanlama regresyonları kaldırılıp Stage195 sözleşme testi eklendi.
- Render ayarı: root directory `backend`, build `npm install`, start `npm start`, health `/health`.

Canlı Render, geçerli Google API anahtarı, fiziksel Android ve Suno ses testi bu kaynak paketi içinde doğrulanmış sayılmaz.
