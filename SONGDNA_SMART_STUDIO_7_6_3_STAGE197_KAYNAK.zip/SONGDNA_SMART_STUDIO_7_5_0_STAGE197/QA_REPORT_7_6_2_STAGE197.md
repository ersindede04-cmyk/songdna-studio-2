# QA — SONGDNA SMART STUDIO 7.6.2 / Stage197

- Release identity: 7.6.2; Android versionCode 47.
- Change: regression contract now expects the primary Lyrics endpoint call plus the conditional Turkish-language repair retry.
- Workflow: Gradle forced dependency refresh removed; cached dependencies retained; bounded retries with backoff added to reduce Maven HTTP 429 risk.
- Render deployment commands and archive root path unchanged.
- External GitHub Actions APK build, live Render/Gemini and physical-device tests pending.


7.6.2 additions: five-song love/non-love rotation, human-centered lyrical seed library, reduced technical jargon, and rhythm summary in the Lyrics tab.
