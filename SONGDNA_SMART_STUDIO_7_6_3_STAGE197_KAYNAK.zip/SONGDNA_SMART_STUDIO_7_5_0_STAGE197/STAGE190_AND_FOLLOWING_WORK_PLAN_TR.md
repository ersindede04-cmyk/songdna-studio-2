# SONGDNA SMART STUDIO — Stage 190 ve Sonraki İş Planı

## A. Stage 190 — Arayüz sadeleştirmesi
1. Seyrek kullanılan yaratıcı girişleri ana akıştan çıkarıp tek bir kapalı alt bölümde toplamak.
2. Doğal dille komut aracını gelişmiş/isteğe bağlı araç olarak konumlandırmak.
3. Kullanılan tüm element ID'lerini ve JavaScript bağlantılarını korumak.
4. Root, web ve Android HTML kaynaklarını eşitlemek.
5. Music DNA, modern/geleneksel, füzyon, vokal, ad-lib, Styles/Lyrics ve API işleyişini değiştirmemek.

## B. Sonraki geliştirme — Otomatik hikâye döngüsü
1. Gerçek tema ve hikâye kütüphanesi sayısını kaynak koddan envanterlemek.
2. Mevcut `story-diversity-engine` ve tema/hikâye seçim kodunu incelemek.
3. Tekrarların neden oluştuğunu belirlemek: seçim havuzu, geçmiş kapsamı, aile sınıflandırması ve başarı sonrası kayıt.
4. Tema ailesi, somut hikâye noktası, olay/çatışma ve anlatım kalıbı için ayrı tekrar belleği tasarlamak.
5. Üretim başarılı olduğunda geçmişi ilerletmek; başarısız üretimde döngüyü ilerletmemek.
6. Modern, geleneksel ve füzyon profillerinin kendi uygun hikâye/anlatım kaynaklarına bağlı kalmasını sağlamak.

## C. Sonraki geliştirme — Bağımsız “Seçimi Harmanla” motoru
1. Kullanıcının butonuyla isteğe bağlı çalışmak; otomatik üretim döngüsüne müdahale etmemek.
2. Tek veri kaynağı olarak mevcut SONGDNA tema/hikâye/duygu kütüphanelerini kullanmak.
3. Modern, geleneksel veya füzyon üretim profiline göre doğru kütüphane ve anlatım kaynaklarını seçmek.
4. Kaynak bileşenlerin duygu, olay, karakter, çatışma, atmosfer ve anlatım rollerini çözümlemek.
5. Kaynakları mekanik biçimde eklemek yerine yeni anlam ve neden-sonuç ilişkileriyle özgün hikâye üretmek.
6. Türkçe anlam, dil, giriş-gelişme-dönüm noktası-sonuç, duygu tutarlılığı, özgünlük ve şarkı sözüne dönüştürülebilirlik denetimleri uygulamak.
7. Kalite eşiğini geçmeyen sonucu yeniden yazmak veya kullanıcıya başarısızlık bildirmek; anlamsız sonucu Lyrics'e aktarmamak.
8. Modern sözlerde uygun ad-lib/performance yönlendirmelerini, geleneksel sözlerde ilgili halk anlatımı ve vokal tavrını kullanmak.
9. Styles/Lyrics uyumunu ve ana Music DNA kimliğini korumak.
10. Kaydedilmeyen hikâyeyi geçici tutmak; kullanıcının kaydettiğini kişisel arşive almak. Geçici hikâyeleri ana kütüphaneye yazmamak.

## D. Doğrulama kapıları
1. Kaynak düzeyi birim ve regresyon testleri.
2. Tema/hikâye tekrar senaryoları ve çoklu üretim testi.
3. Modern, geleneksel ve füzyon profilleri için harmanlama örnekleri.
4. Türkçe hikâye tutarlılığı ve şarkı sözü dönüşüm testleri.
5. Render + gerçek Gemini uçtan uca testi.
6. Android gerçek cihaz testi.

## Değişmez koruma ilkeleri
- Mevcut kütüphaneler silinmeyecek veya baştan yazılmayacak.
- Ana üretim, Music DNA, Styles/Lyrics ve mevcut prodüksiyon motorları harmanlamadan bağımsız kalacak.
- Harmanlama hatası ana üretimi durdurmayacak.
- Paketleme/dağıtım, Stage190 değişiklik listesi ve test sonuçları kullanıcıya sunulduktan sonra açık onayla yapılacak.
