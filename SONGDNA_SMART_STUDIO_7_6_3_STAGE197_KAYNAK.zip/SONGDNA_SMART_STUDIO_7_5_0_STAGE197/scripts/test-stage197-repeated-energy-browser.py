"""Regression: the same Melodic Trap energy choice must work on consecutive songs."""
import json
import re
from pathlib import Path
from playwright.sync_api import sync_playwright
from browser_test_utils import launch_chromium

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "index.html").read_text(encoding="utf-8")
sources = re.findall(r'<script\b[^>]*src=["\']([^"\']+)["\'][^>]*></script>', html, re.I)
html = re.sub(r'<script\b[^>]*src=["\'][^"\']+["\'][^>]*></script>', '', html, flags=re.I)
shim = '''<script>(()=>{const d={songdna_api_base:"https://mock.invalid",songdna_app_token:"stage197-test-token-12345"};Object.defineProperty(window,"localStorage",{value:{getItem:k=>d[k]??null,setItem:(k,v)=>d[k]=String(v),removeItem:k=>delete d[k]}})})()</script>'''
html = html.replace('</head>', shim + '</head>')

with sync_playwright() as p:
    browser = launch_chromium(p, headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
    page = browser.new_page(viewport={"width": 390, "height": 844}, locale="tr-TR")
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.set_content(html, wait_until='domcontentloaded')
    for src in sources:
        page.add_script_tag(content=(ROOT / src).read_text(encoding='utf-8'))
    page.wait_for_timeout(400)
    calls = {"lyrics": 0, "style": 0, "lyrics-audit": 0}

    def handler(route):
        request = route.request
        if request.method != 'POST':
            route.continue_()
            return
        endpoint = request.url.rsplit('/', 1)[-1]
        calls[endpoint] = calls.get(endpoint, 0) + 1
        if endpoint == 'lyrics':
            route.fulfill(status=200, content_type='application/json', body=json.dumps({
                "lyrics": "TITLE: Yolun Sonu\n[Verse 1 – Male Lead Vocal]\nBir gün yola çıktım, eski sokaklardan\n[Chorus – Male Lead Vocal]\nYolum sana döner, kalbim aynı yerde"
            }))
        elif endpoint == 'style':
            route.fulfill(status=200, content_type='application/json', body=json.dumps({
                "style": "Turkish melodic trap, warm 808, intimate male melodic rap, emotional hook, clear vocal space"
            }))
        elif endpoint == 'lyrics-audit':
            route.fulfill(status=200, content_type='application/json', body=json.dumps({"result": "ok", "audit": {"status": "pass"}}))
        else:
            route.fulfill(status=200, content_type='application/json', body='{}')

    page.route('https://mock.invalid/**', handler)
    page.locator('#dna').select_option('5')  # 06 · Melodic Trap
    page.locator('#energy').select_option('1')  # Melodik ve duygusal
    page.wait_for_timeout(250)

    for run in range(2):
        if run:
            page.locator('#standardModeTab').click()
        page.locator('#aiGenerate').click()
        page.wait_for_function("document.querySelector('#aiGenerate').disabled === false", timeout=20000)
        page.wait_for_timeout(250)
        status = page.locator('#aiStatus').inner_text()
        assert 'hazır' in status.lower(), f"Run {run + 1} failed: {status}"
        assert page.locator('#energy').input_value() == '1', 'The selected energy value must remain unchanged'

    assert calls['lyrics'] == 2, f"Expected two Lyrics requests, got {calls}"
    assert calls['style'] == 2, f"Expected two Styles requests, got {calls}"
    assert not errors, f"Browser runtime errors: {errors}"
    print('PASS: Melodic Trap + Melodik ve duygusal energy generated twice consecutively; 2 Lyrics, 2 Styles, no browser errors.')
    browser.close()
