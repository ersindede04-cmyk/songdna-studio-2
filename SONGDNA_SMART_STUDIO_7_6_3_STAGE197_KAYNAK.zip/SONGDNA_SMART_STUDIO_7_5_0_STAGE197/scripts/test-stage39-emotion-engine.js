const fs=require('fs');
const vm=require('vm');
const source=fs.readFileSync('emotion-engine.js','utf8');
const sandbox={globalThis:{}};
vm.runInNewContext(source,sandbox);
const engine=sandbox.globalThis.SongDnaEmotionEngine;
const types=['melancholy','anger','love','hope','longing','confidence','joy','anxiety','grief','triumph'];
let count=0;
for(const type of types){
  const levels=[];
  for(let intensity=1;intensity<=4;intensity++){
    const result=engine.build(type,intensity,'');
    if(result.type!==type||result.intensity!==intensity||!result.promptText||Object.keys(result.dimensions).length!==7||Object.prototype.hasOwnProperty.call(result.dimensions,'energy'))throw new Error(`${type}/${intensity} invalid`);
    for(const value of Object.values(result.dimensions))if(value< -100||value>100)throw new Error(`${type}/${intensity} signed priority out of range`);
    levels.push(result);count++;
  }
  if(!(levels[3].intensity>levels[0].intensity))throw new Error(`${type} intensity ordering failed`);
}
if(engine.build('auto',3).type!=='auto')throw new Error('auto inference mode failed');
const app=fs.readFileSync('app.js','utf8');
if(!app.includes('baseContext.emotionProfile')||!app.includes('SongDnaProductionAdaptationEngine'))throw new Error('production adaptation integration missing');
const html=fs.readFileSync('index.html','utf8');
if(!html.includes('id="emotionType"')||!html.includes('id="emotionIntensity"')||!html.includes('emotion-engine.js'))throw new Error('UI wiring missing');
console.log(`Stage 39 Emotion Engine PASS: ${count} type/intensity combinations, auto mode, UI wiring and manual mixer override guard.`);
