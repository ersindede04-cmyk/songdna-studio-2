# SONGDNA Studio 4.5.0 – Değişiklikler

- 4.4.0 tabanı korunarak 4.5.0 sürümüne yükseltildi.
- Mevcut 1–40 Music DNA seçimleri korundu; 26 araştırma profili MDNA-041–MDNA-066 olarak eklendi.
- Önceki araştırma paketlerindeki 031–040 kimlik çakışmaları, mevcut katalog profillerini korumak için güvenli biçimde yeniden numaralandırıldı.
- Enstrüman, rap flow, vokal icra ve prodüksiyon teknikleri tek seçilebilir teknik modül alanında toplandı.
- Ayrı ritim, vokal ve intro modül kütüphaneleri veri kataloğunda korundu.
- Gemini yalnızca Styles/Lyrics metni hazırlar; ses üretimini Suno yapar.
- İki çıktı alanı, kullanıcı seçimlerinin önceliği, şarkı dili bağımsızlığı, intro kuralları ve Hakkında telif satırı korundu.
