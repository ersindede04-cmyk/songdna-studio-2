/* SONGDNA Scene Jargon Library v1.0
 * Optional, user-selected lexical guidance. Not an ad-lib list and never auto-injected.
 * Scene terms are contextual, time-sensitive and not a substitute for native-speaker review.
 */
(function(root){
 'use strict';
 const scenes={
  france:{label:'French Rap / Français urbain',status:'researched-curated-not-native-validated',note:'Fransız rap söz varlığı tek tip değildir. Verlan, gündelik konuşma, göçmen dilleriyle temas ve yerel mahalle kullanımları bölgeye ve kuşağa göre değişir. Terimleri yalnızca kullanıcı seçerse, doğal cümle içinde ve ana Fransızca akışı bozmadan kullan.',sources:['https://sites.uclouvain.be/bkl-cbl/wp-content/uploads/2017/06/verbeke2017.pdf','https://iris.unimo.it/handle/11380/1069066','https://escholarship.org/uc/item/1fp698jw'],items:[
   ['fr-meuf','meuf','femme','Verlan; gündelik/argo hitap','Söz içinde; doğal konuşma bağlamında','Her Fransızca konuşura veya her döneme aitmiş gibi sunma'],
   ['fr-chelou','chelou','louche / bizarre','Verlan; gündelik değerlendirme','Anlatı veya punchline içinde','Aşırı sık kullanma; bağlam dışı komikleşebilir'],
   ['fr-ouf','ouf','fou / incroyable','Verlan; şaşkınlık veya yoğunluk','Tepki ya da punchline sonrası','Bir vokal ünlemi değil; cümle içinde kullan'],
   ['fr-tess','tess','cité / quartier','Verlan; belirli şehir/mahalle söylemi','Mahalle/yer anlatısı','Bütün banliyöleri tekleştirme; bölgesel ve kimlik yüklü'],
   ['fr-tieks','tieks','quartier','Verlan; mahalle/çevre','Yer/aidiyet anlatısı','Her bağlamda tess ile birebir eş anlamlı varsayma'],
   ['fr-scred','en scred','discrètement / gizlice','Argo ifade','Gizlilik veya arka planda yapılan eylem','Konuşma dili; yazım ve kullanım değişebilir'],
   ['fr-wesh','wesh','selam / dikkat çekme / tepki','Fransız gençlik dili; kökeni Arapça selamlaşma ifadesiyle ilişkilidir','Diyalog açılışı veya karakter sesi','Her satıra ekleme; karikatürleştirme'],
   ['fr-igo','igo','pote / ami (arkadaş)','Bazı Fransız rap sözlüklerinde görülen hitap','Doğrudan hitap','Bölgesel; evrensel Fransızca gibi kullanma']
  ]},
  germany:{label:'Deutschrap / Almanca gençlik ve rap dili',status:'researched-curated-not-native-validated',note:'Deutschrap jargonunda İngilizce ödünçlemeler, Türkçe/Arapça/Slav dilleriyle temas ve yerel gençlik dili bulunur. Hitaplar ve dini kökenli ifadeler saf ad-lib değildir; yalnızca uygun karakter ve cümle bağlamında seç.',sources:['https://beckassets.blob.core.windows.net/product/readingsample/15976690/9783959351829_readingsample_1.pdf','https://ids-pub.bsz-bw.de/frontdoor/deliver/index/docId/10921/file/Cotgrove_The_importance_of_linguistic_markers_2018.pdf','https://www.tagesschau.de/wissen/forschung/sprache-jugendwort-veraenderungen-100.html'],items:[
   ['de-digga','Digga / Dicker','samimi arkadaş hitabı','Hamburg hip-hop ve Almanca gençlik diliyle ilişkili','Doğrudan hitap; konuşma arası','Bölge/kuşak değişir; her dizeye koyma'],
   ['de-brudi','Brudi','kardeş / yakın arkadaş','Almanca rapte topluluk/aidiyet hitabı','Crew veya arkadaş hitabı','Bir ad-lib sesi değil; söz içinde kullan'],
   ['de-bratan','Bratan','kanka / kardeş','Slav/Rus etkili Almanca gençlik/rap dili','Doğrudan hitap','Kültürel kökeni ve karakter bağlamını gözet'],
   ['de-akhi','Akhi / Akh','kardeş / yakın hitap','Arapça kökenli, Almanca şehir dili/rapte görülebilir','Yalnızca karakterin dil repertuvarı uygunsa','Dini/kimlik bağlamı taşıyabilir; rastgele ekleme'],
   ['de-alter','Alter','şaşkınlık veya arkadaş hitabı','Gündelik Almanca gençlik dili','Tepki veya hitap','Gündelik; rap sahnesine özel değil'],
   ['de-krass','krass','çok etkileyici / aşırı / sert','Gündelik Almanca değerlendirme','Vurgu cümlesi','Anlamı bağlama göre olumlu/olumsuz olabilir'],
   ['de-stabil','stabil','sağlam / iyi / güvenilir','Gençlik dili ve rap bağlamında övgü','Kısa değerlendirme','Aşırı tekrar etme; doğal cümlede kullan'],
   ['de-amstart','am Start sein','hazır / mevcut / sahnede','Almanca hip-hop jargonunda yerleşik ifade','Kendini/ekibini tanıtma','Sadece İngilizce “start” diye çevirmeden Almanca sözdiziminde kullan']
  ]},
  uk:{label:'UK Drill / Grime / MLE',status:'researched-curated-not-native-validated',note:'MLE tek bir etnik grubun veya bütün Birleşik Krallık gençlerinin dili değildir. Jamaican Patois, Cockney, Arapça, Afrika dilleri ve yerel Londra kullanımının etkileri vardır. Drill, grime ve şehirler arasında terimlerin anlamı/değeri değişebilir.',sources:['https://onlinelibrary.wiley.com/doi/full/10.1111/josl.12653','https://www.theguardian.com/music/2024/apr/09/bait-ting-certi-how-uk-rap-changed-the-language-of-the-nation','https://www.sciencedirect.com/science/article/pii/S0271530917301325'],items:[
   ['uk-bruv','bruv','brother / mate','Cockney ve geniş UK gündelik hitabı','Doğrudan hitap','Londra dışına otomatik genelleme yapma'],
   ['uk-fam','fam','yakın arkadaş / kendi çevresi','MLE hitap terimi','Crew veya arkadaş hitabı','Her cümlede kullanılmaz; samimiyet tonu gerekir'],
   ['uk-mandem','mandem','erkek arkadaş grubu / ekip','MLE; Jamaican Patois etkili çoğul grup hitabı','Ekip/kalabalık referansı','Gruptan söz ederken; tek kişiye hitap etme'],
   ['uk-ting','ting','thing; bağlama göre kişi/olay','MLE yazım ve telaffuz özelliği','Kısa konuşma ifadesi','Çok anlamlı; otomatik romantik anlam yükleme'],
   ['uk-ends','ends','mahalle / kişinin çevresi','MLE yer/aidiyet terimi','Yer/mahalle anlatısı','Belirli sosyal coğrafya; bağlam dışı kullanma'],
   ['uk-gassed','gassed','heyecanlı / coşmuş','MLE/UK gençlik dili','Tepki veya öz değerlendirme','Anlam ve yaygınlık kuşağa göre değişebilir'],
   ['uk-peak','peak','kötü/şanssız durum; talihsizlik','MLE/UK gençlik dili','Olumsuz punchline veya anlatı','Standart İngilizcedeki “zirve” anlamıyla karıştırma'],
   ['uk-peng','peng','çekici / çok iyi','MLE/UK gençlik dili; köken ve yayılım çok katmanlı','Övgü cümlesi','Nesne/kişi için kullanımı bağlama duyarlı'],
   ['uk-bare','bare','çok / bol miktarda','MLE nicelik belirteci','Ölçü/yoğunluk anlatısı','Standart İngilizce anlamından farklı kullanımı olabilir'],
   ['uk-safe','safe','tamam / teşekkür / selamlaşma-kapanış','UK gündelik/MLE kullanımında çok işlevli','Kısa onay veya vedalaşma','Ton ve bağlama göre işlevi değişir']
  ]},
  us:{label:'US Hip-Hop / Trap / regional rap',status:'researched-curated-not-native-validated',note:'ABD hip-hop dili tek bir lehçe değildir. AAVE kökenli veya belirli şehirlerde gelişmiş terimleri tüm ABD’ye ve tüm konuşurlara mal etme. Bölgesel terimleri yalnızca seçilen sahneye ve karaktere uyduğunda kullan.',sources:['https://mtosmt.org/issues/mto.22.28.2/mto.22.28.2.wallmark.php','https://www.dictionary.com/culture/slang/no-cap','https://www.dictionary.com/culture/slang/bet','https://www.dictionary.com/culture/slang/deadass','https://www.britishcouncil.org/sites/default/files/wed_ebook_final_web_artwork.pdf'],items:[
   ['us-nocap','no cap','abartısız / gerçekten / yalan yok','ABD gençlik dili; Black slang ve hip-hop yayılımıyla ilişkili','Cümle sonu vurgu','Her barın sonuna koyma; dönemsel ve kimlik yüklü'],
   ['us-cap','cap','yalan / abartı','ABD gençlik ve hip-hop dili','İtiraz veya punchline','“No cap” ile anlam ilişkisini koru'],
   ['us-bet','bet','tamam / anlaştık / kesin','ABD gündelik ve hip-hop dili','Tek kelimelik cevap','Tonuna göre onay veya kuşku ifade edebilir'],
   ['us-deadass','deadass','cidden / gerçekten','Özellikle New York Black/Latino konuşma çevreleriyle ilişkili','Cümle vurgusu veya şaşkın soru','NYC kökenini tüm ABD’ye mal etme; çok tekrarlama'],
   ['us-drip','drip','stil / giyim havası','ABD hip-hop ve popüler gençlik dili','Stil/özgüven anlatısı','Dönemsel ve bağlama bağlı'],
   ['us-flex','flex','gösteriş yapmak / sergilemek','Hip-hop ve genel İngilizce kullanımı','Kendini/başarıyı anlatma','Her zaman olumlu değildir; gösteriş anlamı taşır'],
   ['us-sayless','say less','anladım / tamam, daha fazla açıklama gerekmez','Çağdaş ABD konuşma dili','Kısa cevap veya geçiş','Klişe kullanım riskine dikkat'],
   ['us-forreal','for real','gerçekten / cidden','ABD gündelik konuşma ve rap','Vurgu veya onay','“No cap” ile aynı tam işlevde değildir']
  ]},
  turkey:{label:'Türkçe Rap / Türkiye',status:'researched-curated-not-native-validated',note:'Türkçe rapte argo, hitap, kelime yankısı, ünlem ve sanatçıya özgü imza ad-lib birbirinden ayrılmalıdır. Aşağıdaki genel Türkçe örnekler sanatçı imzası değildir; yerel ağız veya belirli rapçi taklidi üretmek için kullanılmaz.',sources:['https://ide.asbu.edu.tr/sites/fakulte_bolumler/ydf/ide.asbu.edu.tr/files/2020-06/An%20Analysis%20of%20Turkish%20Slang%20Words%20Used%20in%20Ceza%27s%20Rap%20Music.pdf','https://dergipark.org.tr/tr/pub/akaded/article/1575500','https://www.rapertuar.com/nedir/ad-lib-nedir-rap-muzikte-ad-libler-ne-anlama-geliyor/'],items:[
   ['tr-kanka','kanka','yakın arkadaş hitabı','Gündelik Türkçe gençlik dili','Doğrudan hitap veya ekip sözü','Her vokal boşluğuna ekleme'],
   ['tr-abi','abi','saygı/samimiyet hitabı','Gündelik Türkçe; sosyal ilişkiye göre değişir','Hitap','Yaş/statü ilişkisini gözet'],
   ['tr-aynen','aynen','onay / katılma','Gündelik konuşma','Cevap veya kısa vurgu','Konuşma dili; seçici kullan'],
   ['tr-harbi','harbi','gerçekten / sahiden','Gündelik argo','Vurgu cümlesi','Ton ve bölgeye göre değişir'],
   ['tr-vay','vay','şaşkınlık / hayranlık','Türkçe ünlem','Punchline veya melodik tepki','Sesli ad-lib olarak seçilirse uzatılabilir'],
   ['tr-of','of','bıkkınlık / yoğun duygu','Türkçe ünlem','Melodik cümle sonu','Duyguya uygun tonda kullan'],
   ['tr-ey','ey','çağrı / vurgu','Türkçe ünlem; şiirsel ve rap bağlamı','Bar başı veya cevap','Hitap/ünlem işlevini koru'],
   ['tr-echo','kelime yankısı','ana kelimeyi tekrar ederek vurgulama','Rap vokal prodüksiyon tekniği','Bar sonu veya boşluk','Yalnızca kullanıcının sözünden kelime seç; yeni anlam ekleme']
  ]}
 };
 const get=scene=>{const s=scenes[scene];return s?s.items.map(x=>({id:x[0],term:x[1],meaning:x[2],register:x[3],usage:x[4],caution:x[5]})):[];};
 const note=scene=>scenes[scene]?.note||'Bu sahne için araştırılmış jargon listesi yok. Yerel ifade uydurma; kullanıcı tarafından sağlanan ifadeleri kullan.';
 const sources=scene=>scenes[scene]?.sources||[];
 root.SongDnaSceneJargonCatalog={scenes:Object.keys(scenes).map(id=>({id,label:scenes[id].label,status:scenes[id].status})),get,note,sources,version:'1.0'};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaSceneJargonCatalog;
})(typeof globalThis!=='undefined'?globalThis:this);
