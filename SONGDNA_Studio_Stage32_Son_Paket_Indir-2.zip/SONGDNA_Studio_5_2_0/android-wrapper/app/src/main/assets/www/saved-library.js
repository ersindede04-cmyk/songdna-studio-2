/* SONGDNA Saved Lyrics Library core. Backward-compatible with songdna_saved records. */
(function(root){
  let sequence=0;
  const makeId=()=>`sd-${Date.now().toString(36)}-${(++sequence).toString(36)}-${Math.random().toString(36).slice(2,8)}`;
  function normalize(records){
    if(!Array.isArray(records)) return [];
    return records.filter(x=>x&&typeof x==='object'&&!Array.isArray(x)).map(x=>({
      ...x,
      id: typeof x.id==='string'&&x.id ? x.id : makeId(),
      title: String(x.title||'İsimsiz kayıt'),
      lyrics: String(x.lyrics||''),
      style: String(x.style||x.sty||''),
      sty: String(x.sty||x.style||''),
      favorite: x.favorite===true
    }));
  }
  function filter(records,query='',mode='all'){
    const q=String(query||'').trim().toLocaleLowerCase('tr');
    return records.filter(x=>(mode!=='favorites'||x.favorite===true)&&(!q||[x.title,x.dna,x.created,x.lyrics,x.style].some(v=>String(v||'').toLocaleLowerCase('tr').includes(q))));
  }
  function toggleFavorite(records,id){return records.map(x=>x.id===id?{...x,favorite:!x.favorite}:x)}
  function rename(records,id,title){const clean=String(title||'').trim();if(!clean) return records;return records.map(x=>x.id===id?{...x,title:clean}:x)}
  function update(records,id,patch){return records.map(x=>x.id===id?{...x,...patch,id:x.id}:x)}
  function remove(records,ids){const set=new Set(ids);return records.filter(x=>!set.has(x.id))}
  function add(records,record){const copy={...record,id:makeId(),favorite:false,title:String(record.title||'İsimsiz kayıt'),lyrics:String(record.lyrics||''),style:String(record.style||record.sty||''),sty:String(record.sty||record.style||'')};return [...records,copy]}
  root.SongDnaSavedLibrary={normalize,filter,toggleFavorite,rename,update,remove,add};
  if(typeof module!=='undefined'&&module.exports) module.exports=root.SongDnaSavedLibrary;
})(typeof globalThis!=='undefined'?globalThis:this);
