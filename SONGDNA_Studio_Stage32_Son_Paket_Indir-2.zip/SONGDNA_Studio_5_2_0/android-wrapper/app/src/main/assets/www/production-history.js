/* SONGDNA Production History: independent from the user-managed saved library. */
(function(root){
  let seq=0;
  const makeId=()=>`ph-${Date.now().toString(36)}-${(++seq).toString(36)}-${Math.random().toString(36).slice(2,7)}`;
  function normalize(items){
    if(!Array.isArray(items))return [];
    return items.filter(x=>x&&typeof x==='object'&&!Array.isArray(x)).map(x=>({...x,id:typeof x.id==='string'&&x.id?x.id:makeId(),title:String(x.title||'İsimsiz üretim'),lyrics:String(x.lyrics||''),style:String(x.style||x.sty||''),sty:String(x.sty||x.style||''),created:String(x.created||''),dna:String(x.dna||'')})).slice(-20);
  }
  function add(items,record){const current=normalize(items);const entry={...record,id:makeId(),title:String(record.title||'İsimsiz üretim'),lyrics:String(record.lyrics||''),style:String(record.style||record.sty||''),sty:String(record.sty||record.style||''),created:String(record.created||new Date().toLocaleString('tr-TR'))};return [...current,entry].slice(-20);}
  function updateLatest(items,record){const current=normalize(items);if(!current.length)return add(current,record);const last=current[current.length-1];current[current.length-1]={...last,...record,id:last.id};return current;}
  function filter(items,query=''){const q=String(query||'').trim().toLocaleLowerCase('tr');return normalize(items).filter(x=>!q||[x.title,x.dna,x.created,x.lyrics,x.style].some(v=>String(v||'').toLocaleLowerCase('tr').includes(q)));}
  function remove(items,ids){const set=new Set(ids);return normalize(items).filter(x=>!set.has(x.id));}
  root.SongDnaProductionHistory={normalize,add,updateLatest,filter,remove};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaProductionHistory;
})(typeof globalThis!=='undefined'?globalThis:this);
