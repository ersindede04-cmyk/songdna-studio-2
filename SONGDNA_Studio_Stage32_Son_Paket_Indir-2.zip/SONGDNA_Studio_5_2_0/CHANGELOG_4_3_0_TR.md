# SONGDNA Studio 4.3.0 — Güncelleme Notları

- Android telefon ekranına göre neon mor / elektrik mavisi mobil arayüz.
- Ana ekran sekmelere ayrıldı: Üretim, Şablon, Müzik DNA, Çıktılar.
- Ana eylem adı “Şarkı Sözü Oluştur” olarak düzeltildi. Uygulama ses üretmez; Suno için STYLES ve LYRICS metinlerini hazırlar.
- STYLES ve LYRICS mobilde alt alta, ayrı kopyalama düğmeleriyle gösterilir.
- Türkiye kataloğuna modern Turkish Rap, Drill, R&B, Afro House, Electronic Pop, Alternative/Indie, Modern Arabesk, Anatolian Rock ve Dance Pop seçenekleri eklendi.
- Türkiye seçimi Bozlak, Kırşehir, Zeybek veya başka bir geleneksel unsuru varsayılan olarak etkinleştirmez. Geleneksel katmanlar isteğe bağlıdır.
- Gemini söz üretim yönergesi; tür/kültür ile şarkı konusunu ayırır, klişe ve tekrarları azaltır, kullanıcının özel talimatını önceliklendirir.
- Global ad-lib ve kısa vokal motif seçenekleri genişletildi.
- Gemini API anahtarı backend .env içinde kalır; uygulama yalnızca sunucu adresi ve uygulama erişim kodunu saklar. Bu, API anahtarını APK veya cihaz depolamasında açıkta bırakmamak için korunmuştur.
- Android WebView asset dosyaları güncellendi.

## Not
Bu paket kaynak kodu ve Android build workflow içerir. APK, GitHub Actions üzerinden mevcut Android projesi kullanılarak oluşturulabilir. Sunucu tarafında mevcut Render servisi ve .env değişkenleri korunmalıdır.
- Tablet ve yatay ekran düzeni tamamlandı: geniş ekranlarda iki sütunlu üretim alanı, daha geniş seçim kartları ve yan yana STYLES / LYRICS sonuç panelleri.
- Telefon düzeni korunarak 760 px altındaki ekranlarda tek sütun ve alt alta çıktı görünümü sürdürüldü; tablet ayar çekmecesi geniş ekran ölçülerine uyarlandı.
- AI / API bağlantı ayarları yalnızca hamburger menüsündeki Ayarlar çekmecesinde bulunur; ana üretim ekranında API alanı gösterilmez.
