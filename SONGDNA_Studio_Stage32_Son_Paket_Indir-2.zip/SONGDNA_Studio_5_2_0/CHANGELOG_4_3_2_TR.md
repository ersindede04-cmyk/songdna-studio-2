# SONGDNA Studio 4.3.2 — Tam Dil Desteği

- Uygulama arayüzü için ortak Türkçe/İngilizce çeviri sözlüğü eklendi.
- Üretim, hazır şablonlar, dünya müziği tasarımı, sonuçlar, menü, Genel Ayarlar, Intro & Yerel Sesler, Vokal DNA, AI/API bağlantısı, Temalar ve Hakkında ekranlarının sabit metinleri çevrilebilir hale getirildi.
- Varsayılan arayüz dili English olarak ayarlandı. Automatic cihaz dilini algılar; Türkçe cihazlarda Türkçe, desteklenmeyen dillerde İngilizce kullanır.
- Elle seçilen Türkçe/English tercihi cihazda saklanır ve uygulama yeniden açıldığında korunur.
- Sonradan oluşturulan arayüz metinleri ve seçenekler de çeviri gözlemcisiyle işlenir.
- Kullanıcının yazdığı şarkı sözleri, konu, özel talimatlar ve üretilen LYRICS/STYLES içerikleri otomatik çevrilmez. Şarkı dili arayüz dilinden bağımsızdır.
- Web ve Android WebView JavaScript dosyaları eşitlendi.
- Sürüm 4.3.2 / Android versionCode 17.

## Test sınırı
JavaScript sözdizimi, proje bütünlüğü, HTML/JS eşitliği ve Android XML statik kontrolleri çalıştırılır. Gerçek Android cihazda dil değiştirme, APK derlemesi ve canlı Gemini/Render testi bu paket oluşturma ortamında doğrulanmış sayılmaz.
