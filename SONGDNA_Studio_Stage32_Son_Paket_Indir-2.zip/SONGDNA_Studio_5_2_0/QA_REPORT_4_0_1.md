# SONGDNA Studio 4.0.1 — Kaynak QA Raporu

## Kaynak doğrulamaları
- Proje kök yapısı ve gerekli dosyalar.
- Web ve Android'e gömülü HTML eşitliği.
- Android XML parse.
- Android applicationId, sürüm, SDK ve JVM hedefleri.
- Backend ve inline JavaScript sözdizimi.
- 18 Music DNA, Intro DNA 14–33 ve PRESERVE kontrolleri.
- Gemini-only provider, ayrı Lyrics/Style uçları ve fallback mantığı.

## 4.0.1 bakım testleri
- STYLE isteği öncesi `build({scroll:false,silent:true})` ile seçim snapshot'ının yenilenmesi.
- STYLE promptunun güncel `last.context` üzerinden kurulması.
- Gemini fetch timeout hatasının retryable 504 olarak sınıflandırılması.
- Timeout sonrası model fallback zincirinin denenmesi.
- Tüm modellerin timeout olması halinde 504 yanıtı.
- AndroidX Core WindowInsets ile sistem çubuğu / display-cutout güvenli alanları.

## Bu paket üzerinde çalıştırılan kontroller
- `python3 scripts/verify-source.py`: tüm kontroller geçti.
- Node.js inline JavaScript ve backend syntax: geçti.
- Android XML parse ve Web/Android HTML eşitliği: geçti.
- Gemini timeout simülasyonu: ilk modelin iki timeout hatasından sonra ikinci model başarılı oldu; `fallbackUsed=true` doğrulandı.
- Tüm modeller timeout simülasyonu: HTTP 504 doğrulandı.

## Bu paket içinde ayrıca doğrulanması gerekenler
- `python3 scripts/verify-source.py`
- Node.js syntax checks
- Android XML parse
- UI asset parity
- Backend mock testleri (API anahtarı olmadan 401/429/503 akışları)
- Gerçek Android APK derlemesi GitHub Actions ortamında yapılmalıdır.

## Henüz cihaz veya canlı sağlayıcı testi değildir
- Fiziksel Android 15 cihazında durum çubuğu, klavye ve ekran yönü.
- Gerçek Gemini API anahtarıyla lyrics ve STYLE üretimi.
- Render/hosting HTTPS dağıtımı ve gerçek model fallback.
