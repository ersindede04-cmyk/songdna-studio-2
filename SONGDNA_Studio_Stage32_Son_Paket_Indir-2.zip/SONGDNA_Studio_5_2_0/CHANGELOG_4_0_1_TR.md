# SONGDNA Studio 4.0.1 — Geliştirici Paketi

## Korunan ürün özellikleri
- 18 Music DNA paketi.
- Intro DNA kataloğu 14–33 ve mevcut bölgesel intro seçenekleri.
- PRESERVE kısa, uzun ve kapalı modları.
- Gemini üzerinden ayrı şarkı sözü ve STYLE üretimi.
- Suno için iki ayrı çıktı alanı: STYLES ve LYRICS.
- Yerel arşiv, ayarlar ve Hakkında ekranı.
- Telif satırı: `© 2026 SONGDNA Studio – Tüm hakları saklıdır.`

## Bu bakım güncellemesinde yapılanlar
- Gemini STYLE isteği öncesinde seçimlerden yeni paket oluşturulur; eski `last` nesnesinin güncel olmayan seçimleriyle istek gönderilmez.
- STYLE promptuna seçili DNA, füzyon, enerji, BPM, dil, vokal düzeni, Intro DNA, PRESERVE, EXCLUDE ve yaratıcı notlar eklenir.
- Gemini ağ zaman aşımı retryable 504 olarak işaretlenir; yedek model zinciri zaman aşımında da denenir.
- Yedek modellerin tümü zaman aşımına uğrarsa API 504 döndürür.
- Android 15 / targetSdk 35 için WebView sistem çubuğu ve ekran çentiği güvenli alanları AndroidX Core WindowInsets ile uygulanır.
- Backend başlangıç mesajı ve proje dokümantasyonu 4.0.1 sürümüyle hizalanır.

## Sürüm bilgisi
- Android `versionName`: 4.0.1
- Android `versionCode`: 12
- `applicationId`: `com.songdna.studio` (güncelleme uyumluluğu için korunur)
