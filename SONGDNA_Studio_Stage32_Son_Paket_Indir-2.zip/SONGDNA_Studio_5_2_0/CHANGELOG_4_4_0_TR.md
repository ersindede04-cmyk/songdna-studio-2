# SONGDNA Studio 4.4.0 — Değişiklikler

- Görsel tema, referans görseldeki siyah/gece laciverti zemin, neon mor, fuşya ve elektrik mavisi paletine yaklaştırıldı.
- Şarkı dili listesi genişletildi: Türkçe, İngilizce, Almanca, Fransızca, İspanyolca, Azerbaycan Türkçesi, Arapça lehçeleri, Farsça, Rusça, Yunanca, Hintçe, Urduca, Bengalce, Pencapça, Portekizce varyantları, İtalyanca, Korece, Japonca, Mandarin, Endonezce, Vietnamca, Tayca, Svahili ve Kürtçe Kurmancî/Soranî.
- Gemini istemine seçilen dilde doğrudan ve doğal üretim talimatı eklendi; Türkçe taslak oluşturup çevirme yaklaşımı açıkça yasaklandı.
- Vokal ayarlarına üç kaynaklı Ad-lib seçimi, Sound Diversity ve kullanıcı ifadeleri alanları eklendi.
- Kişisel Ad-lib metni cihazın yerel depolamasında saklanır; üretim sırasında silinmez.
- Gemini backend endpointleri ve mevcut API akışı değiştirilmedi.
- Android uygulama sürümü 4.4.0 / versionCode 18 olarak güncellendi.

Not: Bu sürümde ayrı bir mevcut-söz-çeviri ekranı, sınırsız kayıt yönetimi için kayıt başına düzenleme/silme/favori sistemi veya bütün kültürel Ad-lib katalogları henüz uygulanmış değildir. Bunlar sonraki geliştirme kapsamıdır.
