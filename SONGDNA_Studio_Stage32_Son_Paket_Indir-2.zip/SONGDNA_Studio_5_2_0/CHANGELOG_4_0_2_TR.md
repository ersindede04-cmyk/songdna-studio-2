# SONGDNA Studio 4.0.2 — Değişiklikler

## Korunan özellikler
- 18 Music DNA, Intro DNA 14–33, PRESERVE kısa/uzun/kapalı seçenekleri.
- Gemini söz ve STYLE üretimi için ayrı uç noktalar ve iki ayrı Suno çıktı alanı.
- Arşiv, Ayarlar, Hakkında ve telif satırı aynen korundu.

## Düzeltmeler ve güvenlik
- Gemini modelleri ortam değişkenlerinden okunuyor; sunucu tarafındaki Flash model izin listesi dışındaki Pro ve çok modlu modeller reddediliyor.
- Varsayılan model `gemini-3.1-flash-lite`; Pro/çok modlu modele otomatik geçiş yok. Ücretsiz kullanım için Google projesinin Free Tier üzerinde kalması ve faturalandırmanın açılmaması gerekir.
- Toplam üretim bütçesi 78 saniye, model başına en fazla 24 saniye.
- İstemci 150 saniyelik sınırla Render soğuk başlangıcına tolerans tanıyor.
- İstemci bağlantısı kesilirse Gemini isteği de iptal ediliyor.
- Eski temperature ayarı kaldırıldı.
- Model seçimi `/health` üzerinden dinamik güncelleniyor.
- JavaScript `www/app.js` dosyasına ayrıldı; Android varlığıyla birebir eşitleniyor.
- Android yedekleme kapatıldı.
- Render proxy/IP ayarı ve Android `file://` CORS gereksinimi kurulum belgesinde açıklandı.
- APK imzalama GitHub Secrets ile isteğe bağlı hale getirildi; imzasız debug APK akışı korunuyor.

## Test notu
Kaynak doğrulaması ve statik kontroller yapılır. Gerçek Android cihaz, Render ortamı ve canlı Gemini API testi ayrıca gereklidir; bu testler yapılmadan ürünün canlı ortamda doğrulandığı iddia edilmez.

- Intro DNA katalog açıklamasına kültürel/dilsel doğrulama uyarısı eklendi; doğrulanmamış içerik doğrulanmış gibi sunulmuyor.
