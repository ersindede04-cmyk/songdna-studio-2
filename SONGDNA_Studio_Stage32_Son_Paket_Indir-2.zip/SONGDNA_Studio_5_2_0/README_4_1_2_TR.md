# SONGDNA Studio 4.1.2 – Complete Integrated Package

Bu paket tek SONGDNA Studio uygulamasıdır. Ayrı JSON uygulaması veya ikinci kurulum yoktur.

- Global Music DNA veri seti uygulamanın JavaScript dosyasına gömülüdür; uygulama çevrimdışıyken de seçim verilerini okuyabilir.
- Aynı veri setinin düzenlenebilir kaynak kopyası `data/music_dna_global_v1_1.json` altında tutulur.
- 30 profil, mevcut DNA seçim sırasıyla eşleştirilir.
- İsteğe bağlı enstrüman/çalım tekniği seçimi aynı STYLES üretimine bağlanmıştır.
- Web ve Android WebView dosyaları eşitlenmiştir.
- Ana müzik türü ve şarkı dili kullanıcının seçimine bağlı kalır.
- Suno çıktıları yine yalnızca STYLES ve LYRICS alanlarıdır.

## Derleme
`android-wrapper` dizinindeki Gradle projesi, mevcut GitHub Actions iş akışıyla APK üretmek için kullanılabilir. Canlı Gemini ve gerçek Android cihaz testi bu paket oluşturma işlemi sırasında çalıştırılmamıştır.
