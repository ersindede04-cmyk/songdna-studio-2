# SONGDNA Studio 4.1.0 – Türkçe değişiklik notları

## Yeni
- Hazır müzik kombinasyonları ve tamamen özelleştirilebilir tasarım birlikte sunulur.
- Türkiye/Anadolu, Arap-Orta Doğu, Balkan, Afrika, Hindistan/Güney Asya, Latin Amerika/İspanyol, Avrupa/Kelt, Doğu Asya, İran/Pers ve modern füzyon bölgeleri eklendi.
- Bölgeye göre alt gelenek ve çoklu enstrüman seçimi eklendi.
- Yerel vokal karakteri, ad-lib/ifade ve yerleşim seçilebilir.
- STYLES ve LYRICS ayrı, düzenlenebilir çıktı alanlarında gösterilir; ayrı kopyalama düğmeleri vardır.
- Suno'ya otomatik metin aktarımı yapılmaz. Kullanıcı çıktıları kendi alanlarında kopyalar.

## Korunanlar
- Gemini üzerinden /api/lyrics ve /api/style
- Flash-only model politikası
- Intro DNA kataloğu ve PRESERVE seçenekleri
- Arşiv, ayarlar, görünüm ve Hakkında bölümü

## Test durumu
Bu paket statik kaynak kontrolleri ve JavaScript sözdizimi testlerinden geçirilmelidir. Gerçek cihaz, Render ve canlı Gemini üretim testi ayrıca yapılmalıdır.
