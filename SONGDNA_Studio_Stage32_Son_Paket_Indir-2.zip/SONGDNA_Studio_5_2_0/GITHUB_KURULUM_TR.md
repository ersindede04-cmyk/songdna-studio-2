# SONGDNA Studio 5.2.0 — GitHub APK kurulumu

1. ZIP dosyasını açın.
2. İçindeki `SONGDNA_Studio_5_2_0/` klasörünün **içeriğini** GitHub deposunun kök dizinine yükleyin. Proje klasörünü iç içe ikinci kez koymayın.
3. GitHub deposunda Actions bölümünü açın.
4. **SONG DNA SMART STUDIO 5.2.0 - Android APK** iş akışını seçin.
5. **Run workflow** ile derlemeyi başlatın.
6. İşlem başarılı olursa Artifacts bölümünden `SONGDNA-Studio-5.2.0-debug-APK` dosyasını indirin.

## İmzalı APK
İlk telefon testleri için debug APK yeterlidir. İmzalı release APK istenirse GitHub Actions Secrets bölümüne şu dört sır eklenmelidir:
- `SONGDNA_KEYSTORE_BASE64`
- `SONGDNA_KEYSTORE_PASSWORD`
- `SONGDNA_KEY_ALIAS`
- `SONGDNA_KEY_PASSWORD`

Keystore dosyasını ve parolaları ZIP'e veya GitHub kaynak koduna koymayın. Gelecek güncellemelerde aynı keystore ve alias korunmalıdır.

## Render / Gemini
APK oluşturmak, Render sunucusunu güncellemez. `backend/` klasörünü Render servisine dağıtın ve `APP_ACCESS_TOKEN`, `GEMINI_API_KEY` ortam değişkenlerini tanımlayın. Diğer ayarlar ve Android WebView CORS notları `backend/DEPLOY_TR.md` dosyasındadır.

## Sürüm bilgisi
- Uygulama: 5.2.0
- Android versionCode: 27
- Application ID: `com.songdna.studio`

GitHub Actions başarılı derleme, APK'nın oluşturulduğunu gösterir; gerçek telefon kurulumu ve kullanım testleri ayrıca yapılmalıdır.
