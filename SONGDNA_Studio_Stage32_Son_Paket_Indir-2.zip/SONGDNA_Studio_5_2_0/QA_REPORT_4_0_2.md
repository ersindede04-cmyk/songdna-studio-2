# SONGDNA Studio 4.0.2 — QA raporu

## Statik kaynak doğrulaması
- [x] 18 Music DNA ve Intro DNA 14–33 korunmuş.
- [x] STYLES ve LYRICS ayrı; `/api/style` ve `/api/lyrics` mevcut.
- [x] Hakkında telif satırı birebir korunmuş.
- [x] Web ve Android HTML/JS dosyaları birebir eşit.
- [x] Backend Pro/çok modlu model kabul etmiyor; yalnızca izinli Flash metin modelleri kabul ediliyor.
- [x] Pro modele otomatik geçiş yok; Google proje faturalandırma seviyesi ayrıca belirleyici.
- [x] İstemci ve sunucu zaman aşımı sınırları mevcut; istemci bağlantısı kesilince upstream istek iptal ediliyor.
- [x] Android `allowBackup=false` ve cleartext trafik kapalı.
- [x] Intro DNA için kültürel/dilsel doğrulama uyarısı görünür.
- [x] JavaScript, JSON ve Android XML statik kontrolleri geçti.
- [x] Yerel backend smoke testinde `/health` yanıtı ve hatalı erişim kodunun 401 ile reddi doğrulandı.

## Henüz yapılmayan canlı doğrulamalar
- [ ] GitHub Actions üzerinde gerçek Android APK derlemesi.
- [ ] Fiziksel Android cihazda kurulum, ekran/klavye ve WebView testi.
- [ ] Render üzerinde gerçek dağıtım ve proxy/IP doğrulaması.
- [ ] Gerçek Gemini API anahtarıyla canlı Lyrics ve STYLE üretimi.
- [ ] Intro DNA içeriklerinin ilgili dillerin ana dili konuşurları tarafından kültürel doğrulaması.

## Sınır
`verify-source.py` statik kaynak doğrulamasıdır. Yerel smoke test de canlı Gemini çağrısı değildir. Bu nedenle APK derlemesi, gerçek cihaz testi, Render dağıtımı ve canlı Gemini yanıtı başarılı olmuş gibi gösterilmemektedir.
