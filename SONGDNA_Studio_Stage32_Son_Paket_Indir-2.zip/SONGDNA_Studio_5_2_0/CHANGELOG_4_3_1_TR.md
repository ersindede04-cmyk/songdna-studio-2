# SONGDNA Studio 4.3.1 — Güncelleme Notları

- Telefon arayüzü dikey, dokunmatik ve kompakt kullanım için düzenlendi.
- Tablet/yatay geniş ekranlarda üretim ve çıktı alanları yan yana açılır; dar ekranlarda tek sütun düzeni korunur.
- Neon mor, pembe ve elektrik mavisi görsel sistem; parlak ana üretim düğmesi ve Suno bağlantı düğmesi iyileştirildi.
- Suno bağlantısı renkli SUNO işaretli “Suno’yu Aç” düğmesi olarak düzenlendi; mevcut resmi Suno oluşturma adresi korunur.
- Menü; Genel Ayarlar, AI Configuration, Temalar, Hakkında ve Çıkış önceliğiyle yeniden düzenlendi. Intro & Yerel Sesler, Vokal DNA ve Projelerim ayrı yardımcı bölümler olarak korundu.
- Tema tercihlerine Sistem seçeneği eklendi; Gece/Gündüz/Sistem tercihi cihazda saklanır.
- Uygulama dili tercihi Automatic/Türkçe/English olarak eklendi ve saklanır. Bu sürümde tüm arayüz metinlerinin canlı çevirisi henüz tamamlanmamıştır.
- Android uygulamasına güvenli yerel çıkış köprüsü eklendi.
- Gemini üretim uçları, backend sunucu kodu, Music DNA ve Intro DNA katalogları korunmuştur.
- Web ve Android WebView dosyaları eşitlendi.

## Doğrulama sınırları

Kaynak bütünlüğü, JavaScript sözdizimi, Android XML ve WebView dosya eşitliği statik olarak denetlenir. Canlı Gemini/Render bağlantısı, gerçek cihaz görünümü ve APK derlemesi bu ortamda çalıştırılmış sayılmaz.
