# SONGDNA Studio 5.2.0 Candidate — Backend Dağıtım Notları

Bu klasör Aşama 29'da doğrulanan Gemini API sunucusunu içerir. Paket **aday kaynak** durumundadır; canlı Render dağıtımı yapılmış değildir.

## Çalışma zamanı
- Node.js: 20 veya üzeri
- Başlatma: `npm start` (eşdeğeri: `node server.js`)
- Sağlık kontrolü: `GET /health`
- API yolları: `POST /api/lyrics`, `POST /api/style`, `POST /api/command`

## Zorunlu ortam değişkenleri
- `APP_ACCESS_TOKEN`: En az 12 karakterli, tahmin edilmesi zor uygulama erişim anahtarı.
- `GEMINI_API_KEY`: Google Gemini API anahtarı.

## İsteğe bağlı ortam değişkenleri
- `GEMINI_MODELS`: Virgülle ayrılmış izinli Flash metin modelleri. Varsayılan allowlist: `gemini-3.1-flash-lite`, `gemini-3.6-flash`, `gemini-3.8-flash`.
- `GEMINI_MODEL`: İzinli listedeki varsayılan model.
- `PORT`: Sunucu portu; varsayılan `8080`.
- `ALLOWED_ORIGIN`: CORS izinli origin; varsayılan `*`.
- `TRUST_PROXY`: Yalnızca güvenilir proxy arkasında `true` yapılmalı.

## Render için kaynak ayarı
Bu backend klasörünü ayrı bir servis olarak dağıtacaksan, servis kök dizini `backend`, başlatma komutu `npm start` olabilir. Mevcut Render servisini değiştirmeden önce doğru servisi, mevcut ortam değişkenlerini ve son dağıtım kaynağını doğrula. Bu pakette gerçek gizli anahtar bulunmaz; `.env.example` yalnızca örnek adları içerir.

## Dağıtım öncesi kontrol
1. `APP_ACCESS_TOKEN` ve `GEMINI_API_KEY` Render ortamına güvenli biçimde eklenmeli.
2. `GET /health` yanıtında `SONGDNA Studio 5.2.0 candidate AI` ve beklenen Flash modelleri görülmeli.
3. Uygulama erişim kodu ile `/api/lyrics`, `/api/style` ve `/api/command` canlı testleri yapılmalı.
4. Android uygulama sunucu adresi ve erişim koduyla doğrulanmalı.
5. Canlı testlerden sonra aday etiketi kaldırılıp nihai sürüm kararı verilmelidir.

Aşama 29'un yerel testleri gerçek Gemini hesabı, Render veya Android cihaz kullanmaz. Bu nedenle bu notlar dağıtım talimatıdır; dağıtımın gerçekleştiğini göstermez.
