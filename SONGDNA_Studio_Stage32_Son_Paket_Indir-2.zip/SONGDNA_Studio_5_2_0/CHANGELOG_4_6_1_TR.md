# SONGDNA Studio 4.6.1 – Değişiklikler

- Kaynak temel olarak doğrulanmış 4.6.0 geliştirici paketi kullanıldı.
- Doğal Dil Komutu · Gemini paneline 12 adet isteğe bağlı hazır komut şablonu eklendi.
- Şablon seçimi yalnızca mevcut komut metin alanını doldurur; kullanıcı metni serbestçe düzenleyebilir, silebilir veya yeniden yazabilir.
- Fransızca aşk şarkısı için Melodik Trap ve Modern Trap ayrı başlangıç şablonları eklendi.
- Komutlar mevcut `/api/command` uç noktasından yorumlanır; yeni backend endpoint'i eklenmedi.
- Gemini'nin yalnızca açıkça belirtilen seçimleri uygulama ve belirtilmeyen ayarları koruma davranışı muhafaza edildi.
- Styles ve Lyrics olmak üzere iki Suno çıktı alanı, mevcut Music DNA kataloğu, Intro/yerel ses modülleri ve üretim akışı korundu.
- Android versionName 4.6.1, versionCode 21 olarak güncellendi.

Canlı Gemini/Render ve fiziksel Android cihaz testleri bu statik kaynak kontrolünün kapsamında değildir.
