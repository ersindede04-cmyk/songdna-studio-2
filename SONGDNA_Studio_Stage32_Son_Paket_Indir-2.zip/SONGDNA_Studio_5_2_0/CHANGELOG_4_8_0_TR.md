# SONGDNA Studio 4.8.0 – Değişiklik Kaydı

- Üç yaratıcı mod: Otomatik Şablon, Gemini Serbest Yaratıcılık ve Karma Yaratıcılık.
- Konu, duygu, atmosfer, hikâye/olay ve anlatım biçimi alanları; yeni kombinasyon ve sabitleme kontrolü.
- Otomatik son 20 şarkı sözü hafızası ve Gemini promptlarına geçmiş söz ekleme kaldırıldı.
- Yalnızca tekrar çeşitliliği için sınırlı konu seçimi kaydı tutulur; sözler/Styles kaydedilmez ve Gemini'ye gönderilmez.
- Manuel arşiv bölümü Favori Şarkı Sözlerim olarak adlandırıldı; kayıt kullanıcı eylemiyle yapılır.
- Yeni indigo/violet/cyan/champagne görsel tema.
- Web ve Android varlıkları eşitlendi; Android versionCode 23 / versionName 4.8.0.
- İki çıktı alanı ve ayrı kopyalama akışı korunur. Ses üretimi/oynatımı eklenmedi.
