# SONGDNA Studio 5.2.0 — Aşama 31.2 Music DNA Aranjman Rehberleri

## Amaç
66 Music DNA profilinin her birinin yalnızca tür etiketi değil, kendi müzikal kimliğine uygun aranjman yaklaşımı da Gemini prodüksiyon talimatına aktarılmalıdır. Özellikle geleneksel/yerel müziklerde standart pop verse/chorus yapısının otomatik dayatılması önlenmelidir.

## Uygulanan değişiklik
- `GLOBAL_MUSIC_DNA.music_dna_profiles` içindeki 66 profilin tamamında birbirinden farklı ve türe özgü `arrangement_guidance` bulunur.
- İlk paketteki denetimde MDNA-001..018 profillerinde ortak pop şablonu, MDNA-019..030 profillerinde ise ortak geleneksel müzik şablonu kullanıldığı görüldü; bu 30 profil tek tek yeniden yazıldı.
- MDNA-031..066 aralığındaki 36 profile ait önceden eklenmiş özgün rehberler korundu.
- Sonuç: 66 profil / 66 ayrı aranjman yönlendirmesi; ortak genel şablon tekrarı yoktur.
- Çağdaş pop/rap profillerinde verse/hook/bridge yapısı esnek ve şarkı brief'ine bağlı tutulur.
- Gamelan, Pansori, Urtiin Duu, Gürcü/Arnavut/Sardinya çok sesliliği, Mugham, Ahellil, Bomba, Plena, Son Jarocho ve benzeri profillerde kendi ritmik/vokal/ensemble mantığı korunur; uygun olmayan standart pop şeması zorlanmaz.
- Production DNA motoru seçili profilin `arrangement_guidance` alanını kullanır; ayrıca `prompt_guidance` alanı da Gemini'ye iletilir.
- Profil bazlı aranjman paketi hem Gemini Styles hem Gemini Lyrics prompt gövdesine aktarılır; açık kullanıcı seçimleri varsayılan aranjman rehberinden önceliklidir.
- Backend model izin listesi bu çalışmada değiştirilmedi: mevcut sunucu yapılandırması Flash modelleriyle sınırlıdır. Bu nedenle Pro modelinde canlı üretim doğrulaması yapılmış gibi sunulmaz; prompt entegrasyonu mevcut Gemini API akışına yapılmıştır.
- Styles ve Lyrics iki çıktı alanı, Intro'nun Lyrics başlangıcına eklenmesi, 28 dil profili ve ortak İngilizce/İspanyolca jargon havuzları değiştirilmemiştir.

## Testler
- `scripts/test-stage31-2-music-dna-arrangement.js`: PASS — 66 profil, 66 benzersiz aranjman rehberi, ilk 30 profilin ortak şablonlardan arındırılması, geleneksel profillerde kimlik koruması, Gemini Styles + Lyrics aktarımı, kullanıcı seçim önceliği ve JSON/runtime eşitliği.
- `node --check app.js`: PASS.
- `scripts/verify-source.py`: PASS — root, `www/` ve Android WebView runtime eşitliği.
- Önceki Stage 26/28/29/30/31.1 regresyon testleri de paketleme öncesi yeniden çalıştırılmıştır.

## Sınırlar
Bu aşama kaynak ve prompt yönlendirmesi doğrulamasıdır. Gerçek Gemini hesabıyla 66 profilin tamamından örnek üretim, uzman müzisyen değerlendirmesi, fiziksel Android cihaz testi, uzaktan GitHub Actions APK derlemesi, Render dağıtımı ve Suno ses çıktısı doğrulaması yapılmış değildir. Bunlar paketleme sonrası dış doğrulama adımlarıdır.
