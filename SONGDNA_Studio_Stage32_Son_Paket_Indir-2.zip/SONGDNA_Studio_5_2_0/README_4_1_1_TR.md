# SONGDNA Studio 4.1.1 – Global Music DNA Extension

## Bu paket ne yapar?
- 4.3.0 kaynak projesini temel alır.
- Mevcut Music DNA 01–18 kayıtlarını değiştirmeden 19–30 aralığını uygulamanın seçim listesine ekler.
- Intro DNA kayıtlarına dokunmaz; mevcut intro davranışı ve 14–33 kayıtları korunur.
- Ayrıntılı kültürel/müzikal profil verisini `data/music_dna_global_v1_1.json` içinde sunar.
- Anadolu bağlamında tezene, şelpe, Zeybek tezene tavrı ve Bozlak tezene tavrını ayrı teknik kayıtları olarak tanımlar.

## Önemli doğruluk notu
Bu sürüm, kaynakları ve veri şemasını düzenlenmiş bir üretim adayıdır; tüm kültürel profiller akademik olarak sertifikalı değildir. `evidence_status` alanı bu ayrımı açıkça gösterir. Özellikle geniş bölgesel etiketler yerel müzisyen/uzman incelemesi gerektirir. BPM değerleri yaratıcı başlangıç noktalarıdır; türün zorunlu temposu değildir.

## Sabit ürün kuralları
- Yalnızca iki Suno çıktı alanı: STYLES ve LYRICS.
- Ana tür ve ana şarkı dili kullanıcının seçimidir; kültürel katmanlar bunları otomatik değiştirmez.
- Intro/yerel vokal yönergeleri kullanılırsa LYRICS başına eklenir; üçüncü çıktı alanı yoktur.
- Müzik çalar, ses üretimi veya görsel üretim özelliği eklenmemiştir.
- Kayıtlar ID/slug ile tekilleştirilir; mevcut kayıtların üzerine yazılmaz.

## Kurulum
ZIP içindeki `www/app.js` ve `android-wrapper/.../assets/www/app.js` güncellenmiştir. Android web içeriği ve web sürümü aynı JavaScript dosyasını kullanır. Diğer kaynak dosyalar korunmuştur.

## Kaynaklar
- CompMusic corpora: https://compmusic.upf.edu/corpora
- CompMusic datasets: https://compmusic.upf.edu/datasets
- Saraga collections: https://mtg.github.io/saraga/
- UNESCO Intangible Cultural Heritage: https://ich.unesco.org/
- MTG-Jamendo: https://mtg.github.io/mtg-jamendo-dataset/
- Discogs developer/database reference: https://www.discogs.com/developers
- ISMIR resources: https://ismir.net/resources/

Kaynak kayıtlarının kullanım koşulları birbirinden farklıdır. Bu paket kayıt, ses, nota veya MIDI örneklerini kopyalamaz.
