# SONGDNA Studio 4.3.0

SONGDNA Studio, Suno için iki metin çıktısı hazırlayan bir jeneratördür: STYLES (müzik tarzı komutu) ve LYRICS (şarkı sözleri + seçilmiş intro/ad-lib). Ses veya müzik üretmez.

## Kurulum
1. ZIP'i açın.
2. `backend/` içindeki `.env.example` dosyasını `.env` olarak kopyalayın.
3. `GEMINI_API_KEY`, `APP_ACCESS_TOKEN` ve diğer sunucu değişkenlerini kendi backend ortamınıza girin. API anahtarını telefondaki uygulamaya koymayın.
4. Backend'i Render'daki mevcut `songdna-ai-api` servisine dağıtın.
5. Android uygulamada Menü → AI ve API Bağlantısı bölümüne HTTPS sunucu adresini ve `APP_ACCESS_TOKEN` değerini bir kez girin.
6. Android APK için `.github/workflows/build.yml` GitHub Actions workflow'unu çalıştırın.

## Android
`android-wrapper/` içindeki WebView uygulaması `www/` arayüz dosyalarını assets içinden yükler. Bu nedenle `www/index.html` ve `www/app.js` değişiklikleri Android assets klasörüne de eşlenmiştir.

## Ürün ilkeleri
- Ana işlem: Şarkı Sözü Oluştur.
- Çıktılar: yalnızca STYLES ve LYRICS.
- Ana müzik türü, prodüksiyon, ülke/kültür ve isteğe bağlı bölgesel DNA birbirinden bağımsızdır.
- Türkiye seçimi geleneksel yöresel temayı otomatik seçmez.
- Bölgesel DNA söz konusu veya şarkı dili dayatmaz.
- Kullanıcının özel talimatı hazır şablonlardan önceliklidir.
