# SONGDNA Studio 5.2.0 — Aşama 30.5 Ürün Denetimi ve Aşama 31.1 Sahne Jargonu

## Kapsam
Aşama 30.5'te 5.2.0 Stage 30.4 kaynak paketi yeniden açıldı; ürün manifesti, değişiklik kaydı, çalışma zamanı kodu, 66 Music DNA profili, küresel kültürel ad-lib profilleri ve mevcut testler incelendi. Ardından Aşama 31.1'de araştırılmış rap sahnesi jargonunu ad-lib vokal seslerinden ayrı seçilebilir bir katman olarak ekledik.

## Aşama 30.5 — Denetim bulguları

### Mevcut ve testle desteklenen altyapı
- 66 Music DNA profili ve 70 enstrüman/teknik modülü JSON kataloğunda mevcut.
- Katalogda 16 ritim modülü, 14 vokal teknik modülü ve 12 intro motif modülü bulunuyor.
- 28 dil profili kayıtlı; bu sayı 28 dil için doğrulanmış jargon/ad-lib sözlüğü bulunduğu anlamına gelmiyor.
- 5.2.0 istemci tarafında Lyrics, Styles ve Command API sözleşmesi; iki ana çıktı alanı; Gemini talimat motoru; kayıt kütüphanesi ve son 20 üretim geçmişi bulunuyor.
- Stage 26/27/28 geleneksel vokal yönlendirme katalogları ve 66 Music DNA eşleme regresyonları mevcut.

### Ürün boşlukları
- Mevcut 28 dil profilinin bir bölümü doğrulanmış yerel ifade kataloğu yerine genel/kelimesiz vokal fallback kullanıyor.
- Mevcut ad-lib phrase bank, sözlü jargon/hitapları vokal seslerinden ayırmakta yetersizdi; bazı kelimeler yalnızca `lexicalOnly` listesiyle öneri motorundan dışlanıyordu.
- Music DNA profil sayısı ve statik eşleme testleri, her türün gerçek Gemini/Suno çıktısında kalite onayı aldığı anlamına gelmiyor.
- Canlı Gemini, Render, GitHub Actions APK ve fiziksel Android testleri yapılmış değil.

## Aşama 31.1 — Uygulanan geliştirme
- `scene-jargon-catalog.js` eklendi.
- Fransız rap/Français urbain, Deutschrap, UK Drill/Grime/MLE, US Hip-Hop/Trap ve Türkçe Rap için 42 isteğe bağlı söz varlığı girdisi eklendi.
- Her kayıt terim, anlam, register/kültürel bağlam, doğal kullanım yeri ve yanlış kullanım uyarısı içeriyor.
- Araştırma kaynakları sahne profillerine eklendi; katalog native-speaker onaylı olarak sunulmuyor.
- Yeni `Sahne jargonu / kelime havuzu` çoklu seçim alanı eklendi.
- ABD ve UK sahne profilleri manuel seçilebilir hale getirildi; ortak English pool varsayılanı bozulmadı.
- Seçilen jargon yalnızca Gemini talimatına rehber olarak aktarılır. Otomatik söz/ad-lib eklenmez; kullanıcı seçimi yoksa modelden yerel jargon uydurmaması istenir.
- Jargon ve ad-lib vokal ifadeleri birbirinden ayrıldı. Ana şarkı dili ve iki çıktı alanı değişmedi.
- Music DNA değişiminde, dil/sahne değişiminde jargon listesi yenilenir; farklı kültürden seçilmiş terimler yeni sahneye taşınmaz.

## Araştırma dayanağı
- Fransız rapte verlan, argot ve bölgesel/kimliksel farklılıklar: Verbeke corpus study; Preite sociolinguistic study; Westphal's research on verlan.
- Deutschrap'te Anglizismen, kod değiştirme ve hitap terimleri: Hip-Hop Slang research sample; linguistic markers in German Gangsta Rap; Tagesschau youth-language reporting.
- UK MLE/Grime'de dil teması ve terimlerin bölgesel dağılımı: Journal of Sociolinguistics MLE study; Guardian reporting; Language & Communication research on grime address terms.
- ABD hip-hop vokal ad-liblerinin call-and-response ve ikinci vokal katmanı olarak işlevi: Music Theory Online study; US slang entries cross-checked against Dictionary.com/Cambridge.
- Türkçe rap söz varlığı ve ad-lib tekniği: Turkish rap slang study; Turkish rap lyric pragmatics study; Rapertuar ad-lib explainer.

## Test sonuçları
- `scripts/test-stage31-scene-jargon.js`: PASS — 5 hedef sahnede veri bütünlüğü, kaynaklar, güvenli fallback ve prompt/UI bağlantısı.
- `scripts/test-stage31-scene-jargon-browser.py`: PASS — 14/14 — sahne değişimi, 42 terim, metadata, manuel çoklu seçim, kültürler arası seçim sızıntısı olmaması ve boş fallback.
- `node --check app.js`: PASS.
- `node --check scene-jargon-catalog.js`: PASS.
- Önceki Stage 30.2/30.3/30.4 ve API/katalog/regresyon testleri kaynak senkronizasyonundan sonra yeniden çalıştırılacak.

## Açık kalanlar
- 28 dilin tümüne ait doğrulanmış söz/jargon katalogları tamamlanmış değildir.
- US alt bölgeleri ve alt türleri (ör. Atlanta, New York, Memphis, Detroit) henüz ayrı ayrı derinleştirilmemiştir.
- Fransız ve Alman bölgesel/kuşaksal ayrımlar için native-speaker review gerekir.
- 66 Music DNA profilinin tümü için gerçek üretim örneği ve kalite puanlama seti henüz tamamlanmamıştır.
- Gerçek Gemini, Render, Android APK/cihaz ve Suno ses testi yapılmamıştır.

## Sonuç
Aşama 30.5 ürün denetimi tamamlandı. Aşama 31.1, beş rap sahnesi için 42 terimli isteğe bağlı jargon katmanını kaynak koduna entegre etti. Bu, küresel kültürel vokal sisteminin tamamlandığı anlamına gelmez; kalan diller ve alt sahneler için aşamalı araştırma ve uygulama sürmelidir.
