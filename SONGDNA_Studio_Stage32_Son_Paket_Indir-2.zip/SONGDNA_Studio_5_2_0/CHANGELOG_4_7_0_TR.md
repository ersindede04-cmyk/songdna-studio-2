# SONGDNA Studio 4.7.0 – Değişiklik Kaydı

## Ürün ilkesi
- SONGDNA Studio yalnızca şarkı sözü ve Suno müzik tarzı komutu hazırlayan bir jeneratördür. Ses oynatıcı, müzik dinleme veya ses üretme özelliği eklenmemiştir.
- Suno için iki çıktı korunur: STYLES ve LYRICS.

## Yeni ve güncellenenler
- Telefon düzeni korunarak tablet ve geniş ekranlar için uyarlanabilir çalışma alanı iyileştirildi.
- Kullanıcı konu yazmadığında her üretimde değişen, yakın geçmişte kullanılmamış otomatik konu seçimi eklendi. Elle girilen konu korunur.
- Son 20 Gemini üretimi başlık, konu, tam sözler, Styles, dil ve Music DNA bilgileriyle ayrı bir akıllı hafızada saklanır. 21. kayıtta en eski hafıza kaydı çıkarılır. Kullanıcının manuel arşivi bundan etkilenmez.
- Yeni üretim promptu son 20 kaydı dikkate alarak hikâye, nakarat, metafor ve ifadelerin tekrarını azaltmaya çalışır.
- 24 desteklenen dil için doğal anlatım, yerel şiir/müzik geleneği, söylenebilirlik ve zoraki kafiyeden kaçınma talimatları güçlendirildi. Teknik/dijital ifadeler mutlak yasak değildir; yalnızca bağlam dışı ve klişe kullanımından kaçınılır.
- Android versionCode 22, versionName 4.7.0.

## Test sınırı
Bu paket üzerinde kaynak bütünlüğü, JavaScript sözdizimi, backend sözdizimi, JSON katalogları, Android XML ve web/Android dosya eşitliği statik olarak kontrol edilir. Gerçek Gemini API, Render dağıtımı, GitHub Actions APK derlemesi, imzalama ve fiziksel telefon/tablet testleri bu çalışma ortamında doğrulanmış değildir.
