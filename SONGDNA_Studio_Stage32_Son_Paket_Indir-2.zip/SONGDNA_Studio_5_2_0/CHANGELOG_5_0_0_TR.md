# SONGDNA Studio 5.0.0 — Değişiklik Kaydı

- SONGDNA'nın seçili Music DNA ve yapılandırılmış müzik modüllerini kaynak kabul eden Suno Prompt Engine talimatları güçlendirildi.
- Akıllı yapımcı yaklaşımı: groove/half-time, davul-bas, enstrüman rolleri, armoni, vokal, geçiş ve prodüksiyon kararları birbiriyle tutarlı biçimde ele alınır.
- Ad-lib üretimi varsayılan olarak temel vokal-prodüksiyon katmanı haline getirildi; duygu, enerji, groove, söz anlamı, vurgu ve boşluklara göre seçilip yerleştirilmesi istenir.
- Kullanıcı seçimleri, özel ifadeleri, deneysel füzyonları ve seçilmiş yöresel katmanları koruma kuralları güçlendirildi.
- Telefon/tablet duyarlı mevcut yerleşim korundu; dokunmatik hedefler ve tablet genişlikleri için iyileştirmeler yapıldı.
- Yeni SONG DNA / SMART STUDIO görseli Android uygulama ikonu olarak eklendi.
- Android versionName 5.0.0, versionCode 24 olarak güncellendi.
- Gemini API uçları, erişim kodu, hız sınırları, model yedekleme ve iki alanlı Styles/Lyrics akışı korundu.
- Uygulama ses üretmez veya oynatmaz; Suno için metin/prompt hazırlar.
