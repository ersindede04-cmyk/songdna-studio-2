# SONGDNA Studio 4.3.2 — QA Report

## Passed static checks
- Required project files present.
- Web and Android WebView HTML/JavaScript copies match.
- Android XML parses successfully.
- Frontend and backend JavaScript syntax checks pass.
- Backend package metadata and start script present.
- 18 base Music DNA packages and Intro DNA 14–33 retained.
- PRESERVE controls and exact About copyright retained.
- Flash-only model allowlist, cancellation/timeouts, dynamic model list and frontend API-key isolation checks pass.
- Interface localization dictionary added for Turkish and English, including main creation, template, result, settings, intro, vocal, AI/API and About UI.
- English default, device-locale Automatic mode and persisted manual language choice implemented.
- User-entered lyrics, theme, custom instructions and generated output areas excluded from automatic UI translation.

## Not verified in this environment
- APK build/signing.
- Physical Android phone and tablet rendering.
- Interactive language switching on a physical device/WebView.
- Live Render health check or Gemini generation request.

Run `python3 scripts/verify-source.py` before building. GitHub Actions/Gradle and real-device tests remain required for release confidence.
