const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..', 'www');
const catalog = require('../www/adlib-catalog.js');
const resolver = require('../www/global-cultural-adlib.js');
const engine = require('../www/genre-adlib-engine.js');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const expected = {
  'MDNA-041':'gamelan','MDNA-042':'gnawa','MDNA-044':'mongolian',
  'MDNA-045':'georgian','MDNA-047':'maloya','MDNA-052':'baul'
};
const allIds = new Set();
for (const [id, scene] of Object.entries(expected)) {
  const r = resolver.resolve('English', 'auto', id);
  assert.strictEqual(r.scene, scene, `${id} should route to ${scene}`);
  assert.strictEqual(r.source, 'music-dna-auto');
  const items = catalog.get(scene);
  assert.strictEqual(items.length, 4, `${scene} should have four directions`);
  assert(catalog.note(scene).length > 40);
  for (const x of items) {
    assert(x.id && x.phrase && x.function && x.placement && x.delivery && x.caution);
    assert.strictEqual(x.kind, 'vocal_direction');
    assert(x.genreIds && x.genreIds.length === 1);
    assert(!allIds.has(x.id), `duplicate ${x.id}`);
    allIds.add(x.id);
  }
  const plan = engine.resolveAdlibMatchPlan({musicDnaId:id,dna:scene,adlibScene:scene});
  const filtered = engine.filterItems(items, plan);
  assert.strictEqual(filtered.items.length, 4, `${scene} should pass genre filter`);
}
assert.strictEqual(allIds.size, 24);
globalThis.SongDnaGenreAdlibEngine = engine;
function extractFunction(name) {
  const start = app.indexOf(`function ${name}(`); assert(start >= 0, `missing ${name}`);
  const brace = app.indexOf('{', start); let depth=0, quote=null, escape=false;
  for(let i=brace;i<app.length;i++){const ch=app[i];if(quote){if(escape)escape=false;else if(ch==='\\')escape=true;else if(ch===quote)quote=null;continue;}if(ch==='"'||ch==="'"||ch==='`'){quote=ch;continue;}if(ch==='{')depth++;if(ch==='}'&&--depth===0)return app.slice(start,i+1);}
  throw new Error(`unterminated ${name}`);
}
eval(extractFunction('recommendAdlibPhrases'));
for (const [id, scene] of Object.entries(expected)) {
  const rec = recommendAdlibPhrases({musicDnaId:id,dna:scene,adlibScene:scene,adlib:'Dengeli'},catalog);
  assert(rec.suggestions.length>0 && rec.suggestions.every(x=>x.id.startsWith({gamelan:'gamelan-',gnawa:'gnawa-',mongolian:'mon-',georgian:'georgian-',maloya:'maloya-',baul:'baul-'}[scene])), `${scene} recommendations must stay in its own catalog`);
}
const manual = recommendAdlibPhrases({musicDnaId:'MDNA-044',dna:'Mongolian Urtiin Duu',adlibScene:'mongolian',adlibPhraseIds:['mon-nugalaa']},catalog);
assert.strictEqual(manual.suggestions.length,0,'manual phrase selection must suppress auto recommendations');
assert.strictEqual(resolver.resolve('English','turkey','MDNA-052').scene,'turkey','manual override wins');
assert.strictEqual(resolver.resolve('English','baul','MDNA-041').scene,'baul','manual selection wins');
assert(html.includes('src="genre-adlib-engine.js"'), 'genre engine must load before app');
for (const scene of Object.values(expected)) assert(html.includes(`value="${scene}"`), `missing manual UI option ${scene}`);
assert(app.includes("resolveDefaultAdlibCulture(baseContext.languageLabel,baseContext.adlibSceneOverride,gp?.id||null)"));
assert(app.includes("adlibPhraseIds:Array.from($('adlibPhraseBank')?.selectedOptions||[]).map(o=>o.value)"));
assert(app.includes("if(manualPhraseIds.length)return {scene,count:0,suggestions:[],excluded:[],manualOverride:true"));
assert(app.includes('SongDnaGenreAdlibEngine?.resolveAdlibMatchPlan'));
console.log(`Stage 26 PASS: ${Object.keys(expected).length} Music DNA routes, ${allIds.size} unique tradition-specific vocal directions, genre filtering, manual override precedence, manual phrase precedence and UI loading/options.`);
