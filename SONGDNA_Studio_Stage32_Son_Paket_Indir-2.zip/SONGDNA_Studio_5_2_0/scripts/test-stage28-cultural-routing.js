const assert = require('assert');
const fs = require('fs');
const path = require('path');
const catalog = require('../www/adlib-catalog.js');
const resolver = require('../www/global-cultural-adlib.js');
const engine = require('../www/genre-adlib-engine.js');
const app = fs.readFileSync(path.join(__dirname, '../www/app.js'), 'utf8');
const html = fs.readFileSync(path.join(__dirname, '../www/index.html'), 'utf8');

// The two Stage 25 profiles must resolve from Music DNA, regardless of interface/song language.
for (const [id, scene, expectedCount] of [
  ['MDNA-025', 'hindustani', 4],
  ['MDNA-043', 'pansori', 4]
]) {
  const result = resolver.resolve('Türkçe', 'auto', id);
  assert.strictEqual(result.scene, scene, `${id} automatic cultural route`);
  assert.strictEqual(result.source, 'music-dna-auto');
  assert.strictEqual(result.musicDnaId, id);
  const items = catalog.get(scene);
  assert.strictEqual(items.length, expectedCount);
  assert(items.every(x => x.kind === 'vocal_direction' && x.id && x.function && x.placement && x.caution));
  const plan = engine.resolveAdlibMatchPlan({musicDnaId:id, dna:scene, adlibScene:scene});
  const filtered = engine.filterItems(items, plan);
  assert.strictEqual(filtered.items.length, expectedCount, `${id} genre filter`);
}

// Japanese Min’yō and Persian Āvāz remain manual-only; language alone must not auto-select them.
for (const [language, manualScene, expectedCount] of [
  ['日本語 · Japonca', 'minyo', 1],
  ['فارسی · Farsça', 'avaz', 4]
]) {
  const automatic = resolver.resolve(language, 'auto', null);
  assert.notStrictEqual(automatic.scene, manualScene, `${manualScene} must not auto-route by language`);
  const manual = resolver.resolve(language, manualScene, null);
  assert.strictEqual(manual.scene, manualScene);
  assert.strictEqual(manual.source, 'manual-override');
  assert.strictEqual(catalog.get(manualScene).length, expectedCount);
}

// No duplicate catalog IDs; the existing Stage 26/27 routing remains intact.
const expectedExisting = {
 'MDNA-041':'gamelan','MDNA-042':'gnawa','MDNA-044':'mongolian','MDNA-045':'georgian',
 'MDNA-047':'maloya','MDNA-052':'baul','MDNA-046':'samba-de-roda','MDNA-049':'albanian',
 'MDNA-053':'sardinian','MDNA-054':'ahellil','MDNA-062':'bomba','MDNA-063':'plena','MDNA-064':'son-jarocho'
};
for (const [id, scene] of Object.entries(expectedExisting))
  assert.strictEqual(resolver.resolve('English','auto',id).scene, scene, `${id} legacy route preserved`);
const uniqueScenes = catalog.scenes.filter(s => !['english'].includes(s.id));
const allIds = uniqueScenes.flatMap(s => catalog.get(s.id).map(x => x.id));
assert.strictEqual(new Set(allIds).size, allIds.length, 'catalog IDs must be unique outside intentional English legacy aggregation');
assert(html.includes('value="hindustani"') && html.includes('value="pansori"'));
assert(html.includes('value="minyo"') && html.includes('value="avaz"'));
assert(html.includes('src="global-cultural-adlib.js"') && html.includes('src="genre-adlib-engine.js"'));
assert(app.includes('SongDnaGlobalCulturalAdlib?.resolve'));
console.log('Stage 28 PASS: MDNA-025/043 auto routes restored, 13 Stage 26/27 routes preserved, Min’yō/Āvāz remain manual-only, UI and script integration verified.');
