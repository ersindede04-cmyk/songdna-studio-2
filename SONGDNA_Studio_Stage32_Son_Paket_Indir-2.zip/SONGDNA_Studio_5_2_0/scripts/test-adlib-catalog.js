const assert=require('assert');
globalThis.SongDnaAdlibCatalog=require('../www/adlib-catalog.js');
const fs=require('fs');const src=fs.readFileSync(__dirname+'/../www/app.js','utf8');
function extract(name){const start=src.indexOf('function '+name+'(');assert(start>=0,'missing '+name);const brace=src.indexOf('{',start);let depth=0,quote=null,escape=false;for(let i=brace;i<src.length;i++){const c=src[i];if(quote){if(escape)escape=false;else if(c==='\\')escape=true;else if(c===quote)quote=null;continue;}if(c==='"'||c==="'"||c==='`'){quote=c;continue;}if(c==='{')depth++;if(c==='}'&&--depth===0)return src.slice(start,i+1);}throw Error('unterminated '+name)}
eval(extract('recommendAdlibPhrases'));
eval(extract('resolveDefaultAdlibCulture'));
eval(extract('adlibSceneForCultureSource'));
eval(extract('buildAdlibArrangement'));
eval(extract('buildVocalProfile'));
const expected=['global','us','france','germany','uk','turkey'];
const sceneIds=SongDnaAdlibCatalog.scenes.map(x=>x.id);
for(const scene of expected)assert(sceneIds.includes(scene),`legacy scene ${scene} must remain available`);
for(const scene of ['baul','gamelan','gnawa','maloya','georgian','mongolian'])assert(sceneIds.includes(scene),`Stage 26 scene ${scene} missing`);
for(const scene of ['albanian','sardinian','ahellil','samba-de-roda','bomba','plena','son-jarocho','saman'])assert(sceneIds.includes(scene),`Stage 27 scene ${scene} missing`);
for(const scene of expected){const items=SongDnaAdlibCatalog.get(scene);assert(items.length>=6,scene+' catalog too small');assert(items.every(x=>x.id&&x.phrase&&x.function&&x.placement&&x.caution),scene+' incomplete entry');}
for(const scene of ['baul','gamelan','gnawa','maloya','georgian','mongolian','albanian','sardinian','ahellil','samba-de-roda','bomba','plena','son-jarocho','saman']){const items=SongDnaAdlibCatalog.get(scene);assert(items.length===4,scene+' must contain four focused directions');assert(items.every(x=>x.kind==='vocal_direction'),scene+' entries must be typed as vocal directions');}
let c={dna:'UK Drill',adlibScene:'uk',adlibPhraseIds:['uk-reload','uk-yo']};let profile=buildVocalProfile(c);
assert(profile.promptText.includes('Reload!'),'selected phrase absent');assert(profile.promptText.includes('Yo!'),'second selected phrase absent');assert(!profile.promptText.includes('Pull up!'),'unselected phrase leaked');
const automaticProfile=buildVocalProfile({dna:'Turkish Rap',adlibScene:'turkey',adlibPhraseIds:[]});
assert(automaticProfile.automaticPhrases.length>0,'automatic mode should suggest safe catalog phrases');
assert(automaticProfile.promptText.includes('Automatic catalog recommendations'),'automatic recommendations must reach the vocal prompt');
const manualProfile=buildVocalProfile({dna:'UK Drill',adlibScene:'uk',adlibPhraseIds:['uk-yo']});
assert(manualProfile.promptText.includes('Yo!'),'manual phrase must remain in prompt');
assert.equal(manualProfile.automaticPhrases.length,0,'manual selections must override automatic suggestions');
const classicRecommendations=recommendAdlibPhrases({dna:'Turkish Rap',adlibScene:'turkey',adlibPhraseIds:[],productionProfile:{arrangementMode:'classic'}},SongDnaAdlibCatalog).suggestions.map(x=>x.id);
const modernRecommendations=recommendAdlibPhrases({dna:'Turkish Rap',adlibScene:'turkey',adlibPhraseIds:[],productionProfile:{arrangementMode:'modern'}},SongDnaAdlibCatalog).suggestions.map(x=>x.id);
assert.notDeepEqual(classicRecommendations,modernRecommendations,'arrangement mode must influence ad-lib recommendation ranking');
assert(SongDnaAdlibCatalog.note('germany').toLocaleLowerCase('tr').includes('dini/kültürel'),'cultural caution missing');
console.log('International Ad-lib Catalog tests passed: legacy scenes preserved, Stage 26/27 catalogs present, metadata completeness, manual override priority, automatic suggestions and cultural safeguards.');
