const assert=require('node:assert/strict');
const fs=require('node:fs');
const catalog=require('../scene-jargon-catalog.js');
const app=fs.readFileSync(require('node:path').join(__dirname,'../app.js'),'utf8');
const html=fs.readFileSync(require('node:path').join(__dirname,'../index.html'),'utf8');
const target=['france','germany','uk','us','turkey'];
for(const scene of target){
 const items=catalog.get(scene);
 assert(items.length>=8,`${scene}: at least eight curated terms`);
 assert(items.every(x=>x.id&&x.term&&x.meaning&&x.register&&x.usage&&x.caution),`${scene}: complete metadata`);
 assert(catalog.sources(scene).length>=2,`${scene}: at least two research sources`);
 assert(catalog.note(scene).length>40,`${scene}: contextual guidance`);
 console.log(`PASS ${scene}: ${items.length} terms, metadata and research refs`);
}
assert.equal(catalog.get('south-asia').length,0,'unresearched scene must not fabricate terms');
assert.match(catalog.note('south-asia'),/uydurma|yok/i,'fallback explicitly avoids invented jargon');
assert.match(html,/id="adlibJargonBank"/,'jargon picker exists');
assert.match(html,/scene-jargon-catalog\.js/,'catalog script loaded');
assert.match(app,/adlibJargonIds=Array\.from\(\$\('adlibJargonBank'\)/,'only selected jargon IDs enter generation context');
assert.match(app,/Selected terms: \$\{jargonGuidance\}/,'selected terms enter vocal prompt');
assert.match(app,/NOT automatic ad-libs/,'lexical jargon distinguished from ad-libs');
assert.match(app,/renderAdlibJargonBank\(\)/,'jargon picker is populated');
assert.match(app,/No scene-jargon terms selected; do not invent local slang/,'empty selection blocks invented slang');
console.log('PASS unresearched cultures use safe empty fallback');
console.log('PASS UI and prompt integration; terms remain opt-in and separate from ad-libs');
console.log('STAGE 31 SCENE JARGON TESTS PASSED');
