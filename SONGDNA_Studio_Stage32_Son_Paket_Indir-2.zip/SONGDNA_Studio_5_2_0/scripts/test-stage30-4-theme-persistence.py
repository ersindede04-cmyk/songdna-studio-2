#!/usr/bin/env python3
"""Stage 30.4: theme bootstrap, persistence, system sync and theme identity checks."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'index.html').read_text(encoding='utf-8')
APP=(ROOT/'app.js').read_text(encoding='utf-8')
bootstrap=re.search(r'<script id="songdna-520-theme-bootstrap">([\s\S]*?)</script>',HTML)
assert bootstrap, 'early theme bootstrap missing'
logic=re.search(r"const themeMode=document\.getElementById\('themeMode'\);[\s\S]*?(?=/\* Full UI localization)",APP)
assert logic, 'theme controller block missing'
styles='\n'.join(re.findall(r'<style\b[^>]*>([\s\S]*?)</style>',HTML,re.I))

HARNESS=f'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#07090d"><style>{styles}</style></head><body>
{bootstrap.group(1)}
<main class="app"><header class="top"><button class="menu-button">Menu</button><div class="brand">SONGDNA</div></header>
<nav class="mobile-tabs"><button class="mobile-tab active">ÜRETİM</button><button class="mobile-tab">STYLES + LYRICS</button></nav>
<section class="section"><h2>Settings</h2><div class="field"><label for="themeMode">Tema</label><select id="themeMode"><option value="system">Sistem</option><option value="dark">Gece</option><option value="light">Gündüz</option></select></div>
<div class="choice-chip"><input type="checkbox" checked> Seçili seçenek</div><button class="btn">Action</button><button class="btn secondary">Secondary</button></section></main>
<script>{logic.group(0)}</script></body></html>'''

checks=[]
def record(name,ok,detail=''):
    checks.append(bool(ok));print(('PASS' if ok else 'FAIL')+' '+name+(f' — {detail}' if detail else ''))

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    for mode in ['dark','light','system']:
        for system_light in [False,True]:
            context=browser.new_context(viewport={'width':390,'height':844},color_scheme='light' if system_light else 'dark')
            context.add_init_script(f"(()=>{{const data={{songdna_theme:{mode!r}}};Object.defineProperty(window,'localStorage',{{value:{{getItem:k=>data[k]??null,setItem:(k,v)=>data[k]=String(v)}}}});window.__themeStore=data;}})()")
            page=context.new_page();page.set_content(HARNESS,wait_until='load')
            expected_light=mode=='light' or (mode=='system' and system_light)
            record(f'bootstrap {mode} / system_light={system_light}',page.locator('body').evaluate("e=>e.classList.contains('light')")==expected_light)
            record(f'color-scheme {mode} / system_light={system_light}',page.locator('html').evaluate("e=>getComputedStyle(e).colorScheme")==('light' if expected_light else 'dark'))
            record(f'status bar color {mode} / system_light={system_light}',page.locator('meta[name="theme-color"]').get_attribute('content')==('#F5F7FA' if expected_light else '#07090d'))
            page.locator('#themeMode').select_option('light' if not expected_light else 'dark')
            new_mode='light' if not expected_light else 'dark'
            new_light=new_mode=='light'
            record(f'change to {new_mode} applies immediately',page.locator('body').evaluate("e=>e.classList.contains('light')")==new_light)
            record(f'change to {new_mode} persists',page.evaluate("window.__themeStore.songdna_theme")==new_mode)
            record(f'change to {new_mode} updates status bar',page.locator('meta[name="theme-color"]').get_attribute('content')==('#F5F7FA' if new_light else '#07090d'))
            context.close()

    # System mode follows OS changes; explicit user choices remain fixed.
    context=browser.new_context(viewport={'width':390,'height':844},color_scheme='dark')
    context.add_init_script("(()=>{const data={songdna_theme:'system'};Object.defineProperty(window,'localStorage',{value:{getItem:k=>data[k]??null,setItem:(k,v)=>data[k]=String(v)}});window.__themeStore=data;})()")
    page=context.new_page();page.set_content(HARNESS,wait_until='load')
    page.emulate_media(color_scheme='light')
    record('system mode reacts to OS light-theme change',page.locator('body').evaluate("e=>e.classList.contains('light')"))
    page.locator('#themeMode').select_option('dark')
    page.emulate_media(color_scheme='light')
    record('manual dark preference is not overridden by OS changes',not page.locator('body').evaluate("e=>e.classList.contains('light')"))
    page.locator('#themeMode').select_option('system')
    page.emulate_media(color_scheme='dark')
    page.wait_for_function("!document.body.classList.contains('light')")
    record('returning to system mode follows OS dark-theme change',not page.locator('body').evaluate("e=>e.classList.contains('light')"))
    context.close()

    # Theme identity and legibility for interactive states.
    for theme in ['dark','light']:
        page=browser.new_page(viewport={'width':390,'height':844},color_scheme='dark' if theme=='dark' else 'light')
        page.set_content(HARNESS.replace('<body>','<body class="light">') if theme=='light' else HARNESS,wait_until='load')
        expected_bg='rgb(255, 208, 0)' if theme=='dark' else 'rgb(234, 241, 255)'
        tab=page.locator('.mobile-tab.active')
        bg=tab.evaluate('(e)=>getComputedStyle(e).backgroundColor')
        image=tab.evaluate('(e)=>getComputedStyle(e).backgroundImage')
        record(f'{theme}: selected navigation uses approved accent',expected_bg in bg or ('255, 208, 0' in image if theme=='dark' else '234, 241, 255' in image),f'{bg}; {image}')
        chip=page.locator('.choice-chip').evaluate('(e)=>({bg:getComputedStyle(e).backgroundColor,color:getComputedStyle(e).color})')
        record(f'{theme}: selected choice has readable foreground',bool(chip['color']) and chip['color']!='rgba(0, 0, 0, 0)')
        section=page.locator('.section').evaluate('(e)=>({bg:getComputedStyle(e).backgroundColor,color:getComputedStyle(e).color})')
        record(f'{theme}: settings surface and text are styled',bool(section['bg']) and bool(section['color']))
        control=page.locator('#themeMode').evaluate('(e)=>({bg:getComputedStyle(e).backgroundColor,color:getComputedStyle(e).color})')
        record(f'{theme}: theme selector has readable foreground',bool(control['color']) and control['color']!='rgba(0, 0, 0, 0)')
        page.close()
    browser.close()

# Source safeguards: early bootstrap, safe storage, legacy WebView listener fallback.
record('bootstrap runs before main application content',HTML.index('songdna-520-theme-bootstrap')<HTML.index('<main class="app">'))
record('theme storage access is guarded',"try{const saved=localStorage.getItem('songdna_theme')" in logic.group(0) and 'try{localStorage.setItem' in logic.group(0))
record('system theme listener supports modern and legacy WebView',"themeMedia.addEventListener('change',onSystemThemeChange)" in logic.group(0) and "themeMedia.addListener(onSystemThemeChange)" in logic.group(0))
record('invalid stored preference falls back to system',"['dark','light','system'].includes(saved)?saved:'system'" in logic.group(0))
record('user-approved yellow/blue theme definitions retained', 'body:not(.light) .mobile-tab.active' in HTML and 'body.light .mobile-tab.active' in HTML and '#ffd000' in HTML and '#EAF1FF' in HTML)
print(f'\nSTAGE 30.4 RESULT: {sum(checks)}/{len(checks)} passed')
if not all(checks): raise SystemExit(1)
