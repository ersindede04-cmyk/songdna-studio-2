const assert=require('assert');
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const m=app.match(/const GLOBAL_MUSIC_DNA=(\{.*?\});\nconst TECHNIQUE_MODULES/s);
assert(m,'embedded Music DNA catalog missing');
const embedded=JSON.parse(m[1]);
const source=JSON.parse(fs.readFileSync(path.join(root,'data/music_dna_global_v1_1.json'),'utf8'));
assert.equal(embedded.music_dna_profiles.length,66);
assert.equal(source.music_dna_profiles.length,66);
for(const p of source.music_dna_profiles){
  for(const key of ['classic_arrangement_guidance','modern_arrangement_guidance','hybrid_arrangement_guidance']){
    assert(p[key]&&p[key].length>180,`${p.id} missing ${key}`);
    assert.equal(embedded.music_dna_profiles.find(x=>x.id===p.id)[key],p[key],`${p.id} runtime mismatch for ${key}`);
  }
}
for(const key of ['productionArrangementMode','adlibAdaptationMode','adlibCultureSources','adlibPhraseBank'])assert(html.includes(`id="${key}"`),`missing UI ${key}`);
assert(/const requestedMode=\$\('productionArrangementMode'\)\?\.value\|\|'auto'/.test(app),'arrangement selection not read');
assert(/const modeKey=arrangementMode\+'_arrangement_guidance'/.test(app),'per-profile arrangement mode guidance not selected');
assert(/CROSS-CULTURAL AD-LIB ADAPTATION/.test(app),'cross-cultural adaptation instruction missing');
assert(/CROSS-CULTURAL AD-LIB LANGUAGE/.test(app),'original-language preservation instruction missing');
assert(/Automatic catalog recommendations \(use selectively when no manual phrases were chosen\)/.test(app),'automatic phrase suggestions not routed to vocal prompt');
assert(/Manual phrase selections override automatic recommendations/.test(app),'manual ad-lib priority missing');
assert(/const arrangementMode=c\.productionProfile\?\.arrangementMode/.test(app),'ad-lib recommendation ranking must consider arrangement mode');
assert(/function adlibSceneForCultureSource/.test(app),'culture source routing helper missing');
assert(/adlibCultureSources.*addEventListener/.test(app),'culture source UI change listener missing');
for(const file of ['www/app.js','android-wrapper/app/src/main/assets/www/app.js'])assert.equal(fs.readFileSync(path.join(root,file),'utf8'),app,`${file} differs from root app.js`);
for(const file of ['www/index.html','android-wrapper/app/src/main/assets/www/index.html'])assert.equal(fs.readFileSync(path.join(root,file),'utf8'),html,`${file} differs from root index.html`);
console.log('Stage 32 passed: 66 profiles x 3 arrangement guides, selectable arrangement modes, auto ad-lib guidance, multi-culture catalog routing, adaptation/original-language rules and web/Android parity.');
