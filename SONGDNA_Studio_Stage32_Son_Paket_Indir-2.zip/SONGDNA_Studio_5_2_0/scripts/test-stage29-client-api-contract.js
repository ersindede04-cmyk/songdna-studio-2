'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const backendServer = fs.readFileSync(path.join(root, 'backend', 'server.js'), 'utf8');
const backendPackage = JSON.parse(fs.readFileSync(path.join(root, 'backend', 'package.json'), 'utf8'));
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'BUILD_MANIFEST.json'), 'utf8'));
const checks = [
  ['client has one Lyrics endpoint call', (app.match(/postGemini\('\/api\/lyrics'/g) || []).length === 1],
  ['client has two Styles endpoint call paths', (app.match(/postGemini\('\/api\/style'/g) || []).length === 2],
  ['client has one Command endpoint call', (app.match(/postGemini\('\/api\/command'/g) || []).length === 1],
  ['server accepts all three endpoints', server.includes("['/api/lyrics', '/api/style', '/api/command']")],
  ['server returns command field', /command:\s*result\.text/.test(server)],
  ['server returns lyrics field', /lyrics:\s*result\.text/.test(server)],
  ['server returns style field', /style:\s*result\.text/.test(server)],
  ['backend deployment copy matches audited root server', backendServer === server],
  ['backend package declares Node 20+ and start command', backendPackage.engines?.node === '>=20' && backendPackage.scripts?.start === 'node server.js'],
  ['command parser allows client schema fields', ['genre','language','fusion','energy','leadVoice','backingVoice','adlib','vocalEffect','technique','bpm','theme','notes'].every(k => server.includes(`'${k}'`) || server.includes(`${k}:`) || server.includes(`parsed.${k}`))],
  ['manifest remains 5.2.0 / Android code 27', manifest.version === '5.2.0' && manifest.android.version_code === 27],
  ['Styles and Lyrics remain the only primary outputs', manifest.preserved.includes('two editable output fields: Styles and Lyrics')],
  ['web and root runtime assets are identical', ['app.js','index.html','adlib-catalog.js','global-cultural-adlib.js','genre-adlib-engine.js','saved-library.js','production-history.js'].every(name => fs.readFileSync(path.join(root,'www',name),'utf8') === fs.readFileSync(path.join(root,name),'utf8'))],
  ['all runtime script references resolve', ['saved-library.js','production-history.js','adlib-catalog.js','global-cultural-adlib.js','genre-adlib-engine.js','app.js'].every(name => fs.existsSync(path.join(root,'www',name)) && fs.readFileSync(path.join(root,'index.html'),'utf8').includes(`src=\"${name}\"`))]
];
let failed = 0;
for (const [label, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${label}`); if (!ok) failed++; }
if (failed) process.exit(1);
console.log(`STAGE 29 CLIENT/API CONTRACT TESTS PASSED (${checks.length}/${checks.length})`);
