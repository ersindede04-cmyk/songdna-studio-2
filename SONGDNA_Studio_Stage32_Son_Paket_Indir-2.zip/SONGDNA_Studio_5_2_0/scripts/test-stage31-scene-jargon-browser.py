#!/usr/bin/env python3
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'app.js').read_text(encoding='utf-8')
CAT=(ROOT/'scene-jargon-catalog.js').read_text(encoding='utf-8')
fn=re.search(r'function renderAdlibJargonBank\(\)\{[^\n]*\}',APP)
assert fn, 'renderAdlibJargonBank function missing'
harness='''<!doctype html><html><body>
<select id="adlibScene"><option value="france">France</option><option value="us">US</option><option value="uk">UK</option><option value="germany">Germany</option><option value="uk">UK</option><option value="us">US</option><option value="turkey">Turkey</option><option value="south-asia">South Asia</option></select>
<select id="adlibJargonBank" multiple></select><div id="adlibJargonHelp"></div>
<script>__CAT__</script><script>
const $=id=>document.getElementById(id);
const languageLabel=()=> 'English';
const selectedGlobalProfile=()=>null;
const resolveDefaultAdlibCulture=(language,override)=>({scene:override==='auto'?'none':override,label:override,status:'user-selected'});
__FN__
$('adlibScene').addEventListener('change',renderAdlibJargonBank);
renderAdlibJargonBank();
</script></body></html>'''
harness=harness.replace('__CAT__',CAT).replace('__FN__',fn.group(0))
checks=[]
def record(name,ok,detail=''):
 checks.append(bool(ok));print(('PASS ' if ok else 'FAIL ')+name+(f' — {detail}' if detail else ''))
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page();page.set_content(harness,wait_until='load')
 for scene,expected in [('france',8),('germany',8),('uk',10),('us',8),('turkey',8),('south-asia',0)]:
  page.locator('#adlibScene').select_option(scene)
  count=page.locator('#adlibJargonBank option').count()
  record(f'{scene}: scene change loads the right jargon pool',count==expected,f'{count}/{expected}')
  if expected:
   first=page.locator('#adlibJargonBank option').first
   record(f'{scene}: term shows meaning and metadata',bool(first.text_content()) and bool(first.get_attribute('title')))
  else:
   record('unresearched scene: empty safe fallback is explained','uydurulmaz' in page.locator('#adlibJargonHelp').inner_text().lower())
 page.locator('#adlibScene').select_option('france')
 page.locator('#adlibJargonBank').select_option(['fr-meuf','fr-chelou'])
 record('manual multi-selection is available',page.locator('#adlibJargonBank').evaluate("e=>Array.from(e.selectedOptions).map(x=>x.value)")==['fr-meuf','fr-chelou'])
 page.locator('#adlibScene').select_option('germany')
 record('selection does not leak across cultures',page.locator('#adlibJargonBank').evaluate('e=>e.selectedOptions.length')==0)
 browser.close()
print(f'\nSTAGE 31 BROWSER RESULT: {sum(checks)}/{len(checks)} passed')
if not all(checks): raise SystemExit(1)
