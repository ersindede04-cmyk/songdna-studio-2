#!/usr/bin/env python3
"""Stage 30.3: browser layout checks for editable Styles/Lyrics output cards."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'index.html').read_text(encoding='utf-8')
STYLES = '\n'.join(re.findall(r'<style\b[^>]*>([\s\S]*?)</style>', SOURCE, re.I))
HARNESS = f'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>{STYLES}</style></head><body>
<main class="app"><header class="top">SONGDNA</header><section class="hero"><h1>Şarkının DNA'sını tasarla.</h1></section>
<nav class="mobile-tabs"><button class="mobile-tab">✦ ÜRETİM</button><button class="mobile-tab active">♫ STYLES + LYRICS</button></nav>
<div id="generatorPanel" class="tab-panel">Generator</div>
<div id="resultsPanel" class="tab-panel active"><section class="section" id="results"><h2>STYLES ve LYRICS</h2><button class="btn secondary" id="styleGenerate">STYLES’I YENİDEN OLUŞTUR</button><div class="split-outputs">
<div class="output-card style-card"><h3 id="styleOutputTitle">STYLES · Müzik Tarzı</h3><textarea id="styleResult" class="result-editor" aria-labelledby="styleOutputTitle">A long Styles prompt wraps safely across the available output width.</textarea><div class="actions"><button class="btn secondary" id="copyStyle">Stili Kopyala</button><button class="btn secondary" id="clearStyle">Temizle</button></div></div>
<div class="output-card lyrics-card"><h3 id="lyricsOutputTitle">LYRICS · Şarkı Sözleri</h3><textarea id="lyricsResult" class="result-editor lyrics-editor" aria-labelledby="lyricsOutputTitle">[Verse 1] A long lyrics content line that remains editable without forcing horizontal scrolling.</textarea><div class="actions"><button class="btn secondary" id="copyLyrics">Sözleri Kopyala</button><button class="btn secondary" id="clearLyrics">Temizle</button></div></div>
</div></section></div><footer class="footer">Footer</footer></main></body></html>'''

checks=[]
# Keep the source, browser runtime and Android WebView copies byte-identical.
for name in ['index.html','app.js','adlib-catalog.js','global-cultural-adlib.js','genre-adlib-engine.js','saved-library.js','production-history.js']:
    root=(ROOT/name).read_bytes()
    record_name=f'{name}: root/www/Android assets identical'
    www=(ROOT/'www'/name)
    android=(ROOT/'android-wrapper/app/src/main/assets/www'/name)
    checks.append(www.exists() and android.exists() and www.read_bytes()==root and android.read_bytes()==root)
    print(('PASS' if checks[-1] else 'FAIL')+' '+record_name)

# Confirm copy handlers and accessible labels remain wired in the real source.
APP=(ROOT/'app.js').read_text(encoding='utf-8')
for name, ok in [
    ('Styles copy handler preserved', "$('copyStyle').onclick" in APP),
    ('Lyrics copy handler preserved', "$('copyLyrics').onclick" in APP),
    ('Styles output remains editable', "$('styleResult').addEventListener('input'" in APP),
    ('Lyrics output remains editable', "$('lyricsResult').addEventListener('input'" in APP),
    ('Styles textarea has accessible heading', 'aria-labelledby="styleOutputTitle"' in SOURCE),
    ('Lyrics textarea has accessible heading', 'aria-labelledby="lyricsOutputTitle"' in SOURCE),
]:
    checks.append(ok)
    print(('PASS' if ok else 'FAIL')+' '+name)

def record(name, ok, detail=''):
    checks.append(bool(ok))
    print(('PASS' if ok else 'FAIL') + ' ' + name + (f' — {detail}' if detail else ''))

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
    cases=[(390,844,'phone-portrait',False),(760,1024,'small-tablet-portrait',False),(900,1200,'tablet-portrait',False),(900,700,'small-tablet-landscape',False),(1024,768,'tablet-landscape',True),(1179,820,'large-tablet-landscape',True),(1280,800,'desktop',True)]
    for width,height,label,two_columns in cases:
        page=browser.new_page(viewport={'width':width,'height':height})
        page.set_content(HARNESS,wait_until='load')
        result=page.locator('#resultsPanel')
        split=page.locator('.split-outputs')
        style=page.locator('.style-card')
        lyrics=page.locator('.lyrics-card')
        record(f'{label}: output screen visible',result.evaluate("e=>getComputedStyle(e).display")!='none')
        layout=page.evaluate('''() => { const a=document.querySelector('.style-card').getBoundingClientRect(); const b=document.querySelector('.lyrics-card').getBoundingClientRect(); return Math.abs(a.y-b.y)<2 && b.x>a.x; }''')
        record(f'{label}: expected output columns',layout==two_columns,'side-by-side' if layout else 'stacked')
        record(f'{label}: both output cards fit their grid cells',style.evaluate('(e)=>e.getBoundingClientRect().width>0') and lyrics.evaluate('(e)=>e.getBoundingClientRect().width>0'))
        overflow=page.evaluate('''() => { const s=document.querySelector('.split-outputs').getBoundingClientRect(); const a=document.querySelector('.style-card').getBoundingClientRect(); const b=document.querySelector('.lyrics-card').getBoundingClientRect(); return Math.max(a.right,b.right)<=s.right+1 && Math.min(a.left,b.left)>=s.left-1 && document.documentElement.scrollWidth<=window.innerWidth+1; }''')
        record(f'{label}: no horizontal output overflow',overflow)
        for selector in ['#styleResult','#lyricsResult']:
            fit=page.locator(selector).evaluate('(e)=>e.getBoundingClientRect().width<=e.parentElement.getBoundingClientRect().width+1 && getComputedStyle(e).overflowWrap!="normal"')
            record(f'{label}: {selector} fits and wraps',fit)
        buttons=page.locator('.output-card .actions .btn')
        record(f'{label}: four output action buttons present',buttons.count()==4)
        min_height=page.locator('#copyStyle').evaluate('(e)=>e.getBoundingClientRect().height')
        record(f'{label}: copy/clear controls touch-sized',min_height>=44,f'{min_height:.0f}px')
        page.close()

    # Theme preference checks: selected colors remain intentionally yellow/blue.
    for theme,expected,label in [('dark','#ffd000','dark-yellow'),('light','#eaf1ff','light-blue')]:
        page=browser.new_page(viewport={'width':390,'height':844})
        page.set_content(HARNESS.replace('<body>', '<body class=\"light\">') if theme=='light' else HARNESS,wait_until='load')
        style=page.locator('.mobile-tab.active').evaluate('(e)=>({background:getComputedStyle(e).background,backgroundColor:getComputedStyle(e).backgroundColor,backgroundImage:getComputedStyle(e).backgroundImage})')
        expected_color='rgb(234, 241, 255)' if theme=='light' else 'rgb(255, 208, 0)'
        record(f'{label}: selected tab theme color remains intentional',expected_color in style['background'] or expected_color in style['backgroundColor'],str(style))
        page.close()
    browser.close()

passed=sum(checks)
print(f'\n{passed}/{len(checks)} Stage 30.3 browser layout checks passed')
if passed!=len(checks): raise SystemExit(1)
