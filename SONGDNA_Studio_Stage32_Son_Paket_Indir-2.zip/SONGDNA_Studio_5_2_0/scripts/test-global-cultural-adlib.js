const assert=require('assert');
const registry=require('../www/global-cultural-adlib.js');
const catalog=require('../www/adlib-catalog.js');
const fs=require('fs');
const js=fs.readFileSync(__dirname+'/../www/app.js','utf8');
const html=fs.readFileSync(__dirname+'/../www/index.html','utf8');
assert.strictEqual(registry.profiles.length,28,'all 28 language profiles must remain');
const expected=[
 ['Türkçe','turkey','reviewed-phrase-catalog'],['Français · Fransızca','france','reviewed-phrase-catalog'],['Deutsch · Almanca','germany','reviewed-phrase-catalog'],
 ['English · İngilizce','english','shared-language-catalog'],['Español · İspanyolca','spanish','shared-language-catalog'],
 ['Azərbaycan dili','azerbaijan','provisional-language-pool'],['العربية · Arapça (Standart)','west-asia','regional-fallback'],['Arapça · Mısır lehçesi','north-africa','regional-fallback'],['Arapça · Levant','west-asia','regional-fallback'],['فارسی · Farsça','west-asia','regional-fallback'],['Русский · Rusça','eastern-europe-eurasia','regional-fallback'],['Ελληνικά · Yunanca','europe','regional-fallback'],['हिन्दी · Hintçe','south-asia','regional-fallback'],['اردو · Urduca','south-asia','regional-fallback'],['বাংলা · Bengalce','south-asia','regional-fallback'],['ਪੰਜਾਬੀ · Pencapça','south-asia','regional-fallback'],['Português · Brezilya','latin-america','regional-fallback'],['Português · Avrupa','europe','regional-fallback'],['Italiano · İtalyanca','europe','regional-fallback'],['한국어 · Korece','east-asia','regional-fallback'],['日本語 · Japonca','east-asia','regional-fallback'],['中文 · Mandarin','east-asia','regional-fallback'],['Bahasa Indonesia','southeast-asia','regional-fallback'],['Tiếng Việt','southeast-asia','regional-fallback'],['ไทย · Tayca','southeast-asia','regional-fallback'],['Kiswahili · Svahili','east-africa','regional-fallback'],['Kurmancî · Kürtçe','west-asia','regional-fallback'],['سۆرانی · Kürtçe','west-asia','regional-fallback']
];
for(const [label,scene,status] of expected){const p=registry.resolve(label);assert.strictEqual(p.scene,scene,label+' scene');assert.strictEqual(p.status,status,label+' status');if(p.status==='regional-fallback')assert(catalog.get(scene).length>0,label+' must resolve only to a generic regional bridge');}
const cross=registry.resolve('Türkçe','france');assert.strictEqual(cross.scene,'france');assert.strictEqual(cross.source,'manual-override');assert.strictEqual(cross.language,'Turkish');
const manualUs=registry.resolve('English · İngilizce','us');assert.strictEqual(manualUs.scene,'us');
assert.strictEqual(registry.resolve('Türkçe','auto','MDNA-025').scene,'hindustani');
assert.strictEqual(registry.resolve('Türkçe','auto','MDNA-043').scene,'pansori');
assert(js.includes('SongDnaGlobalCulturalAdlib?.resolve'));
assert(js.includes('adlibCatalogStatus'));
assert(html.includes('global-cultural-adlib.js'));
console.log('Global Cultural Ad-lib tests passed: 28 profiles, current English/Spanish shared pools, regional fallbacks, manual override and Stage 25 DNA routes.');
