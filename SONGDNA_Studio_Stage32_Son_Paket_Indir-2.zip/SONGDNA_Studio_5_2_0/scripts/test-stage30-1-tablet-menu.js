'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const checks = [];
function check(name, condition) {
  checks.push({ name, pass: Boolean(condition) });
  console.log(`${condition ? 'PASS' : 'FAIL'} ${name}`);
}
const start = html.indexOf('<style id="songdna-520-stage30-1-tablet-aux-navigation">');
const end = html.indexOf('</style>', start);
const patch = start >= 0 && end >= 0 ? html.slice(start, end + 8) : '';
check('Stage 30.1 responsive override is present', Boolean(patch));
check('Tablet breakpoint includes 760–1179px', /@media\s*\(min-width:\s*760px\)\s*and\s*\(max-width:\s*1179px\)/.test(patch));
check('Tablet auxiliary panels become visible when active', /#templatePanel\.active[\s\S]*?#dnaPanel\.active[\s\S]*?display:\s*block\s*!important/.test(patch));
check('Tablet auxiliary panels receive a dedicated full-width grid row', /grid-template-areas:\s*"top top"\s*"hero hero"\s*"nav generator"\s*"nav results"\s*"aux aux"\s*"footer footer"/.test(patch) && /grid-area:\s*aux\s*!important/.test(patch));
check('Wide-screen auxiliary panels become visible when active', /@media\s*\(min-width:\s*1180px\)[\s\S]*?#templatePanel\.active[\s\S]*?display:\s*block\s*!important/.test(patch));
check('Drawer actions still activate the requested panel', /\[data-open-screen\][\s\S]*?activateScreen\(id\)/.test(app));
check('Main navigation remains exactly two tabs', (html.match(/class="mobile-tab(?: active)?"/g) || []).length === 2);
check('Dark-theme selected state remains yellow', /body:not\(\.light\) \.mobile-tab\.active\{[^}]*#ffd400/i.test(html));
check('Light-theme selected state remains blue', /body\.light \.mobile-tab\.active\{[^}]*#2563eb/i.test(html));
check('Styles and Lyrics output cards remain present', /id="styleResult"/.test(html) && /id="lyricsResult"/.test(html));
const copies = [
  path.join(root, 'www', 'index.html'),
  path.join(root, 'android-wrapper', 'app', 'src', 'main', 'assets', 'www', 'index.html')
];
for (const file of copies) check(`${path.relative(root, file)} matches root index.html`, fs.readFileSync(file, 'utf8') === html);
const failed = checks.filter(x => !x.pass);
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed`);
if (failed.length) process.exit(1);
