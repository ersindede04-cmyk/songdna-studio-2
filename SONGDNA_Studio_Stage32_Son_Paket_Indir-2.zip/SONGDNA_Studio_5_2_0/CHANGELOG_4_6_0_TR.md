# SONGDNA Studio 4.6.0 – Değişiklikler

- 4.5.0 geliştirici kaynak paketi temel alındı; mevcut Music DNA kataloğu ve iki Suno çıktı alanı korundu.
- Yeni Doğal Dil Komutu alanı eklendi. Kullanıcı Türkçe veya başka bir dilde şarkı isteğini yazar; Gemini komutu yapılandırılmış JSON olarak çözümler.
- Yalnızca açıkça belirtilen seçimler uygulanır: Music DNA, şarkı dili, füzyon, enerji, vokal, ad-lib, efekt, teknik modül, BPM, konu ve yaratıcı talimat.
- Belirtilmeyen seçimler korunur; arayüz dili ve şarkı dili birbirinden bağımsızdır.
- Backend'e /api/command uç noktası eklendi. Mevcut /api/lyrics ve /api/style akışları korunmuştur.
- Sürüm 4.6.0 / Android versionCode 20.

Gemini komut yorumlar ve Suno metinlerini hazırlar; gerçek ses üretimini Suno yapar. Canlı API/cihaz testleri yayın öncesi gereklidir.
