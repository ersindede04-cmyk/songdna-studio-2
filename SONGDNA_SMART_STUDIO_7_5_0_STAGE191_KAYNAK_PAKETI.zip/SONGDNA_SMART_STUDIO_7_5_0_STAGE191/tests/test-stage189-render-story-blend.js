'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const backend = fs.readFileSync(path.join(root, 'backend/server.js'), 'utf8');
const rootServer = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const app = fs.readFileSync(path.join(root, 'www/app.js'), 'utf8');
const render = fs.readFileSync(path.join(root, 'render.yaml'), 'utf8');
const checks = [
  ['Render Root Directory backend', render.includes('rootDir: backend')],
  ['Render build command npm install', render.includes('buildCommand: npm install')],
  ['Render start command npm start', render.includes('startCommand: npm start')],
  ['Render health check /health', render.includes('healthCheckPath: /health')],
  ['Story blend endpoint allowlisted', backend.includes("'/api/story-blend'")],
  ['Story blend task routed', backend.includes("url.pathname === '/api/story-blend'")],
  ['Story response contract returned', backend.includes('story: result.text')],
  ['Client calls matching endpoint', app.includes("postGemini('/api/story-blend',prompt)")],
  ['Client reads story response', app.includes('response.story||response.text')],
  ['Health identifies Stage191', backend.includes('stage: 191')],
  ['Health advertises storyBlend', backend.includes('storyBlend: true')],
  ['Normal lyrics endpoint preserved', backend.includes("'/api/lyrics'")],
  ['Normal style endpoint preserved', backend.includes("'/api/style'")],
  ['Root and backend server copies identical', rootServer === backend]
];
let failed = 0;
for (const [label, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${label}`); if (!ok) failed++; }
console.log(`\\n${checks.length - failed}/${checks.length} checks passed`);
if (failed) process.exit(1);
