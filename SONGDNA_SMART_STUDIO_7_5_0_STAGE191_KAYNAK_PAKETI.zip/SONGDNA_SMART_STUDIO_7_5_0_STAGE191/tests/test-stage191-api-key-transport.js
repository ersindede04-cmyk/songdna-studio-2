'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const backend = fs.readFileSync(path.join(root, 'backend/server.js'), 'utf8');
const rootServer = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
assert.equal(rootServer, backend, 'root and backend server copies must remain byte-identical');
assert.match(backend, /headers:\s*\{\s*'Content-Type':\s*'application\/json',\s*'x-goog-api-key':\s*GEMINI_API_KEY\s*\}/,
  'Gemini API key must be sent in the x-goog-api-key header');
assert.doesNotMatch(backend, /generativelanguage\.googleapis\.com[^\n]*\?key=/,
  'Gemini API key must not be placed in the request URL');
assert.match(backend, /normalizeStoryBlendPrompt/);
assert.match(backend, /url\.pathname === '\/api\/story-blend'/);
assert.match(backend, /'\/api\/lyrics'/);
assert.match(backend, /stage:\s*191/);
console.log('PASS Stage191 Gemini API key header transport, no query-string key, story-blend route, lyrics route and source parity');
