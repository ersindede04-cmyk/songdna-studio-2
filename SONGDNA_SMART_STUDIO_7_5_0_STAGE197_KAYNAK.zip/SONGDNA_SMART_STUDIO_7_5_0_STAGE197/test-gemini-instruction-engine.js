const fs=require('fs');
const js=fs.readFileSync('www/app.js','utf8');
const checks=[
 ['shared instruction envelope exists',/function buildGeminiInstructionEnvelope\(kind,c,basePrompt=''/],
 ['explicit priority order exists',/explicit user instructions.*current UI selections.*selected DNA profiles.*automatic suggestions/s],
 ['two-output contract is explicit',/Use only the two Suno outputs: STYLES and LYRICS/],
 ['lyrics contract integrated',/buildGeminiInstructionEnvelope\('lyrics',currentContext,makeLyricsPrompt\(currentContext\)\)/],
 ['central Styles builder exists',/function buildGeminiStylePrompt\(c,baseStyle,exclude=''/],
 ['automatic Styles call uses central builder',/const stylePrompt=buildGeminiStylePrompt\(snap,generatedResult\.style,generatedResult\.exclude\)/],
 ['manual Styles call uses central builder',/const prompt=buildGeminiStylePrompt\(snapshot,last\.style,last\.exclude\)/],
 ['user choices remain authoritative',/Never silently replace, remove or reinterpret a user selection/],
 ['no additional token counting API',!/countTokens\s*\(/.test(js)],
 ['no new third output field',!/introOutput|thirdOutputField/.test(js)]
];
let failed=0;
for(const [label,pattern] of checks){const ok=pattern instanceof RegExp?pattern.test(js):pattern;console.log(`${ok?'PASS':'FAIL'} ${label}`);if(!ok)failed++;}
const lyricsCalls=(js.match(/postGemini\('\/api\/lyrics'/g)||[]).length;
const styleCalls=(js.match(/postGemini\('\/api\/style'/g)||[]).length;
console.log(`${lyricsCalls===1?'PASS':'FAIL'} exactly one existing Lyrics endpoint call site`);
console.log(`${styleCalls===2?'PASS':'FAIL'} two existing Styles call paths (automatic + manual)`);
if(lyricsCalls!==1||styleCalls!==2)failed++;
if(failed)process.exit(1);
console.log('GEMINI INSTRUCTION ENGINE TESTS PASSED');

// Stage162 backend lyric-quality instruction contract
const backend = fs.readFileSync(require('path').join(__dirname, 'backend/server.js'), 'utf8');
const stage162Checks = [
  ['Stage162 quality engine is attached only to lyrics task', /if \(task === 'lyrics'\) \{\s*systemText \+= `\\n\\nSTAGE162 UNIVERSAL SONGWRITING QUALITY ENGINE/.test(backend)],
  ['native-language composition is mandatory', /NATIVE COMPOSITION: Think and compose directly in the requested language/.test(backend)],
  ['traditional vocal safety prevents unsupported backing vocals', /TRADITIONAL VOCAL SAFETY:.*?do not add female backing vocals/s.test(backend)],
  ['explicit user vocal choices remain authoritative', /A user's explicit vocal choice remains authoritative/.test(backend)],
  ['traditional forms are not forced into pop structure', /without forcing a pop chorus onto forms that do not use one/.test(backend)],
  ['silent editorial gates cover originality and singability', /SILENT EDITORIAL GATES:.*?singability/s.test(backend) && /SILENT EDITORIAL GATES:.*?originality/s.test(backend)],
  ['Styles and other task contracts remain separate', /if \(task === 'lyrics'\)/.test(backend) && /maximum 1000 characters/.test(backend)]
];
let stage162Failed = 0;
for (const [label, ok] of stage162Checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${label}`); if (!ok) stage162Failed++; }
if (stage162Failed) process.exit(1);
console.log('STAGE162 GEMINI QUALITY CONTRACT TESTS PASSED');
