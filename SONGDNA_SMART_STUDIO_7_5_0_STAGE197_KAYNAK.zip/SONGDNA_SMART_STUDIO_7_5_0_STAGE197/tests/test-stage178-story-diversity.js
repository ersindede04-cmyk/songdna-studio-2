const assert=require('node:assert/strict');
const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
const store=new Map();const sandbox={localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,String(v))}};sandbox.globalThis=sandbox;
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../story-diversity-engine.js'),'utf8'),sandbox);
const e=sandbox.SongDnaStoryDiversityEngine;assert.ok(e);
assert.deepEqual(Array.from(e.families('Fabrika düdüğü öttü, vardiyadan çıktım ve servise bindim.')),['work_shift']);
e.remember('Bir vardiya gecesi','Fabrika düdüğü öttü, vardiyadan çıktım, yine yorgunum; servise bindim.');
assert.equal(e.read().length,1);assert.ok(e.guidance('Bir dostun sırrı').includes('work_shift'));
const options=['Gece vardiyasından çıkan birinin gün doğumuna kadar yürüyüşü','Bir pazar yerinde duyulan tek cümlenin bütün günü değiştirmesi','Bir sahil kasabasında sezon bitince kalan sessizlik'];
for(let i=0;i<20;i++){const pick=e.choose(options);assert.notEqual(pick,options[0]);}
const backup=require('../data-backup.js');const payload=backup.create({getItem:k=>k==='songdna_story_diversity_v1'?'{}':null});assert.ok(payload.data.songdna_story_diversity_v1);
console.log('Stage178 narrative scene diversity: PASS');
