const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const files = [
  'app.js',
  'www/app.js',
  'android-wrapper/app/src/main/assets/app.js',
  'android-wrapper/app/src/main/assets/www/app.js'
];
const sources = files.map(file => fs.readFileSync(path.join(root, file), 'utf8'));
const backend = fs.readFileSync(path.join(root, 'backend/server.js'), 'utf8');
const required = [
  'userTopicAnchors:c.theme||\'\'',
  'userExactPhrases:c.localWords||\'\'',
  'USER-CONTENT FIDELITY CONTRACT — HIGH PRIORITY',
  'every distinct meaningful item',
  'reproduce that phrase verbatim at least once',
  'If a meaningful user-provided anchor is missing, revise the lyrics',
  'SONGWRITING QUALITY & EDITORIAL PASS — STAGE159',
  'Use rhyme and sound patterning with intention',
  'Give the chorus one distinctive, emotionally central and easy-to-sing hook',
  "perform a silent editor's pass",
];
for (const file of files) {
  const source = fs.readFileSync(path.join(root, file), 'utf8');
  for (const token of required) {
    if (!source.includes(token)) throw new Error(`${file}: missing ${token}`);
  }
  if (!source.includes("prompt=buildGeminiInstructionEnvelope('lyrics',currentContext,makeLyricsPrompt(currentContext))")) {
    throw new Error(`${file}: Lyrics generation route changed`);
  }
}
if (new Set(sources).size !== 1) throw new Error('Four app.js runtime copies are not byte-identical');
if (!/USER-CONTENT\s+FIDELITY\s+IS\s+MANDATORY/.test(backend)) throw new Error('backend/server.js: missing server-level creative fidelity rule');
if (!/STAGE159\s+SONGWRITING QUALITY STANDARD/.test(backend)) throw new Error('backend/server.js: missing Stage159 quality standard');
console.log('PASS Stage157 user creative input fidelity contract; four app.js copies identical and backend policy present');
