Stage 70 deployment baseline retained; current application release: 7.6.0 on Stage197 infrastructure.

# SONGDNA SMART STUDIO 7.5.0 — Stage197 Render Kurulum Rehberi

Bu aşama, telefondan GitHub deposuna yalnızca ZIP dosyası yükleyebilen kullanım için hazırlanmıştır. Stage197 kaynak ZIP dosyasını GitHub deposunun ana dizinine tek dosya olarak yükleyin. Eski dosyaları silmeniz gerekmez.

## Render > Settings > Build & Deploy

- Branch: `main`
- Root Directory: **boş bırakın**
- Build Command:

```bash
mkdir -p render-stage197-source && unzip -o SONGDNA_SMART_STUDIO_7_5_0_STAGE197_KAYNAK.zip -d render-stage197-source && npm --prefix render-stage197-source/SONGDNA_SMART_STUDIO_7_5_0_STAGE197/backend install --omit=dev
```

- Start Command:

```bash
npm --prefix render-stage197-source/SONGDNA_SMART_STUDIO_7_5_0_STAGE197/backend start
```

## Render > Environment

Mevcut `GEMINI_API_KEY` ve `APP_ACCESS_TOKEN` değerlerini değiştirmeyin. Aşağıdaki değişkeni ekleyin:

- `NODE_VERSION` = `22.16.0`

`GEMINI_API_KEY_2` eklemeyin. API anahtarını ZIP içine veya GitHub'a koymayın.

## Dağıtım

1. GitHub'a `SONGDNA_SMART_STUDIO_7_5_0_STAGE197_KAYNAK.zip` dosyasını depo ana dizinine yükleyin.
2. Render'da servis ayarlarını yukarıdaki gibi düzenleyin.
3. İlk geçişte **Manual Deploy > Clear build cache & deploy** seçeneğini kullanın.
4. Build başarılı olursa `/health` adresini açın. JSON yanıtında `"stage":197` ve `"service":"SONGDNA SMART STUDIO 7.5.0 Stage197 AI"` görünmelidir.

## Neden eski dosyalar silinmiyor?
Build komutu ZIP'i `render-stage197-source` adlı ayrı klasöre açar. Start komutu da yalnızca bu klasördeki Stage197 backend'i çalıştırır. Böylece depodaki Stage190 veya başka eski dosyalar silinmez; çalışan servis komutla Stage197 klasörüne yönlendirilir.

Not: GitHub'a ZIP yüklemek tek başına Render ayarlarını değiştirmez. Render Build Command, Start Command ve `NODE_VERSION` bir defa ayarlanmalıdır. Bu rehberdeki canlı dağıtım henüz yapılmış değildir.
