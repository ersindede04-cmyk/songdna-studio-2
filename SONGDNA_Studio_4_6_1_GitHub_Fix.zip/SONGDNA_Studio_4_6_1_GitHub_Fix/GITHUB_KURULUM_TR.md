# SONGDNA Studio 4.6.1 — GitHub kurulumu

## Önemli: ZIP klasör yapısı

Bu ZIP'in içinde `SONGDNA-Studio-4.6.1` adlı bir ana klasör vardır. Yeni workflow iki yerleşimi de tanır:

- **Önerilen:** ZIP'i açın ve `SONGDNA-Studio-4.6.1` klasörünün İÇİNDEKİ tüm dosya ve klasörleri GitHub deposunun ana dizinine yükleyin.
- **Alternatif:** `SONGDNA-Studio-4.6.1` klasörünün tamamını depo ana dizinine yükleyin. Workflow bu iç içe yerleşimi de otomatik bulur.

Doğru proje kökünde `scripts/verify-source.py`, `android-wrapper`, `backend`, `www` ve `.github` bulunmalıdır. `.github/workflows/build-apk.yml` dosyası GitHub deposunda `.github/workflows/` konumunda olmalıdır ki Actions iş akışı listelensin.

## Android APK oluşturma

1. GitHub deposunu açın ve **Code** bölümünde proje dosyalarının yüklendiğini kontrol edin.
2. **Actions** bölümüne girin.
3. **SONGDNA Studio 4.6.1 - Android APK** iş akışını seçin.
4. **Run workflow** düğmesine basın.
5. İşlem tamamlanınca başarılı çalışmayı açın. Sayfanın altındaki **Artifacts** bölümünden `SONGDNA-Studio-4.6.1-debug-APK` dosyasını indirin.

Debug APK, imzalama anahtarları olmadan da oluşturulur. İmzalı Release APK yalnızca aşağıdaki dört GitHub Secret'ın tamamı tanımlanmışsa ayrıca üretilir:

- `SONGDNA_KEYSTORE_BASE64`
- `SONGDNA_KEYSTORE_PASSWORD`
- `SONGDNA_KEY_ALIAS`
- `SONGDNA_KEY_PASSWORD`

Keystore dosyasını depoya veya ZIP'e yüklemeyin. Aynı uygulamanın sonraki sürümlerini güncelleyebilmek için mevcut imzalama anahtarını ve alias'ı koruyun.

## Render / Gemini

APK derlemek, Render backend'ini güncellemez. 4.6.1'in doğal dil komut yorumlayıcısı için `backend/server.js` dosyasını ayrıca Render servisine dağıtın. Render ortamında `.env.example` içindeki gerekli değişkenleri tanımlayın. `GEMINI_API_KEY` hiçbir zaman APK'ya veya GitHub deposuna konulmamalıdır.
