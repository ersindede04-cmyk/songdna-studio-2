#!/usr/bin/env python3
"""Static source integrity checks for SONGDNA Studio 5.0.0."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    ".github/workflows/build-apk.yml", "android-wrapper/settings.gradle.kts",
    "android-wrapper/build.gradle.kts", "android-wrapper/gradle.properties",
    "android-wrapper/app/build.gradle.kts", "android-wrapper/app/src/main/AndroidManifest.xml",
    "android-wrapper/app/src/main/java/com/songdna/studio/MainActivity.kt",
    "android-wrapper/app/src/main/assets/www/index.html", "android-wrapper/app/src/main/assets/www/app.js",
    "www/index.html", "www/app.js", "backend/server.js", "backend/package.json", "backend/.env.example",
]
missing = [x for x in REQUIRED if not (ROOT / x).is_file()]
if missing:
    raise SystemExit("FAIL missing files:\n- " + "\n- ".join(missing))
print("PASS required project files")

# ZIP packages may be stored in the repository root for release/build history.
# Reject only ZIP archives nested inside the actual source directories.
source_dirs = [ROOT / name for name in ("www", "android-wrapper", "backend", "scripts")]
nested_archives = [
    item for folder in source_dirs if folder.exists()
    for item in folder.rglob("*") if item.is_file() and item.suffix.lower() == ".zip"
]
if nested_archives:
    raise SystemExit("FAIL nested ZIP archive in source tree:\n- " + "\n- ".join(str(item.relative_to(ROOT)) for item in nested_archives))
web = (ROOT / "www/index.html").read_bytes()
web_js = (ROOT / "www/app.js").read_bytes()
if web != (ROOT / "android-wrapper/app/src/main/assets/www/index.html").read_bytes():
    raise SystemExit("FAIL web/android HTML mismatch")
if web_js != (ROOT / "android-wrapper/app/src/main/assets/www/app.js").read_bytes():
    raise SystemExit("FAIL web/android JavaScript mismatch")
if b'<script src="app.js" defer></script>' not in web:
    raise SystemExit("FAIL external app.js script reference missing")
print("PASS web and Android HTML/JS parity")

for path in (ROOT / "android-wrapper/app/src/main").rglob("*.xml"):
    ET.parse(path)
print("PASS Android XML parsing")

settings = (ROOT / "android-wrapper/settings.gradle.kts").read_text()
gradle = (ROOT / "android-wrapper/app/build.gradle.kts").read_text()
manifest = (ROOT / "android-wrapper/app/src/main/AndroidManifest.xml").read_text()
workflow = (ROOT / ".github/workflows/build-apk.yml").read_text()
checks = {
    'rootProject.name = "SONGDNA-Studio-5.1.0"' in settings: "Gradle project name",
    'versionName = "5.1.0"' in gradle and 'versionCode = 25' in gradle: "app version 5.1.0 / code 25",
    'applicationId = "com.songdna.studio"' in gradle: "stable application ID",
    'jvmTarget = "17"' in gradle and 'targetCompatibility = JavaVersion.VERSION_17' in gradle: "Java/Kotlin target 17",
    'android:allowBackup="false"' in manifest: "Android backup disabled",
    'android:usesCleartextTraffic="false"' in manifest: "cleartext disabled",
    "assembleDebug" in workflow and "actions/upload-artifact@v4" in workflow: "debug APK workflow",
    "SONGDNA_KEYSTORE_BASE64" in workflow and "assembleRelease" in workflow: "conditional signed release workflow",
}
failed = [label for ok, label in checks.items() if not ok]
if failed:
    raise SystemExit("FAIL build configuration: " + ", ".join(failed))

node = shutil.which("node")
if not node:
    raise SystemExit("FAIL Node.js required for JavaScript syntax checks")
for path in [ROOT / "www/app.js", ROOT / "backend/server.js"]:
    result = subprocess.run([node, "--check", str(path)], capture_output=True, text=True)
    if result.returncode:
        raise SystemExit(f"FAIL JavaScript syntax {path.name}:\n{result.stderr}")
package = json.loads((ROOT / "backend/package.json").read_text())
if not package.get("scripts", {}).get("start"):
    raise SystemExit("FAIL backend start script missing")
print("PASS JavaScript syntax and backend package metadata")

html = web.decode("utf-8")
js = web_js.decode("utf-8")
ids = [int(x) for x in re.findall(r"^\s*(\d+):\{region:", js, re.M)]
if ids != list(range(14, 34)):
    raise SystemExit(f"FAIL Intro DNA 14–33: {ids}")
dna = re.search(r"const dna=\[(.*?)\];", js, re.S)
if not dna or len(re.findall(r"\['\d{2} ·", dna.group(1))) != 18:
    raise SystemExit("FAIL expected 18 base Music DNA packages")
if 'MDNA-066' not in js or 'TECH-PROD-031' not in js:
    raise SystemExit("FAIL expanded research catalog or 31 production techniques missing")
for token in ["PRESERVE", "styleGenerate", "/api/style", "/api/lyrics", "/api/command", "interpretCommand"]:
    if token not in js and token not in html:
        raise SystemExit(f"FAIL retained feature missing: {token}")
if "© 2026 SONGDNA Studio – Tüm hakları saklıdır." not in html:
    raise SystemExit("FAIL exact About copyright missing")
print("PASS retained Music DNA, Intro DNA 14–33, natural-language command flow, PRESERVE and About copyright")

backend = (ROOT / "backend/server.js").read_text()
for token in ["ALLOWED_FLASH_MODELS", "GEMINI_MODELS", "TOTAL_GENERATION_BUDGET_MS", "PER_MODEL_TIMEOUT_MS", "AbortSignal.any", "requestSignal", "billingPolicy"]:
    if token not in backend:
        raise SystemExit(f"FAIL backend policy or timeout feature missing: {token}")
if "temperature:" in backend:
    raise SystemExit("FAIL deprecated Gemini temperature parameter remains")
if "VERIFIED_MODELS" in backend:
    raise SystemExit("FAIL obsolete model allowlist label remains")
if "AbortController" not in js or "150000" not in js:
    raise SystemExit("FAIL client request timeout missing")
if "refreshFreeModels" not in js or "base+'/health'" not in js:
    raise SystemExit("FAIL dynamic health/model refresh missing")
if "GEMINI_API_KEY" in js:
    raise SystemExit("FAIL Gemini API key must never be in frontend")
if "yerel dil ve kültürel doğrulama uzman/native konuşur onayı anlamına gelmez" not in html:
    raise SystemExit("FAIL Intro DNA cultural-validation disclaimer missing")
if "ALLOWED_ORIGIN=*" not in (ROOT / "README.md").read_text():
    raise SystemExit("FAIL Android WebView CORS guidance missing")
print("PASS Flash-only model allowlist, cancellation, timeouts, dynamic model list and frontend key isolation")

# 5.0.0 product safeguards: no lyric history, three creative modes, manual favorites.
for token in ["function chooseFreshTopic", "function makeLyricsPrompt", "creativeMode", "creativeTopic", "creativeMood", "creativeAtmosphere", "creativeStory", "creativeNarrative", "Favori Şarkı Sözlerim"]:
    if token not in js and token not in html:
        raise SystemExit(f"FAIL 5.0 creative/favorites feature missing: {token}")
for token in ["function lyricMemory(", "function saveLyricMemory(", "Recent memory:"]:
    if token in js:
        raise SystemExit(f"FAIL removed automatic lyric memory remains: {token}")
if "gemini_lyric_memory" in backend.lower() or "recent-song memory" in backend.lower():
    raise SystemExit("FAIL backend still instructs Gemini to use lyric history")
if "const enteredTopic=$('theme').value.trim()" not in js:
    raise SystemExit("FAIL user topic override flow missing")
if "@media(min-width:760px)" not in html and "@media (min-width: 760px)" not in html:
    raise SystemExit("FAIL responsive tablet layout breakpoint missing")
if "STYLES" not in html or "LYRICS" not in html:
    raise SystemExit("FAIL two generator output fields missing")
if "audio-player" in html.lower() or "<audio" in html.lower():
    raise SystemExit("FAIL audio player markup found; SONGDNA is a prompt/lyrics generator only")
print("PASS 5.0 creative modes, template controls, manual favorites, removed lyric memory, responsive UI and generator-only identity")
print("ALL STATIC SOURCE CHECKS PASSED. Remote APK build, real-device testing, Render deployment and live Gemini calls are still required.")
