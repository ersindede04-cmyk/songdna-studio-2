#!/usr/bin/env python3
"""Stage 166 mobile UI: accessible switch behavior, language default and drawer layout."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from browser_test_utils import launch_chromium
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def record(name,ok,detail=''):
    checks.append(bool(ok)); print(('PASS' if ok else 'FAIL')+' '+name+(f' — {detail}' if detail else ''))
with sync_playwright() as p:
    browser=launch_chromium(p,headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    context=browser.new_context(viewport={'width':390,'height':844},locale='tr-TR')
    page=context.new_page()
    
    html=(ROOT/'index.html').read_text(encoding='utf-8')
    script_sources=__import__('re').findall(r'<script\b[^>]*src=[\"\']([^\"\']+)[\"\'][^>]*></script>', html, flags=__import__('re').I)
    html=__import__('re').sub(r'<script\b[^>]*src=[\"\'][^>]*></script>', '', html, flags=__import__('re').I)
    shim='<script>(()=>{const data={};Object.defineProperty(window,\"localStorage\",{value:{getItem:k=>data[k]??null,setItem:(k,v)=>data[k]=String(v),removeItem:k=>delete data[k]}})})()</script>'
    html=html.replace('</head>',shim+'</head>')
    page.set_content(html,wait_until='domcontentloaded')
    for src in script_sources:
        page.add_script_tag(content=(ROOT/src).read_text(encoding='utf-8'))
    page.wait_for_timeout(500)
    record('default interface language follows Turkish device locale',page.locator('html').get_attribute('lang')=='tr')
    for selector in ['#traditionalMusicEnabled','#modernMusicEnabled','#pureTraditionalProduction']:
        loc=page.locator(selector)
        record(f'{selector} exposed as accessible switch',loc.get_attribute('role')=='switch')
        style=loc.evaluate('(e)=>({appearance:getComputedStyle(e).appearance,width:getComputedStyle(e).width,height:getComputedStyle(e).height})')
        record(f'{selector} rendered as phone toggle',style['appearance']=='none' and style['width']=='48px' and style['height']=='28px',str(style))
    trad=page.locator('#traditionalMusicEnabled')
    before=trad.is_checked();trad.click(force=True)
    record('traditional switch changes underlying checkbox state',trad.is_checked()!=before)
    page.locator('#menuOpen').click()
    for target in ['generalPanel','appearancePanel','aiPanel','introPanel','vocalPanel','archivePanel','aboutPanel']:
        record(f'{target} menu entry available',page.locator(f'[data-drawer-target="{target}"]').count()==1)
    # The settings sequence is stable and ordered in the actual drawer.
    order=page.locator('[data-drawer-target="generalPanel"], [data-drawer-target="appearancePanel"], [data-drawer-target="aiPanel"], [data-drawer-target="introPanel"], [data-drawer-target="vocalPanel"], [data-drawer-target="archivePanel"], [data-drawer-target="aboutPanel"]').evaluate_all('(es)=>es.map(e=>e.getAttribute("data-drawer-target"))')
    record('settings, themes, AI, intro, vocal, projects and about are ordered',order==['generalPanel','appearancePanel','aiPanel','introPanel','vocalPanel','archivePanel','aboutPanel'],str(order))
    page.locator('#generalPanel').evaluate('(e)=>e.classList.add("active")')
    record('app language selector offers automatic, Turkish and English',page.locator('#appLanguage option').evaluate_all('(es)=>es.map(e=>e.value)')==['auto','tr','en'])
    record('app language selector defaults to automatic',page.locator('#appLanguage').input_value()=='auto')
    record('Turkish labels are preserved',page.get_by_text('Geleneksel müzik',exact=True).count()>=1)
    page.locator('#menuClose').click()  # Close the drawer before testing sticky production tabs.
    record('Stage167 has exactly two fixed production mode tabs',page.locator('.production-mode-tabs [data-production-mode]').count()==2)
    record('Stage167 production tabs are side by side',page.locator('.production-mode-tabs').evaluate('(e)=>getComputedStyle(e).display')=='grid' and page.locator('.production-mode-tabs').evaluate('(e)=>getComputedStyle(e).gridTemplateColumns.split(" ").length')==2)
    record('Standard production is selected by default',page.locator('#standardModeTab').get_attribute('aria-pressed')=='true' and page.locator('#dnaPanel').evaluate('(e)=>!e.classList.contains("active")'))
    page.locator('#globalModeTab').click()
    record('Global tab activates existing regional panel and shared generator',page.locator('#dnaPanel').evaluate('(e)=>e.classList.contains("active")') and page.locator('#generatorPanel').evaluate('(e)=>e.classList.contains("active")'))
    record('Shared song generation action is present',page.locator('#aiGenerate').count()==1 and 'ŞARKIYI OLUŞTUR' in page.locator('#aiGenerate').inner_text())
    page.locator('#standardModeTab').click()
    record('Standard tab returns to standard-only view',page.locator('#generatorPanel').evaluate('(e)=>e.classList.contains("active")') and page.locator('#dnaPanel').evaluate('(e)=>!e.classList.contains("active")'))
    record('Traditional menu label is consistent','Geleneksel Üretim' in page.locator('[data-open-screen="dnaPanel"]').inner_text())
    page.evaluate("document.body.classList.remove('drawer-open')")
    page.locator('#globalModeTab').click()
    page.locator('[data-screen="resultsPanel"]').click()
    page.locator('[data-screen="generatorPanel"]').click()
    record('Global panel remains available after output-tab navigation',page.locator('#dnaPanel').evaluate('(e)=>e.classList.contains("active")'))
    page.locator('#standardModeTab').click()
    context.close()
    # A separate English-device context verifies the automatic fallback path.
    en_context=browser.new_context(viewport={'width':390,'height':844},locale='en-US')
    en_page=en_context.new_page()
    en_html=(ROOT/'index.html').read_text(encoding='utf-8')
    en_sources=__import__('re').findall(r'<script\b[^>]*src=[\"\']([^\"\']+)[\"\'][^>]*></script>', en_html, flags=__import__('re').I)
    en_html=__import__('re').sub(r'<script\b[^>]*src=[\"\'][^>]*></script>', '', en_html, flags=__import__('re').I)
    en_html=en_html.replace('</head>',shim+'</head>')
    en_page.set_content(en_html,wait_until='domcontentloaded')
    for src in en_sources:
        en_page.add_script_tag(content=(ROOT/src).read_text(encoding='utf-8'))
    en_page.wait_for_timeout(300)
    record('automatic mode follows English device locale',en_page.locator('html').get_attribute('lang')=='en')
    record('English labels are translated',en_page.get_by_text('Traditional Music',exact=True).count()>=1)
    en_context.close();browser.close()
print(f'\nSTAGE 166 MOBILE UI RESULT: {sum(checks)}/{len(checks)} passed')
if not all(checks): raise SystemExit(1)
