# SONGDNA SMART STUDIO 6.1.0 — Stage153 Paket Uyumluluğu

## Amaç
Stage152 denemelerinde ortaya çıkan kaynak/test/iş akışı uyumsuzluklarını tek bir Stage153 kaynak paketi ve ona özel GitHub Actions iş akışı altında sabitlemek. Stage153, uygulamanın Music DNA, üretim mantığı, Gemini akışı veya Styles/Lyrics davranışını değiştirmez; paketleme ve Android derleme doğrulamasını ayrıştırır.

## Stage153 kimliği
- Kaynak arşivi: `SONGDNA_SMART_STUDIO_6_1_0_STAGE153_SOURCE.zip`
- İş akışı: `.github/workflows/build.yml`
- Android proje dizini, sabit klasör varsayımıyla değil `android-wrapper/settings.gradle.kts` üzerinden keşfedilir.
- Gradle, keşfedilen mutlak Android proje diziniyle çalıştırılır.
- Eski Stage70 testi artık kaldırılmış `-p android-wrapper` komutunu aramaz; gerçek keşif ve derleme sözleşmesini doğrular.
- Dört `BUILD_MANIFEST.json` dosyası aynı kalır ve Stage151 uygulama kaynaklarının sürüm/aşama bilgisini korur. Stage153, paketleme/derleme aşamasıdır; uygulama özellik aşaması değildir.

## Bilinçli kapsam
Uygulama kaynakları ve mevcut Stage151 manifestleri değiştirilmemiştir. Stage152 iş akışı kimlikleri Stage153 olarak ayrıştırılmış, eski `build-stage152.yml` kaldırılmıştır. Böylece yeni depo yüklemesi eski Stage152 arşiv adına veya iş akışı adına bağlanmaz.

## Doğrulama
Bu paketin hazırlanması sırasında ZIP bütünlüğü, kaynak/WebView eşleşmesi, JavaScript regresyon testleri, Python regresyon testleri ve Stage70 iş akışı sözleşmesi ayrıca çalıştırılmalıdır. GitHub Actions üzerinde gerçek Android APK derlemesi başarılı olmadan APK üretildiği iddia edilmez.
