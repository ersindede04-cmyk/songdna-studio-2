# SONGDNA Studio 2.0.0 — Clean Android Build

Bu paket, yeni ve boş bir GitHub deposunun **ana dizinine doğrudan yüklenecek** şekilde hazırlanmıştır. ZIP'i GitHub'a tek dosya olarak yüklemeyin; ZIP'i cihazınızda çıkartın ve içindeki tüm dosya/klasörleri depo ana dizinine yükleyin.

## Sabit proje kimlikleri

| Alan | Değer |
|---|---|
| GitHub depo adı önerisi | `songdna-studio-2` |
| Depo içindeki proje kökü | Depo ana dizini |
| Gradle proje adı | `SONGDNA-Studio-2.0.0` |
| Android modülü | `android-wrapper/app` |
| Android applicationId | `com.songdna.studio` |
| Android namespace | `com.songdna.studio` |
| Uygulama sürümü | `2.0.0` |
| versionCode | `9` |
| Workflow | `.github/workflows/build-apk.yml` |
| APK artifact | `SONGDNA-Studio-2.0.0-debug-APK` |

`applicationId` bilerek `com.songdna.studio` olarak korunmuştur. Böylece bu uygulamanın önceki sürümleriyle Android uygulama kimliği tutarlı kalır; yeni bir kimlik çakışması yaratılmaz.

## Derleme ortamı

- Java 17
- Kotlin JVM target 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin Android Plugin 2.0.21
- Android SDK Platform 35
- Android Build Tools 35.0.0
- minSdk 23 / targetSdk 35

Java ve Kotlin bytecode hedefleri aynı olacak şekilde ayarlanmıştır. Bu, önceki derlemede görülen `Java 1.8` / `Kotlin 17` uyumsuzluğunu önlemek içindir.

## Temiz GitHub kurulumu

1. GitHub'da yeni ve boş bir depo oluşturun: `songdna-studio-2`.
2. Bu ZIP'i telefonda veya bilgisayarda çıkartın.
3. Çıkan paketin içindeki tüm dosya ve klasörleri yeni deponun ana dizinine yükleyin. `.github` klasörünün de yüklendiğini kontrol edin.
4. GitHub deposunda **Actions** sekmesine girin.
5. `SONGDNA Studio 2.0.0 - Android APK` iş akışını seçin ve **Run workflow** düğmesine basın.
6. İşlem yeşil tik ile tamamlanırsa çalıştırmanın **Artifacts** bölümünden `SONGDNA-Studio-2.0.0-debug-APK` dosyasını indirin.
7. İndirilen artifact ZIP'ini çıkartın. İçindeki `app-debug.apk` Android uygulama dosyasıdır.

## Tek proje / tek yol kuralı

- Kaynak ZIP'i depo içine koymayın.
- `android-wrapper` klasörünü ikinci bir `SONGDNA-Studio` klasörünün içine taşımayın.
- İkinci bir Android `app` modülü oluşturmayın.
- Workflow dosyasının ikinci bir kopyasını eklemeyin.
- Derleme yalnızca `-p android-wrapper` yolu üzerinden çalışır.

## Korunan özellikler

1.9 temiz kaynak temel alınmıştır. Türkçe arayüz, 18 Music DNA paketi, Intro DNA 14–33, bölgesel otomatik intro akışı, PRESERVE seçenekleri, Suno uyumlu STYLE / LYRICS / EXCLUDE üretimi ve mevcut backend kaynakları korunmuştur. Android WebView içindeki arayüz dosyası, `www/index.html` ile birebir aynı tutulur.

## Backend ve API anahtarları

APK'nın derlenmesi için backend'in internete açılması veya API anahtarı girilmesi gerekmez. AI servislerini kullanmak için `backend/` klasörünü HTTPS destekleyen Node.js 18+ sunucusuna dağıtın. API anahtarlarını Android uygulamasına veya GitHub deposuna koymayın; sunucu ortam değişkenlerinde saklayın.

## Doğrulama durumu

Paket içindeki `scripts/verify-source.py`, GitHub Actions derlemesinden önce dosya yollarını, yinelenen ZIP/proje yapısını, Android XML dosyalarını, web/Android arayüz eşitliğini, sürüm/kimlik ayarlarını, Java-Kotlin hedeflerini, JavaScript sözdizimini ve Intro DNA kayıtlarını denetler.

**Önemli:** Bu yerel kaynak kontrollerinin geçmesi APK'nın üretildiği anlamına gelmez. APK ancak GitHub Actions başarılı olup artifact indirildikten sonra derlenmiş sayılır. Telefona kurulum ve gerçek cihaz testi bundan sonraki ayrı adımdır.
