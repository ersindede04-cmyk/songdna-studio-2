/* SONGDNA SMART STUDIO — Integrated Production & Musical Dependency Engine v1
 * Coordinates production dimensions after DNA, emotion, atmosphere and energy are resolved.
 * Advisory/prompt-planning only: it does not process audio, alter BPM, or override manual choices.
 */
(function(root){
 'use strict';
 const KEYS=['rhythm','bass','melody','vocal','energy','atmosphere','structure','effects'];
 const LABELS={rhythm:'Ritim',bass:'Bas',melody:'Melodi',vocal:'Vokal',energy:'Enerji',atmosphere:'Atmosfer',structure:'Yapı',effects:'Efekt'};
 const clamp=n=>Math.max(0,Math.min(100,Math.round(Number(n)||0)));
 const has=(s,re)=>re.test(String(s||'').toLowerCase());
 const GRAPH=[
  {id:'kick-bass',from:['rhythm','bass'],to:'rhythm',when:d=>d.bass>=88&&d.rhythm>=82,delta:-3,reason:'Bas ve kick aynı anda baskın olduğunda ritmik vuruş yoğunluğu hafifçe seyreltilir; ikisinin de duyulacağı alan korunur.',instruction:'Give kick and bass complementary timing/decay and distinct low-end roles; preserve the selected bass identity.'},
  {id:'vocal-melody',from:['vocal','melody'],to:'melody',when:d=>d.vocal>=84&&d.melody>=88,delta:-4,reason:'Ana vokal ve melodik motif aynı anda öne çıktığında motifin yoğunluğu azaltılır veya cevap aralarına taşınır.',instruction:'Let lead vocal and melodic hook alternate foreground moments; use call-and-response or phrase gaps rather than stacking both continuously.'},
  {id:'atmosphere-effects',from:['atmosphere','effects'],to:'effects',when:d=>d.atmosphere>=88&&d.effects>=82,delta:-4,reason:'Geniş atmosfer ve yoğun efekt bir araya geldiğinde efekt yoğunluğu sadeleştirilir; derinlik korunurken bulanıklık azaltılır.',instruction:'Keep long ambience and transient detail distinct; use selective tails and avoid washing out rhythmic attacks.'},
  {id:'energy-atmosphere',from:['energy','atmosphere'],to:'atmosphere',when:d=>d.energy>=88&&d.atmosphere>=82,delta:-3,reason:'Yüksek enerji ve geniş atmosfer birlikteyken ritmik netliği korumak için atmosfer katmanı sıkılaştırılır.',instruction:'Maintain high energy without flattening dynamics; tighten ambience around rhythmic peaks while retaining emotional space.'},
  {id:'structure-energy',from:['structure','energy'],to:'structure',when:d=>d.energy>=85&&d.structure>=85,delta:0,reason:'Yüksek enerji, bölüm düzeninde kontrollü yükseliş ve belirgin doruklarla taşınır; sürekli yoğunluk zorunlu değildir.',instruction:'Shape energy with section contrast, builds, drops or tradition-appropriate climaxes; do not keep every section at maximum density.'}
 ];
 function build(input={}){
  const preset=input.preset||{};
  const dimensions={};KEYS.forEach(k=>{dimensions[k]=clamp(preset.dimensions?.[k]??50)});
  const locked=new Set([...(preset.userOverrides||[]),...(input.manualOverrides||[])]);
  const adjustments=[],activeRules=[],instructions=[];
  GRAPH.forEach(rule=>{
   if(!rule.when(dimensions))return;
   activeRules.push(rule.id);
   if(rule.delta&& !locked.has(rule.to)){
    dimensions[rule.to]=clamp(dimensions[rule.to]+rule.delta);
    adjustments.push(`${LABELS[rule.to]}: ${rule.reason}`);
   }else adjustments.push(rule.reason);
   instructions.push(rule.instruction);
  });
  const family=String(preset.family||'general');
  const dnaName=input.dnaName||preset.profileName||'Selected Music DNA';
  const bpm=Number(input.bpm)||null;
  const bpmManual=!!input.bpmManual;
  const energy=input.energy||{};
  const emotion=input.emotion||{};
  const atmosphere=input.atmosphere||{};
  const vocal=input.vocal||{};
  const fusion=input.fusion||{};
  const adlib=input.adlib||{};
  const identityRules=[
   'Preserve the selected Music DNA genre, regional identity, authentic instruments, rhythmic grammar and culturally specific performance practice.',
   'Treat emotion and energy as separate dimensions: emotional intensity may be high while rhythmic energy is low, or the reverse; never collapse one into the other.',
   'Do not infer a new genre, instrument, language, vocal identity or regional tradition from a mood label.',
   family==='traditional'?'For traditional profiles, retain tradition-specific meter/usul/free-time phrasing and acoustic performance behavior; do not impose a generic electronic beat.':''
  ].filter(Boolean);
  const bpmInstruction=bpm?(bpmManual?`User-selected tempo is locked at ${bpm} BPM. Preserve it exactly; adapt rhythmic subdivision, phrasing and arrangement around it.`:`Use ${bpm} BPM as the current tempo proposal. Do not change it solely to force a preset range; express energy through articulation, density and arrangement.`):'Respect the selected profile tempo guidance; do not invent an exact BPM.';
  const vocalInstruction=[vocal.lead,vocal.delivery,vocal.texture].filter(Boolean).join('; ');
  const fusionInstruction=fusion.active?`Fusion is intentional. Primary identity remains ${dnaName}; blend only the selected secondary layers: ${fusion.layers||fusion.promptText||'the user-selected fusion roles'}.`:'Do not add an unselected secondary genre or fusion layer.';
  const promptText=[
   'INTEGRATED MUSIC DNA PRODUCTION PROFILE:',
   `Primary identity: ${dnaName} (${family}).`,
   ...identityRules,
   bpmInstruction,
   `Production balance (0–100): ${JSON.stringify(dimensions)}.`,
   `Energy: ${energy.label||energy.key||'profile-led'}; keep independent from emotion.`,
   `Emotion: ${emotion.label||'profile-led'}; intensity: ${emotion.intensityLabel||'profile-led'}.`,
   `Atmosphere: ${atmosphere.label||'profile-led'}.`,
   vocalInstruction?`Vocal direction: ${vocalInstruction}.`:'Preserve the profile-appropriate vocal configuration selected by the user.',
   fusionInstruction,
   adlib.mode?`Ad-lib behavior: ${adlib.mode}; place only in selected gaps and section roles.`:'Keep ad-libs subordinate to the lead vocal and the selected cultural style.',
   ...instructions,
   'Arrange kick, bass, lead vocal, melodic hook and atmosphere so their roles remain distinguishable; intentional blending is allowed when it serves the style.',
   'Translate these directions into coherent Suno Styles and Lyrics instructions from this same final production profile.'
  ].filter(Boolean).join(' ');
  return {version:'1.0',profileId:preset.profileId||null,profileName:dnaName,family,dimensions,userOverrides:[...locked],activeRules,adjustments,instructions,manualBpm:bpmManual,bpm,promptText,canProceed:true};
 }
 root.SongDnaIntegratedProductionEngine={version:'1.0',build,dimensions:KEYS,labels:LABELS,dependencyGraph:GRAPH.map(({id,from,to})=>({id,from,to}))};
})(typeof window!=='undefined'?window:globalThis);
