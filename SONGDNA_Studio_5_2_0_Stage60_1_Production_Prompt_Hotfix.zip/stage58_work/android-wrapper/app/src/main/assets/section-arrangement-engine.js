/* SONGDNA Section-aware Arrangement Engine v1.0
 * Creates independent, genre-aware production/vocal/ad-lib decisions for song sections.
 * Traditional profiles retain their own form; user-selected structure always wins.
 */
(function(root){
 const SECTION_DEFS=[
  {id:'intro',label:'Intro',purpose:'establish identity and leave room before the lead enters'},
  {id:'verse',label:'Verse',purpose:'carry the narrative with controlled space for the lead vocal'},
  {id:'preChorus',label:'Pre-Chorus',purpose:'increase anticipation without prematurely reaching the chorus peak'},
  {id:'chorus',label:'Chorus',purpose:'deliver the main hook with the clearest and most memorable arrangement'},
  {id:'bridge',label:'Bridge',purpose:'create contrast through texture, harmony, rhythm or vocal perspective'},
  {id:'outro',label:'Outro',purpose:'resolve, echo or deliberately leave the musical idea open'}
 ];
 const clamp=n=>Math.max(0,Math.min(100,Math.round(Number(n)||0)));
 function build({family='modern',emotion={},energy={},atmosphere={},mode='adaptive',adlibMode='Akıllı / bölüm odaklı',vocal='',dnaName='',customStructure=''}={}){
  const trad=String(family).toLowerCase().includes('trad');
  const e=clamp(energy.dimensions?.energy??energy.level??energy.value??50), intensity=Number(emotion.intensity)||2;
  const mood=emotion.label||'selected emotional profile';
  const air=atmosphere.label||'Music DNA-compatible atmosphere';
  const adaptive=mode==='adaptive'||mode==='auto';
  const sections=SECTION_DEFS.map((s,i)=>{
   let density=[25,45,62,88,55,30][i];
   if(e<34)density-=12; else if(e>67)density+=8;
   if(intensity>=4 && ['chorus','bridge'].includes(s.id))density+=6;
   density=clamp(density);
   const decisions={
    intro:{rhythm:trad?'introduce the defining acoustic pulse or free-meter gesture gradually':'begin with a restrained motif and minimal rhythm',bass:'withhold or keep low-end subtle until the identity is clear',melody:'present one signature motif',vocal:'optional short pickup or instrumental opening; do not delay the main song',adlibs:'none or one culturally appropriate pickup',effects:'subtle space; avoid an oversized opening'},
    verse:{rhythm:'stable core groove with controlled variation',bass:'support the vocal without masking its phrasing',melody:'sparser counter-motifs and clear vocal space',vocal:'narrative-forward lead with intelligible phrasing',adlibs:'sparse responses at natural gaps and bar endings',effects:'mostly dry/close lead with selective depth'},
    preChorus:{rhythm:'add motion or subdivisional lift only where compatible',bass:'increase movement without forcing a new bass genre',melody:'raise harmonic or melodic tension',vocal:'gradually intensify phrasing and register where suitable',adlibs:'short anticipatory responses, not constant fills',effects:'controlled risers or widening only if stylistically appropriate'},
    chorus:{rhythm:'strongest defining groove and clear rhythmic accents',bass:'fullest coherent low-end support, retaining separation',melody:'strong hook motif and supportive harmony',vocal:'most memorable, open and emotionally direct lead delivery',adlibs:'purposeful call-and-response or hook echoes; leave hook intelligible',effects:'wider backing layers and selective delay/reverb'},
    bridge:{rhythm:'create contrast by thinning, suspending or re-patterning the established groove',bass:'reduce or reshape low-end to create contrast',melody:'introduce a contrasting motif, chord color or melodic answer',vocal:'change perspective, register, texture or intensity',adlibs:'rare, atmospheric or response-based accents',effects:'distinctive transition texture without changing the genre identity'},
    outro:{rhythm:'resolve or gradually strip back the established pulse',bass:'release low-end weight naturally',melody:'return to or gently transform the signature motif',vocal:'final phrase, sustained note or intentional instrumental resolution',adlibs:'few closing echoes only when appropriate',effects:'controlled tail, fade or decisive stop'}
   }[s.id];
   if(trad){decisions.rhythm=({intro:'introduce the tradition-specific pulse, cycle or free-meter phrasing without imposing a pop beat',verse:'preserve the authentic rhythmic cycle, phrasing and ensemble dialogue',preChorus:'if the tradition has no pre-chorus, use a natural instrumental/vocal transition instead of forcing one',chorus:'use the tradition’s actual refrain, response or recurring melodic/rhythmic anchor; do not invent a pop chorus',bridge:'create contrast through authentic variation, ornamentation, call-and-response or ensemble thinning',outro:'resolve through the tradition’s own cadence, cycle or performance convention'})[s.id];decisions.effects='preserve acoustic character and natural room/ensemble sound; no unselected electronic effects';}
   if(mode==='dynamic'){density=clamp(density+([0,0,8,14,12,0][i]));decisions.effects+='; emphasize clear section-to-section contrast';}
   if(mode==='gradual'){density=clamp([18,35,52,82,62,28][i]+(e>67?8:0));decisions.structureMode='continuous gradual build and release';}
   if(mode==='minimal'){density=clamp(Math.min(density, [18,30,38,58,35,20][i]));decisions.rhythm+='; leave deliberate negative space';decisions.adlibs='very sparse, only essential responses';}
   if(!adaptive){decisions.structureMode=mode;}
   return {...s,density,decisions};
  });
  const promptText=[
   `SECTION-AWARE ARRANGEMENT (${adaptive?'adaptive':'user-selected '+mode}) for ${dnaName||'selected Music DNA'}; family=${family}; emotion=${mood} (intensity ${intensity}/4); energy=${energy.label||e}; atmosphere=${air}.`,
   customStructure?`USER STRUCTURE OVERRIDE: ${customStructure}. Preserve it exactly and map section decisions onto its actual sections.`:'Use only sections that fit the selected Music DNA; do not force every conventional pop section.',
   `For each section make distinct decisions for rhythm, bass, melody/harmony, lead/backing vocal, ad-lib placement and effects. Maintain a coherent musical identity and create audible contrast between sections.`,
   ...sections.map(s=>`${s.label}: ${s.purpose}; density ${s.density}/100; ${Object.entries(s.decisions).map(([k,v])=>`${k}: ${v}`).join('; ')}.`),
   trad?'TRADITIONAL IDENTITY LOCK: preserve authentic form, cycle, instruments, vocal practice and performance convention. Verse/chorus/bridge are optional labels only; never impose a modern pop structure on a traditional form.':'',
   `Ad-lib arrangement preference: ${adlibMode}. Lead vocal preference: ${vocal||'selected vocal profile'}. Keep ad-libs subordinate to the lead and hook.`
  ].filter(Boolean).join(' ');
  return {mode:adaptive?'adaptive':mode,sections,promptText,traditionalIdentityLocked:trad};
 }
 root.SongDnaSectionArrangementEngine={build,SECTION_DEFS};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaSectionArrangementEngine;
})(typeof window!=='undefined'?window:globalThis);
