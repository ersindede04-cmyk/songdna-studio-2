# Stage187 — CI doğrulama düzeltmesi

- Stage186 GitHub Actions #237 çıktısındaki gerçek hata giderildi: `scripts/verify-source.py` dosyasının web ve Android dağıtım kopyaları ana dosyayla aynı değildi.
- Kanonik doğrulayıcı dosya, `www/scripts/verify-source.py` ve `android-wrapper/app/src/main/assets/scripts/verify-source.py` konumlarına byte-byte aynı şekilde eşitlendi.
- Stage187 paket kimliği ve GitHub Actions iş akışı aynı aşamayı kullanacak şekilde güncellendi.
- ZIP doğrulaması çıkarma işleminden önce yapılır; bozuk, eksik veya yanlış adlı arşivde APK derlemesine geçilmez.
- Ürün özellikleri, Music DNA kataloğu, konu/hikâye kütüphaneleri, otomatik seçim sırası, Styles/Lyrics üretimi ve backend davranışı değiştirilmedi.
- Uygulama sürümü 7.5.0 ve Android versionCode 42 korunmuştur.

Bu aşama yalnızca kaynak/CI paketleme kararlılığı düzeltmesidir.
