# SONGDNA Studio 2.0.0 — GitHub kurulumu

1. Yeni ve boş GitHub deposu açın: `songdna-studio-2`.
2. `SONGDNA-Studio-2.0.0-Clean-Source.zip` dosyasını cihazda çıkartın.
3. İçindeki tüm dosya ve klasörleri deponun ana dizinine yükleyin. Gizli `.github` klasörü dahil olmalı.
4. ZIP dosyasının kendisini depoya yüklemeyin.
5. Actions → `SONGDNA Studio 2.0.0 - Android APK` → Run workflow.
6. Yeşil tik sonrası Artifacts bölümünden `SONGDNA-Studio-2.0.0-debug-APK` dosyasını indirin.
7. Artifact ZIP'ini çıkartıp `app-debug.apk` dosyasını telefona kurun.

Eski `MusicGen` deposunu, yeni deponun APK'sı başarıyla derlenip telefonda denenene kadar silmeyin.
