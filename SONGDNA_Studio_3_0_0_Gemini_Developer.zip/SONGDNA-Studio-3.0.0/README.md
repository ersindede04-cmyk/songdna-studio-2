# SONGDNA Studio 3.0.0 — Gemini-first Android source

SONGDNA Studio prepares original lyrics and Suno-ready music-style prompts. It does **not** generate audio. Version 3.0 keeps the 2.0 Music DNA and Intro DNA catalogues while moving the AI path to Google Gemini only.

## Version 3.0 changes

- Removed the OpenAI/ChatGPT provider choice and OpenAI backend path.
- Added a Gemini model selector with verified API model IDs: `gemini-3.5-flash-lite`, `gemini-3.6-flash`, and `gemini-3.1-flash-lite`.
- Added server-side model fallback for transient overload/rate-limit/server errors.
- Added independent `POST /api/lyrics` and `POST /api/style` endpoints.
- Kept the Gemini API key exclusively in server environment variables.
- Preserved the 18 Music DNA packages, Intro DNA 14–33, PRESERVE controls, prompt construction, local archive and separate output tabs.
- Android version is 3.0.0 / versionCode 10. Application ID remains `com.songdna.studio` to support in-place upgrade.

## Backend environment

Set these values in Render (or another Node.js host):

```text
APP_ACCESS_TOKEN=<same long random token entered in the app>
GEMINI_API_KEY=<Google AI Studio API key>
GEMINI_MODEL=gemini-3.5-flash-lite
GEMINI_MODELS=gemini-3.5-flash-lite,gemini-3.6-flash,gemini-3.1-flash-lite
```

Do not put secrets in GitHub or in the APK. `GEMINI_MODELS` is filtered against the three model IDs supported by this source. The server tries the selected/default model first and then configured alternatives when it receives transient 408/429/5xx errors. This does not bypass Google's quotas or guarantee availability.

## API endpoints

- `GET /health` — service status, configured Gemini model list and default model (never returns API keys).
- `POST /api/lyrics` — `{ "model": "gemini-3.5-flash-lite", "prompt": "..." }`; returns `{ provider, model, fallbackUsed, lyrics }`.
- `POST /api/style` — same request shape; returns `{ provider, model, fallbackUsed, style }`.

Both POST endpoints require `X-App-Token` matching `APP_ACCESS_TOKEN`.

## Deploy backend to existing Render service

1. Upload the repository contents to the existing GitHub repository root, replacing the old source files while preserving the `.github/workflows` folder.
2. Render is connected to that repository and should deploy the updated `backend/server.js` if its Root Directory is `backend` and Start Command is `npm start`. If Render's Root Directory is currently blank, set it to `backend` before deployment.
3. Keep `APP_ACCESS_TOKEN` and `GEMINI_API_KEY` unchanged.
4. Set `GEMINI_MODEL` and `GEMINI_MODELS` to the values above. Ensure no old/invalid model ID remains in `GEMINI_MODELS`.
5. After deploy, open `/health` and confirm `ok:true`, `gemini:true`, and the three model IDs.

## Build Android APK with GitHub Actions

1. Upload the contents of this source package to the repository root (not the ZIP itself).
2. Open GitHub → Actions → `SONGDNA Studio 3.0.0 - Android APK` → Run workflow.
3. Wait for the workflow to complete successfully.
4. Download `SONGDNA-Studio-3.0.0-debug-APK` from Artifacts, extract it, and install `app-debug.apk`.

The `applicationId` remains unchanged so Android can update the existing app when signing keys match. A debug APK may not install over an APK signed with a different key; in that case Android may require uninstalling the old app first, which can remove local app data. Back up saved projects before installing if prompted.

## Validation

Run `python3 scripts/verify-source.py` before building. This checks source layout, synchronized WebView asset, Android configuration, JavaScript syntax, preserved catalogues and Gemini-only API wiring. A passing local check does not replace remote APK compilation or on-device API testing.
