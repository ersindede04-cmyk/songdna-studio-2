# SONGDNA Studio 2.0.0 — Clean Start QA

## Source basis
- 1.9 CleanBuild Developer source archive supplied in the conversation.
- The 1.9 QA report identifies the 1.7 application/UI and Intro DNA source as the feature baseline and retains the newer server-side AI integration.
- No UI feature set was intentionally removed in this versioning/build cleanup.

## Changes in 2.0.0
- Replaced the nested-ZIP extraction concept with a single repository-root source layout.
- Set one canonical Android project path: `android-wrapper` and one module: `:app`.
- Set Gradle project name to `SONGDNA-Studio-2.0.0`.
- Kept Android `applicationId` and namespace as `com.songdna.studio` to preserve app identity across upgrades.
- Set app versionName `2.0.0` and versionCode `9`.
- Explicitly aligned Java source/target compatibility and Kotlin JVM target to 17.
- Kept Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, SDK 35 and Build Tools 35.0.0.
- Added pre-build checks for repository layout, nested ZIPs, project identity, version, JVM targets, UI parity, XML, JavaScript and Intro DNA 14–33.
- Kept a single manual `workflow_dispatch` workflow and one artifact name.

## Must be verified remotely
- GitHub Actions hosted-runner Gradle compilation.
- APK artifact creation and download.
- Installation and runtime on a physical Android device.
- Backend deployment and live OpenAI/Gemini requests.

A source package cannot honestly be called fully build-verified until the remote workflow produces an APK. A green workflow also does not replace physical-device testing.
