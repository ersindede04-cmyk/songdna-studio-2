plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.songdna.studio"
    compileSdk = 35

    // Keep Java and Kotlin bytecode targets aligned (prevents the 1.8 vs 17 failure).
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "com.songdna.studio"
        minSdk = 23
        targetSdk = 35
        versionCode = 10
        versionName = "3.0.0"
    }
}
