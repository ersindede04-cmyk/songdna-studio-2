const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const checks=[];
function check(name,ok){checks.push([name,!!ok]);if(!ok)console.error('FAIL',name);else console.log('PASS',name);}
check('balanced style tags',(html.match(/<style\b/gi)||[]).length===(html.match(/<\/style>/gi)||[]).length);
check('dark theme anthracite background',html.includes('--bg:#07090d'));
check('dark theme yellow accent',html.includes('--accent:#ffd400'));
check('light theme white and blue',html.includes('--panel:#FFFFFF')&&html.includes('--accent:#2563EB'));
check('dark selected custom option uses dark text',html.includes('body:not(.light) .sd-select-option[aria-selected="true"]{background:#ffd400!important;color:#11151a!important'));
check('native selected option contrast fix',html.includes('body:not(.light) select option:checked,body:not(.light) select option:focus{background:#ffd400!important;color:#11151a!important}'));
check('phone breakpoint present',html.includes('@media (max-width: 759px)'));
check('tablet portrait breakpoint present',html.includes('@media (min-width: 760px) and (max-width: 1179px) and (orientation: portrait)'));
check('tablet landscape breakpoint present',html.includes('@media (min-width: 980px) and (max-width: 1179px) and (orientation: landscape)'));
check('reduced-motion support present',html.includes('prefers-reduced-motion:reduce'));
for(const file of ['index.html']){
 for(const target of ['www/'+file,'android-wrapper/app/src/main/assets/'+file,'android-wrapper/app/src/main/assets/www/'+file]){
  check(target+' synchronized',fs.readFileSync(path.join(root,target),'utf8')===html);
 }
}
if(checks.some(x=>!x[1]))process.exit(1);
console.log(`Stage 47 theme QA passed: ${checks.length} checks.`);
