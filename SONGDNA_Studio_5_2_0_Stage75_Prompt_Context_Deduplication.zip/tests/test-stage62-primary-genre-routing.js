'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
require(path.join(root, 'www/genre-adlib-engine.js'));
const engine = global.SongDnaGenreAdlibEngine;
assert.ok(engine, 'genre/ad-lib engine loads');

// A non-MDNA global profile ID must not mask the actual selected Music DNA.
const resolved = engine.resolveAdlibMatchPlan({
  dna: 'Emotional Trap', musicDnaId: 'global-profile-unknown',
  globalProfile: { id: 'global-profile-unknown' }
});
assert.equal(resolved.musicDnaId, 'MDNA-009');
assert.ok(resolved.genreIds.includes('emotional_rap'));
assert.equal(resolved.isTraditional, false);

// Traditional profiles must fail closed when the scene catalog has no verified genre affinity.
const traditional = engine.resolveAdlibMatchPlan({ dna: 'Aegean Zeybek – Regional Folk Character' });
assert.equal(traditional.isTraditional, true);
const unsafe = [
  { id: 'modern-hype', phrase: 'Hey', genreIds: ['trap'] },
  { id: 'unknown-phrase', phrase: 'Unknown' }
];
const filtered = engine.filterItems(unsafe, traditional);
assert.deepEqual(filtered.items, []);
assert.equal(filtered.matchLevel, 'traditional-no-verified-affinity');

// A verified traditional affinity is allowed; a mismatched classified phrase is not.
const verified = engine.filterItems([
  { id: 'folk-response', phrase: 'Ah', genreIds: ['traditional_folk'] },
  { id: 'trap-hype', phrase: 'Yeah', genreIds: ['trap'] }
], traditional);
assert.deepEqual(verified.items.map(x => x.id), ['folk-response']);

// For modern genres, unmatched classified items are excluded; unclassified items may remain as fallback.
const modern = engine.resolveAdlibMatchPlan({ dna: 'Emotional Trap' });
const modernFiltered = engine.filterItems([
  { id: 'wrong', genreIds: ['drill'] },
  { id: 'neutral' }
], modern);
assert.deepEqual(modernFiltered.items.map(x => x.id), ['neutral']);
console.log('PASS Stage 62 primary genre routing: identity fallback, traditional fail-closed, verified affinity and safe modern fallback.');
