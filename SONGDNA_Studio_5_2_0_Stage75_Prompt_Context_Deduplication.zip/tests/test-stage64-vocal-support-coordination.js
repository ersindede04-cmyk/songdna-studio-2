'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../www/app.js'), 'utf8');
const extract = (start, end) => source.slice(source.indexOf(start), source.indexOf(end, source.indexOf(start)));
const snippets = [
  extract('function recommendAdlibPhrases(', '\n\n// Global Cultural Ad-lib DNA registry'),
  extract('function buildAdlibArrangement(', '\n// Vocal & Ad-lib Engine'),
  extract('function buildVocalProfile(', '\n// Experimental Fusion Lab')
].join('\n');
const sandbox = {
  globalThis: null,
  SongDnaAdlibCatalog: { get: () => [], note: () => '' },
  SongDnaSceneJargonCatalog: { get: () => [], note: () => '' },
  SongDnaAdlibIntelligenceEngine: { evaluate: () => ({ score: 0, reasons: [] }), buildPlan: () => ({ sections: {}, promptText: 'ADLIB_PLAN_TEST' }) },
  SongDnaGenreAdlibEngine: {
    resolveAdlibMatchPlan: () => ({ genreIds: ['trap'], isTraditional: false }),
    filterItems: items => ({ items, matchLevel: 'test' })
  },
  adlibSceneForCultureSource: () => null,
  resolveDefaultAdlibCulture: () => ({ scene: 'none', status: 'test', label: 'test', guidance: '' })
};
sandbox.globalThis = sandbox;
vm.runInNewContext(snippets, sandbox);

const minimal = sandbox.recommendAdlibPhrases({ back: 'minimal', adlib: 'high', dna: 'Modern Trap' }, { get: () => [
  { id: 'group', phrase: 'Hey', function: 'group hype', meaning: 'crowd', placement: 'chorus', delivery: 'shout' },
  { id: 'soft', phrase: 'Mm', function: 'melodic', meaning: 'soft harmony', placement: 'phrase-end', delivery: 'sung' }
] });
assert.equal(minimal.count, 1, 'minimal backing limits automatic phrase density');
assert.equal(minimal.suggestions.length, 1);
assert.notEqual(minimal.suggestions[0].id, 'group', 'crowd/hype phrases are down-ranked for minimal backing');

const profile = sandbox.buildVocalProfile({
  dna: 'Emotional Trap', back: 'female harmonies', mainVoice: 'male lead',
  adlib: 'balanced', adlibScene: 'none', languageLabel: 'Turkish',
  productionArrangementMode: 'modern', adlibArrangementMode: 'Akıllı / bölüm odaklı'
});
assert.match(profile.promptText, /FEMALE HARMONY SUPPORT/);
assert.match(profile.promptText, /ADLIB_PLAN_TEST/);
assert.ok(Array.isArray(profile.arrangement.promptText));
assert.doesNotThrow(() => profile.promptText.includes('ADLIB_PLAN_TEST'), 'arrangement prompt array is joined into the final vocal prompt');

const groupProfile = sandbox.buildVocalProfile({
  dna: 'Zeybek', back: 'crowd group vocals', adlib: 'balanced', adlibScene: 'none',
  languageLabel: 'Turkish', productionArrangementMode: 'classic'
});
assert.match(groupProfile.promptText, /GROUP VOCAL SUPPORT/);
assert.match(groupProfile.promptText, /do not add crowd shouts unless the genre and cultural profile support them/);
console.log('PASS Stage 64 vocal support coordination: backing-role direction, minimal density, genre-aware group restraint and arrangement prompt integration.');
