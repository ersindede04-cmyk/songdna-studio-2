'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const appPath = path.join(__dirname, '../www/app.js');
const source = fs.readFileSync(appPath, 'utf8');
const start = source.indexOf('function buildSharedOutputIdentityContract(c){');
const end = source.indexOf('// 5.2.0 Gemini Instruction Engine:', start);
assert.ok(start >= 0 && end > start, 'shared identity helper must exist at script scope');
const helperSource = source.slice(start, end);
const sandbox = {};
vm.runInNewContext(helperSource + '\nthis.buildSharedOutputIdentityContract=buildSharedOutputIdentityContract;', sandbox);
const ctx = {
 profileSnapshot:{id:'snapshot-66'}, dna:'Emotional Trap', bpm:142, bpmManual:true,
 energy:'Medium', emotionProfile:{label:'Melancholic'}, atmosphereProfile:{label:'Intimate / nocturnal'},
 mainVoice:'Male lead', back:'Female harmonies', vocalDelivery:'restrained melodic rap', vocalTexture:'airy',
 adlib:'low density', adlibPlacement:'line endings', effects:'short plate', fusion:'none',
 technique:{name:'808 glide'}, productionProfile:{preset:{profileId:'MDNA-EMO-TRAP',family:'modern',identityTraits:['minor-key melody','half-time trap pulse'],userOverrides:[{dimension:'rhythm',value:'manual'}]},promptText:'locked production DNA'},
 sectionArrangementProfile:{promptText:'Verse restrained; chorus wider'}, integratedProductionProfile:{promptText:'integrated shared production'},
 globalProfile:{id:'MDNA-EMO-TRAP',musical_traits:['minor-key melody']}
};
const contract = sandbox.buildSharedOutputIdentityContract(ctx);
for (const expected of ['snapshot-66','Emotional Trap','142','Melancholic','Intimate / nocturnal','Male lead','Female harmonies','808 glide','rhythm','manual']) assert.ok(contract.includes(expected), `shared contract must retain ${expected}`);
assert.match(contract,/same production snapshot/);
assert.match(contract,/Respect manual locks/);
assert.match(contract,/song topic remains independent/);
const styleStart = source.indexOf('function buildGeminiStylePrompt(');
const lyricsStart = source.indexOf('function makeLyricsPrompt(');
assert.ok(source.slice(styleStart, lyricsStart).includes('buildSharedOutputIdentityContract(c)'), 'Styles prompt must use shared contract');
assert.ok(source.slice(lyricsStart, lyricsStart + 500).includes('buildSharedOutputIdentityContract(c)'), 'Lyrics prompt must use shared contract');
assert.match(source,/sharedIdentityContract:buildSharedOutputIdentityContract\(c\)/,'provider envelope must carry same contract');
console.log('PASS Stage 66 Styles/Lyrics shared identity contract, snapshot, manual locks, vocal roles and arrangement consistency.');
