'use strict';
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const net = require('node:net');
const path = require('node:path');

async function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      server.close(() => resolve(port));
    });
  });
}
async function waitForHealth(base, child) {
  const until = Date.now() + 8000;
  while (Date.now() < until) {
    if (child.exitCode !== null) throw new Error('API server exited: ' + child.exitCode);
    try {
      const response = await fetch(base + '/health');
      if (response.ok) return response.json();
    } catch (_) {}
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error('Health check timed out');
}

(async () => {
  const port = await freePort();
  const root = path.resolve(__dirname, '..');
  const token = 'stage69-runtime-token-12345';
  const child = spawn(process.execPath, [
    '--require', path.join(__dirname, 'mock-gemini-fetch.cjs'),
    path.join(root, 'server.js')
  ], {
    cwd: root,
    env: {
      ...process.env,
      PORT: String(port),
      APP_ACCESS_TOKEN: token,
      GEMINI_API_KEY: 'test-only-never-real',
      GEMINI_MODELS: 'gemini-3.1-flash-lite,gemini-3.6-flash,gemini-3.8-flash',
      GEMINI_MODEL: 'gemini-3.1-flash-lite'
    },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let logs = '';
  child.stdout.on('data', x => { logs += x.toString(); });
  child.stderr.on('data', x => { logs += x.toString(); });
  const base = `http://127.0.0.1:${port}`;
  const headers = { 'Content-Type': 'application/json', 'X-App-Token': token };
  const post = (prompt) => fetch(base + '/api/lyrics', {
    method: 'POST', headers, body: JSON.stringify({ model: 'gemini-3.1-flash-lite', prompt })
  });

  try {
    const health = await waitForHealth(base, child);
    assert.equal(health.ok, true);
    assert.equal(health.providers.gemini, true);
    assert.equal(JSON.stringify(health).includes('test-only-never-real'), false, 'health must never disclose API key');
    console.log('PASS health reports provider availability without exposing secrets');

    const empty = await post('EMPTY_RESPONSE_TEST');
    assert.equal(empty.status, 502);
    assert.match((await empty.json()).error, /Gemini üretimi başarısız/i);
    console.log('PASS empty candidate payload rejected');

    const malformed = await post('MALFORMED_RESPONSE_TEST');
    assert.equal(malformed.status, 502);
    assert.match((await malformed.json()).error, /Gemini üretimi başarısız/i);
    console.log('PASS malformed upstream payload is contained and does not expose internals');

    const invalid = await post('API_400_TEST');
    assert.equal(invalid.status, 502);
    assert.match((await invalid.json()).error, /üretimi başarısız/i);
    console.log('PASS non-retryable upstream request error stops model fallback');

    const quota = await post('API_429_TEST');
    assert.equal(quota.status, 429);
    assert.match((await quota.json()).error, /kotasına ulaşıldı/i);
    console.log('PASS quota error remains distinct after allowed fallback attempts');

    const wrongMethod = await fetch(base + '/api/lyrics', { method: 'GET' });
    assert.equal(wrongMethod.status, 404);
    console.log('PASS unsupported method rejected');

    console.log('STAGE 69 GEMINI RUNTIME RESILIENCE TESTS PASSED (6 groups)');
  } catch (error) {
    console.error('STAGE 69 GEMINI RUNTIME RESILIENCE TESTS FAILED:', error.stack || error);
    if (logs) console.error('SERVER LOGS:\n' + logs);
    process.exitCode = 1;
  } finally {
    child.kill('SIGTERM');
  }
})();
