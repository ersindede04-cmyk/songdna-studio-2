'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const appPath = path.join(__dirname, '../www/app.js');
const source = fs.readFileSync(appPath, 'utf8');

// Exercise the same shared identity contract used by both output builders.
const start = source.indexOf('function buildSharedOutputIdentityContract(c){');
const end = source.indexOf('// 5.2.0 Gemini Instruction Engine:', start);
assert.ok(start >= 0 && end > start, 'shared identity contract must be available');
const sandbox = {};
vm.runInNewContext(source.slice(start, end) + '\nthis.buildSharedOutputIdentityContract=buildSharedOutputIdentityContract;', sandbox);

const scenarios = [
  { name:'Emotional Trap', family:'modern', emotion:'Melancholic', energy:'Low', bpm:142, voice:'Male melodic lead', backing:'Female harmonies', technique:'808 glide', topic:'a family reunion', lock:'manual rhythm lock' },
  { name:'Turkish Folk', family:'traditional', emotion:'Longing', energy:'Medium', bpm:96, voice:'Regional folk lead', backing:'No backing vocals', technique:'tezene picking', topic:'a family reunion', lock:'manual melody lock' },
  { name:'Zeybek', family:'traditional', emotion:'Proud / resolute', energy:'High', bpm:9, voice:'Traditional lead vocal', backing:'Community response', technique:'bağlama tezene', topic:'a family reunion', lock:'manual rhythm lock' }
];
for (const [i, s] of scenarios.entries()) {
  const ctx = {
    profileSnapshot:{id:`stage68-${i}`}, dna:s.name, bpm:s.bpm, energy:s.energy,
    emotionProfile:{label:s.emotion}, atmosphereProfile:{label:'Open / grounded'},
    mainVoice:s.voice, back:s.backing, technique:{name:s.technique}, theme:s.topic,
    productionProfile:{preset:{profileId:`profile-${i}`,family:s.family,identityTraits:[s.technique,s.family],userOverrides:[{dimension:s.lock.split(' ')[1],value:'manual'}]},promptText:'shared production profile'},
    globalProfile:{id:`profile-${i}`,musical_traits:[s.technique]},
    sectionArrangementProfile:{promptText:'preserve selected form'}, integratedProductionProfile:{promptText:'same shared identity'}
  };
  const contract = sandbox.buildSharedOutputIdentityContract(ctx);
  for (const expected of [s.name, String(s.bpm), s.emotion, s.energy, s.voice, s.backing, s.technique, s.lock.split(' ')[1]]) {
    assert.ok(contract.includes(expected), `${s.name}: shared contract retains ${expected}`);
  }
  assert.ok(!contract.includes(s.topic), 'song topic is not coupled to genre identity');
  assert.match(contract,/same production snapshot/);
  assert.match(contract,/Respect manual locks/);
  assert.match(contract,/song topic remains independent/);
}

// Verify that the production call graph uses the same contract for Lyrics and both Styles paths.
assert.match(source,/buildGeminiInstructionEnvelope\('lyrics',currentContext,makeLyricsPrompt\(currentContext\)\)/);
assert.match(source,/function buildGeminiStylePrompt\(c,baseStyle,exclude=''/);
assert.match(source,/buildSharedOutputIdentityContract\(c\)/);
assert.match(source,/const stylePrompt=buildGeminiStylePrompt\(snap,generatedResult\.style,generatedResult\.exclude\)/);
assert.match(source,/const prompt=buildGeminiStylePrompt\(snapshot,last\.style,last\.exclude\)/);
assert.match(source,/if\(!isCurrentGeneration\(requestId,generatedResult\)\)return/);
assert.match(source,/if\(last!==resultRef\)/);
console.log('PASS Stage 68: multi-genre shared identity scenarios and Lyrics/automatic Styles/manual Styles call graph.');
