const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const envelopeStart = app.indexOf('function buildGeminiInstructionEnvelope');
const envelopeEnd = app.indexOf('\nfunction buildGeminiStylePrompt', envelopeStart);
if (envelopeStart < 0 || envelopeEnd < 0) throw new Error('Gemini instruction envelope not found');
const envelope = app.slice(envelopeStart, envelopeEnd);
const forbidden = [
  'integratedProduction:c.integratedProductionProfile?.promptText',
  'sectionArrangement:c.sectionArrangementProfile?.promptText',
  'vocal:c.vocalProfile?.promptText',
  'vocalIdentity:c.vocalIdentityProfile?.promptText',
  'fusionLab:c.fusionProfile?.promptText'
];
for (const marker of forbidden) {
  if (envelope.includes(marker)) throw new Error('Duplicated verbose context remains in envelope: ' + marker);
}
if (!envelope.includes('productionProfileId:c.productionProfile?.preset?.profileId')) {
  throw new Error('Compact profile identity reference missing');
}
if (!app.includes('INTEGRATED PRODUCTION COORDINATION: ${c.integratedProductionProfile?.promptText||\'none\'}')) {
  throw new Error('Integrated production guidance is not explicitly included in Styles task prompt');
}
const copies = [
  'www/app.js',
  'android-wrapper/app/src/main/assets/app.js',
  'android-wrapper/app/src/main/assets/www/app.js'
];
for (const rel of copies) {
  if (fs.readFileSync(path.join(root, rel), 'utf8') !== app) {
    throw new Error('Runtime app.js copy mismatch: ' + rel);
  }
}
console.log('Stage 75 PASS: verbose engine guidance is not serialized twice in the shared envelope; engine coordination remains represented in task prompts; runtime copies match.');
