const fs=require('fs');
const js=fs.readFileSync('www/app.js','utf8');
const checks=[
 ['shared instruction envelope exists',/function buildGeminiInstructionEnvelope\(kind,c,basePrompt=''/],
 ['explicit priority order exists',/explicit user instructions.*current UI selections.*selected DNA profiles.*automatic suggestions/s],
 ['two-output contract is explicit',/Use only the two Suno outputs: STYLES and LYRICS/],
 ['lyrics contract integrated',/buildGeminiInstructionEnvelope\('lyrics',currentContext,makeLyricsPrompt\(currentContext\)\)/],
 ['central Styles builder exists',/function buildGeminiStylePrompt\(c,baseStyle,exclude=''/],
 ['automatic Styles call uses central builder',/const stylePrompt=buildGeminiStylePrompt\(snap,generatedResult\.style,generatedResult\.exclude\)/],
 ['manual Styles call uses central builder',/const prompt=buildGeminiStylePrompt\(snapshot,last\.style,last\.exclude\)/],
 ['user choices remain authoritative',/Never silently replace, remove or reinterpret a user selection/],
 ['no additional token counting API',!/countTokens\s*\(/.test(js)],
 ['no new third output field',!/introOutput|thirdOutputField/.test(js)]
];
let failed=0;
for(const [label,pattern] of checks){const ok=pattern instanceof RegExp?pattern.test(js):pattern;console.log(`${ok?'PASS':'FAIL'} ${label}`);if(!ok)failed++;}
const lyricsCalls=(js.match(/postGemini\('\/api\/lyrics'/g)||[]).length;
const styleCalls=(js.match(/postGemini\('\/api\/style'/g)||[]).length;
console.log(`${lyricsCalls===1?'PASS':'FAIL'} exactly one existing Lyrics endpoint call site`);
console.log(`${styleCalls===2?'PASS':'FAIL'} two existing Styles call paths (automatic + manual)`);
if(lyricsCalls!==1||styleCalls!==2)failed++;
if(failed)process.exit(1);
console.log('GEMINI INSTRUCTION ENGINE TESTS PASSED');
