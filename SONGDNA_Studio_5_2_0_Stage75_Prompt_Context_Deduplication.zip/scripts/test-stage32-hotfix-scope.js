const fs = require('fs');
const vm = require('vm');
const source = fs.readFileSync('www/app.js', 'utf8');
const helperMarker = '// Shared Stage 32 culture-source resolver.';
const helperPos = source.indexOf(helperMarker);
const promptPos = source.indexOf('function buildGeminiInstructionEnvelope');
if (helperPos < 0 || promptPos < 0 || helperPos > promptPos) {
  throw new Error('Culture-source resolver must be declared at script scope before the Gemini prompt builder.');
}
const match = source.slice(helperPos).match(/function adlibSceneForCultureSource\(value\)\{[^\n]+\}/);
if (!match) throw new Error('Global culture-source resolver declaration not found.');
const sandbox = {};
vm.runInNewContext(match[0] + '\nthis.resolve = adlibSceneForCultureSource;', sandbox);
const cases = [
  ['French Rap / France · Français', 'france'],
  ['US Hip-Hop / English · US English', 'us'],
  ['UK Drill-Grime / UK English-MLE', 'uk'],
  ['Deutschrap / German', 'germany'],
  ['Turkish Rap / Turkish', 'turkey'],
  ['Spanish Trap / Spanish', 'spanish'],
  ['K-Hip-Hop / Korean', 'east-asia'],
  ['Japanese Hip-Hop / Japanese', 'east-asia'],
  ['Persian Rap / Persian', 'west-asia'],
  ['Unsupported culture', null]
];
for (const [input, expected] of cases) {
  const actual = sandbox.resolve(input);
  if (actual !== expected) throw new Error(`${input}: expected ${expected}, got ${actual}`);
}
for (const file of ['app.js', 'www/app.js', 'android-wrapper/app/src/main/assets/www/app.js']) {
  if (fs.readFileSync(file, 'utf8') !== source) throw new Error(`${file} is not synchronized with www/app.js`);
}
console.log(`Stage 32.1 hotfix passed: global resolver scope, ${cases.length} culture mappings, and 3-way runtime parity.`);
