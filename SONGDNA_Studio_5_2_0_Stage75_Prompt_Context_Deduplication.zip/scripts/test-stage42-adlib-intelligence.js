const assert=require('node:assert/strict');
const e=require('../adlib-intelligence-engine.js');
const emotions=['auto','melancholy','anger','love','hope','longing','confidence','joy','anxiety','grief','triumph'];
const energies=['low','medium','high','veryHigh'];
let combos=0;
for(const emotion of emotions){for(let intensity=1;intensity<=4;intensity++){for(const energy of energies){
 const c={emotionProfile:{type:emotion,label:emotion,intensity,intensityLabel:String(intensity)},energyProfile:{level:energy}};
 const p=e.buildPlan(c);assert.ok(p.promptText.includes('AD-LIB INTELLIGENCE'));assert.ok(p.density>=1&&p.density<=4);assert.equal(p.energy,energy);combos++;
 const scored=e.evaluate(c,{function:'melodic emotional response',meaning:'soft sustained echo',placement:'verse ending',delivery:'sung'});assert.ok(Number.isFinite(scored.score));
}}}
const low=e.buildPlan({emotionProfile:{type:'melancholy',intensity:4},energyProfile:{level:'low'}});
const high=e.buildPlan({emotionProfile:{type:'melancholy',intensity:4},energyProfile:{level:'veryHigh'}});
assert.equal(low.emotion,high.emotion);assert.notEqual(low.energy,high.energy);
assert.match(low.sections.verse,/wide gaps|breath-shaped|intimate|sustained/i);
assert.match(high.sections.chorus,/call-and-response|group layer|hook peaks/i);
const joy=e.evaluate({emotionProfile:{type:'joy',intensity:4},energyProfile:{level:'high'}},{function:'group celebration call and response',meaning:'hype crowd',placement:'chorus',delivery:'shouted'});
const grief=e.evaluate({emotionProfile:{type:'grief',intensity:4},energyProfile:{level:'low'}},{function:'group celebration call and response',meaning:'hype crowd',placement:'chorus',delivery:'shouted'});
assert.ok(joy.score>grief.score,'emotion should influence phrase ranking');
console.log(`Stage 42 ad-lib intelligence: ${combos} emotion/intensity/energy combinations passed.`);
