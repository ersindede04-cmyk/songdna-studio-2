'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = process.cwd();
const app = fs.readFileSync(`${root}/app.js`, 'utf8');
const html = fs.readFileSync(`${root}/index.html`, 'utf8');
const webApp = fs.readFileSync(`${root}/www/app.js`, 'utf8');
const androidApp = fs.readFileSync(`${root}/android-wrapper/app/src/main/assets/www/app.js`, 'utf8');

// Evaluate only the literal Music DNA catalogue declaration, without browser dependencies.
const catalogueSource = app.slice(0, app.indexOf('const GLOBAL_MUSIC_DNA='));
const sandbox = {};
vm.runInNewContext(`${catalogueSource}\nglobalThis.__musicDnaCount = dna.length;`, sandbox);
assert.equal(sandbox.__musicDnaCount, 66, 'the selectable runtime catalogue must contain exactly 66 Music DNA profiles');
assert.match(html, /<option value="auto66"[^>]*>Otomatik · 66 paketin tamamını sırayla döndür/);
assert.match(html, /<option value="manual">Elle seç · 66 paketin tamamı/);
assert.doesNotMatch(html, /auto18|İlk 18 paketi/);
assert.match(app, /n%dna\.length/);
assert.match(app, /\(index\+1\)%dna\.length/);
assert.match(app, /songdna_music_dna_rotation_v1/); // old progress migration
assert.match(app, /expectedRevision!==musicDnaModeRevision/);
assert.match(app, /v\('musicDnaMode'\)!=='auto66'/);
assert.match(app, /Number\(v\('dna'\)\)!==index/);
assert.match(app, /commitMusicDnaRotation\(rotatedMusicDna\.index,rotationRevisionAtStart\)/);
assert.ok(app.includes("$('dna').addEventListener('change',()=>{musicDnaModeRevision++;if(v('musicDnaMode')==='auto66')$('musicDnaMode').value='manual';});"), 'manual DNA selection must disable auto mode');
assert.equal(webApp, app, 'web runtime must match root runtime');
assert.equal(androidApp, app, 'Android WebView runtime must match root runtime');
console.log('Stage 46 PASS: exactly 66 profiles, wraparound rotation, legacy progress migration, manual override, in-flight manual-change protection, success-only commit call and runtime parity.');
