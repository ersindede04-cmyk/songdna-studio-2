from pathlib import Path
import re
root = next(parent for parent in Path(__file__).resolve().parents if (parent / 'www' / 'index.html').exists())
html = (root / 'www' / 'index.html').read_text(encoding='utf-8')
app = (root / 'www' / 'app.js').read_text(encoding='utf-8')
assert "querySelectorAll('select:not([multiple])')" in app
assert "mountThemedSelect('musicDnaMode')" not in app
assert "mountThemedSelect('commandTemplate')" not in app
assert "select:not([multiple])" in app and 'themedSelectObserver.observe(document.body' in app
assert '.sd-select-trigger' in html and '.sd-select-menu' in html and '.sd-select-option' in html
assert 'body:not(.light) .sd-select-option[aria-selected="true"]' in html
assert 'body.light .sd-select-option[aria-selected="true"]' in html
assert '#ffd400' in html and '#eaf1ff' in html and '#2563eb' in html
assert re.search(r'<style id="songdna-520-stage54-unified-dropdowns">[\s\S]*?</style>', html)
# All deployed source copies must be byte-identical.
for rel in ('index.html', 'app.js'):
    canonical = (root / 'www' / rel).read_bytes()
    assert (root / rel).read_bytes() == canonical, f'root {rel} mismatch'
    assert (root / 'android-wrapper/app/src/main/assets/www' / rel).read_bytes() == canonical, f'Android {rel} mismatch'
print('Stage 54 unified dropdown checks: PASS')
