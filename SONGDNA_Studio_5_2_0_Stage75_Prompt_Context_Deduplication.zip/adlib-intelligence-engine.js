/* SONGDNA Ad-lib Intelligence Engine v1.0
 * Mood/energy-aware phrase ranking, density and section placement.
 * Cultural phrase authenticity and manual selection remain authoritative.
 */
(function(root){
 'use strict';
 const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
 const EMOTION_MAP={
  melancholy:{family:'reflective',prefer:['emotional','melodic','sustain','breath','echo','soft'],avoid:['hype','crowd','shout','aggressive']},
  grief:{family:'reflective',prefer:['emotional','melodic','sustain','breath','soft','response'],avoid:['hype','crowd','festival','shout']},
  longing:{family:'reflective',prefer:['emotional','melodic','sustain','echo','breath'],avoid:['hype','crowd','shout']},
  love:{family:'warm',prefer:['melodic','harmony','soul','soft','response','echo'],avoid:['aggressive','hype']},
  hope:{family:'uplifting',prefer:['lift','response','melodic','rising','chorus'],avoid:['dark','menacing']},
  anger:{family:'intense',prefer:['sharp','rhythmic','call','emphasis','hype','assertive'],avoid:['whisper','soft','sustain']},
  confidence:{family:'assertive',prefer:['call','emphasis','rhythmic','hype','response'],avoid:['whisper','fragile']},
  joy:{family:'celebratory',prefer:['celebration','hype','group','call','response','chorus'],avoid:['grief','whisper']},
  anxiety:{family:'tense',prefer:['breath','echo','tension','whisper','short'],avoid:['festival','crowd','celebration']},
  triumph:{family:'anthemic',prefer:['group','hype','call','response','chorus','lift'],avoid:['whisper','sparse']}
 };
 const ENERGY={low:{count:1,spacing:'wide',rule:'very sparse; one isolated accent at most'},medium:{count:2,spacing:'moderate',rule:'selective phrase-end and hook responses'},high:{count:3,spacing:'active',rule:'more frequent rhythmic accents in genuine gaps'},veryHigh:{count:3,spacing:'dense-controlled',rule:'layered and frequent call-and-response at selected peaks; never mask the lead'}};
 function resolveEnergy(c={}){
  const k=c.energyProfile?.level||c.energyProfile?.key;
  if(['low','medium','high','veryHigh'].includes(k))return k;
  const raw=String(c.energy||'').toLowerCase();
  if(/very.?high|çok yüksek|festival|hard rave/.test(raw))return 'veryHigh';
  if(/high|yüksek|enerjik|yoğun/.test(raw))return 'high';
  if(/low|düşük|sakin|calm/.test(raw))return 'low';
  return 'medium';
 }
 function evaluate(c={},item={}){
  const emotion=c.emotionProfile||{},type=emotion.type||'auto',level=Number(emotion.intensity)||2,energy=resolveEnergy(c),profile=EMOTION_MAP[type];
  const words=(String(item.function||'')+' '+String(item.meaning||'')+' '+String(item.placement||'')+' '+String(item.delivery||'')).toLowerCase();
  let score=0,reasons=[];
  if(profile){const good=profile.prefer.filter(x=>words.includes(x)),bad=profile.avoid.filter(x=>words.includes(x));score+=good.length*(level>=3?3:2)-bad.length*(level>=3?3:2);if(good.length)reasons.push(`${emotion.label||type} duygusuyla uyumlu`);}
  const e=ENERGY[energy];
  if(energy==='low'&&/soft|breath|melodic|emotional|sustain|echo/.test(words)){score+=3;reasons.push('düşük enerjiye uygun');}
  if(energy==='high'&&/rhythmic|call|hype|emphasis|response|energy/.test(words)){score+=3;reasons.push('yüksek enerjiye uygun');}
  if(energy==='veryHigh'&&/group|hype|call|response|crowd|rhythmic|celebration/.test(words)){score+=4;reasons.push('çok yüksek enerji zirvesine uygun');}
  if(energy==='veryHigh'&&/whisper|soft|sparse/.test(words))score-=2;
  if(energy==='low'&&/crowd|festival|hype|shout/.test(words))score-=3;
  return {score,reasons,energy,emotion:type,intensity:level};
 }
 function buildPlan(c={}){
  const energy=resolveEnergy(c),e=ENERGY[energy],emotion=c.emotionProfile||{},type=emotion.type||'auto',level=Number(emotion.intensity)||2,profile=EMOTION_MAP[type];
  const intensityFactor=clamp(level/2,.5,2),density=clamp(e.count*intensityFactor,1,4);
  const moodRule=profile?`Emotional direction ${emotion.label||type} at ${emotion.intensityLabel||level+'/4'}: ${level>=3?'make supporting-vocal expression more emotionally distinct, but do not automatically increase phrase count':'keep supporting-vocal expression controlled and context-sensitive'}.`:'Infer ad-lib emotional color only from the explicit song brief; do not assume a mood.';
  const sections={
   intro:energy==='low'?'Optional single breath, hum or motif; preserve an exposed lead entrance.':'Use a brief identity motif only if it supports the opening; do not delay the lead.',
   verse:energy==='low'?'Leave wide gaps; one quiet phrase-end response at most.':energy==='veryHigh'?'Use short rhythmic accents in selected bar gaps; alternate active and empty bars.':'Place selective phrase-end responses; keep the lead intelligible.',
   preChorus:energy==='low'?'Use silence or a subtle sustained lift.':'Increase anticipation with a short rising response or breath cue.',
   chorus:energy==='veryHigh'?'Use the strongest call-and-response, selective doubles and group layer at hook peaks; avoid continuous overlap.':energy==='low'?'One restrained melodic answer or harmony accent; preserve space.':'Use concise hook answers and selective doubles.',
   bridge:'Change texture; remove or thin ad-libs to create contrast, unless the bridge is the deliberate climax.',
   outro:'Resolve with a reduced echo or motif related to the intro; do not introduce unrelated phrases.'
  };
  if(profile?.family==='reflective'||profile?.family==='tense'){
   sections.verse+=' Favor breath-shaped, intimate or sustained responses over crowd shouts.';
   sections.chorus+=' Emotional intensity should be expressed through phrasing and tone, not simply more shouts.';
  } else if(profile?.family==='celebratory'||profile?.family==='anthemic'||profile?.family==='assertive'||profile?.family==='intense'){
   sections.chorus+=' Favor confident calls and clear group responses when the selected genre/culture supports them.';
  } else if(profile?.family==='warm'){
   sections.chorus+=' Favor warm melodic echoes and harmony doubles over aggressive hype calls.';
  }
  return {energy,emotion:type,intensity:level,density:Math.round(density*10)/10,spacing:e.spacing,sections,moodRule,energyRule:`Energy tier ${energy}: ${e.rule}.`,promptText:[`AD-LIB INTELLIGENCE: ${moodRule}`,`Density target ${Math.round(density*10)/10}/4; spacing ${e.spacing}. ${e.rule}.`,...Object.entries(sections).map(([k,v])=>`${k.toUpperCase()} AD-LIB: ${v}`),'Manual phrase selections always override automatic phrase recommendations. Use only verified catalog phrases or user-provided wording; otherwise prefer wordless vocalises or silence.'].join(' ')};
 }
 root.SongDnaAdlibIntelligenceEngine={version:'1.0',resolveEnergy,evaluate,buildPlan,emotionMap:EMOTION_MAP,energyLevels:ENERGY};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaAdlibIntelligenceEngine;
})(typeof globalThis!=='undefined'?globalThis:this);
