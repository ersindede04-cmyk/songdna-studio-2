# SONGDNA Studio 5.2.0 — Android / Web / Gemini source package

SONGDNA Studio prepares original lyrics and Suno-ready Styles prompts. It is a prompt and lyric helper, not an audio player or audio-generation engine.

## Project layout
- `www/`: web runtime.
- `android-wrapper/`: native Android WebView wrapper and Gradle project.
- `backend/`: Node.js Gemini API service.
- `scripts/` and `tests/`: source, API and regression tests.
- `BUILD_MANIFEST.json`: version and build metadata.

The same seven runtime files are included in `www/` and Android's bundled WebView assets. `scripts/verify-source.py` checks that they remain identical.

## Version
- App version: **5.2.0**
- Android versionCode: **27**
- Application ID: `com.songdna.studio`
- Minimum SDK: 23
- Target SDK: 35

## GitHub APK build
1. Upload the contents of this ZIP to the root of the GitHub repository (do not nest the outer project folder).
2. Open GitHub → Actions.
3. Select **SONG DNA SMART STUDIO 5.2.0 - Android APK**.
4. Select **Run workflow**.
5. When the workflow succeeds, download `SONGDNA-Studio-5.2.0-debug-APK` from Artifacts.

The workflow validates source files, builds with Java 17 / Gradle 8.9 / Android SDK 35, verifies the APK and uploads its SHA-256 checksum to the job log. This source package has not itself been remotely built yet.

## Signed release APK (optional)
A signed release is built only when all four GitHub Actions secrets are configured:
- `SONGDNA_KEYSTORE_BASE64`
- `SONGDNA_KEYSTORE_PASSWORD`
- `SONGDNA_KEY_ALIAS`
- `SONGDNA_KEY_PASSWORD`

Keep the original keystore and alias safe for future updates. Never commit the keystore or passwords to the repository. A debug APK is sufficient for initial device testing.

## Render / Gemini deployment
Deploy `backend/` as the Render service root (or configure the service root directory to `backend`). Set:
- `APP_ACCESS_TOKEN`: random secret, at least 12 characters.
- `GEMINI_API_KEY`: Google AI Studio key; server-side only.
- Optional: `GEMINI_MODEL`, `GEMINI_MODELS`, `PORT`, `ALLOWED_ORIGIN`, `TRUST_PROXY`.

For this Android local-file WebView build, `ALLOWED_ORIGIN=*` is documented in `backend/DEPLOY_TR.md`. Do not put `GEMINI_API_KEY` in the app, web files, or GitHub source. Confirm Google billing and quota policy in the Google AI Studio project; the model ID alone does not guarantee free use.

## Local source checks
From the project root:
```bash
python3 scripts/verify-source.py
node tests/test-stage29-api-contract.js
node scripts/test-stage29-client-api-contract.js
node test-gemini-instruction-engine.js
node tests/test-saved-library.js
node tests/test-production-history.js
node scripts/test-stage28-cultural-routing.js
node scripts/test-stage26-traditional-vocal.js
node scripts/test-genre-adlib-engine.js
node scripts/test-global-cultural-adlib.js
node scripts/test-adlib-catalog.js
node scripts/test-stage31-2-music-dna-arrangement.js
```

## Verification boundaries
Static and isolated tests do not prove a remote GitHub Actions build, a live Render deployment, real Gemini account connectivity, Android WebView behavior on a physical device, or Suno audio results. Those require separate remote and device testing.

## Stage 38 updates

Stage 38 repairs the malformed stylesheet boundaries that caused CSS rules to appear as page text, changes automatic Music DNA rotation to the full 66-profile catalogue, adds male/female pairs for all vocal command-template families, and uses theme-aware custom dropdowns for the Music DNA mode and command-template selectors. The Stage 37 100,000-character prompt limit remains intact. The Android WebView asset bundle is synchronized with the web source.

To build the Android APK from GitHub Actions, add `SONGDNA_Studio_5_2_0_Stage38_Theme_DNA_Vocal_Integration.zip` to the repository root and run the `build.yml` workflow. The workflow explicitly extracts the ZIP before source validation and APK compilation.
