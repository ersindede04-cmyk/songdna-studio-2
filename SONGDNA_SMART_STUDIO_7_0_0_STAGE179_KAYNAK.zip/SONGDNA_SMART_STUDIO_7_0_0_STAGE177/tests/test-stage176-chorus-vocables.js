const fs=require('fs');const path=require('path');const root=path.resolve(__dirname,'..');
const app=fs.readFileSync(path.join(root,'www/app.js'),'utf8');
const catalog=fs.readFileSync(path.join(root,'www/adlib-catalog.js'),'utf8');
for(const phrase of ['CHORUS REPETITION CONTROL','Do not duplicate a complete chorus consecutively','Preserve legitimate refrain, kavuştak','VOCABLES / RHYTHMIC VOCAL SYLLABLES']) if(!app.includes(phrase)) throw new Error('Missing prompt rule: '+phrase);
for(const phrase of ['taka taka','paka paka','taka tuka','papi papi','ram papapam','la la la','ta ta ta','ya ya ya','a ya ya ya','bam bam','dan dan','Prrr']) if(!catalog.toLowerCase().includes(phrase.toLowerCase())) throw new Error('Missing vocal pattern: '+phrase);
if(!catalog.includes("'vocable'")) throw new Error('Vocable category metadata missing');
console.log('Stage176 chorus repetition and vocable catalog checks passed.');
