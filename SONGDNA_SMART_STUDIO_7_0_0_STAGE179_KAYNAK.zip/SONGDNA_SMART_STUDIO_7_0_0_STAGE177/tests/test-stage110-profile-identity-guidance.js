'use strict';
const fs=require('fs');
const path=require('path');
const assert=require('assert');
const root=path.resolve(__dirname,'..');
const source=fs.readFileSync(path.join(root,'app.js'),'utf8');
const match=source.match(/const GLOBAL_MUSIC_DNA=(\{.*?\});/);
assert(match,'GLOBAL_MUSIC_DNA catalog must exist');
const catalog=JSON.parse(match[1]);
assert.strictEqual(catalog.music_dna_profiles.length,75,'catalog profile count must remain 69');
const byId=Object.fromEntries(catalog.music_dna_profiles.map(p=>[p.id,p]));
for(const id of ['MDNA-022','MDNA-050','MDNA-052','MDNA-055']){
 const p=byId[id];assert(p,`${id} must remain in catalog`);
 assert(p.musical_traits.length>=3,`${id} needs distinct defining traits`);
 assert(p.instrument_guidance&&p.lyrics_guidance,`${id} needs instrument and lyric guidance`);
 assert(p.source_refs.length,`${id} must retain provenance`);
}
assert(/Preserve the user-selected language/.test(byId['MDNA-022'].lyrics_guidance),'UK Drill must not infer language');
assert(/do not assume violent, criminal or territorial themes/i.test(byId['MDNA-022'].lyrics_guidance),'UK Drill must not stereotype lyric subjects');
assert(/rather than treating every instrument as mandatory/i.test(byId['MDNA-052'].instrument_guidance),'Baul instruments must not all be forced');
for(const rel of ['www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'])
 assert.strictEqual(fs.readFileSync(path.join(root,rel),'utf8'),source,`${rel} must match root app.js`);
console.log('Stage 110 profile identity guidance: PASS (69 profiles; 4 strengthened; mirrored runtime assets synchronized)');
