'use strict';
const fs=require('fs');
const vm=require('vm');
const source=fs.readFileSync('app.js','utf8');
function assert(ok,message){if(!ok)throw new Error(message);}
assert(source.includes('PRIMARY MUSIC DNA LYRICS GUIDANCE (profile-specific; preserve the selected language and user topic):'),'Lyrics prompt must receive profile-specific lyric guidance');
assert(source.includes('PRIMARY MUSIC DNA ARRANGEMENT CONTEXT (shape section pacing and phrasing only where relevant):'),'Lyrics prompt must receive profile arrangement guidance');
assert(source.includes('initStage129MusicDnaLyricsAnchors'),'Stage 129 policy missing');
assert(source.includes('Keep the user-selected song language, subject, exact custom phrases, lead/backing voice identities and manual instructions authoritative.'),'User choices must remain authoritative');
assert(source.includes('Never fabricate missing catalog information'),'Missing catalog details must not be invented');
assert(source.includes('globalThis.SongDnaMusicDnaLyricsAnchors={policy,automaticRewrite:false,usesProfileGuidance:true}'),'Runtime policy API missing');
const start=source.indexOf('const GLOBAL_MUSIC_DNA=')+'const GLOBAL_MUSIC_DNA='.length;
const end=source.indexOf(';\nconst TECHNIQUE_MODULES',start);
assert(start>0&&end>start,'Music DNA catalog declaration not found');
const catalog=vm.runInNewContext('('+source.slice(start,end)+')');
const profiles=catalog.music_dna_profiles;
assert(profiles.length===75,`Expected 75 profiles, found ${profiles.length}`);
let covered=0;
for(const profile of profiles){
 const guidance=String(profile.lyrics_guidance||'').trim();
 assert(guidance.length>0,`${profile.id} has no lyric guidance`);
 assert(guidance.length>=20,`${profile.id} guidance is unexpectedly empty/short`);
 covered++;
}
const languageControlled=profiles.filter(p=>/language|selected text|user-selected/i.test(p.lyrics_guidance||''));
const inventionGuarded=profiles.filter(p=>/do not|don't|avoid|never|not be forced|optional|independently/i.test(p.lyrics_guidance||''));
const userContentPreserved=profiles.filter(p=>/preserve|user-supplied|user-provided|user-selected/i.test(p.lyrics_guidance||''));
assert(languageControlled.length>=60,'Most profiles should explicitly control language or defer to selected text');
assert(inventionGuarded.length>=60,'Most profiles should constrain invented or forced content');
assert(userContentPreserved.length>=60,'Most profiles should preserve or defer to user content');

const emptyProfile={id:'TEST',lyrics_guidance:'',arrangement_guidance:''};
assert(!String(emptyProfile.lyrics_guidance||'').trim(),'Empty guidance must remain empty, not be fabricated');
assert(source.includes("No profile-specific lyric guidance is documented; follow the selected vocal and arrangement choices without inventing cultural details."),'Missing profile guidance must use conservative fallback');
console.log(`Stage 129: ${covered+9} assertions passed (${covered}/69 profiles contain documented lyric guidance)`);
