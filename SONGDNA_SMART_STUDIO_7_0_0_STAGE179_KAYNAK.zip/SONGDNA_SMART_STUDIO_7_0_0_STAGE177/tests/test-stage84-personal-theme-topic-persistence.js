const fs=require('fs');const path=require('path');const root=path.resolve(__dirname,'..');
const js=['app.js','www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'];
const html=['index.html','www/index.html','android-wrapper/app/src/main/assets/index.html','android-wrapper/app/src/main/assets/www/index.html'];
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const source=read(js[0]);
for(const token of ["PERSONAL_THEME_TOPIC_KEY='songdna_personal_theme_topic_v1'",'function restorePersonalThemeTopic()','function savePersonalThemeTopic()','restorePersonalThemeTopic();',"addEventListener('click',savePersonalThemeTopic)"]){if(!source.includes(token))throw Error('Missing persistence behavior: '+token)}
if(!source.includes("themeMode==='custom'" )||!source.includes("topicMode==='custom'"))throw Error('Only custom-mode content should be saved');
if(!source.includes("saved.version!==1"))throw Error('Stored data version validation missing');
for(const p of js){if(read(p)!==source)throw Error('App JS copies differ: '+p)}
const page=read(html[0]);if(!page.includes('id="savePersonalThemeTopic"')||!page.includes('id="personalThemeTopicStatus"'))throw Error('Explicit save control/status missing');
for(const p of html){if(read(p)!==page)throw Error('HTML copies differ: '+p)}
console.log('Stage 84 personal theme/topic persistence: PASS (explicit save, custom-only, versioned restore, 4-copy sync)');
