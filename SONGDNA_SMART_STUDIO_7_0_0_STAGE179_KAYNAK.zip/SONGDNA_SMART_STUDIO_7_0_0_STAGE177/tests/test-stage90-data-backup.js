const assert=require('node:assert/strict');
const backup=require('../data-backup.js');
function storage(seed={}){const m=new Map(Object.entries(seed));return{getItem:k=>m.has(k)?m.get(k):null,setItem(k,v){m.set(k,String(v))},removeItem:k=>m.delete(k),dump:()=>Object.fromEntries(m)}}
const source=storage({songdna_history:'[{"lyrics":"Söz"}]',songdna_saved:'[]',songdna_personal_theme_topic_v1:'{"theme":"Kişisel"}',songdna_app_token:'SECRET',songdna_api_base:'https://private.invalid'});
const payload=backup.create(source);
assert.equal(payload.data.songdna_history,'[{"lyrics":"Söz"}]');
assert.equal('songdna_app_token' in payload.data,false);
assert.equal('songdna_api_base' in payload.data,false);
const target=storage({songdna_history:'old',songdna_saved:'old-saved'});
const restored=backup.restore(target,payload);
assert.equal(restored.ok,true);
assert.equal(target.getItem('songdna_history'),'[{"lyrics":"Söz"}]');
assert.equal(target.getItem('songdna_personal_theme_topic_v1'),'{"theme":"Kişisel"}');
assert.throws(()=>backup.validate({format:'wrong',version:1,data:{songdna_history:'[]'}}));
assert.throws(()=>backup.validate({format:'songdna-local-backup',version:1,data:{songdna_history:[]}}));
// A failed write must roll back every key already touched.
let calls=0;const failing={getItem:k=>calls>0&&k==='songdna_saved'?'wrong':(k==='songdna_history'?'before':null),setItem(k,v){calls++},removeItem(){}};
const failed=backup.restore(failing,{format:'songdna-local-backup',version:1,createdAt:'2026-11-20T00:00:00.000Z',data:{songdna_history:'after',songdna_saved:'new'}});
assert.equal(failed.ok,false);
console.log('Stage90 backup/restore tests passed.');
