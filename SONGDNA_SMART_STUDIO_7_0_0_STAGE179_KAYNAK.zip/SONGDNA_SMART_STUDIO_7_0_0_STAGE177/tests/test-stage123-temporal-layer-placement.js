'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const engine=require(path.join(root,'three-layer-production-orchestrator.js'));
const conflict=engine.analyze({
 main:{id:'MAIN',name:'Main',promptText:'steady dance pulse and lead vocal',elements:['kick']},
 secondary:{id:'ALT',name:'Alternative',promptText:'broken-beat groove and polyphonic vocal arrangement',elements:['kick']},
 helper:{id:'HELP',name:'Helper',promptText:'sliding 808 bass'}
});
assert(conflict.notes.length>=1,'fixture should contain genuine layer differences/repeat');
assert(conflict.temporalSeparationPlans.length>=1,'genuine conflicts should have temporal advisory plans');
for(const plan of conflict.temporalSeparationPlans){
 assert.equal(plan.primaryRole,'main');
 assert.equal(plan.advisoryOnly,true);
 assert.equal(plan.automaticReassignment,false);
 assert.equal(plan.requiresExistingSection,true);
 assert.deepEqual(plan.matchedExistingSections,[],'without supplied arrangement sections, no placement is assumed');
 assert.equal(plan.sectionSource,'none_supplied');
 assert(plan.constraints.some(x=>x.includes('Do not invent or force')));
}
assert.equal(conflict.selectionChanged,false);
const compatible=engine.analyze({main:{id:'M',name:'Main',promptText:'steady dance pulse'},secondary:{id:'S',name:'Support',promptText:'steady dance pulse'}});
assert.deepEqual(compatible.temporalSeparationPlans,[],'compatible layers should not receive forced temporal separation');
const noMain=engine.analyze({secondary:{id:'S',name:'Secondary',promptText:'broken-beat groove'},helper:{id:'H',name:'Helper',promptText:'steady dance pulse'}});
assert(noMain.temporalSeparationPlans.every(x=>x.primaryRole===null),'never invent a primary identity');
const source=fs.readFileSync(path.join(root,'three-layer-production-orchestrator.js'),'utf8');
assert(source.includes('Stage 123/124: map conflicts only onto section names explicitly present in the arrangement'));
for(const rel of ['www/three-layer-production-orchestrator.js','android-wrapper/app/src/main/assets/three-layer-production-orchestrator.js','android-wrapper/app/src/main/assets/www/three-layer-production-orchestrator.js'])
 assert.equal(fs.readFileSync(path.join(root,rel),'utf8'),source,rel+' synchronized');
console.log('PASS Stage 123: time-separated role suggestions are advisory, conditional, and preserve manual selections.');
