'use strict';
const fs=require('fs');
const vm=require('vm');
const source=fs.readFileSync('app.js','utf8');
function assert(ok,message){if(!ok)throw new Error(message);}
assert(source.includes('initStage131TopicLanguageIsolation'),'Stage 131 prompt integration missing');
assert(source.includes('The user-selected song language is authoritative and independent of the Music DNA genre'),'Language authority policy missing');
assert(source.includes('The user-selected song subject, story, point of view and custom phrases are authoritative'),'Topic authority policy missing');
assert(source.includes('globalThis.SongDnaTopicLanguageIsolation={policy,audit:auditMusicDnaTopicLanguageIsolation,automaticRewrite:false,userLanguageWins:true,userTopicWins:true}'),'Public audit API missing');
const start=source.indexOf('function auditMusicDnaTopicLanguageIsolation(');
const end=source.indexOf('\n/* Stage 130 — cross-check',start);
assert(start>=0&&end>start,'Topic/language audit function missing');
const fn=source.slice(start,end).replace('function auditMusicDnaTopicLanguageIsolation','globalThis.auditMusicDnaTopicLanguageIsolation=function auditMusicDnaTopicLanguageIsolation');
const sandbox={};vm.runInNewContext(fn,sandbox);
let r=sandbox.auditMusicDnaTopicLanguageIsolation({selectedLanguage:'Türkçe',selectedTopic:'Ayrılık',musicIdentityProfile:{id:'MDNA-UKD-01',name:'UK Drill'}});
assert(r.level==='ok'&&r.selectedLanguage==='Türkçe'&&r.selectedTopic==='Ayrılık','Genre profile must not override selected language or topic');
r=sandbox.auditMusicDnaTopicLanguageIsolation({selectedLanguage:'Türkçe',selectedTopic:'Ayrılık',musicIdentityProfile:{id:'X',language:'English',dialect:'MLE',lyric_theme:'street life'}});
assert(r.level==='warning'&&r.issues.length===3,'Explicit conflicting profile metadata must be disclosed');
r=sandbox.auditMusicDnaTopicLanguageIsolation({selectedLanguage:'English',selectedTopic:'hope',musicIdentityProfile:{id:'X',language:'English',lyric_theme:'hope'}});
assert(r.level==='ok','Matching explicit metadata should not warn');
r=sandbox.auditMusicDnaTopicLanguageIsolation({});
assert(r.level==='ok'&&r.automaticRewrite===false,'Missing data must remain neutral and non-destructive');
const m=source.match(/const GLOBAL_MUSIC_DNA=(\{.*?\});\n/s);
assert(m,'Music DNA catalog not found');
const catalog=JSON.parse(m[1]);
assert(catalog.music_dna_profiles.length===75,'Expected 75 Music DNA profiles');
for(const profile of catalog.music_dna_profiles){
 const check=sandbox.auditMusicDnaTopicLanguageIsolation({selectedLanguage:'Türkçe',selectedTopic:'Kullanıcının belirlediği konu',musicIdentityProfile:profile});
 assert(check.level==='ok',`Profile ${profile.id} must not impose language or topic`);
}
console.log('Stage 131: 78 assertions passed; 69/69 profiles preserve user language/topic authority');
