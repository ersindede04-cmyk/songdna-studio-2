#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
function extract(source, pattern, label) {
  const m = source.match(pattern);
  assert(m, `${label} must exist`);
  return m[0].replace(/\r\n/g, '\n').trim();
}
const contracts = [
  [/async function postGemini\(path,prompt\)\s*\{[\s\S]*?\n\}/, 'postGemini'],
  [/const FALLBACK_FLASH_MODELS=\[[\s\S]*?\];/, 'fallback model catalogue'],
  [/async function refreshFreeModels\(\)\{[\s\S]*?\n\}/, 'health/model refresh']
];
const reference = read('reference/SONGDNA_6_2_0_POSTGEMINI_REFERENCE.js');
const app = read('app.js');
for (const [pattern, label] of contracts) {
  assert.strictEqual(extract(app, pattern, label), extract(reference, pattern, label),
    `Stage177 must preserve the exact 6.2.0 ${label} contract`);
}
for (const endpoint of ['/api/lyrics', '/api/style']) {
  assert(app.includes("postGemini('" + endpoint + "'"), `Missing production endpoint ${endpoint}`);
}
assert(app.indexOf("postGemini('/api/lyrics'") < app.indexOf("postGemini('/api/style'"),
  'Primary generation must keep Lyrics first and Styles second');
const server = read('backend/server.js');
for (const endpoint of ['/api/lyrics', '/api/style']) {
  assert(server.includes(endpoint), `Backend route missing ${endpoint}`);
}
assert(server.includes("'X-App-Token'") || server.includes('x-app-token'),
  'Backend must retain the app-token authentication contract');
assert(server.includes('150_000') || server.includes('150000'),
  'Backend must retain the 150,000-character prompt ceiling');
const copies = [
  'app.js', 'www/app.js',
  'android-wrapper/app/src/main/assets/app.js',
  'android-wrapper/app/src/main/assets/www/app.js'
];
for (const file of copies) assert.strictEqual(read(file), app, `${file} differs from root app.js`);
console.log('PASS: Stage177 preserves the exact 6.2.0 postGemini transport, fallback model catalogue and /health refresh contracts');
console.log('PASS: Lyrics-first then Styles generation sequence retained');
console.log('PASS: backend endpoints, token contract and prompt ceiling retained');
console.log('PASS: all four app.js runtime copies are byte-identical');
