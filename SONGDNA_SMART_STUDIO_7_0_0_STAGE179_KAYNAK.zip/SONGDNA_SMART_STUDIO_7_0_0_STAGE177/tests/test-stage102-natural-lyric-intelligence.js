const fs=require('fs');const path=require('path');const root=path.resolve(__dirname,'..');
const files=['app.js','www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'];
const sources=files.map(f=>fs.readFileSync(path.join(root,f),'utf8'));
for(const f of files){const s=fs.readFileSync(path.join(root,f),'utf8');
 for(const token of ['LYRIC CREATION DIRECTIVE','2–4 distinct supporting subtopics','emotional progression','idiomatic, contemporary','singable when performed','forced rhyme','AI-style parallel sentences','manual choice locks only its own dimension','Broad theme and specific topic must remain distinct','Output only the requested Suno-ready title and lyrics']) if(!s.includes(token)) throw new Error(`${f}: missing ${token}`);
 if(!s.includes("return original({...c,theme:manualTheme||c.theme||values[0]})+brief;")) throw new Error(`${f}: existing lyrics prompt handoff changed`);
}
if(new Set(sources).size!==1) throw new Error('Four app.js entrypoints are not byte-identical');
console.log('PASS Stage102 natural lyric intelligence contract; four app.js copies identical');
