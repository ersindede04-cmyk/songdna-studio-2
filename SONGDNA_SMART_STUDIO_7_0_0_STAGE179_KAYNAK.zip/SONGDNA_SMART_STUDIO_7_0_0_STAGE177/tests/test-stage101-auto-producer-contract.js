'use strict';
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const files=['app.js','www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'];
const required=[
 'AUTOMATIC PRODUCER DECISION POLICY',
 'groove and rhythmic subdivision',
 'backing-vocal roles',
 'ad-lib character and placement',
 'all other unspecified areas remain automatic',
 'automaticAdlibPhrases:',
 'manualAdlibPhrases:',
 'function buildSharedOutputIdentityContract(c)',
 'VOCAL DNA:'
];
for(const rel of files){
 const source=fs.readFileSync(path.join(root,rel),'utf8');
 for(const token of required){if(!source.includes(token))throw new Error(`${rel}: missing ${token}`);}
 if(!/const automaticPhrases=selectedPhrases\.length\?\[\]:/.test(source))throw new Error(`${rel}: automatic ad-lib fallback missing`);
 if(!/No safe catalog recommendation available; use wordless vocalises or silence\./.test(source))throw new Error(`${rel}: safe ad-lib fallback missing`);
 if(!/Do not invent dialect, sacred phrases or supposedly authentic local words\./.test(source))throw new Error(`${rel}: cultural safety guard missing`);
}
console.log('Stage 101 automatic producer contract: PASS');
console.log('4 app entrypoints contain the same automatic/manual priority contract and ad-lib safeguards.');
