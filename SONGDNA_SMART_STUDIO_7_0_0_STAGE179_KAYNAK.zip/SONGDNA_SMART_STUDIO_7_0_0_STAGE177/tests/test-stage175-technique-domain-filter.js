"use strict";
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const root = path.resolve(__dirname, "..");
const app = fs.readFileSync(path.join(root, "app.js"), "utf8");
const web = fs.readFileSync(path.join(root, "www/app.js"), "utf8");
const android = fs.readFileSync(path.join(root, "android-wrapper/app/src/main/assets/www/app.js"), "utf8");
assert.equal(app, web, "root and web app runtime must match");
assert.equal(app, android, "Android WebView runtime must match");
assert.match(app, /const techniqueDomain=module=>/);
assert.match(app, /const family=String\(module\.family\|\|''\)\.trim\(\)\.toLowerCase\(\)/);
assert.match(app, /vocal performance\|shared vocal technique\|general vocal technique/);
assert.match(app, /rap\|hip\.\?hop\|electronic\|production\|detroit techno\|uk garage/);
assert.match(app, /anadolu\|türk halk\|zeybek\|bozlak\|gamelan\|gnawa\|pansori/);
assert.match(app, /techniqueSelect\.replaceChildren\(\.\.\.options\)/, "filtered options must be removed from the native select, not merely hidden");
assert.match(app, /traditionalToggle\.checked&&!modernToggle\.checked&&domain!=='modern'/);
assert.match(app, /!traditionalToggle\.checked&&modernToggle\.checked&&domain!=='traditional'/);
assert.match(app, /const techniqueIsTraditional=module=>techniqueDomain\(module\)==='traditional'/);

const catalog = JSON.parse(fs.readFileSync(path.join(root, "data/music_dna_global_v1_1.json"), "utf8"));
const classifierSource = app.match(/const techniqueDomain=module=>\{[\s\S]*?\n \};/);
assert.ok(classifierSource, "runtime technique domain classifier must be extractable for direct contract checks");
const classify = new Function(`${classifierSource[0]}; return techniqueDomain;`)();
const byId = Object.fromEntries(catalog.instrument_technique_modules.map(module => [module.id, module]));
for (const id of ["TECH-TR-001", "TECH-TR-002", "TECH-TR-003", "TECH-TR-004", "INST-034", "INST-035", "INST-038", "INST-041", "INST-043", "INST-047", "INST-054"]) {
  assert.equal(classify(byId[id]), "traditional", `${id} must remain available in traditional-only mode`);
}
for (const id of ["INST-051", "INST-052", "INST-053", "TECH-RAP-001", "TECH-PROD-001", "TECH-PROD-031"]) {
  assert.equal(classify(byId[id]), "modern", `${id} must remain in modern-only mode`);
}
for (const id of ["TECH-VOC-001", "TECH-VOC-002", "TECH-VOC-003", "TECH-VOC-004"]) {
  assert.equal(classify(byId[id]), "shared", `${id} must remain available in both domains`);
}
console.log("PASS: Stage175 family-based traditional/modern/shared technique filtering and synchronized WebView runtime");
