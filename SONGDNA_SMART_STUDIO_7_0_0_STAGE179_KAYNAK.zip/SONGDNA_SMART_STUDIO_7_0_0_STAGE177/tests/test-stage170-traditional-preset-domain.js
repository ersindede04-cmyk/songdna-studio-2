'use strict';
const fs=require('node:fs');
const assert=require('node:assert/strict');
const app=fs.readFileSync('app.js','utf8');
const block=app.match(/const presets=\[([\s\S]*?)\n \];/);
assert.ok(block,'Traditional preset catalog must exist');
const presets=block[1];
const regions=app.match(/const regionMap=\{([\s\S]*?)\n \};/);
assert.ok(regions,'Traditional region catalog must exist');
const regionCatalog=regions[1];
for(const forbidden of ['Modern Türk Müziği','Modern şehir / pop kültürü','United States / ABD','United Kingdom / Birleşik Krallık','Modern Fusion','Bollywood','Reggae/Soca','Rap ad-lib / hype shouts','Synth bass','808','Analog synth']){
  assert.ok(!regionCatalog.includes(forbidden),`Modern region or instrument leaked into Traditional workspace: ${forbidden}`);
}
for(const forbidden of ['Turkish Modern Trap','Turkish Pop + Electronic Pop Fusion','Turkish R&B Fusion','Arabian Night','Afro Drill','Amapiano Soul','Indian Fusion','Punjabi Bhangra','Japanese Dark Pop','Persian Desert']){
  assert.ok(!presets.includes(forbidden),`Modern/fusion preset leaked into Traditional workspace: ${forbidden}`);
}
for(const required of ['Anadolu Zeybek','Türk Halk Müziği Topluluğu','Türk Klasik Sanat Müziği','Hindustani Alaap','Carnatic Tala','Balkan Brass & Dance','Flamenko Compás & Gitar','Azerbaycan Mugham']){
  assert.ok(presets.includes(required),`Expected traditional preset missing: ${required}`);
}
for(const id of ['MDNA-028','MDNA-067','MDNA-068','MDNA-025','MDNA-026','MDNA-024','MDNA-023','MDNA-050']){
  assert.ok(presets.includes(id),`Traditional preset must resolve to catalogued profile ${id}`);
}
console.log('PASS Stage170 traditional preset domain separation');
