const fs=require('fs');const path=require('path');
const root=path.resolve(__dirname,'..');
const files=['app.js','www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'];
const sources=files.map(f=>fs.readFileSync(path.join(root,f),'utf8'));
const required=[
 'Stage 104: shared creative identity with separate lyric-writing and sound-design craft.',
 'STAGE 104 — DISTINCTIVE SONGWRITER CRAFT:',
 'one human contradiction, revealing detail or unexpected angle',
 'remove any line that could be pasted unchanged into dozens of unrelated songs.',
 'STAGE 104 — DISTINCTIVE SUNO SOUND DESIGN:',
 'Preserve the selected primary Music DNA as the unmistakable center.',
 'Translate the selected fusion into audible musical behavior',
 'Keep vocal delivery and backing-vocal interaction consistent with LYRICS.',
 'remain within the existing 1000-character Styles limit.',
 'const stage104LyricsPrompt=makeLyricsPrompt;',
 'const stage104StylePrompt=buildGeminiStylePrompt;'
];
for(const f of files){const s=fs.readFileSync(path.join(root,f),'utf8');for(const token of required)if(!s.includes(token))throw new Error(`${f}: missing ${token}`);}
if(new Set(sources).size!==1)throw new Error('Four app.js copies are not byte-identical');
const s=sources[0];
if(!s.includes("return stage104LyricsPrompt(c)+'\\n\\nSTAGE 104"))throw new Error('Lyrics prompt wrapper missing');
if(!s.includes("return stage104StylePrompt(c,baseStyle,exclude)+'\\n\\nSTAGE 104"))throw new Error('Styles prompt wrapper missing');
if(!s.includes("'Use only the two Suno outputs: STYLES and LYRICS.'"))throw new Error('Two-field output invariant missing');
console.log('PASS Stage104 Lyrics + Styles creative identity contracts; four app.js copies identical');
