'use strict';
const assert=require('node:assert/strict');
const engine=require('../three-layer-production-orchestrator.js');
const make=(existingSections)=>engine.analyze({
 main:{id:'MAIN',name:'Main',promptText:'steady dance pulse and solo lead vocal',elements:['kick']},
 secondary:{id:'ALT',name:'Alternative',promptText:'broken-beat groove and polyphonic vocal arrangement',elements:['kick']},
 helper:{id:'HELP',name:'Helper',promptText:'sliding 808 bass'},
 existingSections
});
{
 const result=make(['Verse','Chorus','Bridge','Outro']);
 assert(result.temporalSeparationPlans.length>=1);
 const rhythm=result.temporalSeparationPlans.find(x=>x.code==='RHYTHMIC_FOUNDATION_DIFFERENCE');
 assert(rhythm);
 assert.deepEqual(rhythm.matchedExistingSections,['Bridge']);
 assert.equal(rhythm.sectionSource,'user_or_arrangement_supplied');
 assert.equal(rhythm.requiresExistingSection,true);
 assert.equal(rhythm.automaticReassignment,false);
}
{
 const result=make(['Verse','Chorus']);
 const rhythm=result.temporalSeparationPlans.find(plan=>plan.code==='RHYTHMIC_FOUNDATION_DIFFERENCE');
 assert.deepEqual(rhythm.matchedExistingSections,[],'verse/chorus are not treated as rhythmic contrast sections');
 const vocal=result.temporalSeparationPlans.find(plan=>plan.code==='VOCAL_ARRANGEMENT_ROLE_DIFFERENCE');
 assert.deepEqual(vocal.matchedExistingSections,['Verse','Chorus'],'existing verse/chorus may host vocal arrangement contrast');
}
{
 const result=make([]);
 for(const plan of result.temporalSeparationPlans){
  assert.deepEqual(plan.matchedExistingSections,[]);
  assert.equal(plan.sectionSource,'none_supplied');
  assert(plan.constraints.some(x=>x.includes('make no placement assumption')));
 }
}
{
 const result=engine.analyze({main:{id:'M',name:'Main',promptText:'steady dance pulse'},secondary:{id:'S',name:'Support',promptText:'steady dance pulse'},existingSections:['Bridge']});
 assert.deepEqual(result.temporalSeparationPlans,[],'compatible layers must not get section placement advice');
}
console.log('Stage 124 section-aware placement tests: 4/4 passed');
