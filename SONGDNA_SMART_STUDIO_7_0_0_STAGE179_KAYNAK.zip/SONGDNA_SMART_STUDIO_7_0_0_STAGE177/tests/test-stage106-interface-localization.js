'use strict';
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const required=[
  "'Müzik alanları':'Music Domains'",
  "'Müzik alanlarını etkinleştir':'Enable music domains'",
  "'Geleneksel müzik':'Traditional Music'",
  "'Modern müzik':'Modern Music'",
  "'İki alanı ayrı ayrı açıp kapatabilirsin.",
  "'Etkin müzik alanlarına uymayan teknik modül seçimi kaldırıldı.'",
  "'Üretim için Geleneksel Müzik veya Modern Müzik alanlarından en az birini aç.'"
];
for(const item of required)if(!app.includes(item))throw new Error('Missing localization mapping: '+item);
if(!app.includes("const ui=(tr,en)=>document.documentElement.lang==='tr'?tr:en;"))throw new Error('Language-aware dynamic UI helper missing');
if(!app.includes('Active catalog: ${Array.from(main.options).length} Music DNA profiles.'))throw new Error('Dynamic English catalog helper missing');
if(!html.includes('id="traditionalMusicEnabled"')||!html.includes('id="modernMusicEnabled"'))throw new Error('Music domain controls missing');
console.log('PASS Stage 106 interface localization contract');
