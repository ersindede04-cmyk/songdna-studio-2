const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const runtimeFiles = ['app.js','www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'];
const runtime = runtimeFiles.map(file => fs.readFileSync(path.join(root,file),'utf8'));
if (new Set(runtime).size !== 1) throw new Error('Stage161 runtime copies differ');
const app = runtime[0];
const backend = fs.readFileSync(path.join(root,'backend/server.js'),'utf8');
const profiles = [
'English:', 'Turkish:', 'Azerbaijani (Azerbaijani Turkish):', 'Mandarin Chinese:', 'Hindi:', 'Spanish:',
'Modern Standard Arabic:', 'Egyptian Arabic:', 'Levantine Arabic:', 'French:', 'Bengali:',
'Brazilian Portuguese:', 'European Portuguese:', 'German:', 'Persian (Farsi):', 'Russian:', 'Greek:',
'Urdu:', 'Punjabi:', 'Italian:', 'Korean:', 'Japanese:', 'Indonesian:', 'Vietnamese:', 'Thai:',
'Swahili (Kiswahili):', 'Kurdish Kurmanji:', 'Kurdish Sorani:'
];
if (profiles.length !== 28) throw new Error('Expected exactly 28 language profiles');
for (const token of ['28 EXPLICIT LANGUAGE PROFILES','UNIVERSAL QUALITY LAYER','GENRE / TRADITION ADAPTATION LAYER','SILENT MULTI-PASS EDITORIAL REVIEW', ...profiles]) {
  if (!app.includes(token)) throw new Error(`Client prompt missing ${token}`);
  if (!backend.includes(token)) throw new Error(`Backend system policy missing ${token}`);
}
for (const token of ['do not substitute Sorani forms','do not substitute Kurmanji forms','do not import European Portuguese forms','do not default to Brazilian forms','do not substitute Levantine or MSA phrasing']) {
  if (!app.includes(token)) throw new Error(`Profile distinction missing ${token}`);
}
if (!app.includes("prompt=buildGeminiInstructionEnvelope('lyrics',currentContext,makeLyricsPrompt(currentContext))")) throw new Error('Existing Lyrics request route changed');
if (!backend.includes("'/api/lyrics'")) throw new Error('Existing Lyrics endpoint missing');
console.log('PASS Stage161: exactly 28 explicit language profiles are present in client and backend; generation flow preserved.');
