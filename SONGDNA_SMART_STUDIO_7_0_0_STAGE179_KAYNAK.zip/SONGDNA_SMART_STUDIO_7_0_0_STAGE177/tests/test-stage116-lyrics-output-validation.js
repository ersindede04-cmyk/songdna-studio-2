const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),source=fs.readFileSync(path.join(root,'app.js'),'utf8');
const start=source.indexOf('const SUNO_LYRICS_PLANNING_LIMIT=5000;'),end=source.indexOf('function auditSunoLyricsDetailed(lyrics){',start);assert(start>=0&&end>start);
const box={};vm.runInNewContext(source.slice(start,end)+';this.validateGeminiLyricsOutput=validateGeminiLyricsOutput;',box);const v=box.validateGeminiLyricsOutput;
assert.equal(v('[Verse 1]\nYollar uzar gecede\n[Chorus]\nKalbim döner yine').valid,true);assert.equal(v('a'.repeat(5000)).valid,true);assert.equal(v('a'.repeat(5001)).valid,false);assert.equal(v('').valid,false);assert.equal(v('[Verse 1\nmissing bracket').valid,false);assert.equal(v('Here are your lyrics:\n[Verse 1]\nHello').valid,false);assert.equal(v('[Verse 1]\nHello\nSTYLES: dark pop').valid,false);assert.equal(v('[Verse 1]\nGecede yürürüm',{languageLabel:'Türkçe'}).language,'Türkçe');
assert.match(source,/const lyricsCheck=validateGeminiLyricsOutput\(rawText,currentContext\);if\(!lyricsCheck.valid\)throw/);
for(const rel of ['www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'])assert.equal(fs.readFileSync(path.join(root,rel),'utf8'),source);
console.log('PASS Stage 116: LYRICS output validation and mirrored runtime copies.');
