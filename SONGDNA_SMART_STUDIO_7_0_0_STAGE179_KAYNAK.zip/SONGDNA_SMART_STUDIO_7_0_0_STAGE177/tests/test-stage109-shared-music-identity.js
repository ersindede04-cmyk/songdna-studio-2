const assert=require('node:assert/strict');
require('../three-layer-production-orchestrator.js');
const engine=globalThis.SongDnaThreeLayerProductionOrchestrator;
assert.equal(engine.version,'1.2');
const drill=engine.build({
 main:{id:'MDNA-UKD',name:'UK Drill',family:'UK Drill',promptText:'London drill rhythmic identity',musicalTraits:['sliding 808','syncopated drill drums'],arrangementGuidance:'dark sparse melodic loop'},
 secondary:{id:'MDNA-ATM',name:'Dark Ambient',family:'Electronic',elements:['atmospheric texture']},
 helper:{},
 identity:{profileId:'MDNA-UKD',name:'UK Drill',primaryGenre:'UK Drill',domain:'modern',region:'London, United Kingdom',language:'English (UK)',definingTraits:['sliding 808','syncopated drill drums'],performanceGuidance:'UK Drill vocal flow',productionGuidance:'dark sparse London drill production',vocalGuidance:'percussive UK English delivery'}
});
assert.equal(drill.musicIdentityProfile.domain,'modern');
assert.equal(drill.musicIdentityProfile.region,'London, United Kingdom');
assert.equal(drill.musicIdentityProfile.language,'English (UK)');
assert.equal(drill.musicIdentityProfile.selectedLayers.length,2);
assert(drill.identityPrompt.includes('ONE SHARED MUSIC IDENTITY PROFILE'));
assert(drill.sharedPrompt.includes('UK Drill vocal flow'));
assert.equal(drill.stylesContext,drill.lyricsContext);
assert.equal(drill.sharedContext.musicIdentityProfile,drill.musicIdentityProfile);
const traditional=engine.build({main:{id:'MDNA-BAUL',name:'Bengal Baul',family:'traditional',musicalTraits:['ektara','dotara']},identity:{profileId:'MDNA-BAUL',name:'Bengal Baul',domain:'traditional',region:'Bengal',language:'Bengali',definingTraits:['ektara','dotara']}});
assert.equal(traditional.musicIdentityProfile.domain,'traditional');
assert.equal(traditional.musicIdentityProfile.language,'Bengali');
assert(traditional.sharedPrompt.includes('Do not invent undocumented cultural or technical details'));
const empty=engine.build({});
assert.equal(empty.musicIdentityProfile.name,null);
assert.equal(empty.musicIdentityProfile.domain,'unclassified');
assert.equal(empty.sharedContext.autoFilled,false);
console.log('PASS: Stage 109 shared Music Identity Profile (4 scenarios)');
