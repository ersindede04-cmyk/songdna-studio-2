const fs=require('fs');const path=require('path');const vm=require('vm');
const root=path.resolve(__dirname,'..');const source=fs.readFileSync(path.join(root,'app.js'),'utf8');
const start=source.indexOf("const PERSONAL_THEME_TOPIC_KEY='songdna_personal_theme_topic_v1';");
const end=source.indexOf("restorePersonalThemeTopic();",start)+"restorePersonalThemeTopic();".length;
if(start<0||end<0)throw Error('Stage84 persistence block not found');
const block=source.slice(start,end);
function harness(initial={},opts={}){
 const nodes={songThemeCustom:{value:'',dataset:{}},songThemeMode:{value:'auto'},theme:{value:'',dataset:{}},topicMode:{value:'auto'},personalThemeTopicStatus:{textContent:''},savePersonalThemeTopic:{addEventListener(){}}};
 const data=new Map(Object.entries(initial));const storage={getItem(k){if(opts.readFail)throw Error('read blocked');return data.has(k)?data.get(k):null},setItem(k,v){if(opts.writeFail)throw Error('write blocked');data.set(k,String(v));}};
 const context={localStorage:storage,$:id=>nodes[id],console:{warn(){}},JSON};vm.runInNewContext(block,context);return {nodes,data,context};
}
let h=harness({'songdna_personal_theme_topic_v1':JSON.stringify({version:1,theme:'Kendi tema',topic:'Kendi konu'})});
if(h.nodes.songThemeCustom.value!=='Kendi tema'||h.nodes.songThemeMode.value!=='custom'||h.nodes.theme.value!=='Kendi konu'||h.nodes.topicMode.value!=='custom'||h.nodes.theme.dataset.userEdited!=='1')throw Error('Valid saved content did not restore');
h=harness({'songdna_personal_theme_topic_v1':JSON.stringify({version:1,theme:'Sadece tema',topic:''})});if(h.nodes.songThemeMode.value!=='custom'||h.nodes.topicMode.value!=='auto')throw Error('Partial restore changed unrelated mode');
h=harness({'songdna_personal_theme_topic_v1':JSON.stringify({version:2,theme:'Eski',topic:'Eski'})});if(h.nodes.songThemeCustom.value!=='')throw Error('Unsupported version was restored');
h=harness({'songdna_personal_theme_topic_v1':'{bad json'});if(h.nodes.songThemeCustom.value!=='')throw Error('Malformed JSON should be ignored safely');
h=harness({}, {readFail:true});if(h.nodes.songThemeCustom.value!=='')throw Error('Storage read failure should not crash startup');
h=harness();h.nodes.songThemeMode.value='template';h.nodes.songThemeCustom.value='Template text';h.nodes.topicMode.value='custom';h.nodes.theme.value='Kişisel konu';h.context.savePersonalThemeTopic();let saved=JSON.parse(h.data.get('songdna_personal_theme_topic_v1'));if(saved.theme!==''||saved.topic!=='Kişisel konu')throw Error('Template mode was incorrectly saved as personal content');
h=harness({}, {writeFail:true});h.nodes.topicMode.value='custom';h.nodes.theme.value='Kayıt denemesi';h.context.savePersonalThemeTopic();if(!h.nodes.personalThemeTopicStatus.textContent.includes('Kayıt yapılamadı'))throw Error('Storage write failure was not reported');
console.log('Stage85 persistence runtime checks: PASS (restore, partial restore, version guard, malformed data, read/write failures, custom-only save)');
