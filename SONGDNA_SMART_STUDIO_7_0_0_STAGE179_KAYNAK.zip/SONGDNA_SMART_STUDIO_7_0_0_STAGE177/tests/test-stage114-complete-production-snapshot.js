const assert=require('node:assert/strict');
const engine=require('../profile-snapshot-engine.js');
const base={dna:'UK Drill',style:'Dark UK Drill',bpm:140,language:'English',theme:'Night journey',topicMode:'custom',songThemeMode:'custom',songTheme:'Urban solitude',musicIdentityProfile:{profileId:'MDNA-UKD-001',name:'UK Drill'},threeLayerProduction:{selectedRoles:['main'],sharedPrompt:'UK Drill main layer'},threeLayerProductionPrompt:'UK Drill shared prompt',manualLocks:{bpm:true,language:true}};
const a=engine.build(base);
assert(engine.matches(a,engine.build(JSON.parse(JSON.stringify(base)))),'identical final generation states match');
for(const [key,value] of Object.entries({songTheme:'Different theme',topicMode:'auto',songThemeMode:'template',musicIdentityProfile:{profileId:'MDNA-002',name:'Other'},threeLayerProduction:{selectedRoles:['main','helper'],sharedPrompt:'changed'},threeLayerProductionPrompt:'changed prompt',manualLocks:{bpm:false,language:true}})){
 const changed=engine.build({...base,[key]:value});
 assert.notEqual(a.id,changed.id,`${key} change must invalidate old production snapshot`);
}
assert.equal(engine.matches(a,engine.build({...base,bpm:141})),false,'manual BPM change invalidates prior snapshot');
console.log('PASS: Stage 114 complete production snapshot detects topic, identity, layer and manual-lock changes');
