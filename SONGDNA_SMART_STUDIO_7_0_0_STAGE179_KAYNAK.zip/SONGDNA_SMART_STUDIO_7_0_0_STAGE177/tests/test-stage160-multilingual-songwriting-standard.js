const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const runtimeFiles = ['app.js','www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'];
const runtime = runtimeFiles.map(file => fs.readFileSync(path.join(root,file),'utf8'));
if (new Set(runtime).size !== 1) throw new Error('Stage160 runtime copies differ');
const app = runtime[0];
const backend = fs.readFileSync(path.join(root,'backend/server.js'),'utf8');
const profiles = [
  'English:', 'Mandarin Chinese:', 'Hindi:', 'Spanish:', 'Standard Arabic:',
  'French:', 'Bengali:', 'Portuguese:', 'Turkish:', 'Azerbaijani (Azerbaijani Turkish):'
];
for (const token of ['STAGE160 MULTILINGUAL SONGWRITING STANDARD','UNIVERSAL QUALITY LAYER','LANGUAGE-SPECIFIC LAYER','GENRE / TRADITION ADAPTATION LAYER','SILENT MULTI-PASS EDITORIAL REVIEW', ...profiles]) {
  if (!app.includes(token)) throw new Error(`Client prompt missing ${token}`);
  if (!backend.includes(token)) throw new Error(`Backend system policy missing ${token}`);
}
for (const token of ['Never use Turkish or English as an intermediate draft','Azerbaijani vocabulary, morphology, suffixes, idioms','Do not impose one language\'s syntax']) {
  if (!app.includes(token)) throw new Error(`Language policy missing ${token}`);
}
if (!app.includes("prompt=buildGeminiInstructionEnvelope('lyrics',currentContext,makeLyricsPrompt(currentContext))")) throw new Error('Existing Lyrics request route changed');
if (!backend.includes("'/api/lyrics'") || !backend.includes('STAGE159 SONGWRITING QUALITY STANDARD')) throw new Error('Existing Lyrics endpoint or Stage159 policy missing');
console.log('PASS Stage160: universal + 10 language profiles + genre/tradition layer + editorial pass; existing Lyrics flow preserved.');
