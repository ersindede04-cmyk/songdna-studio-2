'use strict';
const assert=require('assert');
const fs=require('fs');
const app=fs.readFileSync('app.js','utf8');
const blocks=[
 ['Stage 132 routing','initStage132ThreeLayerOutputRouting','THREE-LAYER ROUTING AUDIT:'],
 ['Stage 134 domain','initStage134ThreeLayerDomainIntegrity','THREE-LAYER DOMAIN INTEGRITY:'],
 ['Stage 136 manual selection','initStage136ManualLayerSelectionIntegrity','MANUAL LAYER SELECTION AUDIT:']
];
for(const [label,init,compact] of blocks){
 const start=app.indexOf('(function '+init);
 const end=app.indexOf('\n})();',start);
 assert(start>=0&&end>start,label+' integration exists');
 const block=app.slice(start,end);
 assert(block.includes(compact),label+' structured audit remains available');
 assert(!/const policy\s*=/.test(block),label+' no longer appends a duplicate policy paragraph');
}
assert(app.includes('globalThis.SongDnaThreeLayerOutputRouting={audit:auditThreeLayerOutputRouting'));
assert(app.includes('globalThis.SongDnaThreeLayerDomainIntegrity={audit:auditThreeLayerDomainIntegrity'));
assert(app.includes('globalThis.SongDnaManualLayerSelectionIntegrity={audit:auditManualLayerSelectionIntegrity'));
console.log('Stage 148: 12 assertions passed; duplicate prompt policy removed while audit APIs remain.');
