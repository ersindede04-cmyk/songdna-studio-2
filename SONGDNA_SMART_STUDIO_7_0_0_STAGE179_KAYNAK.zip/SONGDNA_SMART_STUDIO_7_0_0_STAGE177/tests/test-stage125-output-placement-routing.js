const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const engine=require('../three-layer-production-orchestrator.js');
const root=path.resolve(__dirname,'..');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');

const sections=['Intro','Verse','Chorus','Bridge','Outro'];
const result=engine.analyze({
 main:{id:'main',name:'Straight Pulse',promptText:'steady dance pulse'},
 secondary:{id:'secondary',name:'Broken Beat',promptText:'broken-beat groove'},
 helper:{},existingSections:sections
});
assert(result.temporalSeparationPlans.length>0,'conflict should produce a placement plan');
const rhythm=result.temporalSeparationPlans.find(x=>x.code==='RHYTHMIC_FOUNDATION_DIFFERENCE');
assert.deepEqual(rhythm.matchedExistingSections,['Bridge'],'only the supplied bridge may be matched for rhythmic contrast');

const vocal=engine.analyze({
 main:{id:'main',name:'Polyphonic',promptText:'multiple independent vocal lines'},
 secondary:{id:'secondary',name:'Solo Lead',promptText:'single lead vocalist'},
 existingSections:['Verse','Chorus']
});
const vocalPlan=vocal.temporalSeparationPlans.find(x=>x.code==='VOCAL_ARRANGEMENT_ROLE_DIFFERENCE');
assert.deepEqual(vocalPlan.matchedExistingSections,['Verse','Chorus'],'existing verse/chorus can host a vocal contrast');

const none=engine.analyze({main:{id:'m',promptText:'steady dance pulse'},secondary:{id:'s',promptText:'broken-beat groove'}});
assert(none.temporalSeparationPlans.every(x=>x.matchedExistingSections.length===0),'no supplied sections means no placement');

assert.match(app,/sectionLayerPlacement\s*=\s*\{/,'runtime must create a shared placement-routing object');
assert.match(app,/SECTION-SPECIFIC VOCAL LAYER PLACEMENT/,'Lyrics prompt must receive vocal placement guidance');
assert.match(app,/SECTION-SPECIFIC PRODUCTION LAYER PLACEMENT/,'Styles prompt must receive production placement guidance');
assert.match(app,/existingSections:arrangementSections/,'runtime must use the actual arrangement sections');

const guidanceBlock=app.slice(app.indexOf('c.sectionLayerPlacement={'),app.indexOf('c.sectionLayerPlacement={')+1000);
assert.match(guidanceBlock,/plan\.code==='VOCAL_ARRANGEMENT_ROLE_DIFFERENCE'/,'Lyrics routing must exclude non-vocal layer conflicts');
assert.match(guidanceBlock,/advisoryOnly:true,selectionChanged:false/,'placement routing must remain advisory and immutable');
console.log('Stage 125: 8 assertions passed');
