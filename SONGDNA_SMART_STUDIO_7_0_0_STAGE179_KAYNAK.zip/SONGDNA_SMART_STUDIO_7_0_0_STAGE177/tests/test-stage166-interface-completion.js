'use strict';
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const requiredSwitches = [
  'traditionalMusicEnabled',
  'modernMusicEnabled',
  'pureTraditionalProduction'
];
for (const id of requiredSwitches) {
  const re = new RegExp(`<input[^>]*id="${id}"[^>]*role="switch"`);
  if (!re.test(html)) throw new Error(`Accessible switch missing: ${id}`);
}
if (!html.includes('.switch-control input[type="checkbox"]::after')) throw new Error('Switch thumb styling missing');
if (!html.includes('prefers-reduced-motion:reduce')) throw new Error('Reduced-motion support missing');
if (!app.includes("const pref=localStorage.getItem('songdna_app_language')||'auto';")) throw new Error('Automatic device-language default missing');
if (!app.includes("appLanguage.value=localStorage.getItem('songdna_app_language')||'auto';")) throw new Error('Language selector does not default to auto');
const drawerStart = html.indexOf('id="drawerNav"');
const nav = html.slice(drawerStart >= 0 ? drawerStart : html.indexOf('data-drawer-target="generalPanel"') - 2000, html.indexOf('id="generalPanel"'));
const order = ['data-drawer-target="generalPanel"','data-drawer-target="appearancePanel"','data-drawer-target="aiPanel"','data-drawer-target="introPanel"','data-drawer-target="vocalPanel"','data-drawer-target="archivePanel"','data-drawer-target="aboutPanel"'];
let last = -1;
for (const token of order) { const at = nav.indexOf(token); if (at < 0 || at <= last) throw new Error(`Drawer order invalid at ${token}`); last = at; }
if (!app.includes("'Saf Geleneksel İcra · Geleneksel düzenlemeyi koru':'Pure Traditional Performance · Preserve traditional arrangement'")) throw new Error('Strict traditional switch localization missing');
console.log('PASS Stage 166 interface completion contract');
