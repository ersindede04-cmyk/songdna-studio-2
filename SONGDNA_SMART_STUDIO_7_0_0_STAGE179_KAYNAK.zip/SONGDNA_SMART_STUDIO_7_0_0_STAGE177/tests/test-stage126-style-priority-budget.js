const fs=require('fs');
const source=fs.readFileSync('app.js','utf8');
function assert(ok,message){if(!ok)throw new Error(message);}
assert(source.includes('Stage 126 — prioritize high-information Styles details'), 'Stage 126 policy is missing');
assert(source.includes('Keep the final Styles field at or below 1000 characters'), '1000-character budget is not explicit');
assert(source.includes('primary Music DNA identity and its defining traits'), 'Primary identity is not first priority');
assert(source.includes('Never remove or weaken an explicit manual choice'), 'Manual selection protection is missing');
assert(source.includes('Merge synonymous or repeated descriptors'), 'Redundancy reduction guidance is missing');
assert(source.includes('do not cut a tag mid-phrase'), 'Safe phrase-boundary guidance is missing');
assert(source.includes("const key=x.toLowerCase().replace(/[.,;:]+$/,'');if(seenStyleParts.has(key))continue;"), 'Initial Styles draft does not deduplicate exact repeated parts');
assert(source.includes('if(n.length>1000)continue;'), 'A long item still blocks later concise high-value items');
assert(source.includes("'selected-secondary-helper','section-placement','mood-effects-generic-polish'"), 'Priority order is incomplete');
assert(source.includes("globalThis.SongDnaStylePriorityBudget={limit:1000"), 'Priority budget metadata is not exposed for QA');
console.log('Stage 126: 10 assertions passed');
