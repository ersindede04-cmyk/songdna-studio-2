'use strict';

// Test-only Gemini replacement. No network calls or API key are used.
global.fetch = async (url, options = {}) => {
  if (!String(url).includes('generativelanguage.googleapis.com')) {
    throw new Error('Unexpected outbound request in isolated test: ' + url);
  }
  const body = JSON.parse(options.body || '{}');
  const system = body.systemInstruction?.parts?.[0]?.text || '';
  const prompt = body.contents?.[0]?.parts?.[0]?.text || '';
  const model = String(url).match(/models\/([^:]+):/)?.[1] || '';
  if (prompt.includes('API_429_TEST')) {
    return { ok: false, status: 429, async json() { return { error: { message: 'simulated quota limit' } }; } };
  }
  for (const [marker, status] of [['API_401_TEST',401],['API_403_TEST',403],['API_404_TEST',404],['API_500_TEST',500],['API_503_TEST',503]]) {
    if (prompt.includes(marker)) return { ok: false, status, async json() { return { error: { message: `simulated upstream ${status}` } }; } };
  }
  if (prompt.includes('API_400_TEST')) {
    return { ok: false, status: 400, async json() { return { error: { message: 'simulated invalid request' } }; } };
  }
  if (prompt.includes('EMPTY_RESPONSE_TEST')) {
    return { ok: true, status: 200, async json() { return { candidates: [], usageMetadata: {} }; } };
  }
  if (prompt.includes('MALFORMED_RESPONSE_TEST')) {
    return { ok: true, status: 200, async json() { throw new Error('simulated malformed JSON'); } };
  }
  if (prompt.includes('FALLBACK_TEST') && model === 'gemini-3.1-flash-lite') {
    return { ok: false, status: 503, async json() { return { error: { message: 'simulated temporary model outage' } }; } };
  }
  let output;
  if (system.includes('strict structured command parser')) {
    if (prompt.includes('INVALID_JSON_TEST')) output = 'This is not JSON';
    else if (prompt.includes('INVALID_BPM_TEST')) output = JSON.stringify({ genre: '2', bpm: 241, theme: 't'.repeat(260), notes: 'n'.repeat(1300) });
    else output = '```json\n{"genre":"2","language":"English","fusion":"Anatolian trap","energy":"High","leadVoice":"Male","backingVoice":"Choir","adlib":"Melodic","vocalEffect":"Reverb","technique":"TECH-TR-001","bpm":"128","theme":"Night drive","notes":"Keep the hook melodic","rogue":"must-not-pass"}\n```';
  } else if (system.includes('Suno Prompt Engine')) {
    output = 'English melodic trap, warm keys, tight drums, deep 808 bass.';
  } else {
    output = 'TITLE: Test Song\n[Verse 1]\nA test lyric line.';
  }
  return {
    ok: true,
    status: 200,
    async json() {
      return {
        candidates: [{ content: { parts: [{ text: output }] } }],
        usageMetadata: { promptTokenCount: 10, candidatesTokenCount: 20, totalTokenCount: 30 }
      };
    }
  };
};
