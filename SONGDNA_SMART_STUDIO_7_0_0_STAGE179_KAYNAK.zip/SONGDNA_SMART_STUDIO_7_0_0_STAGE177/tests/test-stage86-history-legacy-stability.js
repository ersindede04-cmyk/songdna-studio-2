const assert=require('node:assert/strict');
const h=require('../www/production-history.js');
const legacy=[
 {title:'Eski kayıt',lyrics:'Sözler',sty:'Dark trap',created:'2026-10-01'},
 {title:'İkinci kayıt',lyrics:'Başka sözler',style:'Anadolu rock',created:'2026-10-02'}
];
const first=h.normalize(legacy);
const second=h.normalize(legacy);
assert.equal(first.length,2);
assert.equal(first[0].id,second[0].id,'legacy ID remains stable across repeated reads');
assert.equal(first[1].id,second[1].id,'each legacy entry gets a repeatable ID');
assert.notEqual(first[0].id,first[1].id,'different legacy entries do not share IDs');
assert.equal(first[0].style,'Dark trap');
assert.equal(first[0].lyrics,'Sözler');
assert.equal(legacy[0].id,undefined,'normalization does not mutate stored source');
const withMetadata=h.normalize([{id:'known',title:'Meta',lyrics:'L',style:'S',custom:{keep:true}}]);
assert.deepEqual(withMetadata[0].custom,{keep:true},'unknown metadata remains intact');
const updated=h.updateLatest(first,{style:'Updated'});
assert.equal(updated[1].id,first[1].id,'update preserves stable identity');
assert.equal(updated[1].style,'Updated');
console.log('Stage86 history legacy stability tests passed.');
