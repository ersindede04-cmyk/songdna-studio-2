'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const engine=require(path.join(root,'three-layer-production-orchestrator.js'));
const result=engine.build({
 main:{id:'MDNA-MAIN',name:'Main identity',family:'Primary genre',promptText:'Lead vocal with documented phrasing',selected:true},
 secondary:{id:'LAYER-RHYTHM',name:'Rhythm layer',family:'Percussion',promptText:'Hand percussion and syncopated rhythm',selected:true},
 helper:{id:'LAYER-VOICE',name:'Vocal response',family:'Vocal support',promptText:'Backing vocal call-and-response and ad-lib delivery',selected:true},
 identity:{profileId:'MDNA-MAIN',name:'Main identity',primaryGenre:'Primary genre',domain:'modern'}
});
assert.deepEqual(result.outputPlans.styles.includedRoles,['main','secondary','helper']);
assert.deepEqual(result.outputPlans.lyrics.includedRoles,['main','helper']);
assert.deepEqual(result.outputPlans.lyrics.excludedRoles,['secondary']);
assert.equal(result.outputPlans.styles.primaryRole,'main');
assert.equal(result.outputPlans.lyrics.primaryRole,'main');
assert.equal(result.sharedContext.manualSelectionWins,true);
assert.equal(result.sharedContext.autoFilled,false);
const noMain=engine.build({secondary:{id:'S',name:'Secondary',promptText:'Synth bass and percussion'},helper:{id:'H',name:'Helper',promptText:'Texture only'}});
assert.deepEqual(noMain.outputPlans.styles.includedRoles,['secondary','helper']);
assert.deepEqual(noMain.outputPlans.lyrics.includedRoles,[]);
assert.equal(noMain.outputPlans.lyrics.primaryRole,null);
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
assert(app.includes('STAGE 121 — THREE-LAYER LYRICS SCOPE'));
assert(app.includes('STAGE 121 — THREE-LAYER STYLES SCOPE'));
assert(app.includes('Instrumental, rhythmic, bass, synth, percussion and mix-only secondary/helper layers affect Styles, not lyric vocabulary'));
for(const rel of ['www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'])
 assert.equal(fs.readFileSync(path.join(root,rel),'utf8'),app,rel+' synchronized');
for(const rel of ['www/three-layer-production-orchestrator.js','android-wrapper/app/src/main/assets/three-layer-production-orchestrator.js','android-wrapper/app/src/main/assets/www/three-layer-production-orchestrator.js'])
 assert.equal(fs.readFileSync(path.join(root,rel),'utf8'),fs.readFileSync(path.join(root,'three-layer-production-orchestrator.js'),'utf8'),rel+' synchronized');
console.log('PASS Stage 121: three-layer roles are scoped separately for Styles and Lyrics; main identity and manual selections remain authoritative.');
