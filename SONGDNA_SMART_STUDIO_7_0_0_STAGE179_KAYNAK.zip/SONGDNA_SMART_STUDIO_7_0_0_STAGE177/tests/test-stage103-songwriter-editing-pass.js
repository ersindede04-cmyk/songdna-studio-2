const fs=require('fs');const path=require('path');const root=path.resolve(__dirname,'..');
const files=['app.js','www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'];
const sources=files.map(f=>fs.readFileSync(path.join(root,f),'utf8'));
const required=[
 'SILENT SONGWRITER EDITING PASS — BEFORE RETURNING THE LYRICS:',
 'not as separate impressive-sounding lines',
 'woven naturally into the story rather than presented as a checklist',
 'wording exists mainly to complete a rhyme',
 'a real person could naturally say',
 'natural spoken rhythm, grammatical flow and singability',
 'never output the checklist, analysis, alternate drafts or quality score',
 'manual choice locks only its own dimension',
 'Broad theme and specific topic must remain distinct'
];
for(const f of files){const s=fs.readFileSync(path.join(root,f),'utf8');for(const token of required){if(!s.includes(token))throw new Error(`${f}: missing ${token}`);}if(!s.includes("return original({...c,theme:manualTheme||c.theme||values[0]})+brief;"))throw new Error(`${f}: prompt handoff changed`);}
if(new Set(sources).size!==1)throw new Error('Four app.js entrypoints are not byte-identical');
console.log('PASS Stage103 silent songwriter editing contract; four app.js copies identical');
