const assert=require('node:assert/strict');
const backup=require('../data-backup.js');
function storage(seed={}){const m=new Map(Object.entries(seed));return{getItem:k=>m.has(k)?m.get(k):null,setItem(k,v){m.set(k,String(v))},removeItem:k=>m.delete(k),dump:()=>Object.fromEntries(m)}}
const source=storage({songdna_history:'[{"lyrics":"Şarkı sözü"}]',songdna_saved:'[]',songdna_personal_theme_topic_v1:'{"theme":"Kişisel"}',songdna_api_key:'SECRET'});
const payload=backup.create(source);
assert.equal(payload.version,2);assert.equal(payload.checksum,backup.checksum(payload.data));
assert.equal(backup.validate(payload).songdna_history,'[{"lyrics":"Şarkı sözü"}]');
assert.equal('songdna_api_key' in payload.data,false);
const target=storage({songdna_history:'old'});assert.equal(backup.restore(target,payload).ok,true);assert.equal(target.getItem('songdna_history'),payload.data.songdna_history);
const corrupted=JSON.parse(JSON.stringify(payload));corrupted.data.songdna_history+='x';assert.throws(()=>backup.validate(corrupted),/doğrulaması/);
const truncated={...payload,data:{songdna_history:'partial'}};assert.throws(()=>backup.validate(truncated),/doğrulaması/);
assert.throws(()=>backup.validate({...payload,createdAt:'not-a-date'}),/tarihi/);
assert.throws(()=>backup.validate({...payload,data:{songdna_history:'x'.repeat(5_000_001)}}),/büyük/);
assert.throws(()=>backup.validate({...payload,data:{songdna_history:'x'.repeat(4_500_000),songdna_saved:'y'.repeat(4_500_000),songdna_lyric_memory:'z'.repeat(4_500_000),songdna_personal_theme_topic_v1:'a'.repeat(4_500_000),songdna_personal_adlibs_v1:'b'.repeat(4_500_000)}}),/toplam boyutu/);
// Stage90 version-1 backups remain importable for backward compatibility.
const legacy={format:'songdna-local-backup',version:1,createdAt:'2026-11-20T00:00:00.000Z',data:{songdna_history:'legacy'}};
assert.equal(backup.validate(legacy).songdna_history,'legacy');
assert.throws(()=>backup.validate({...payload,version:99}));
console.log('Stage91 backup integrity tests passed.');
