'use strict';
const assert=require('assert');
const fs=require('fs');
const vm=require('vm');
const engine=require('../three-layer-production-orchestrator.js');
const app=fs.readFileSync('app.js','utf8');
assert(app.includes('initStage132ThreeLayerOutputRouting'),'Stage 132 prompt integration missing');
assert(app.includes('globalThis.SongDnaThreeLayerOutputRouting={audit:auditThreeLayerOutputRouting'),'Public routing audit missing');
const start=app.indexOf('function auditThreeLayerOutputRouting(');
const end=app.indexOf('\n/* Stage 131 —',start);
assert(start>=0&&end>start,'Routing audit function missing');
const fn=app.slice(start,end).replace('function auditThreeLayerOutputRouting','globalThis.auditThreeLayerOutputRouting=function auditThreeLayerOutputRouting');
const sandbox={};vm.runInNewContext(fn,sandbox);
let built=engine.build({main:{id:'MDNA-UKD',name:'UK Drill',family:'Drill',promptText:'Sliding 808 and syncopated drums',musicalTraits:['sliding 808']},secondary:{id:'FX-1',name:'Atmospheric Texture',promptText:'Ambient synth texture'},helper:{}});
let r=sandbox.auditThreeLayerOutputRouting(built);
assert.strictEqual(r.level,'ok');
assert.deepStrictEqual(Array.from(r.stylesRoles),['main','secondary']);
assert.deepStrictEqual(Array.from(r.lyricsRoles),['main']);
assert.deepStrictEqual(Array.from(r.lyricsExcludedRoles),['secondary']);
assert.strictEqual(r.primaryRole,'main');
// Explicit vocal secondary is allowed to guide lyric performance.
built=engine.build({main:{id:'M',name:'Main'},secondary:{id:'V',name:'Vocal Response',promptText:'Call and response backing vocals'},helper:{}});
r=sandbox.auditThreeLayerOutputRouting(built);
assert.strictEqual(r.level,'ok');
assert.deepStrictEqual(Array.from(r.lyricsRoles),['main','secondary']);
// Empty helper stays empty; it is not auto-filled.
built=engine.build({main:{id:'M',name:'Main'},secondary:{},helper:{}});
r=sandbox.auditThreeLayerOutputRouting(built);
assert.strictEqual(r.level,'ok');
assert.deepStrictEqual(Array.from(r.selectedRoles),['main']);
// No main identity: secondary cannot be promoted.
built=engine.build({main:{},secondary:{id:'S',name:'Secondary'},helper:{}});
r=sandbox.auditThreeLayerOutputRouting(built);
assert.strictEqual(r.level,'ok');
assert.strictEqual(r.primaryRole,null);
// Detect a selected role silently omitted from Styles.
built=engine.build({main:{id:'M',name:'Main'},secondary:{id:'S',name:'Secondary'},helper:{}});
built.outputPlans.styles.includedRoles=['main'];
r=sandbox.auditThreeLayerOutputRouting(built);
assert.strictEqual(r.level,'warning');
assert(r.issues.some(x=>x.includes('Styles katman listesi')));
// Detect an unselected role injected into Lyrics.
built=engine.build({main:{id:'M',name:'Main'},secondary:{},helper:{}});
built.outputPlans.lyrics.includedRoles.push('helper');
r=sandbox.auditThreeLayerOutputRouting(built);
assert.strictEqual(r.level,'warning');
assert(r.issues.some(x=>x.includes('seçilmemiş katman')));
// Detect a false primary assignment when main is absent.
built=engine.build({main:{},secondary:{id:'S',name:'Secondary'},helper:{}});
built.outputPlans.styles.primaryRole='secondary';
r=sandbox.auditThreeLayerOutputRouting(built);
assert.strictEqual(r.level,'warning');
// API is explicitly non-destructive.
assert.strictEqual(r.automaticRewrite,false);
assert.strictEqual(r.selectionChanged,false);
console.log('Stage 132: 16 assertions passed; role boundaries and output routing validated.');
