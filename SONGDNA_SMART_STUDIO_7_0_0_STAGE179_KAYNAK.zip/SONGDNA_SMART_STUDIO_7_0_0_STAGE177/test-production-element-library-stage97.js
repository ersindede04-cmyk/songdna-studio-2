const lib=require('./production-element-library.js');
if(lib.list().length!==71) throw new Error('catalog count');
const deep=lib.build({dna:'Deep House',style:'Deep House, Melodic House',profile:{name:'Deep House',primary_genre:'Deep House',tags:['deep-house','house']},layers:[{role:'main',selected:true,name:'Deep House',family:'house'}]});
if(!deep.enabled||!deep.items.length||!deep.promptText.includes('kick')) throw new Error('deep house composition failed');
const traditional=lib.build({dna:'Turkish Folk',style:'Turkish Folk',profile:{name:'Turkish Folk',primary_genre:'Turkish Folk'},layers:[{role:'main',selected:true,name:'Turkish Folk',family:'traditional folk'}]});
if(traditional.enabled||traditional.items.length) throw new Error('traditional auto-electronic injection');
console.log(JSON.stringify({catalog:lib.list().length,deepHouse:deep.items.map(x=>x.name),traditionalDisabled:!traditional.enabled}));
