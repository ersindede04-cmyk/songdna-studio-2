const fs=require('fs'),vm=require('vm');
const ctx={console};ctx.globalThis=ctx;vm.createContext(ctx);
vm.runInContext(fs.readFileSync('production-element-library-data.js','utf8'),ctx);
vm.runInContext(fs.readFileSync('production-element-library.js','utf8'),ctx);
const out=ctx.SONGDNAProductionElementLibrary.build({dna:'Deep House',style:'Deep House',profile:{name:'Deep House',primary_genre:'Deep House',tags:['deep-house']},layers:[{role:'main',selected:true,name:'Deep House',family:'house'}]});
if(!out.enabled||out.items.length<5)throw Error('browser mode failed');
console.log('browser mode ok',out.items.length);
