"""Shared browser launcher for SONGDNA's Playwright regression tests.

CI installs Playwright-managed Chromium. Local/controlled runners may provide
SONGDNA_CHROMIUM_EXECUTABLE to use an already-installed Chromium binary.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path


def launch_chromium(playwright, **kwargs):
    executable = os.environ.get("SONGDNA_CHROMIUM_EXECUTABLE", "").strip()
    if not executable:
        executable = shutil.which("chromium") or shutil.which("chromium-browser") or ""
    if executable:
        path = Path(executable)
        if not path.is_file():
            raise RuntimeError(
                f"SONGDNA_CHROMIUM_EXECUTABLE does not point to a file: {executable}"
            )
        kwargs["executable_path"] = str(path)
    return playwright.chromium.launch(**kwargs)
