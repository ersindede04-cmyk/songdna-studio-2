#!/usr/bin/env python3
"""Stage170 live Chromium checks for workspace isolation, toggles and responsive layout."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from browser_test_utils import launch_chromium
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def record(name,ok,detail=''):
    checks.append(bool(ok)); print(('PASS' if ok else 'FAIL')+' '+name+(f' — {detail}' if detail else ''))
with sync_playwright() as p:
    browser=launch_chromium(p,headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    for width,height,label in [(390,844,'phone'),(820,1180,'tablet-portrait'),(1180,820,'tablet-landscape')]:
        page=browser.new_page(viewport={'width':width,'height':height},locale='tr-TR')
        html=(ROOT/'index.html').read_text(encoding='utf-8')
        import re
        sources=re.findall(r'<script\b[^>]*src=["\']([^"\']+)["\'][^>]*></script>',html,flags=re.I)
        html=re.sub(r'<script\b[^>]*src=["\'][^>]*></script>','',html,flags=re.I)
        shim='<script>(()=>{const data={};Object.defineProperty(window,\"localStorage\",{value:{getItem:k=>data[k]??null,setItem:(k,v)=>data[k]=String(v),removeItem:k=>delete data[k]}})})()</script>'
        html=html.replace('</head>',shim+'</head>')
        page.set_content(html,wait_until='domcontentloaded')
        for src in sources: page.add_script_tag(content=(ROOT/src).read_text(encoding='utf-8'))
        page.wait_for_timeout(350)
        record(f'{label}: modern workspace initially selected',page.locator('#standardModeTab').get_attribute('aria-pressed')=='true' and not page.locator('#dnaPanel').evaluate('(e)=>e.classList.contains("active")'))
        if width<=420:
            wordmark=page.locator('.brand')
            record(f'{label}: wordmark does not wrap on narrow screens',wordmark.evaluate('(e)=>getComputedStyle(e).whiteSpace')=='nowrap' and wordmark.evaluate('(e)=>e.scrollWidth<=e.clientWidth'))
        trad=page.locator('#traditionalMusicEnabled'); modern=page.locator('#modernMusicEnabled'); pure=page.locator('#pureTraditionalProduction')
        trad.uncheck(force=True); modern.check(force=True)
        page.locator('#globalModeTab').click()
        record(f'{label}: workspace tab leaves music-domain switches independent',not trad.is_checked() and modern.is_checked())
        record(f'{label}: traditional workspace shows regional controls',page.locator('#dnaPanel').evaluate('(e)=>e.classList.contains("active")'))
        record(f'{label}: shared production details collapse in traditional workspace',not page.locator('#sharedProductionSettings').evaluate('(e)=>e.open'))
        page.locator('#worldRegion').select_option(label='Türkiye')
        subregions=page.locator('#worldSubregion option').all_text_contents()
        region_names=page.locator('#worldRegion option').all_text_contents()
        instrument_names=page.locator('#instrumentChoices .instrument-switch-name').all_text_contents()
        vocal_options=page.locator('#worldVocal option').all_text_contents()
        record(f'{label}: traditional region list excludes modern studio regions',not any(x in region_names for x in ['United States / ABD','United Kingdom / Birleşik Krallık','Modern Fusion']))
        record(f'{label}: Türkiye subregions exclude modern pop/urban options',not any('Modern' in x or 'şehir / pop' in x for x in subregions),str(subregions))
        record(f'{label}: Turkish instrument list excludes synth/808 choices',not any(x in instrument_names for x in ['Synth bass','808','Analog synth','Elektrik gitar']),str(instrument_names))
        record(f'{label}: traditional vocal choices exclude rap-hype option',not any('Rap ad-lib' in x for x in vocal_options))
        opts=page.locator('#quickPreset option').all_text_contents()
        bad=['Turkish Modern Trap','Turkish Pop + Electronic Pop Fusion','Turkish R&B Fusion','Arabian Night','Afro Drill','Amapiano Soul','Japanese Dark Pop','Persian Desert']
        record(f'{label}: modern presets excluded from traditional selector',not any(any(b in o for b in bad) for o in opts),str(opts))
        record(f'{label}: traditional catalog presets remain available',any('Anadolu Zeybek' in o for o in opts) and any('Azerbaycan Mugham' in o for o in opts))
        instruments=page.locator('#instrumentChoices input[role="switch"]')
        record(f'{label}: instrument options render as independent switches',instruments.count()>=5)
        if instruments.count():
            first=instruments.nth(0); first.check(force=True); page.wait_for_timeout(250)
            record(f'{label}: instrument switch can be enabled independently',first.is_checked())
            track=page.locator('#instrumentChoices .instrument-switch:has(input:checked) .switch-track').first
            color=track.evaluate('(e)=>getComputedStyle(e).backgroundColor')
            record(f'{label}: enabled instrument switch is yellow',color in ['rgb(245, 196, 0)','rgb(245, 196, 0)'],color)
        if not pure.is_checked(): pure.click(force=True)
        record(f'{label}: pure traditional toggle does not change domain switches',not trad.is_checked() and modern.is_checked())
        record(f'{label}: pure traditional toggle is accessible',pure.get_attribute('role')=='switch')
        cols=page.locator('#instrumentChoices').evaluate('(e)=>getComputedStyle(e).gridTemplateColumns.split(" " ).length')
        if width>=760: record(f'{label}: tablet instrument layout has multiple columns',cols>=4,str(cols))
        else: record(f'{label}: phone instrument layout remains compact',cols>=2 and cols<=3,str(cols))
        page.locator('#standardModeTab').click()
        record(f'{label}: modern tab returns without changing domains',not trad.is_checked() and modern.is_checked() and not page.locator('#dnaPanel').evaluate('(e)=>e.classList.contains("active")'))
        page.close()
    browser.close()
print(f'\nSTAGE170 WORKSPACE RESULT: {sum(checks)}/{len(checks)} passed')
if not all(checks): raise SystemExit(1)
