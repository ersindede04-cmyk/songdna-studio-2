const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const context=app.slice(app.indexOf('function context()'),app.indexOf('// Stage 59:'));
const envelope=app.slice(app.indexOf('function buildGeminiInstructionEnvelope'),app.indexOf('\nfunction buildGeminiStylePrompt'));
const shared=app.slice(app.indexOf('function buildSharedOutputIdentityContract'),app.indexOf('// 5.2.0 Gemini Instruction Engine'));
const lyrics=app.slice(app.indexOf('function makeLyricsPrompt'),app.indexOf('// Only recognized standalone'));
const style=app.slice(app.indexOf('function buildGeminiStylePrompt'),app.indexOf('function makeLyricsPrompt'));
for(const marker of ["productionProfile.promptText+='; '+adaptation.promptText","productionProfile.promptText+='; '+baseContext.emotionProfile.promptText","productionProfile.promptText+='; '+baseContext.atmosphereProfile.promptText","productionProfile.promptText+='; '+baseContext.energyProfile.promptText","productionProfile.promptText+='; '+baseContext.sectionArrangementProfile.promptText","productionProfile.promptText+='; '+baseContext.fusionProfile.promptText","productionProfile.promptText+='; '+baseContext.integratedProductionProfile.promptText"]){assert(!context.includes(marker),'Engine prompt text must not be concatenated into core Production DNA: '+marker)}
for(const marker of ['sectionArrangement:c.sectionArrangementProfile?.promptText','production:c.productionProfile?.promptText','integratedProduction:c.integratedProductionProfile?.promptText'])assert(!shared.includes(marker),'Shared identity contract must not duplicate full engine prompt bodies: '+marker);
assert(envelope.includes('sharedIdentityContract:buildSharedOutputIdentityContract(c)'),'Compact canonical identity contract remains available to the provider');
assert(envelope.includes('personalProductionModelActive:!!c.productionModelPrompt'),'Envelope retains compact production model presence');
for(const marker of ['EMOTION ADAPTATION:','ATMOSPHERE GUIDANCE:','ENERGY ADAPTATION:','INTEGRATED PRODUCTION COORDINATION:','SECTION-BY-SECTION ARRANGEMENT PLAN','APPROVED PRODUCTION DNA PACKAGE'])assert(lyrics.includes(marker),'Lyrics task must retain separate engine guidance: '+marker);
for(const marker of ['EMOTION ADAPTATION:','ATMOSPHERE GUIDANCE:','ENERGY ADAPTATION:','INTEGRATED PRODUCTION COORDINATION:','SECTION ARRANGEMENT:','PRODUCTION DNA:'])assert(style.includes(marker),'Styles task must retain separate engine guidance: '+marker);
assert(!app.includes("c.productionProfile.promptText=[c.productionProfile.promptText,c.productionModelPrompt].filter(Boolean).join('; ')"),'Personal model text must not be appended to Production DNA');
for(const rel of ['www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'])assert.strictEqual(fs.readFileSync(path.join(root,rel),'utf8'),app,'Runtime copy mismatch: '+rel);
console.log('Stage 76 PASS: core production DNA is no longer a container for repeated engine prompt bodies; engine-specific guidance remains once in each relevant task; canonical identity and envelope are compact; production model remains active; all runtime copies match.');
