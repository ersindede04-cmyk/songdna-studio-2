'use strict';
const fs = require('fs');
const path = require('path');
const roots = [
  path.resolve(__dirname, '..', 'app.js'),
  path.resolve(__dirname, '..', 'www', 'app.js'),
  path.resolve(__dirname, '..', 'android-wrapper', 'app', 'src', 'main', 'assets', 'app.js')
].filter(fs.existsSync);
if (!roots.length) throw new Error('No app.js source found');
for (const file of roots) {
  const source = fs.readFileSync(file, 'utf8');
  for (const token of [
    'pureTraditionalProduction',
    'PURE TRADITIONAL PRODUCTION — WORLDWIDE CULTURAL AUTHENTICITY LOCK',
    'Modern Music',
    'Do not substitute generic'
  ]) {
    if (!source.includes(token)) throw new Error(`${path.basename(file)} missing ${token}`);
  }
}
const htmlFiles = [
  path.resolve(__dirname, '..', 'index.html'),
  path.resolve(__dirname, '..', 'www', 'index.html'),
  path.resolve(__dirname, '..', 'android-wrapper', 'app', 'src', 'main', 'assets', 'index.html'),
  path.resolve(__dirname, '..', 'android-wrapper', 'app', 'src', 'main', 'assets', 'www', 'index.html')
].filter(fs.existsSync);
if (htmlFiles.length !== 4) throw new Error(`Expected four synchronized HTML copies; found ${htmlFiles.length}`);
for (const file of htmlFiles) {
  const html = fs.readFileSync(file, 'utf8');
  const domainBlock = html.match(/<div class=\"field\"><label>Müzik alanları<\/label>[\s\S]*?<\/div>/)?.[0] || '';
  if (!domainBlock.includes('traditionalMusicEnabled') || !domainBlock.includes('modernMusicEnabled')) {
    throw new Error(`${path.basename(file)} is missing the two music-domain controls`);
  }
  if (domainBlock.includes('pureTraditionalProduction')) {
    throw new Error(`${path.basename(file)} incorrectly places the production approach among music domains`);
  }
  if (!html.includes('Düzenleme yaklaşımı') || !html.includes('Saf Geleneksel İcra')) {
    throw new Error(`${path.basename(file)} is missing the separate traditional arrangement approach`);
  }
}
console.log('Stage158 traditional arrangement approach checks passed.');
