#!/usr/bin/env python3
"""Chromium responsive-CSS and two-tab interaction harness for Stage 30.2."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
from browser_test_utils import launch_chromium

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / 'index.html').read_text(encoding='utf-8')
STYLES = '\n'.join(re.findall(r'<style\b[^>]*>([\s\S]*?)</style>', SOURCE, re.I))
HARNESS = f'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>{STYLES}</style></head><body><main class="app">
<header class="top">SONGDNA</header><section class="hero"><h1>Şarkının DNA'sını tasarla.</h1></section>
<nav class="mobile-tabs" aria-label="Ana bölümler"><button class="mobile-tab active" data-screen="generatorPanel">✦ ÜRETİM</button><button class="mobile-tab" data-screen="resultsPanel">♫ STYLES + LYRICS</button></nav>
<div class="tab-panel" id="templatePanel">TEMPLATES</div><div class="tab-panel" id="dnaPanel">WORLD MUSIC</div>
<div class="tab-panel active" id="generatorPanel">GENERATOR</div><div class="tab-panel" id="resultsPanel">RESULTS</div><footer class="footer">Footer</footer>
</main><button id="menuOpen">Menu</button><button data-open-screen="templatePanel">Templates</button>
<script>
function activateScreen(id){{document.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('active',p.id===id));document.querySelectorAll('.mobile-tab').forEach(b=>b.classList.toggle('active',b.dataset.screen===id));}}
document.querySelectorAll('.mobile-tab').forEach(b=>b.addEventListener('click',()=>activateScreen(b.dataset.screen)));
document.querySelectorAll('[data-open-screen]').forEach(b=>b.addEventListener('click',()=>activateScreen(b.dataset.openScreen)));
</script></body></html>'''
results=[]
def record(name, ok, detail=''):
    results.append((name, bool(ok)))
    print(('PASS' if ok else 'FAIL') + ' ' + name + (f' — {detail}' if detail else ''))

with sync_playwright() as p:
    browser = launch_chromium(p, headless=True, args=['--no-sandbox','--disable-dev-shm-usage'])
    for width,height,label in [(390,844,'phone'),(760,1024,'small-tablet'),(900,1024,'tablet'),(1024,768,'tablet-landscape'),(1179,820,'large-tablet')]:
        page=browser.new_page(viewport={'width':width,'height':height})
        page.set_content(HARNESS, wait_until='load')
        tabs=page.locator('.mobile-tabs .mobile-tab')
        record(f'{label} {width}px: exactly two primary tabs',tabs.count()==2)
        record(f'{label} {width}px: generator initially visible',page.locator('#generatorPanel').evaluate('(e)=>getComputedStyle(e).display')!='none')
        record(f'{label} {width}px: results initially hidden',page.locator('#resultsPanel').evaluate('(e)=>getComputedStyle(e).display')=='none')
        tabs.nth(1).click()
        record(f'{label} {width}px: second tab activates results only',page.locator('#resultsPanel').evaluate('(e)=>getComputedStyle(e).display')!='none' and page.locator('#generatorPanel').evaluate('(e)=>getComputedStyle(e).display')=='none')
        record(f'{label} {width}px: active tab state follows selection','active' in (tabs.nth(1).get_attribute('class') or '') and 'active' not in (tabs.nth(0).get_attribute('class') or ''))
        tabs.nth(0).click()
        record(f'{label} {width}px: first tab returns to generator',page.locator('#generatorPanel').evaluate('(e)=>getComputedStyle(e).display')!='none' and page.locator('#resultsPanel').evaluate('(e)=>getComputedStyle(e).display')=='none')
        if 760<=width<=1179:
            page.locator('[data-open-screen="templatePanel"]').click()
            record(f'{label} {width}px: auxiliary template panel accessible',page.locator('#templatePanel').evaluate('(e)=>getComputedStyle(e).display')!='none')
            record(f'{label} {width}px: auxiliary view hides primary panels',page.locator('#generatorPanel').evaluate('(e)=>getComputedStyle(e).display')=='none' and page.locator('#resultsPanel').evaluate('(e)=>getComputedStyle(e).display')=='none')
        page.close()
    page=browser.new_page(viewport={'width':1280,'height':800})
    page.set_content(HARNESS,wait_until='load')
    record('wide desktop: generator and results remain side by side',page.locator('#generatorPanel').evaluate('(e)=>getComputedStyle(e).display')!='none' and page.locator('#resultsPanel').evaluate('(e)=>getComputedStyle(e).display')!='none')
    record('wide desktop: mobile tabs are hidden',page.locator('.mobile-tabs').evaluate('(e)=>getComputedStyle(e).display')=='none')
    page.close();browser.close()

passed=sum(ok for _,ok in results)
print(f'\n{passed}/{len(results)} browser checks passed')
if passed!=len(results): raise SystemExit(1)
