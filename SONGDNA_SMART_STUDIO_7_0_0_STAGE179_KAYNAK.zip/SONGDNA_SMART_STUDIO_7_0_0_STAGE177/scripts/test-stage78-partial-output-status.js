const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const app = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');

assert.match(app, /let styleGenerated=false;let styleFailureMessage='';/, 'generation tracks whether Gemini returned Styles');
assert.match(app, /const styleCheck=validateGeminiStyleOutput\(st\);if\(!styleCheck\.valid\)throw/, 'invalid Styles response is treated as a failure');
assert.match(app, /styleGenerated\?'STYLES ve LYRICS hazır\./, 'success status is shown only when both outputs are ready');
assert.match(app, /'LYRICS hazır; STYLES için Gemini üretimi tamamlanamadı\./, 'partial success is reported honestly');
assert.match(app, /Seçimlerinden oluşturulan mevcut taslak korundu\./, 'locally prepared Styles draft is preserved on Gemini failure');
console.log('PASS: Stage 78 partial-output reporting, empty Styles rejection and fallback draft preservation');
