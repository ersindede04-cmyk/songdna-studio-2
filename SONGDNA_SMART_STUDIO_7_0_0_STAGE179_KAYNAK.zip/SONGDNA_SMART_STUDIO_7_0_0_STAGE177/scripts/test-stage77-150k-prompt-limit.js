'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const clientFiles = [
  'app.js', 'www/app.js',
  'android-wrapper/app/src/main/assets/app.js',
  'android-wrapper/app/src/main/assets/www/app.js'
];
for (const file of clientFiles) {
  const source = fs.readFileSync(path.join(root, file), 'utf8');
  if (!source.includes('prompt.length>150000')) throw new Error(`${file}: 150,000 client guard missing`);
  if (source.includes('prompt.length>100000')) throw new Error(`${file}: stale 100,000 client guard remains`);
}
const server = fs.readFileSync(path.join(root, 'backend/server.js'), 'utf8');
if (!server.includes('prompt.length > 150_000')) throw new Error('Server 150,000 prompt guard missing');
if (!server.includes('const MAX_BODY = 1_000_000;')) throw new Error('Server JSON body ceiling not raised to 1 MB');
if (server.includes('prompt.length > 100_000')) throw new Error('Stale 100,000 server guard remains');
console.log('Stage77 150,000-character client/server limit checks passed.');
