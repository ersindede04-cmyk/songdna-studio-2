#!/usr/bin/env python3
"""Stage155 source-package contract validation; no network access required."""
from pathlib import Path
import json, ast
ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "BUILD_PACKAGE_MANIFEST_STAGE155.json").read_text(encoding="utf-8"))
assert manifest["package_stage"] == 155
assert manifest["application_version"] == "6.1.0"
assert manifest["application_manifest_stage"] == 151
assert (ROOT / "requirements-test.txt").is_file()
requirements = (ROOT / "requirements-test.txt").read_text(encoding="utf-8")
assert "playwright==1.57.0" in requirements
js = list((ROOT / "scripts").glob("test-*.js")) + list((ROOT / "tests").glob("test-*.js"))
if (ROOT / "test-gemini-instruction-engine.js").is_file():
    js.append(ROOT / "test-gemini-instruction-engine.js")
py = sorted((ROOT / "scripts").glob("test-*.py"))
assert len(js) == manifest["javascript_test_files"] == 120, f"JS test inventory mismatch: {len(js)}"
assert len(py) == manifest["python_test_files"] == 5, f"Python test inventory mismatch: {len(py)}"
for path in py:
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    source = path.read_text(encoding="utf-8")
    assert "/usr/bin/chromium" not in source, f"Runner-specific Chromium path: {path}"
assert not (ROOT / ".github/workflows/build.yml").exists(), "Stale embedded workflow must not ship in source archive"
assert (ROOT / "android-wrapper/settings.gradle.kts").is_file()
assert (ROOT / "android-wrapper/app/build.gradle.kts").is_file()
print("STAGE155 SOURCE PACKAGE CONTRACT: PASS")
print(f"JavaScript test files: {len(js)}")
print(f"Python test files: {len(py)}")
print("Playwright dependency: declared")
print("Chromium path: runner-independent")
print("Android Gradle project: present")
