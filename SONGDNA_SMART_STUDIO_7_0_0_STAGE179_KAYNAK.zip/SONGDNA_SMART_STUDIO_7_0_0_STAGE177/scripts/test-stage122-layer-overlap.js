'use strict';
const assert=require('assert');
const engine=require('../three-layer-production-orchestrator.js');
const make=(main,secondary,helper)=>engine.analyze({main,secondary,helper});
const base={id:'main-1',name:'Main Identity',family:'Electronic'};
{
 const result=make(base,{id:'sec-1',name:'Secondary',elements:['Analog Bass','Sidechain Compression']},{id:'help-1',name:'Helper',elements:['analog bass']});
 const note=result.notes.find(x=>x.code==='REPEATED_PRODUCTION_ELEMENTS');
 assert(note,'exact repeated production element should be flagged');
 assert(note.message.includes('analog bass'));
 assert.strictEqual(result.advisoryOnly,true);
 assert.strictEqual(result.selectionChanged,false);
}
{
 const result=make(base,{id:'sec-1',name:'Secondary',elements:['Analog Bass']},{id:'help-1',name:'Helper',elements:['Bass Synth']});
 assert(!result.notes.some(x=>x.code==='REPEATED_PRODUCTION_ELEMENTS'),'similar but distinct labels must not be conflated');
}
{
 const result=make(base,{id:'sec-1',name:'Secondary',elements:['  SIDECHAIN   COMPRESSION!']},{id:'help-1',name:'Helper',elements:['sidechain compression']});
 assert(result.notes.some(x=>x.code==='REPEATED_PRODUCTION_ELEMENTS'),'case and whitespace variants should be normalized');
}
{
 const result=make(base,{id:'sec-1',name:'Secondary',elements:['Analog Bass']},{});
 assert(!result.notes.some(x=>x.code==='REPEATED_PRODUCTION_ELEMENTS'),'unselected layers must not create overlap warnings');
}
{
 const input={main:{...base,elements:['Piano']},secondary:{id:'sec-1',name:'Secondary',elements:['Piano']},helper:{}};
 const before=JSON.stringify(input);
 make(input.main,input.secondary,input.helper);
 assert.strictEqual(JSON.stringify(input),before,'analysis must not mutate user selections');
}
console.log('Stage 122 layer overlap tests: 5/5 passed');
