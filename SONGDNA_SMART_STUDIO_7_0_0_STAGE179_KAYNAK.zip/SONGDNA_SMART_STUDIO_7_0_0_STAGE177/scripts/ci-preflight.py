#!/usr/bin/env python3
"""Stage156 CI preflight for pinned Python browser-test dependencies."""
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
requirements = ROOT / "requirements-test.txt"
if not requirements.is_file():
    raise SystemExit("FAIL: requirements-test.txt is missing")
text = requirements.read_text(encoding="utf-8")
match = re.search(r"^playwright==([0-9]+\.[0-9]+\.[0-9]+)\s*$", text, re.M)
if not match:
    raise SystemExit("FAIL: requirements-test.txt must pin playwright with an exact version")
expected = match.group(1)
try:
    installed = version("playwright")
except PackageNotFoundError:
    raise SystemExit("FAIL: Playwright Python distribution is not installed")
if installed != expected:
    raise SystemExit(f"FAIL: Playwright version mismatch; expected {expected}, installed {installed}")
try:
    from playwright.sync_api import sync_playwright  # noqa: F401
except Exception as exc:
    raise SystemExit(f"FAIL: Playwright import failed: {exc}")
print(f"PASS: Playwright distribution metadata verified ({installed})")
