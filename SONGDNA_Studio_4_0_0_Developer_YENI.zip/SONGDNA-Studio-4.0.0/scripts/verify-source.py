#!/usr/bin/env python3
"""Pre-build integrity checks for SONGDNA Studio 4.0.0."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    ".github/workflows/build-apk.yml",
    "android-wrapper/settings.gradle.kts",
    "android-wrapper/build.gradle.kts",
    "android-wrapper/gradle.properties",
    "android-wrapper/app/build.gradle.kts",
    "android-wrapper/app/src/main/AndroidManifest.xml",
    "android-wrapper/app/src/main/java/com/songdna/studio/MainActivity.kt",
    "android-wrapper/app/src/main/assets/www/index.html",
    "www/index.html",
    "backend/server.js",
    "backend/package.json",
    "backend/.env.example",
]
missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
if missing:
    raise SystemExit("FAIL: Missing required files:\n- " + "\n- ".join(missing))
print("PASS: Required files exist at the repository root.")

# There must be one source tree, not an embedded source archive or nested project.
archives = [p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*.zip") if ".git" not in p.parts]
if archives:
    raise SystemExit("FAIL: Nested ZIP archives found: " + ", ".join(archives))
if not (ROOT / "android-wrapper/app/build.gradle.kts").is_file():
    raise SystemExit("FAIL: Android app module path is not the expected unique path.")
print("PASS: No nested ZIP or ambiguous Android module path.")

web = (ROOT / "www/index.html").read_text(encoding="utf-8")
android_web = (ROOT / "android-wrapper/app/src/main/assets/www/index.html").read_text(encoding="utf-8")
if web != android_web:
    raise SystemExit("FAIL: Web UI and Android WebView asset differ.")
print("PASS: Web and Android UI assets are identical.")

xml_files = list((ROOT / "android-wrapper/app/src/main").rglob("*.xml"))
for path in xml_files:
    ET.parse(path)
print(f"PASS: {len(xml_files)} Android XML file(s) parse.")

settings = (ROOT / "android-wrapper/settings.gradle.kts").read_text(encoding="utf-8")
root_gradle = (ROOT / "android-wrapper/build.gradle.kts").read_text(encoding="utf-8")
app_gradle = (ROOT / "android-wrapper/app/build.gradle.kts").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/build-apk.yml").read_text(encoding="utf-8")
manifest = (ROOT / "android-wrapper/app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
checks = {
    'include(":app")' in settings: "Android app module inclusion",
    'rootProject.name = "SONGDNA-Studio-4.0.0"' in settings: "unique Gradle project name",
    'id("com.android.application") version "8.7.3" apply false' in root_gradle: "AGP 8.7.3",
    'id("org.jetbrains.kotlin.android") version "2.0.21" apply false' in root_gradle: "Kotlin 2.0.21",
    "compileSdk = 35" in app_gradle: "compile SDK 35",
    'versionName = "4.0.0"' in app_gradle: "app version 4.0.0",
    "versionCode = 11" in app_gradle: "monotonic app version code 11",
    "sourceCompatibility = JavaVersion.VERSION_17" in app_gradle: "Java target 17",
    "targetCompatibility = JavaVersion.VERSION_17" in app_gradle: "Java bytecode target 17",
    'jvmTarget = "17"' in app_gradle: "Kotlin bytecode target 17",
    'applicationId = "com.songdna.studio"' in app_gradle: "stable application identity",
    'android:name=".MainActivity"' in manifest: "launcher activity",
    'workflow_dispatch:' in workflow: "manual-only workflow trigger",
    '-p android-wrapper clean assembleDebug' in workflow: "single explicit Gradle project path",
    'actions/upload-artifact@v4' in workflow: "APK artifact upload",
}
failed = [label for ok, label in checks.items() if not ok]
if failed:
    raise SystemExit("FAIL: Build configuration checks:\n- " + "\n- ".join(failed))
print("PASS: Project identity, Gradle versions, SDK and Java/Kotlin JVM targets.")

package = json.loads((ROOT / "backend/package.json").read_text(encoding="utf-8"))
if not package.get("scripts", {}).get("start"):
    raise SystemExit("FAIL: Backend start script missing.")
node = shutil.which("node")
if not node:
    raise SystemExit("FAIL: Node.js is required for source syntax checks.")
blocks = re.findall(r"<script(?:\s[^>]*)?>(.*?)</script\s*>", web, re.S | re.I)
if not blocks:
    raise SystemExit("FAIL: No inline JavaScript found.")
for i, block in enumerate(blocks, 1):
    result = subprocess.run([node, "--check", "--input-type=commonjs"], input=block,
                            text=True, capture_output=True)
    if result.returncode:
        raise SystemExit(f"FAIL: Inline JavaScript block {i}:\n{result.stderr}")
result = subprocess.run([node, "--check", str(ROOT / "backend/server.js")],
                        text=True, capture_output=True)
if result.returncode:
    raise SystemExit("FAIL: backend/server.js syntax:\n" + result.stderr)
print(f"PASS: Backend metadata and {len(blocks)} inline JavaScript block(s) plus backend syntax.")

preset_ids = [int(v) for v in re.findall(r"^\s*(\d+):\{region:", web, re.M)]
if preset_ids != list(range(14, 34)):
    raise SystemExit(f"FAIL: Intro DNA 14–33 check failed: {preset_ids}")
if "introPack" not in web or "PRESERVE" not in web.upper():
    raise SystemExit("FAIL: Intro DNA selector or PRESERVE controls missing.")
dna_match = re.search(r"const dna=\[(.*?)\];", web, re.S)
if not dna_match:
    raise SystemExit("FAIL: Main Music DNA catalogue not found.")
music_dna_count = len(re.findall(r"\['\d{2} ·", dna_match.group(1)))
if music_dna_count != 18:
    raise SystemExit(f"FAIL: Expected 18 Music DNA packages; found {music_dna_count}.")
print("PASS: 18 Music DNA packages, Intro DNA 14–33 and PRESERVE controls retained.")
# SONGDNA 3.0 is Gemini-only and exposes independent lyrics/style endpoints.
if "aiProvider" in web or "OpenAI / ChatGPT" in web or "openai" in web.lower():
    raise SystemExit("FAIL: OpenAI provider UI/code reference remains in the app UI.")
for required in ["gemini-3.5-flash-lite", "gemini-3.6-flash", "gemini-3.1-flash-lite", "styleGenerate", "/api/style"]:
    if required not in web:
        raise SystemExit(f"FAIL: Missing Gemini 3.0 UI/API feature: {required}")
backend = (ROOT / "backend/server.js").read_text(encoding="utf-8")
for required in ["/api/lyrics", "/api/style", "generateWithFallback", "GEMINI_API_KEY", "VERIFIED_MODELS"]:
    if required not in backend:
        raise SystemExit(f"FAIL: Missing backend feature: {required}")
if "OPENAI_API_KEY" in backend or "api.openai.com" in backend:
    raise SystemExit("FAIL: OpenAI backend path remains in Gemini-only 3.0.")
print("PASS: Gemini-only provider, verified model selector, separate Lyrics/Style endpoints and fallback logic.")
print("ALL PRE-BUILD CHECKS PASSED. Remote Android compilation and device testing remain required.")
