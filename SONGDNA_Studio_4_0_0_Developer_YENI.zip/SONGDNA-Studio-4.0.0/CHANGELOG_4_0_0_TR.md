# SONGDNA Studio 4.0.0 – Geliştirici Paketi

## Bu sürümde
- Ana ekran Styles, şarkı bilgisi ve iki Suno çıktısına odaklanacak şekilde sadeleştirildi.
- Intro & Sesler, Vokal Ayarları, Gemini/API, Projelerim ve Hakkında üç çizgili menüye taşındı.
- Intro varsayılan olarak kapalıdır; etkinleştirilirse mevcut Intro DNA kataloğu Lyrics başlangıcına eklenir.
- Gemini lyrics talimatlarına her bölüm için açık Male Vocal / Female Vocal / Male & Female Duet etiketi zorunluluğu eklendi.
- Spoken intro ifadeleri ve intro preset metni Styles alanından çıkarıldı; Lyrics başlangıcında tutulur.
- Hakkında ekranına `© 2026 SONGDNA Studio – Tüm hakları saklıdır.` eklendi.
- Var olan DNA profilleri, intro katalog verileri, Gemini `/api/lyrics` ve `/api/style` çağrıları, Android uygulama kimliği ve arşiv mantığı korundu.

## Dürüst durum notu
Bu paket mevcut Gemini API bağlantı mantığını korur; sunucunun canlı çalıştığını veya APK'nın başarıyla derlendiğini tek başına kanıtlamaz. `apiBase` ve `appToken` mevcut kurulumunuzdaki değerlerle ayarlanmalıdır. Gerçek Gemini üretimi, Render sağlık kontrolü ve APK derlemesi ayrıca test edilmelidir.
