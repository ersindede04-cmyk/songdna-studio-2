# SONGDNA SMART STUDIO 7.5.0 — Stage 194

## API geçersiz anahtar teşhis düzeltmesi
- Google Gemini `API_KEY_INVALID` / geçersiz API anahtarı yanıtları, genel HTTP 400 istek hatasından ayrıştırılır.
- Ana üretim hatası için kullanıcıya `GEMINI_API_KEY`, hikâye harmanlama hatası için `GEMINI_API_KEY_2` adı açıkça bildirilir.
- Ana üretim ve hikâye harmanlama anahtarlarının ayrılığı korunur; otomatik anahtara geri dönüş eklenmez.
- Ham sağlayıcı hata ayrıntıları veya gizli anahtar değerleri istemciye aktarılmaz.
- Ana üretim, Styles/Lyrics akışı, otomatik konu sıralaması ve bağımsız hikâye harmanlama mimarisi korunur.

## Sürümleme
- Kaynak temel: Stage192
- Paket aşaması: Stage194
- Uygulama sürümü: 7.5.0 (korundu)
- Android versionCode: 44
