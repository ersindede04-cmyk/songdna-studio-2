const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const gradle=fs.readFileSync(path.join(root,'android-wrapper/app/build.gradle.kts'),'utf8');
const manifest=fs.readFileSync(path.join(root,'android-wrapper/app/src/main/AndroidManifest.xml'),'utf8');
const activity=fs.readFileSync(path.join(root,'android-wrapper/app/src/main/java/com/songdna/studio/MainActivity.kt'),'utf8');
assert.match(gradle,/applicationId\s*=\s*"com\.songdna\.studio"/,'applicationId must remain stable for in-place upgrades');
assert.match(gradle,/versionCode\s*=\s*40/,'current versionCode is recorded and must be advanced for future releases');
assert.match(gradle,/versionName\s*=\s*"7\.1\.0"/,'release version name is stable');
assert.match(manifest,/android:allowBackup="false"/,'backup policy is explicit');
assert.match(activity,/webView\.settings\.domStorageEnabled\s*=\s*true/,'WebView DOM storage must remain enabled');
assert.doesNotMatch(activity,/clearCache\s*\(|clearHistory\s*\(|deleteAllData\s*\(/,'startup must not clear WebView data');
const assetRoot=path.join(root,'android-wrapper/app/src/main/assets/www');
for(const file of ['index.html','app.js','production-history.js','production-history-storage.js']){
  assert.ok(fs.existsSync(path.join(assetRoot,file)),`bundled asset exists: ${file}`);
}
const appCopies=['app.js','www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'].map(p=>fs.readFileSync(path.join(root,p)));
assert.ok(appCopies.every(b=>b.equals(appCopies[0])),'all app.js copies match');
console.log('Stage88 Android upgrade compatibility audit passed.');
