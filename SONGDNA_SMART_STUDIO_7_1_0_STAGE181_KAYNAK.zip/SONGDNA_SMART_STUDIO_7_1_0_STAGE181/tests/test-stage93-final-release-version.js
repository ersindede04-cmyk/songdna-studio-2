'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const manifest = JSON.parse(read('BUILD_MANIFEST.json'));
assert.equal(manifest.version, '7.1.0');
assert.equal(manifest.android.version_name, '7.1.0');
assert.equal(manifest.android.version_code, 40);
assert.equal(manifest.android.application_id, 'com.songdna.studio');
for (const p of ['www/BUILD_MANIFEST.json','android-wrapper/app/src/main/assets/BUILD_MANIFEST.json','android-wrapper/app/src/main/assets/www/BUILD_MANIFEST.json']) assert.deepEqual(JSON.parse(read(p)), manifest);
for (const name of ['app.js','index.html']) {
  const copies = [name,`www/${name}`,`android-wrapper/app/src/main/assets/${name}`,`android-wrapper/app/src/main/assets/www/${name}`].map(read);
  assert.ok(copies.every(x => x === copies[0]), `${name} copies must match`);
}
for (const p of ['data-backup.js','www/data-backup.js','android-wrapper/app/src/main/assets/data-backup.js','android-wrapper/app/src/main/assets/www/data-backup.js']) assert.match(read(p), /APP_VERSION='7\.1\.0'/);
const gradle = read('android-wrapper/app/build.gradle.kts');
assert.match(gradle, /versionCode = 40/); assert.match(gradle, /versionName = "7\.1\.0"/);
const pkg = JSON.parse(read('backend/package.json')); assert.equal(pkg.version, '7.1.0');
assert.equal(read('server.js'), read('backend/server.js'));
console.log('Stage93 final release version tests passed.');
