'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

// This source-package test deliberately does not read GitHub Actions YAML.
// The workflow is a separate deployment artifact and is validated after it is
// authored; source validation must remain runnable from the source ZIP alone.
const packageManifest = JSON.parse(read('BUILD_PACKAGE_MANIFEST_STAGE155.json'));
assert.equal(packageManifest.package_stage, 155);
assert.equal(packageManifest.application_version, '6.1.0');
assert.equal(packageManifest.application_manifest_stage, 151);
assert.equal(packageManifest.android_project, 'android-wrapper/');
assert.equal(packageManifest.gradle_version, '8.9');
assert.equal(packageManifest.java_version, '17');
assert.equal(packageManifest.javascript_test_files, 120);
assert.equal(packageManifest.python_test_files, 5);
assert.equal(packageManifest.python_test_requirements, 'requirements-test.txt');
assert.equal(packageManifest.browser_test_engine, 'Playwright-managed Chromium');

const requirements = read('requirements-test.txt');
assert.match(requirements, /^playwright==1\.57\.0$/m);
for (const test of [
  'scripts/test-stage30-2-two-tab-navigation.py',
  'scripts/test-stage30-3-output-layout.py',
  'scripts/test-stage30-4-theme-persistence.py',
  'scripts/test-stage31-scene-jargon-browser.py',
]) {
  assert.ok(fs.existsSync(path.join(root, test)), `Missing browser test: ${test}`);
  const source = read(test);
  assert.ok(source.includes('from browser_test_utils import launch_chromium'), `${test} does not use shared browser launcher`);
}
assert.ok(fs.existsSync(path.join(root, 'scripts/browser_test_utils.py')));
const launcher = read('scripts/browser_test_utils.py');
assert.ok(launcher.includes('SONGDNA_CHROMIUM_EXECUTABLE'));
assert.ok(launcher.includes('shutil.which("chromium")'));

const gradleSettings = read('android-wrapper/settings.gradle.kts');
assert.ok(gradleSettings.includes('include(":app")'));
const appGradle = read('android-wrapper/app/build.gradle.kts');
for (const value of ['com.songdna.studio', 'compileSdk = 35', 'minSdk = 23', 'targetSdk = 35', 'versionCode = 40', 'versionName = "7.1.0"', 'JavaVersion.VERSION_17', 'jvmTarget = "17"']) {
  assert.ok(appGradle.includes(value), `Missing Android build setting: ${value}`);
}

const render = read('render.yaml');
for (const value of ['rootDir: backend', 'runtime: node', 'buildCommand: npm install', 'startCommand: npm start', 'healthCheckPath: /health', 'key: APP_ACCESS_TOKEN', 'key: GEMINI_API_KEY', 'key: GEMINI_MODELS', 'key: GEMINI_MODEL']) {
  assert.ok(render.includes(value), `Missing Render setting: ${value}`);
}
assert.match(render, /key:\s*APP_ACCESS_TOKEN\s*\n\s*generateValue:\s*true/);
assert.match(render, /key:\s*GEMINI_API_KEY\s*\n\s*sync:\s*false/);
assert.match(render, /key:\s*ALLOWED_ORIGIN\s*\n\s*value:\s*"\*"/);
assert.match(render, /key:\s*TRUST_PROXY\s*\n\s*value:\s*"true"/);
assert.doesNotMatch(render, /AIza[0-9A-Za-z_-]{20,}/);

const envExample = read('backend/.env.example');
assert.ok(envExample.includes('APP_ACCESS_TOKEN='));
assert.ok(envExample.includes('GEMINI_API_KEY='));
assert.ok(!fs.existsSync(path.join(root, 'backend/.env')));
const server = read('backend/server.js');
assert.ok(server.includes("url.pathname === '/health'"));
assert.ok(server.includes("'/api/lyrics', '/api/style', '/api/command'"));
assert.equal(read('server.js'), server);
const guide = read('backend/DEPLOY_TR.md');
assert.ok(guide.includes('Stage 70'));
assert.ok(guide.includes('APP_ACCESS_TOKEN'));
assert.ok(guide.includes('GEMINI_API_KEY'));
console.log('PASS: Stage155 source package, Python browser dependencies, Android Gradle configuration, Render settings and backend contracts');
