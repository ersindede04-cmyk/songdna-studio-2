#!/usr/bin/env python3
"""Strict Stage 60.1 source and Android asset integrity checks."""
from pathlib import Path
import json, re, shutil, subprocess, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
WEB=ROOT/"www"
ANDROID=ROOT/"android-wrapper/app/src/main/assets/www"
ANDROID_ROOT=ROOT/"android-wrapper/app/src/main/assets"
RUNTIME=["index.html","app.js","saved-library.js","production-history.js","adlib-catalog.js","scene-jargon-catalog.js","global-cultural-adlib.js","genre-adlib-engine.js","production-preset-engine.js","emotion-engine.js","production-adaptation-engine.js","energy-engine.js","adlib-intelligence-engine.js","atmosphere-engine.js","section-arrangement-engine.js","vocal-identity-engine.js","music-compatibility-engine.js","integrated-production-engine.js","manual-override-engine.js","profile-snapshot-engine.js","production-model-library.js","dynamic-creativity-engine.js","production-history-storage.js","three-layer-production-orchestrator.js","production-element-library-data.js","production-element-library.js"]
REQUIRED=["BUILD_MANIFEST.json","index.html","app.js","backend/server.js","backend/package.json","android-wrapper/app/build.gradle.kts","android-wrapper/app/src/main/AndroidManifest.xml","android-wrapper/app/src/main/java/com/songdna/studio/MainActivity.kt","scripts/test-stage29-client-api-contract.js","tests/test-stage29-api-contract.js","CHANGELOG_5_2_0_STAGE60_1_PRODUCTION_PROMPT_HOTFIX_TR.md","QA_REPORT_5_2_0_STAGE60_1_SOURCE_SYNC.md"]
for folder in [WEB,ANDROID]:
    REQUIRED += [str(Path(folder.relative_to(ROOT))/n) for n in RUNTIME]
missing=[x for x in REQUIRED if not (ROOT/x).is_file()]
if missing: raise SystemExit("FAIL missing files: "+", ".join(missing))
for name in RUNTIME:
    a=(WEB/name).read_bytes(); b=(ANDROID/name).read_bytes()
    if a!=b: raise SystemExit(f"FAIL WebView asset mismatch: {name}")
    if name.endswith(".js") and (ROOT/name).exists() and (ROOT/name).read_bytes()!=a:
        raise SystemExit(f"FAIL root runtime mismatch: {name}")
    if name.endswith(".js") and (ANDROID_ROOT/name).exists() and (ANDROID_ROOT/name).read_bytes()!=a:
        raise SystemExit(f"FAIL Android root asset mismatch: {name}")
if (ROOT/"index.html").read_bytes()!=(WEB/"index.html").read_bytes(): raise SystemExit("FAIL root index.html mismatch")
if (ANDROID_ROOT/"index.html").read_bytes()!=(WEB/"index.html").read_bytes(): raise SystemExit("FAIL Android root index.html mismatch")
print("PASS: root, web and Android WebView runtime assets are synchronized")
manifest_paths=[ROOT/"BUILD_MANIFEST.json",WEB/"BUILD_MANIFEST.json",ANDROID_ROOT/"BUILD_MANIFEST.json",ANDROID/"BUILD_MANIFEST.json"]
manifests=[json.loads(p.read_text(encoding="utf-8")) for p in manifest_paths]
if any(m!=manifests[0] for m in manifests[1:]): raise SystemExit("FAIL BUILD_MANIFEST.json copies differ")
m=manifests[0]
if m.get("version")!="6.1.0" or m.get("stage")!=163: raise SystemExit("FAIL expected SONGDNA 6.1.0 Stage 163 manifest")
if not any(str(x).startswith("Stage 60.1:") for x in m.get("completed_stages",[])): raise SystemExit("FAIL Stage 60.1 completion marker missing")
print("PASS: all four manifests match and identify SONGDNA 6.1.0 Stage 163")
# Android Gradle identity must agree with the canonical application manifest.
gradle=(ROOT/"android-wrapper/app/build.gradle.kts").read_text(encoding="utf-8")
settings=(ROOT/"android-wrapper/settings.gradle.kts").read_text(encoding="utf-8")
if 'applicationId = "com.songdna.studio"' not in gradle or 'versionName = "6.1.0"' not in gradle or "versionCode = 32" not in gradle:
    raise SystemExit("FAIL Android Gradle application identity/version mismatch")
if 'include(":app")' not in settings: raise SystemExit("FAIL Android Gradle settings does not include :app")
if not (ROOT/"requirements-test.txt").is_file() or not (ROOT/"scripts/ci-preflight.py").is_file():
    raise SystemExit("FAIL Stage161 Python CI preflight files missing")
print("PASS: Android Gradle identity and Stage161 Python CI preflight files")
js=(WEB/"app.js").read_text(encoding="utf-8")
for token in ["SONGDNA_GEMINI_INSTRUCTIONS_2","profileSnapshot:c.profileSnapshot?{version:c.profileSnapshot.version,id:c.profileSnapshot.id}:null","Üretim istemi "]:
    if token not in js: raise SystemExit("FAIL Stage 60.1 prompt hotfix marker missing: "+token)
if "prompt=buildGeminiInstructionEnvelope('lyrics',currentContext,makeLyricsPrompt(currentContext))" not in js: raise SystemExit("FAIL lyrics production envelope route missing")
print("PASS: Stage 60.1 compact profile metadata and prompt preflight markers present")
html=(WEB/"index.html").read_text(encoding="utf-8")
for src in re.findall(r'<script[^>]+src="([^"]+)"',html):
    if not (WEB/src).is_file(): raise SystemExit("FAIL missing HTML script dependency: "+src)
for p in (ROOT/"android-wrapper/app/src/main").rglob("*.xml"): ET.parse(p)
print("PASS: HTML dependencies and Android XML")
node=shutil.which("node")
if not node: raise SystemExit("FAIL Node.js is required")
for p in [WEB/n for n in RUNTIME if n.endswith(".js")]+[ROOT/"backend/server.js"]:
    r=subprocess.run([node,"--check",str(p)],capture_output=True,text=True)
    if r.returncode: raise SystemExit(f"FAIL JS syntax {p}: {r.stderr}")
print("PASS: JavaScript syntax")
backend=(ROOT/"backend/server.js").read_text(encoding="utf-8")
for endpoint in ["/api/lyrics","/api/style","/api/command"]:
    if endpoint not in js or endpoint not in backend: raise SystemExit("FAIL API endpoint contract: "+endpoint)
if "APP_ACCESS_TOKEN" not in backend: raise SystemExit("FAIL backend auth contract")
if "Styles" not in html or "Lyrics" not in html: raise SystemExit("FAIL Styles/Lyrics output fields missing")
print("ALL STAGE163 SOURCE CHECKS PASSED. Live Gemini, Render, external APK build and physical Android tests remain pending.")

# Ensure browser-test dependencies use distribution metadata, not removed module attributes.
preflight=(ROOT/"scripts/ci-preflight.py").read_text(encoding="utf-8")
if "importlib.metadata" not in preflight or "playwright.__version__" in preflight:
    raise SystemExit("FAIL Playwright version check must use importlib.metadata")
if len(list((ROOT/"scripts").glob("test-*.py"))) != 5:
    raise SystemExit("FAIL expected exactly five Python regression test files")
print("PASS: Playwright metadata check and five Python regression test files")

# Stage161 multilingual songwriting regression and package manifest.
package=json.loads((ROOT/"BUILD_PACKAGE_MANIFEST_STAGE163.json").read_text(encoding="utf-8"))
if package.get("package_stage")!=163 or package.get("application_version")!="6.1.0":
    raise SystemExit("FAIL Stage163 package manifest identity")
if package.get("javascript_test_files")!=124 or package.get("python_test_files")!=5:
    raise SystemExit("FAIL Stage163 package regression test counts")
if not (ROOT/"scripts/test-stage163-universal-content-standard.js").is_file() or not (ROOT/"MUSIC_CONTENT_QUALITY_STANDARD_STAGE163_TR.md").is_file():
    raise SystemExit("FAIL Stage163 standard or focused regression missing")
if not (ROOT/"tests/test-stage157-user-creative-input-fidelity.js").is_file() or not (ROOT/"tests/test-stage160-multilingual-songwriting-standard.js").is_file() or not (ROOT/"tests/test-stage161-28-language-profiles.js").is_file():
    raise SystemExit("FAIL Stage161 multilingual songwriting regression test missing")
print("PASS: Stage163 package manifest and universal content standard regression tests")
