/* SONGDNA Preset & Adaptive Mixing Engine v1
 * Deterministic genre presets + dependency-aware balancing. User overrides always win.
 */
(function(root){
 const clamp=n=>Math.max(0,Math.min(100,Math.round(n)));
 const toFiniteNumber=value=>{if(typeof value==='number')return Number.isFinite(value)?value:null;if(typeof value==='string'&&value.trim()!==''){const n=Number(value);return Number.isFinite(n)?n:null;}return null;};
 const DIMENSIONS=['rhythm','bass','melody','vocal','energy','atmosphere','structure','effects'];
 const LABELS={rhythm:'Ritim',bass:'Bas',melody:'Melodi',vocal:'Vokal',energy:'Enerji',atmosphere:'Atmosfer',structure:'Yapı',effects:'Efekt'};
 const PROFILE_FAMILY_OVERRIDES={
  // Clear profile identities must outrank incidental words in tags or traits.
  'MDNA-013':'pop','MDNA-014':'pop','MDNA-018':'general','MDNA-020':'amapiano',
  'MDNA-024':'traditional','MDNA-027':'traditional','MDNA-038':'general',
  'MDNA-046':'traditional','MDNA-053':'traditional','MDNA-054':'traditional',
  'MDNA-060':'amapiano','MDNA-062':'traditional','MDNA-063':'traditional','MDNA-067':'traditional','MDNA-068':'traditional'
 };
 function classify(p){
  const id=String(p?.id||'');
  if(PROFILE_FAMILY_OVERRIDES[id])return PROFILE_FAMILY_OVERRIDES[id];
  const s=[p?.name,p?.primary_genre,p?.subgenre_or_scene,p?.region_or_scene,...(p?.tags||[]),...(p?.musical_traits||[])].join(' ').toLowerCase();
  const has=(r)=>r.test(s);
  if(has(/drum.?and.?bass|\bdnb\b|jungle/))return 'dnb';
  if(has(/tech\s?house/))return 'techHouse';
  if(has(/detroit techno|techno|industrial techno/))return 'techno';
  if(has(/uk garage|2.step|garage/))return 'garage';
  if(has(/amapiano/))return 'amapiano';
  if(has(/house|afro.?house/))return 'house';
  if(has(/trap|drill/))return 'trap';
  if(has(/hip.?hop|rap|boom.?bap/))return 'rap';
  if(has(/folk|traditional|zeybek|bozlak|bağlama|baglama|mugham|pansori|flamenco|gamelan|son jarocho|bhangra|maqam|hindustani/))return 'traditional';
  if(has(/classical|orchestral|chamber/))return 'classical';
  if(has(/reggae|dancehall|ska/))return 'reggae';
  if(has(/latin|reggaeton|salsa|bachata|cumbia/))return 'latin';
  if(has(/ambient|drone|soundscape/))return 'ambient';
  if(has(/pop/))return 'pop';
  return 'general';
 }
 const BASE={
  trap:{bpm:[130,150],v:{rhythm:88,bass:94,melody:65,vocal:88,energy:84,atmosphere:78,structure:78,effects:82},groove:'syncopated trap half-time feel',bass:'808 sub with controlled slides and kick separation',melody:'sparse minor-key piano/synth motif and vocal-led hook',form:'intro, verse, hook, verse, hook, bridge or breakdown, final hook',fx:'vocal throws, filtered transitions and controlled spatial effects'},
  rap:{bpm:[82,104],v:{rhythm:82,bass:76,melody:62,vocal:94,energy:70,atmosphere:65,structure:84,effects:58},groove:'head-nod hip-hop pocket with intentional swing',bass:'round bass/kick relationship, no unnecessary sub movement',melody:'sample, keys or concise loop with space for lyric delivery',form:'intro, verse, hook, verse, hook, optional bridge/outro',fx:'selective saturation, room and delay throws'},
  techno:{bpm:[124,138],v:{rhythm:98,bass:92,melody:58,vocal:30,energy:94,atmosphere:88,structure:95,effects:96},groove:'steady four-on-the-floor pulse with evolving percussion',bass:'driving mono sub and sequenced bassline',melody:'hypnotic synth sequence, restrained motif and evolving texture',form:'DJ intro, groove development, breakdown, build, drop, outro',fx:'filter automation, delay/reverb sends, sidechain where appropriate'},
  house:{bpm:[118,130],v:{rhythm:94,bass:88,melody:72,vocal:48,energy:82,atmosphere:78,structure:90,effects:84},groove:'four-on-the-floor house pulse with offbeat accents',bass:'rounded syncopated bassline locked to kick',melody:'repeating chord/synth motif with gradual layering',form:'intro, groove, breakdown, return, outro',fx:'filter sweeps, tasteful sidechain and transition effects'},
  techHouse:{bpm:[120,130],v:{rhythm:96,bass:94,melody:54,vocal:38,energy:86,atmosphere:68,structure:92,effects:78},groove:'tight four-on-the-floor pulse with restrained syncopated percussion and a steady club pocket',bass:'focused repetitive bass groove locked tightly to the kick; preserve low-end separation',melody:'minimal repeating synth or percussive motif; avoid over-arranged chord layers',form:'DJ-friendly intro, groove establishment, gradual layer changes, controlled breakdown and return, functional outro',fx:'subtle filtering, restrained transitions and controlled sidechain where appropriate'},
  garage:{bpm:[128,140],v:{rhythm:96,bass:82,melody:70,vocal:52,energy:86,atmosphere:74,structure:88,effects:85},groove:'shuffled two-step swing with syncopated kick and snare',bass:'elastic sub/bassline with rhythmic gaps',melody:'chopped vocal or bright chord stabs',form:'DJ intro, shuffled groove, vocal hook, breakdown, return',fx:'vocal chops, stutter edits and filtered transitions'},
  dnb:{bpm:[160,180],v:{rhythm:100,bass:94,melody:62,vocal:45,energy:96,atmosphere:78,structure:92,effects:90},groove:'fast broken breakbeat with tight snare backbeat',bass:'deep rolling sub with a distinct mid-bass layer',melody:'atmospheric pads or concise high-energy motif',form:'intro, build, drop, breakdown, second drop, outro',fx:'break edits, risers, impacts and controlled reverb'},
  amapiano:{bpm:[108,116],v:{rhythm:92,bass:96,melody:74,vocal:48,energy:78,atmosphere:86,structure:88,effects:78},groove:'laid-back log-drum-led piano-house pulse',bass:'syncopated log-drum phrase as a defining low-end voice',melody:'warm piano chords and spacious melodic fragments',form:'groove intro, vocal/chord section, log-drum lift, breakdown, return',fx:'spacious delays, soft transitions and low-end clarity'},
  traditional:{bpm:[65,125],v:{rhythm:62,bass:28,melody:96,vocal:96,energy:58,atmosphere:94,structure:76,effects:22},groove:'tradition-specific usul, meter or free-time phrasing; never impose a generic beat',bass:'natural acoustic low end; avoid modern sub unless deliberately hybrid',melody:'region- and tradition-specific modal/melodic language and authentic instruments',form:'traditional form, stanza/refrain or free-form development as appropriate',fx:'natural room, restrained ambience; preserve performance detail'},
  classical:{bpm:[55,140],v:{rhythm:45,bass:40,melody:100,vocal:78,energy:55,atmosphere:92,structure:96,effects:24},groove:'score-led meter, phrasing and ensemble pulse',bass:'orchestral low-register support and counterpoint',melody:'thematic development, harmony and voice-leading',form:'composition-specific movements and thematic development',fx:'natural hall depth and transparent ensemble imaging'},
  reggae:{bpm:[68,100],v:{rhythm:88,bass:96,melody:68,vocal:78,energy:68,atmosphere:84,structure:78,effects:72},groove:'one-drop or style-specific offbeat skank',bass:'deep melodic bassline as a central musical voice',melody:'offbeat guitar/keyboard skank and relaxed melodic hooks',form:'groove-led verse/chorus with instrumental pockets',fx:'spring-style ambience and dub delay used selectively'},
  latin:{bpm:[88,128],v:{rhythm:96,bass:78,melody:86,vocal:82,energy:84,atmosphere:78,structure:86,effects:58},groove:'style-specific clave, syncopation and percussion interplay',bass:'dance-oriented bass pattern aligned to the rhythmic cycle',melody:'genre-specific melodic phrasing and instrumental responses',form:'intro, verse, coro/hook, instrumental break, return',fx:'clean percussion placement and short spatial accents'},
  ambient:{bpm:[40,100],v:{rhythm:18,bass:52,melody:72,vocal:22,energy:25,atmosphere:100,structure:54,effects:100},groove:'free or minimal pulse; rhythm must remain subordinate',bass:'soft sustained low-frequency foundation',melody:'slow evolving textures, drones and sparse motifs',form:'gradual textural evolution without forced pop sections',fx:'long-form reverb, evolving delay and slow modulation'},
  pop:{bpm:[90,128],v:{rhythm:82,bass:76,melody:92,vocal:96,energy:76,atmosphere:72,structure:98,effects:68},groove:'clear contemporary pop pulse',bass:'supportive tight bass/kick relationship',melody:'memorable topline, chord progression and hook motif',form:'intro, verse, pre-chorus, chorus, verse, chorus, bridge, final chorus',fx:'polished vocal space, controlled transitions and width'},
  general:{bpm:[90,120],v:{rhythm:70,bass:65,melody:75,vocal:75,energy:65,atmosphere:70,structure:75,effects:55},groove:'profile-led pulse and phrasing',bass:'supportive low end matched to the selected style',melody:'profile-led melodic identity',form:'structure follows the selected Music DNA',fx:'effects chosen only where stylistically justified'}
 };
 function build(profile,energyIndex,overrides={}){
  const family=classify(profile),base=BASE[family]||BASE.general,values={...base.v};
  const identity=[...(profile?.tags||[]),...(profile?.musical_traits||[])].join(' ').toLowerCase();
  const has=(re)=>re.test(identity);
  if(has(/polyrhythm|syncopat|offbeat|breakbeat/))values.rhythm=clamp(values.rhythm+5);
  if(has(/deep bass|sub.?bass|808|log.?drum/))values.bass=clamp(values.bass+5);
  if(has(/ornament|modal|maqam|melodic|melody|instrumental motif/))values.melody=clamp(values.melody+4);
  if(has(/call.?and.?response|group vocal|choir|virtuos|ornamented vocal/))values.vocal=clamp(values.vocal+4);
  if(has(/hypnotic|spacious|drone|atmospheric/))values.atmosphere=clamp(values.atmosphere+5);
  if(has(/long transition|build|drop|evolving|dynamic arrangement/))values.structure=clamp(values.structure+4);
  const energyScale=[-.24,-.15,-.04,.06,.14,.22][Number(energyIndex)]??0;
  values.energy=clamp(values.energy+energyScale*100);
  if(family==='traditional'&&energyIndex>=4){values.rhythm=clamp(values.rhythm+8);values.energy=clamp(values.energy+4);}
  const user={};DIMENSIONS.forEach(k=>{if(Object.prototype.hasOwnProperty.call(overrides,k)){const n=toFiniteNumber(overrides[k]);if(n!==null)user[k]=clamp(n);}});
  Object.assign(values,user);
  const adjustments=[];
  // Cross-coupled balance: dependent dimensions are recalculated unless the user explicitly overrides them.
  const derive=(key,delta,reason)=>{if(!Object.prototype.hasOwnProperty.call(user,key)){values[key]=clamp(values[key]+delta);adjustments.push(reason);}};
  if(values.bass>88&&values.rhythm>80)derive('rhythm',-4,'Kick transient density is reduced slightly to leave room for the selected dominant bass.');
  if(values.energy>88&&values.atmosphere>78)derive('atmosphere',-5,'Atmospheric wash is tightened slightly as rhythmic energy rises.');
  if(values.melody>88&&values.vocal>85)derive('melody',-5,'Melodic foreground is slightly restrained to protect the lead vocal.');
  if(values.effects>88&&values.rhythm>85)derive('effects',-5,'Time-based effects are restrained around dense rhythmic transients.');
  if(values.atmosphere>85&&values.effects>80){adjustments.push('Long ambience is kept out of transient-heavy rhythmic elements.');}
  if(values.melody>88&&values.vocal>85){adjustments.push('Melodic hook and lead vocal are assigned alternating foreground moments.');}
  if(family==='traditional'&&values.effects>45&&!user.effects){adjustments.push('Traditional acoustic detail takes priority; effects remain restrained.');}
  if(family==='techno'||family==='house'||family==='garage'||family==='dnb'){
   if(values.structure>80)adjustments.push('Energy curve is shaped through builds, breakdowns and returns rather than arbitrary verse/chorus resets.');
  }
  return {profileId:profile?.id||null,profileName:profile?.name||'Selected Music DNA',identityTraits:profile?.musical_traits||[],moodAtmosphere:profile?.mood_atmosphere||[],family,familyLabel:family.toUpperCase(),dimensions:values,labels:LABELS,bpmRange:base.bpm,groove:base.groove,bassDesign:base.bass,melodicDesign:base.melody,form:base.form,effectsDesign:base.fx,adjustments,userOverrides:Object.keys(user),isUserCustomized:Object.keys(user).length>0};
 }
 root.SongDnaProductionPresetEngine={build,classify,dimensions:DIMENSIONS,labels:LABELS,profileFamilyOverrides:{...PROFILE_FAMILY_OVERRIDES}};
})(typeof window!=='undefined'?window:globalThis);
