/* SONGDNA Global Cultural Vocal Intelligence — Genre map & matching core v1
 * Stable genre IDs are additive metadata; original MDNA IDs/slugs remain untouched.
 * This stage maps all 66 profiles. Phrase catalogs gain per-phrase genre affinities in later catalog stages.
 */
(function(root){
 'use strict';
 const F={
  afro:['afro_dance','afro_house'],
  trap:['rap_hiphop','trap'],
  melodicTrap:['rap_hiphop','trap','melodic_rap'],
  emotionalTrap:['rap_hiphop','trap','emotional_rap'],
  rap:['rap_hiphop'], melodicRap:['rap_hiphop','melodic_rap'], boomBap:['rap_hiphop','boom_bap'], darkRap:['rap_hiphop'],
  pop:['pop'], emotionalPop:['pop','ballad'], popRap:['pop','rap_hiphop'],
  bollywood:['south_asian_fusion','pop'], desi:['south_asian_fusion'], indianClassical:['traditional_folk','indian_classical'],
  amapiano:['afro_dance','amapiano'], reggae:['reggae_dancehall'], drill:['rap_hiphop','drill'],
  turkishFolk:['traditional_folk','turkish_traditional','regional_folk'],
  flamenco:['traditional_folk','flamenco'], balkan:['traditional_folk','regional_folk'],
  hindustani:['traditional_folk','indian_classical'], carnatic:['traditional_folk','indian_classical'],
  makam:['traditional_folk','turkish_traditional'], turkishArtMusic:['turkish_classical_art_music'], zeybek:['traditional_folk','regional_folk','turkish_traditional'],
  arabicRhythm:['traditional_folk','arabic_pop'], callResponse:['traditional_folk','call_response'],
  rnb:['rnb_soul'], electronicPop:['pop','electronic_dance'], alternative:['rock_alternative'], arabesk:['arabesk_fantezi','ballad'], rock:['rock_alternative'], dancePop:['pop','electronic_dance'],
  gamelan:['traditional_folk','indonesian_traditional'], gnawa:['traditional_folk','north_african_traditional'], pansori:['traditional_folk','korean_traditional'],
  longSong:['traditional_folk','mongolian_traditional'], polyphony:['traditional_folk','polyphonic_vocal'], samba:['traditional_folk','latin_folk'], maloya:['traditional_folk','island_folk'],
  bowedFolk:['traditional_folk','mongolian_traditional'], albanianPoly:['traditional_folk','polyphonic_vocal'], mugham:['traditional_folk','azerbaijani_traditional'],
  cubanSon:['traditional_folk','latin_folk'], baul:['traditional_folk','south_asian_folk'], sardinian:['traditional_folk','polyphonic_vocal'], ahellil:['traditional_folk','north_african_traditional'],
  techno:['electronic_dance'], garage:['electronic_dance','uk_garage'], highlife:['afro_dance','african_pop'], soukous:['afro_dance','african_pop'], mbalax:['afro_dance','african_pop'], rai:['arabesk_fantezi','north_african_pop'], bomba:['traditional_folk','latin_folk'], plena:['traditional_folk','latin_folk'], jarocho:['traditional_folk','latin_folk'], jungle:['electronic_dance','breakbeat'], dnb:['electronic_dance','breakbeat']
 };
 const rows=[
 ['MDNA-001','organic-afro','Organic Afro','afro'],['MDNA-002','syncopated-afro','Syncopated Afro','afro'],['MDNA-003','evolving-afro','Evolving Afro','afro'],['MDNA-004','african-dance','African Dance','afro'],['MDNA-005','vocal-afro','Vocal Afro','afro'],
 ['MDNA-006','melodic-trap','Melodic Trap','melodicTrap'],['MDNA-007','modern-trap','Modern Trap','trap'],['MDNA-008','dark-trap','Dark Trap','trap'],['MDNA-009','emotional-trap','Emotional Trap','emotionalTrap'],['MDNA-010','melodic-rap','Melodic Rap','melodicRap'],['MDNA-011','organic-rap','Organic Rap','boomBap'],['MDNA-012','dark-rap','Dark Rap','darkRap'],
 ['MDNA-013','turkish-pop','Turkish Pop','pop'],['MDNA-014','turkish-emotional-pop','Turkish Emotional Pop','emotionalPop'],['MDNA-015','turkish-pop-rap','Turkish Pop Rap','popRap'],['MDNA-016','bollywood-cinematic','Bollywood Cinematic','bollywood'],['MDNA-017','desi-rhythm','Desi Rhythm','desi'],['MDNA-018','indian-emotional','Indian Emotional','indianClassical'],
 ['MDNA-019','afro-house-organic-percussion','Afro House – Organic Percussion','afro'],['MDNA-020','amapiano-log-drum-groove','Amapiano – Log Drum Groove','amapiano'],['MDNA-021','jamaican-dancehall-reggae-groove','Jamaican Dancehall / Reggae Groove','reggae'],['MDNA-022','uk-drill-sliding-808','UK Drill – Sliding 808','drill'],['MDNA-023','flamenco-comp-s-guitar','Flamenco – Compás & Guitar','flamenco'],['MDNA-024','balkan-brass-dance','Balkan Brass & Dance','balkan'],['MDNA-025','hindustani-vocal-alaap-taan','Hindustani Vocal – Alaap & Taan','hindustani'],['MDNA-026','carnatic-tala-mridangam','Carnatic – Tala & Mridangam','carnatic'],['MDNA-027','turkish-makam-vocal-ornamentation','Turkish Makam – Vocal Ornamentation','makam'],['MDNA-028','aegean-zeybek-regional-folk-character','Aegean Zeybek – Regional Folk Character','zeybek'],['MDNA-029','arabic-percussion-maqsum-baladi','Arabic Percussion – Maqsum / Baladi','arabicRhythm'],['MDNA-030','african-call-and-response-vocal-layer','African Call-and-Response Vocal Layer','callResponse'],
 ['MDNA-031','turkish-rap','Turkish Rap','rap'],['MDNA-032','turkish-drill','Turkish Drill','drill'],['MDNA-033','turkish-r-b','Turkish R&B','rnb'],['MDNA-034','turkish-afro-house','Turkish Afro House','afro'],['MDNA-035','turkish-electronic-pop','Turkish Electronic Pop','electronicPop'],['MDNA-036','turkish-alternative-indie','Turkish Alternative / Indie','alternative'],['MDNA-037','modern-arabesk','Modern Arabesk','arabesk'],['MDNA-038','anatolian-rock','Anatolian Rock','rock'],['MDNA-039','turkish-dance-pop','Turkish Dance Pop','dancePop'],['MDNA-040','turkish-pop','Turkish Pop','pop'],
 ['MDNA-041','indonesian-gamelan','Indonesian Gamelan','gamelan'],['MDNA-042','moroccan-gnawa','Moroccan Gnawa','gnawa'],['MDNA-043','korean-pansori','Korean Pansori','pansori'],['MDNA-044','mongolian-urtiin-duu','Mongolian Urtiin Duu','longSong'],['MDNA-045','georgian-polyphonic-singing','Georgian Polyphonic Singing','polyphony'],['MDNA-046','bahian-samba-de-roda','Bahian Samba de Roda','samba'],['MDNA-047','reunion-maloya','Réunion Maloya','maloya'],['MDNA-048','mongolian-morin-khuur','Mongolian Morin Khuur','bowedFolk'],['MDNA-049','albanian-iso-polyphony','Albanian Folk Iso-Polyphony','albanianPoly'],['MDNA-050','azerbaijani-mugham','Azerbaijani Mugham','mugham'],['MDNA-051','cuban-son','Cuban Son','cubanSon'],['MDNA-052','baul-songs','Baul Songs','baul'],['MDNA-053','sardinian-canto-a-tenore','Sardinian Canto a Tenore','sardinian'],['MDNA-054','ahellil-of-gourara','Ahellil of Gourara','ahellil'],['MDNA-055','detroit-techno','Detroit Techno','techno'],['MDNA-056','uk-garage','UK Garage','garage'],['MDNA-057','ghanaian-highlife','Ghanaian Highlife','highlife'],['MDNA-058','congolese-soukous','Congolese Soukous','soukous'],['MDNA-059','senegalese-mbalax','Senegalese Mbalax','mbalax'],['MDNA-060','south-african-amapiano','South African Amapiano','amapiano'],['MDNA-061','algerian-rai','Algerian Raï','rai'],['MDNA-062','puerto-rican-bomba','Puerto Rican Bomba','bomba'],['MDNA-063','puerto-rican-plena','Puerto Rican Plena','plena'],['MDNA-064','veracruz-son-jarocho','Veracruz Son Jarocho','jarocho'],['MDNA-065','uk-jungle','UK Jungle','jungle'],['MDNA-066','uk-drum-and-bass','UK Drum & Bass','dnb'],['MDNA-067','turkish-folk-music','Turkish Folk Music','turkishFolk'],['MDNA-068','turkish-classical-art-music','Turkish Classical Art Music','turkishArtMusic']
 ];
 const profileMap={}; rows.forEach(([id,slug,name,family])=>{profileMap[id]={musicDnaId:id,slug,name,genreIds:F[family],primaryGenreId:F[family][0],subgenreId:F[family][1]||null};});
 const phraseAffinities={
  'tr-he':['rap_hiphop','trap','drill','boom_bap'],'tr-ey':['rap_hiphop','trap','drill','boom_bap'],'tr-yuh':['rap_hiphop','drill'],'tr-word':['rap_hiphop','trap','drill','boom_bap'],
  'tr-ah':['melodic_rap','emotional_rap','ballad','arabesk_fantezi','rnb_soul','traditional_folk'],'tr-of':['melodic_rap','emotional_rap','ballad','arabesk_fantezi'],
  'tr-hay':['pop','electronic_dance','afro_dance'],'tr-hey':['pop','electronic_dance','afro_dance','rap_hiphop']
 };
 const getProfile=(context)=>{
  const candidates=[context?.musicDnaId,context?.globalProfile?.id,((String(context?.dna||'').match(/MDNA-\d{3}/)||[])[0])];
  const id=candidates.find(value=>value&&profileMap[value]);
  if(id)return profileMap[id];
  const name=String(context?.dna||'').toLowerCase();
  return rows.map(r=>profileMap[r[0]]).find(p=>p.name.toLowerCase()===name||p.slug===name.replace(/\s+/g,'-'))||null;
 };
 const resolveAdlibMatchPlan=(context={})=>{
  const profile=getProfile(context);
  const explicit=context.genreId?String(context.genreId):null;
  const genreIds=explicit?[explicit,...(profile?.genreIds||[])]:[...(profile?.genreIds||[])];
  return {musicDnaId:profile?.musicDnaId||null,musicDnaName:profile?.name||context.dna||'unknown',genreIds:[...new Set(genreIds)],primaryGenreId:explicit||profile?.primaryGenreId||null,subgenreId:profile?.subgenreId||null,specificGenreId:profile?.genreIds?.[profile.genreIds.length-1]||null,isTraditional:!!profile?.genreIds?.some(id=>['traditional_folk','turkish_classical_art_music'].includes(id)),languageId:context.languageId||null,adlibScene:context.adlibScene||'none',sourceCultures:Array.isArray(context.adlibCultureSources)?context.adlibCultureSources.slice():[],status:profile?'mapped':'unmapped',catalogPolicy:'language-culture-first; exclude mismatched classified phrases; traditional profiles require verified genre affinity'};
 };
 const filterItems=(items,plan)=>{
  const list=Array.isArray(items)?items:[];const wanted=new Set(plan?.genreIds||[]);if(!wanted.size)return {items:list,matched:false,unclassified:list.length};
  const annotated=list.map(item=>({item,ids:item.genreIds||phraseAffinities[item.id]||null}));
  const classified=annotated.filter(x=>Array.isArray(x.ids));
  if(!classified.length){
   if(plan?.isTraditional)return {items:[],matched:false,matchLevel:'traditional-no-verified-affinity',unclassified:list.length};
   return {items:list,matched:false,matchLevel:'unclassified-catalog',unclassified:list.length};
  }
  const exact=plan?.specificGenreId?classified.filter(x=>x.ids.includes(plan.specificGenreId)):[];
  const matches=exact.length?exact:classified.filter(x=>x.ids.some(id=>wanted.has(id)));
  if(matches.length)return {items:matches.map(x=>x.item),matched:true,matchLevel:exact.length?'specific-subgenre':'genre-family',unclassified:annotated.length-classified.length};
  const safeUnclassified=annotated.filter(x=>!Array.isArray(x.ids)).map(x=>x.item);
  if(plan?.isTraditional)return {items:[],matched:false,matchLevel:'traditional-no-verified-affinity',unclassified:safeUnclassified.length};
  return {items:safeUnclassified,matched:false,matchLevel:safeUnclassified.length?'unclassified-only-fallback':'no-compatible-phrases',unclassified:safeUnclassified.length};
 };
 root.SongDnaGenreAdlibEngine={version:'1.0',profileMap,genreFamilies:Object.keys(F),resolveAdlibMatchPlan,filterItems,phraseAffinities};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaGenreAdlibEngine;
})(typeof globalThis!=='undefined'?globalThis:this);
