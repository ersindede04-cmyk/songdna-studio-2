'use strict';

const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const net = require('node:net');
const path = require('node:path');

async function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.once('error', reject);
    s.listen(0, '127.0.0.1', () => {
      const port = s.address().port;
      s.close(() => resolve(port));
    });
  });
}

async function waitForHealth(base, child) {
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error('Server exited early: ' + child.exitCode);
    try {
      const response = await fetch(base + '/health');
      if (response.ok) return response.json();
    } catch (_) {}
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error('Server health check timed out');
}

(async () => {
  const port = await freePort();
  const root = path.resolve(__dirname, '..');
  const child = spawn(process.execPath, [
    '--require', path.join(__dirname, 'mock-gemini-fetch.cjs'),
    path.join(root, 'server.js')
  ], {
    cwd: root,
    env: {
      ...process.env,
      PORT: String(port),
      APP_ACCESS_TOKEN: 'stage29-test-token-12345',
      GEMINI_API_KEY: 'test-only-key',
      GEMINI_MODELS: 'gemini-3.1-flash-lite,gemini-3.6-flash,gemini-3.8-flash',
      GEMINI_MODEL: 'gemini-3.1-flash-lite',
      TRUST_PROXY: 'true'
    },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let logs = '';
  child.stdout.on('data', x => { logs += x.toString(); });
  child.stderr.on('data', x => { logs += x.toString(); });
  const base = `http://127.0.0.1:${port}`;
  const headers = { 'Content-Type': 'application/json', 'X-App-Token': 'stage29-test-token-12345' };
  const post = (route, body, extraHeaders = {}) => fetch(base + route, {
    method: 'POST', headers: { ...headers, ...extraHeaders }, body
  });

  try {
    const health = await waitForHealth(base, child);
    assert.equal(health.ok, true);
    assert.match(health.service, /7\.6\.4/);
    assert.deepEqual(health.models, ['gemini-3.1-flash-lite', 'gemini-3.6-flash', 'gemini-3.8-flash']);
    console.log('PASS health and Flash allowlist');

    const preflight = await fetch(base + '/api/command', { method: 'OPTIONS' });
    assert.equal(preflight.status, 204);
    console.log('PASS CORS preflight');

    const unauthorized = await fetch(base + '/api/lyrics', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: 'test' })
    });
    assert.equal(unauthorized.status, 401);
    console.log('PASS token authentication');

    const lyrics = await post('/api/lyrics', JSON.stringify({ prompt: 'Generate test lyrics', model: 'gemini-3.1-flash-lite' }));
    const lyricsBody = await lyrics.json();
    assert.equal(lyrics.status, 200);
    assert.match(lyricsBody.lyrics, /TITLE: Test Song/);
    assert.equal(lyricsBody.usage.totalTokens, 30);
    console.log('PASS lyrics response and usage metadata');

    const style = await post('/api/style', JSON.stringify({ prompt: 'Generate test style', model: 'gemini-3.1-flash-lite' }));
    const styleBody = await style.json();
    assert.equal(style.status, 200);
    assert.match(styleBody.style, /melodic trap/i);
    console.log('PASS style response');

    const command = await post('/api/command', JSON.stringify({ prompt: 'Interpret test request', model: 'gemini-3.1-flash-lite' }));
    const commandBody = await command.json();
    assert.equal(command.status, 200);
    const parsed = JSON.parse(commandBody.command);
    assert.deepEqual(parsed, {
      language: 'English',
      genre: '2',
      fusion: 'Anatolian trap',
      energy: 'High',
      leadVoice: 'Male',
      backingVoice: 'Choir',
      adlib: 'Melodic',
      vocalEffect: 'Reverb',
      technique: 'TECH-TR-001',
      bpm: 128,
      theme: 'Night drive',
      notes: 'Keep the hook melodic'
    });
    assert.equal(Object.hasOwn(parsed, 'rogue'), false);
    console.log('PASS command JSON normalization and unknown-key filtering');

    const boundedCommand = await post('/api/command', JSON.stringify({ prompt: 'INVALID_BPM_TEST' }));
    const boundedBody = await boundedCommand.json();
    const bounded = JSON.parse(boundedBody.command);
    assert.equal(boundedCommand.status, 200);
    assert.equal(Object.hasOwn(bounded, 'bpm'), false);
    assert.equal(bounded.theme.length, 240);
    assert.equal(bounded.notes.length, 1200);
    console.log('PASS BPM range and theme/notes length limits');

    const malformedCommand = await post('/api/command', JSON.stringify({ prompt: 'INVALID_JSON_TEST' }));
    const malformedBody = await malformedCommand.json();
    assert.equal(malformedCommand.status, 502);
    assert.equal(typeof malformedBody.error, 'string');
    assert.equal(Object.hasOwn(malformedBody, 'command'), false);
    console.log('PASS malformed command response rejected');

    const invalidBody = await post('/api/lyrics', '{not-json');
    assert.equal(invalidBody.status, 400);
    console.log('PASS malformed request body rejected');

    const overPromptLimit = await post('/api/lyrics', JSON.stringify({ prompt: 'x'.repeat(150001) }));
    assert.equal(overPromptLimit.status, 400);
    console.log('PASS 150,000-character prompt limit');

    const oversized = await post('/api/lyrics', JSON.stringify({ prompt: 'x'.repeat(1010000) }));
    assert.equal(oversized.status, 413);
    console.log('PASS 1,000,000-character request body limit');

    const fallback = await post('/api/style', JSON.stringify({ prompt: 'FALLBACK_TEST', model: 'gemini-3.1-flash-lite' }));
    const fallbackBody = await fallback.json();
    assert.equal(fallback.status, 200);
    assert.equal(fallbackBody.model, 'gemini-3.6-flash');
    assert.equal(fallbackBody.fallbackUsed, true);
    console.log('PASS Flash model fallback after temporary 503');

    let rateLimited = false;
    for (let i = 0; i < 5; i++) {
      const response = await post('/api/style', JSON.stringify({ prompt: 'rate limit probe' }));
      if (response.status === 429) { rateLimited = true; break; }
      assert.equal(response.status, 200);
    }
    assert.equal(rateLimited, true);
    console.log('PASS per-IP request rate limit');

    const authProbeHeaders = { 'Content-Type': 'application/json', 'X-App-Token': 'wrong-token', 'X-Forwarded-For': '203.0.113.77' };
    for (let i = 0; i < 10; i++) {
      const response = await fetch(base + '/api/lyrics', { method: 'POST', headers: authProbeHeaders, body: JSON.stringify({ prompt: 'blocked' }) });
      assert.equal(response.status, 401);
    }
    const validAfterFailures = await fetch(base + '/api/lyrics', {
      method: 'POST',
      headers: { ...headers, 'X-Forwarded-For': '203.0.113.77' },
      body: JSON.stringify({ prompt: 'Generate test lyrics after invalid token attempts', model: 'gemini-3.1-flash-lite' })
    });
    assert.equal(validAfterFailures.status, 200, 'a valid token must work immediately after invalid attempts');
    console.log('PASS invalid tokens return 401 without imposing a five-minute IP lock; valid token recovers immediately');

    console.log('STAGE 29 API CONTRACT TESTS PASSED (12 groups)');
  } catch (error) {
    console.error('STAGE 29 API CONTRACT TESTS FAILED:', error.stack || error);
    if (logs) console.error('SERVER LOGS:\n' + logs);
    process.exitCode = 1;
  } finally {
    child.kill('SIGTERM');
  }
})();
