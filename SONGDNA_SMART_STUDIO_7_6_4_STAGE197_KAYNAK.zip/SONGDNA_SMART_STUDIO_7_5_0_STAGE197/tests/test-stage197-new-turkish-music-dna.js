'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const catalog=JSON.parse(fs.readFileSync(path.join(root,'data/music_dna_global_v1_1.json'),'utf8'));
const profiles=catalog.music_dna_profiles;
const byId=id=>profiles.find(p=>p.id===id);
assert.equal(profiles.length,78,'the existing 75 profiles must remain and three profiles must be appended');
assert.equal(new Set(profiles.map(p=>p.id)).size,78,'profile IDs must remain unique');
for(const [id,domain,name] of [['MDNA-076','traditional','Traditional Arabesk'],['MDNA-077','traditional','Turkish Fantazi Music'],['MDNA-078','modern','Arabesk Rap']]){
 const p=byId(id);assert.ok(p,`${id} must exist`);assert.equal(p.music_domain,domain);assert.equal(p.name,name);
 for(const key of ['slug','primary_genre','musical_traits','arrangement_guidance','prompt_guidance','instrument_guidance','lyrics_guidance','vocal_guidance','form_guidance','quality_standard'])assert.ok(p[key],`${id} must define ${key}`);
}
assert.equal(byId('MDNA-037').name,'Modern Arabesk','existing Modern Arabesk profile must not be overwritten');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
for(const id of ['MDNA-076','MDNA-077','MDNA-078'])assert.ok(app.includes(id),`${id} must be present in the selectable Music DNA array`);
assert.match(app,/"MDNA-076","MDNA-077"/,'traditional domain allowlist must include Arabesk and Fantazi');
assert.doesNotMatch(app,/"MDNA-078"\]/,'Arabesk Rap must not be misclassified as traditional');
console.log('PASS Stage197: Traditional Arabesk, Turkish Fantazi and Arabesk Rap appended as selectable, correctly domain-classified Music DNA profiles.');
