'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const storage=new Map();
const sandbox={localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,String(v))}};
sandbox.globalThis=sandbox;
vm.runInNewContext(fs.readFileSync(path.join(root,'story-diversity-engine.js'),'utf8'),sandbox);
const engine=sandbox.SongDnaStoryDiversityEngine;
assert.equal(engine.themeFamilies.length,12,'the random pool should span distinct semantic theme families');
const songs=[];
for(let i=1;i<=60;i++){
 const seed=engine.generate();
 songs.push(seed);
 assert.ok(seed.storyBrief&&seed.topic&&seed.signature&&seed.themeFamily);
 if(i%5===0){
  assert.equal(seed.themeType,'love');
  assert.equal(seed.themeFamily,'love');
  assert.match(seed.theme,/^Aşk ve bağlılık/);
 }else{
  assert.equal(seed.themeType,'varied');
  assert.notEqual(seed.themeFamily,'love');
 }
 engine.remember(seed.topic,'test lyrics '+i,seed);
}
for(let start=0;start<songs.length;start+=5){
 const block=songs.slice(start,start+5);
 assert.equal(new Set(block.slice(0,4).map(x=>x.themeFamily)).size,4,`the first four themes in cycle ${start/5+1} must use four different semantic families`);
 assert.equal(block[4].themeFamily,'love',`the fifth theme in cycle ${start/5+1} must be love`);
 assert.equal(new Set(block.slice(0,4).map(x=>x.theme)).size,4,'the first four theme labels must differ');
}
assert.equal(engine.readCycleCount(),60,'only successful remembered generations advance the cycle');
console.log('PASS Stage197: four random but semantically distinct non-love theme families, fifth-song love, and successful-only cycle across 12 full cycles.');
