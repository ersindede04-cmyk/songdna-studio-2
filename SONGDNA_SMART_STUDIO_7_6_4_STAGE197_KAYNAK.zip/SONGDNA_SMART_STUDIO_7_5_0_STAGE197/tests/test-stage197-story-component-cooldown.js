'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const store=new Map();
const sandbox={localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,String(v))}};
sandbox.globalThis=sandbox;
vm.runInNewContext(fs.readFileSync(require.resolve('../story-diversity-engine.js'),'utf8'),sandbox);
const engine=sandbox.SongDnaStoryDiversityEngine;
assert.equal(engine.componentCooldown,12,'story components should have a twelve-success cooldown');
const generated=[];
for(let i=0;i<15;i++){
 const seed=engine.generate();
 generated.push(seed);
 engine.remember(seed.topic,'lyrics '+i,seed);
}
for(let i=12;i<generated.length;i++){
 const recent=generated.slice(i-12,i);
 for(const key of ['role','place','trigger','conflict','turn','ending']){
  assert(!recent.some(item=>item[key]===generated[i][key]),`${key} repeated within the last twelve successful stories`);
 }
}
for(let i=0;i<15;i++)assert.equal(generated[i].isLove,i%5===4,'love theme must remain every fifth successful generation');
assert.equal(engine.read().length,15);
console.log('PASS Stage197: individual story components rotate across twelve successful productions; fifth-song love rotation and successful-only memory remain intact.');
