const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');const app=fs.readFileSync(path.join(root,'app.js'),'utf8');const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
assert(html.includes('#storyAdvanced,#templatePanel'),'manual story/topic form is removed from the visible UI');
assert(app.includes('activeAutoStorySeed=engine.generate()'),'automatic story engine creates each seed');
assert(app.includes("currentContext.theme=activeAutoTopic"),'generated topic enters the production context');
assert(app.includes("currentContext.autoStorySeed=activeAutoStorySeed"),'complete story seed enters the prompt context');
assert(app.includes("currentContext.storyDiversityGuidance=automaticStoryMode?"),'long-cycle memory guides automatic generation');
assert(app.includes("const topicMode=v('topicMode')==='template'?'template':'auto'"),'existing dropdown-only manual topic selection remains available alongside automatic mode');
console.log('Stage 81 auto-only expandable story generation: PASS');
