'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
global.window = global;
require(path.join(root, 'www/integrated-production-engine.js'));
const engine = global.SongDnaIntegratedProductionEngine;
assert.ok(engine, 'integrated production engine loads');
const preset = {
  profileId: 'MDNA-TEST', family: 'traditional',
  dimensions: { rhythm: 70, bass: 40, melody: 92, vocal: 90, energy: 60, atmosphere: 70, structure: 80, effects: 30 },
  userOverrides: ['melody']
};
const sectionArrangement = { mode: 'adaptive', promptText: 'SECTION_TEST: preserve actual section roles.' };
const vocalIdentity = { lead: { mode: 'duet' }, promptText: 'VOCAL_TEST: preserve selected duet roles.' };
const result = engine.build({
  preset, dnaName: 'Test Traditional DNA', bpm: 92, bpmManual: true,
  identity: { musicDna: 'Test Traditional DNA', style: 'traditional', profileId: 'MDNA-TEST', globalProfile: 'Regional Test', technique: 'Test technique', identityTraits: ['modal phrasing', 'acoustic ensemble'] },
  sectionArrangement, vocalIdentity,
  manualOverrides: ['melody']
});
assert.equal(result.version, '1.1');
assert.equal(result.identity.profileId, 'MDNA-TEST');
assert.equal(result.identity.musicDna, 'Test Traditional DNA');
assert.deepEqual(result.identity.identityTraits, ['modal phrasing', 'acoustic ensemble']);
assert.equal(result.dimensions.melody, 92, 'manual melody dimension remains locked');
assert.equal(result.manualBpm, true);
assert.equal(result.bpm, 92);
assert.equal(result.sectionArrangementMode, 'adaptive');
assert.equal(result.vocalIdentityMode, 'duet');
assert.match(result.promptText, /Section arrangement mode: adaptive/);
assert.match(result.promptText, /Vocal identity mode: duet/);
assert.match(result.promptText, /Regional Test/);
assert.match(result.promptText, /traditional profiles/);
console.log('PASS Stage 61 shared identity: profile metadata, section arrangement, vocal identity, manual lock and BPM lock.');
