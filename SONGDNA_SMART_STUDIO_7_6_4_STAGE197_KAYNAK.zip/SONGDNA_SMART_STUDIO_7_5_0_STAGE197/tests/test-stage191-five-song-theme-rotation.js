'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const storage=new Map();
const sandbox={localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,String(v))}};
sandbox.globalThis=sandbox;
vm.runInNewContext(fs.readFileSync(path.join(root,'www/story-diversity-engine.js'),'utf8'),sandbox);
const engine=sandbox.SongDnaStoryDiversityEngine;
const love=[];
for(let n=1;n<=20;n++){
 const seed=engine.generate();
 assert.ok(seed.storyBrief&&seed.topic&&seed.signature);
 if(seed.isLove)love.push(n);
 if(n%5!==0)assert.ok(seed.themeFamily&&seed.themeFamily!=='love','first four slots must use a non-love semantic family');
 engine.remember(seed.topic,'Örnek şarkı sözleri',seed);
}
assert.deepEqual(love,[5,10,15,20],'love theme must occur on every fifth successful generation');
for(let start=0;start<20;start+=5)assert.equal(new Set(Array.from({length:4},(_,i)=>engine.read()[start+i]?.themeFamily)).size,4,'four non-love songs in each cycle must use different semantic theme families');
assert.equal(engine.read().length,20);
for(let n=21;n<=55;n++){const seed=engine.generate();if(n%5===0)assert.equal(seed.themeType,'love');else assert.equal(seed.themeType,'varied');engine.remember(seed.topic,'Örnek söz',seed);}
assert.equal(engine.read().length,40,'recent diversity memory remains capped at 40 while the independent rotation counter continues');
assert.equal(engine.readCycleCount(),55,'five-song rotation counter must continue beyond the 40-item anti-repeat memory');
const html=fs.readFileSync(path.join(root,'www/index.html'),'utf8');
assert.match(html,/id="lyricsRhythmPanel"/);
assert.match(html,/id="lyricsRhythmSummary"/);
const app=fs.readFileSync(path.join(root,'www/app.js'),'utf8');
assert.match(app,/function renderLyricsRhythm\(\)/);
assert.match(app,/HUMAN LYRIC LANGUAGE/);
assert.match(app,/technical, architectural, industrial, workplace/);
console.log('PASS Stage191: love every fifth successful song, varied themes, human lyric language and Lyrics rhythm panel');
