'use strict';
const fs=require('fs'); const path=require('path'); const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'); const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const match=app.match(/const GLOBAL_MUSIC_DNA=(\{.*?\});/); assert(match,'catalog missing');
const catalog=JSON.parse(match[1]); const engine=require(path.join(root,'three-layer-production-orchestrator.js'));
assert.equal(catalog.music_dna_profiles.length,78); const txt=v=>Array.isArray(v)?v.filter(Boolean).join(' '):String(v||'');
let pg=0,ig=0,lg=0;
for(const p of catalog.music_dna_profiles){
 const result=engine.build({main:{id:p.id,name:p.name,family:p.primary_genre,promptText:[p.prompt_guidance,p.arrangement_guidance,p.instrument_guidance].map(txt).filter(Boolean).join(' '),elements:[...(p.musical_traits||[]),...(p.tags||[])],musicalTraits:p.musical_traits||[],arrangementGuidance:p.arrangement_guidance},identity:{profileId:p.id,name:p.name,primaryGenre:p.primary_genre,domain:p.music_domain||'unclassified',region:p.region_or_scene,language:'Turkish',definingTraits:p.musical_traits||[],profileGuidance:txt(p.prompt_guidance),productionGuidance:txt(p.instrument_guidance),vocalGuidance:txt(p.lyrics_guidance),arrangementGuidance:p.arrangement_guidance}});
 assert.equal(result.musicIdentityProfile.profileId,p.id); assert(result.sharedPrompt.includes(p.name)); assert.equal(result.stylesContext,result.lyricsContext);
 if(p.prompt_guidance){pg++;assert(result.sharedPrompt.includes(txt(p.prompt_guidance).slice(0,24)),p.id+' profile guidance');}
 if(p.instrument_guidance){ig++;assert(result.sharedPrompt.includes(txt(p.instrument_guidance).slice(0,24)),p.id+' instrument guidance');}
 if(p.lyrics_guidance){lg++;assert(result.sharedPrompt.includes(txt(p.lyrics_guidance).slice(0,24)),p.id+' lyric guidance');}
}
assert(/profileGuidance:guidanceText\(mainProfile\?\.prompt_guidance\)/.test(app));
assert(/promptText:\[mainProfile\?\.prompt_guidance,mainProfile\?\.arrangement_guidance,mainProfile\?\.instrument_guidance/.test(app));
for(const rel of ['www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'])assert.equal(fs.readFileSync(path.join(root,rel),'utf8'),app,rel);
console.log(`Stage 113 primary profile guidance: PASS (69/69; prompt=${pg}, instruments=${ig}, lyrics=${lg})`);
