const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..'),app=fs.readFileSync(path.join(root,'app.js'),'utf8'),html=fs.readFileSync(path.join(root,'index.html'),'utf8');
assert(html.includes('#storyAdvanced,#templatePanel'),'story/topic controls are no longer exposed to the user');
assert(app.includes('currentContext.songTheme=activeAutoStorySeed?.theme'),'theme comes from generated story seed');
assert(app.includes('currentContext.autoStorySeed=activeAutoStorySeed'),'story seed is passed as a structured object');
assert(app.includes('EXPANDABLE STORY LIBRARY SEED'),'lyrics prompt uses the structured story library seed');
assert(app.includes('commitSongThemeCycle()'),'legacy theme rotation remains backward compatible');
assert(html.includes('id="lyricsModeTab"'),'direct Lyrics tab exists');
console.log('Stage 82 automatic theme/topic and Lyrics tab: PASS');
