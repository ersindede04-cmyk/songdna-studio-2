# SONGDNA SMART STUDIO 7.6.3 — Stage197 QA raporu

## Kaynak ve çalışma düzeni

- Başlangıç kaynağı: `SONGDNA_SMART_STUDIO_7_6_2_STAGE197_KAYNAK.zip`
- Orijinal ZIP değiştirilmedi.
- 7.6.3 çalışması ayrı bir klasörde yürütüldü.
- Render'ın kullandığı iç klasör yolu `SONGDNA_SMART_STUDIO_7_5_0_STAGE197` ve arşiv adı `SONGDNA_SMART_STUDIO_7_5_0_STAGE197_KAYNAK.zip` olarak korunacak. Bu eski ad, mevcut Render komutlarıyla uyumluluk içindir; uygulama sürümü 7.6.3'tür.
- Stage numarası **197** olarak kaldı; Stage198 tabanı kullanılmadı.

## Test sonuçları

| Kontrol | Sonuç |
|---|---:|
| Kaynak bütünlüğü / root-www-Android eşleşmesi | PASS |
| JavaScript regresyon dosyaları | **145/145 PASS** |
| Python / tarayıcı regresyon dosyaları | **8/8 PASS** |
| Python CI ön kontrolü | PASS |
| Backend JavaScript sözdizimi | PASS |
| `npm --prefix backend run check` | PASS |
| GitHub Actions YAML ayrıştırması | PASS |
| Music DNA profilleri ve kaynak referansları | 75 profil doğrulandı |
| Stage197 ZIP dağıtım sözleşmesi | PASS |
| Aynı Melodik Trap enerjisiyle art arda üretim | 2/2 PASS |

### Yerel backend denemesi

Node.js 22 üzerinde yerel sunucu başlatıldı:

- `/health`: HTTP 200; `apiVersion: 7.6.3`, `stage: 197`.
- Uygulama erişim kodu olmadan `/api/lyrics`: HTTP 401.
- Doğru uygulama erişim kodu fakat Gemini anahtarı olmadan `/api/lyrics`: HTTP 503 ve `MAIN_GEMINI_KEY_MISSING`.

Ayrıca Chromium testi, Melodic Trap + “Melodik ve duygusal” enerji seçimiyle iki ardışık üretimin başarılı tamamlandığını, 2 Lyrics ve 2 Styles çağrısı yapıldığını ve tarayıcı hatası oluşmadığını doğruladı. Bu testler, sağlık/yetkilendirme ve aynı enerji tekrarı davranışını doğrular; canlı Gemini üretim testi değildir.

### İstem boyutu

Aynı varsayılan seçimler için Chromium yakalaması:

- LYRICS: 98.418 → 71.773 karakter (yaklaşık %27,1 azalma).
- STYLES: 71.924 → 41.570 karakter (yaklaşık %42,2 azalma).

Otomatik hikâye seed’i metin uzunluğunu küçük ölçüde değiştirdiği için tekrar ölçümlerde küçük farklar oluşabilir. Karakter sayısı ölçülmüştür. Canlı Gemini token sayısı/`usageMetadata` henüz ölçülmemiştir. Kaynakta istemci tarafındaki 150.000 ms kesme süresi her API isteği içindir; backend toplam üretim bütçesi 78.000 ms, model başına sınır 24.000 ms’dir. Lyrics ve Styles ayrı isteklerdir. Bu nedenle süre ayarını artırmadım; canlı `usageMetadata` olmadan daha önce bildirilen yaklaşık 112 bin token değeri doğrulanamaz.

## Render ve Android durumu

- Render Build Command, Start Command, ZIP adı, ZIP iç klasör yolu, `NODE_VERSION=22.16.0`, `/health` yolu ve mevcut ortam değişkenleri korunmuştur.
- Canlı Render dağıtımı bu çalışma ortamından yapılmadı ve doğrulanmadı.
- Canlı Gemini anahtarı bu çalışma ortamında bulunmadığından gerçek model çağrısı yapılmadı.
- Android `versionName=7.6.3`, `versionCode=48` olarak güncellendi.
- Bu çalışma ortamında Gradle/Android SDK kurulu olmadığı için APK yerel olarak üretilemedi. `.github/workflows/build.yml` GitHub Actions üzerinde Gradle 8.9 ve Android SDK 35 ile APK üretir; çıktı adı `SONGDNA_SMART_STUDIO_7_6_3_STAGE197_DEBUG.apk` olarak düzeltildi. GitHub Actions çalıştırması ve fiziksel Android cihaz kurulumu henüz doğrulanmadı.
- Nihai kaynak ZIP'i ve APK, kullanıcı onayı alınmadan oluşturulmayacak.

## Paketleme durumu

Kullanıcı onayı alındıktan sonra 7.6.3 kaynak ZIP paketi oluşturulabilir. APK üretimi için GitHub Actions iş akışı hazırdır; bu yerel ortamda Gradle/Android SDK bulunmadığından APK henüz üretilememiştir. Canlı Render ve fiziksel cihaz doğrulaması, kullanıcının kendi Render/GitHub ortamında ayrıca yapılmalıdır.
