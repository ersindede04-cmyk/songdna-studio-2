// Extracted verbatim from the user-supplied SONGDNA Smart Studio 6.2.0 APK assets/app.js.
// Reference contract only; the APK binary and secrets are not included.
async function postGemini(path,prompt){
 if(typeof prompt!=='string'||!prompt.trim())throw new Error('Üretim istemi boş oluşturuldu. Seçimlerini kontrol edip yeniden dene.');
 if(prompt.length>150000)throw new Error('Üretim istemi '+prompt.length.toLocaleString('tr-TR')+' karakter oldu; uygulama sınırı 150.000. Seçimleri veya istem içeriğini sadeleştir.');
 const base=v('apiBase').trim().replace(/\/+$/,'');
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),150000);
 try{
  const res=await fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json','X-App-Token':v('appToken')},body:JSON.stringify({model:v('aiModel'),prompt}),signal:controller.signal});
  let data;try{data=await res.json()}catch(_){throw new Error('Sunucu geçerli yanıt vermedi ('+res.status+').')}
  if(!res.ok)throw new Error(data.error||'İstek başarısız ('+res.status+').');
  recordGeminiUsage(data);
  return data;
 }catch(e){if(e.name==='AbortError')throw new Error('İstek 150 saniyede tamamlanmadı. Sunucu yeni uyanmış veya yoğun olabilir. Biraz bekleyip yeniden deneyebilirsin.');if(!navigator.onLine)throw new Error('İnternet bağlantısı görünmüyor. Bağlantını kontrol edip yeniden dene.');throw new Error(e.message||'Sunucuya ulaşılamadı. HTTPS adresini ve erişim kodunu kontrol et.');}
 finally{clearTimeout(timer)}
}


// FALLBACK_FLASH_MODELS extracted verbatim from the same 6.2.0 APK.
const FALLBACK_FLASH_MODELS=[
  ['gemini-3.1-flash-lite','Gemini 3.1 Flash-Lite · Varsayılan / ekonomik'],
  ['gemini-3.6-flash','Gemini 3.6 Flash · kalite alternatifi'],
  ['gemini-3.8-flash','Gemini 3.8 Flash · kalite alternatifi']
];


// refreshFreeModels extracted verbatim from the same 6.2.0 APK.
async function refreshFreeModels(){
 const base=v('apiBase').trim().replace(/\/+$/,'');if(!base)return;
 try{const r=await fetch(base+'/health',{method:'GET',signal:AbortSignal.timeout(8000)});if(!r.ok)return;const d=await r.json();if(d&&Array.isArray(d.models))renderModelOptions(d.models,d.defaultModel||'gemini-3.1-flash-lite');}
 catch(_){/* Keep the safe, free-only offline catalogue visible. */}
}
