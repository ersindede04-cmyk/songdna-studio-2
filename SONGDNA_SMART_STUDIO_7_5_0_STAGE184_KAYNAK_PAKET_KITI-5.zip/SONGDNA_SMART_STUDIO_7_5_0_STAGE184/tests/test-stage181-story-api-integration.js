#!/usr/bin/env node
'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { setTimeout: delay } = require('node:timers/promises');

const root = path.resolve(__dirname, '..');
const port = 18981 + (process.pid % 1000);
const token = 'stage181-integration-token';
const mock = path.join(root, 'tests/mock-gemini-fetch.cjs');
const child = spawn(process.execPath, ['-r', mock, path.join(root, 'backend/server.js')], {
  cwd: root,
  env: { ...process.env, PORT: String(port), APP_ACCESS_TOKEN: token, GEMINI_API_KEY: 'test-only-key', GEMINI_MODELS: 'gemini-3.1-flash-lite,gemini-3.6-flash' },
  stdio: ['ignore', 'pipe', 'pipe']
});
let logs = '';
child.stdout.on('data', chunk => { logs += chunk.toString(); });
child.stderr.on('data', chunk => { logs += chunk.toString(); });
const request = async (pathname, body, suppliedToken = token) => {
  const response = await fetch(`http://127.0.0.1:${port}${pathname}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-App-Token': suppliedToken },
    body: JSON.stringify(body)
  });
  return { status: response.status, data: await response.json() };
};
(async () => {
  try {
    let ready = false;
    for (let i = 0; i < 50; i++) {
      if (child.exitCode !== null) throw new Error(`Backend exited early: ${logs}`);
      try { const r = await fetch(`http://127.0.0.1:${port}/health`); if (r.ok) { ready = true; break; } } catch (_) {}
      await delay(100);
    }
    assert.ok(ready, `Backend did not become ready: ${logs}`);
    const health = await (await fetch(`http://127.0.0.1:${port}/health`)).json();
    assert.equal(health.apiVersion, '7.5.0');
    assert.equal(health.stage, 184);
    assert.equal(health.capabilities?.storyBlend, true);

    const story = await request('/api/story-blend', {
      model: 'gemini-3.1-flash-lite',
      prompt: JSON.stringify({ task: 'controlled_story_transformation', language: 'Turkish', selectedMaterial: { currentTopic: 'Eski evin anahtarı', emotion: 'özlem' } })
    });
    assert.equal(story.status, 200, JSON.stringify(story.data));
    const parsed = JSON.parse(story.data.story);
    assert.ok(parsed.story.length >= 60 && parsed.story.length <= 1200);
    assert.equal(story.data.usage.promptTokens, 10, 'one story request must use one Gemini response usage record');
    assert.equal(story.data.usage.outputTokens, 20, 'story blend must not issue a second editorial Gemini request');

    const invalidInput = await request('/api/story-blend', { model: 'gemini-3.1-flash-lite', prompt: JSON.stringify({ task: 'wrong_task', selectedMaterial: { currentTopic: 'test' } }) });
    assert.equal(invalidInput.status, 400, JSON.stringify(invalidInput.data));

    const oversizedShape = await request('/api/story-blend', { model: 'gemini-3.1-flash-lite', prompt: JSON.stringify({ task: 'controlled_story_transformation', language: 'Turkish', selectedMaterial: { currentTopic: 'SHORT_STORY_TEST' } }) });
    assert.equal(oversizedShape.status, 502, JSON.stringify(oversizedShape.data));
    assert.ok(oversizedShape.data.error, 'invalid story output must be rejected safely');

    const lyrics = await request('/api/lyrics', { model: 'gemini-3.1-flash-lite', prompt: 'A normal lyrics generation regression check.' });
    assert.equal(lyrics.status, 200, JSON.stringify(lyrics.data));
    assert.match(lyrics.data.lyrics, /TITLE: Test Song/);

    const unauthorized = await request('/api/story-blend', { model: 'gemini-3.1-flash-lite', prompt: '{}' }, 'wrong-token');
    assert.equal(unauthorized.status, 401);



    console.log('PASS Stage184 backend integration: isolated one-call story endpoint, structured input/output validation, auth, and unchanged lyrics endpoint');
  } catch (error) {
    console.error(error);
    console.error(logs);
    process.exitCode = 1;
  } finally {
    child.kill('SIGTERM');
  }
})();
