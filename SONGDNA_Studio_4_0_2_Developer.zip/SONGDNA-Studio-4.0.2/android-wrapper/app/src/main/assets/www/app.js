const dna=[['01 · Organic Afro','Organic Afro House, African Percussion, Tribal Groove, Hand Drums, Organic Bass',122],['02 · Syncopated Afro','Afro House, Syncopated African Groove, Tribal Percussion, Hand Drums, Rhythmic Bass',123],['03 · Evolving Afro','Organic Afro House, Broken African Rhythm, Tribal Percussion, Dynamic Groove, Hand Drums',121],['04 · African Dance','Afro Dance, Afrobeat, Tribal Percussion, African Vocal Chant, Call and Response, Organic Groove',110],['05 · Vocal Afro','Afro House, African Groove, Call and Response, Tribal Percussion, African Vocal Chant, Melodic Groove',120],['06 · Melodic Trap','Melodic Trap, Emotional Trap, Warm 808, R&B, Atmospheric Groove',140],['07 · Modern Trap','Modern Trap, Drill, Punchy 808, Rapid Hi-Hats, Aggressive Groove',142],['08 · Dark Trap','Dark Trap, Drill, Deep 808, Dark Groove, Atmospheric Hip-Hop',140],['09 · Emotional Trap','Emotional Trap, Melodic Rap, Cloud Rap, Warm 808, Emotional Groove',138],['10 · Melodic Rap','Melodic Rap, Hip-Hop, R&B, Emotional Flow, Atmospheric Groove',90],['11 · Organic Rap','Boom Bap, Soul Hip-Hop, Organic Drums, Warm Bass, Melodic Rap',92],['12 · Dark Rap','Dark Rap, Drill, Dark Groove, Deep Bass, Melodic Hip-Hop',140],['13 · Turkish Pop','Turkish Pop, Slow 4/4, Turkish Folk Groove, Melodic Pop, Emotional Vocals',100],['14 · Turkish Emotional Pop','Turkish Pop, Emotional Folk Groove, Melodic Vocals, Turkish Instruments, Slow Groove',90],['15 · Turkish Pop Rap','Turkish Pop, Melodic Rap, Pop-Rap, Turkish Groove, Emotional Hip-Hop',100],['16 · Bollywood Cinematic','Bollywood, Indian Pop, Sitar, Cinematic, Indian Vocal Chant, Desi Groove',108],['17 · Desi Rhythm','Desi, Indian Percussion, Tabla, Dhol, Sitar, Rhythmic Groove',112],['18 · Indian Emotional','Indian Classical, Sitar, Tanpura, Indian Vocal Chant, Emotional Groove',80]];
const L={fusion:[['Yok',''],['Afro House','Afro House'],['Tech House','Tech House'],['Deep House','Deep House'],['Progressive House','Progressive House'],['Melodic Techno','Melodic Techno'],['Uplifting Trance','Uplifting Trance'],['Psytrance','Psytrance'],['Eurodance / 2000s Rave','Eurodance, 2000s Rave'],['Hard Dance','Hard Dance'],['EDM / Festival','EDM, Festival'],['Dance Pop','Dance Pop'],['Reggaeton','Reggaeton'],['Balkan Electronic','Balkan Electronic'],['Arabic Electronic','Arabic Electronic'],['Latin House','Latin House'],['Japanese Traditional','Japanese Traditional Instruments']],
energy:[['Sakin ve atmosferik','calm atmospheric'],['Melodik ve duygusal','melodic emotional'],['Orta enerjili','mid-energy'],['Yüksek enerjili','high energy'],['Çok yüksek – festival/club','festival club energy'],['Sert – rave/hard dance','hard rave energy']],
language:[['Tamamen Türkçe','Turkish'],['Türkçe + kültürden kısa ifadeler','Turkish with short culturally accurate phrases'],['Türkçe + İngilizce','Turkish and English'],['Türkçe + Arapça','Turkish and Arabic'],['Türkçe + İspanyolca','Turkish and Spanish'],['Çok dilli','multilingual']],
region:[['Levant / Arap','Levantine Arabic'],['Batı Afrika','West African'],['Güney Afrika','South African'],['Hindustani','Hindustani'],['Pencap','Punjabi'],['Bengal','Bengali'],['Flamenko','Flamenco'],['Balkanlar','Balkan'],['Latin Amerika','Latin American'],['Karayipler','Caribbean'],['Japonya','Japanese'],['Doğu Asya','East Asian'],['Anadolu halk','Anatolian Turkish folk'],['İran','Persian'],['Yunan','Greek'],['Serbest','folk']],
preVoice:[['Geleneksel yerel','traditional local vocal'],['Kadın-erkek karşılıklı','female and male call and response'],['Kadın solo','female solo'],['Erkek solo','male solo'],['Grup / koro','group chant']],
mainVoice:[['Erkek ana + kadın destek','male lead vocal with female support'],['Kadın ana + erkek destek','female lead vocal with male support'],['Kadın-erkek düet','male and female duet'],['Erkek rap + kadın melodik','male rap with female melodic vocal'],['Kadın rap + erkek melodik','female rap with male melodic vocal'],['Kadın solo','female solo vocal'],['Erkek solo','male solo vocal'],['Grup / koro','group choir vocals']],
back:[['Kadın-erkek call & response','male-female call and response backing vocals'],['Kadın armonileri','female harmonies'],['Erkek arka vokal','male backing vocals'],['Kalabalık vokali','crowd group vocals'],['Çok katmanlı armoni','layered vocal harmonies'],['Minimal','minimal backing vocals'],['Kültürel cevaplar','cultural vocal responses']],
adlib:[['Minimal','sparse ad-libs'],['Dengeli','tasteful ad-libs'],['Yoğun ritmik','dense rhythmic ad-libs'],['Festival komutları','festival crowd-call ad-libs']],
effects:[['Doğal','natural dry vocals'],['Reverb+delay+double','reverb, delay, stereo doubles'],['Telefon/megafon','telephone megaphone vocal effect'],['Pitch + chops','pitch-shifted vocal chops'],['Ping-pong echo','echo, ping-pong delay'],['Harmoni + reverb','layered harmonies, reverb'],['Distortion + formant','distorted formant vocal effects']]};
const $=id=>document.getElementById(id),v=id=>$(id).value;
dna.forEach((d,i)=>$('dna').append(new Option(d[0],i)));
for(const k in L){if($(k))L[k].forEach((o,i)=>$(k).append(new Option(o[0],i)))}
$('energy').value=3;$('language').value=1;$('adlib').value=1;
const en=k=>L[k][+v(k)][1],tr=k=>L[k][+v(k)][0],pre=()=>document.querySelector('input[name=pre]:checked').value==='yes' && $('introPack').value!=='none';
document.querySelectorAll('input[name=pre]').forEach(x=>x.onchange=()=>{if(x.value==='yes'&&x.checked&&v('introPack')==='none')$('introPack').value='auto';$('preFields').classList.toggle('hidden',!pre());});
$('introPack').addEventListener('change',()=>{if(v('introPack')==='none'){document.querySelector('input[name=pre][value=no]').checked=true;}else{document.querySelector('input[name=pre][value=yes]').checked=true;} $('preFields').classList.toggle('hidden',!pre());});

let tab='style',last={};
$('apiBase').value=localStorage.getItem('songdna_api_base')||'';
const FALLBACK_FLASH_MODELS=[
  ['gemini-3.1-flash-lite','Gemini 3.1 Flash-Lite · Varsayılan / ekonomik'],
  ['gemini-3.6-flash','Gemini 3.6 Flash · kalite alternatifi'],
  ['gemini-3.8-flash','Gemini 3.8 Flash · kalite alternatifi']
];
function renderModelOptions(models,defaultModel){
 const select=$('aiModel'), current=select.value||defaultModel;
 const safe=(models||[]).filter(x=>FALLBACK_FLASH_MODELS.some(m=>m[0]===x));
 const list=safe.length?safe:FALLBACK_FLASH_MODELS.map(m=>m[0]);
 select.replaceChildren();
 list.forEach(id=>{const meta=FALLBACK_FLASH_MODELS.find(m=>m[0]===id);select.append(new Option(meta?meta[1]:id,id));});
 select.value=list.includes(current)?current:(list.includes(defaultModel)?defaultModel:list[0]);
}
renderModelOptions(FALLBACK_FLASH_MODELS.map(m=>m[0]),'gemini-3.1-flash-lite');
async function refreshFreeModels(){
 const base=v('apiBase').trim().replace(/\/+$/,'');if(!base)return;
 try{const r=await fetch(base+'/health',{method:'GET',signal:AbortSignal.timeout(8000)});if(!r.ok)return;const d=await r.json();if(d&&Array.isArray(d.models))renderModelOptions(d.models,d.defaultModel||'gemini-3.1-flash-lite');}
 catch(_){/* Keep the safe, free-only offline catalogue visible. */}
}
refreshFreeModels();
$('apiBase').addEventListener('change',refreshFreeModels);
async function postGemini(path,prompt){
 const base=v('apiBase').trim().replace(/\/+$/,'');
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),150000);
 try{
  const res=await fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json','X-App-Token':v('appToken')},body:JSON.stringify({model:v('aiModel'),prompt}),signal:controller.signal});
  let data;try{data=await res.json()}catch(_){throw new Error('Sunucu geçerli yanıt vermedi ('+res.status+').')}
  if(!res.ok)throw new Error(data.error||'İstek başarısız ('+res.status+').');
  return data;
 }catch(e){if(e.name==='AbortError')throw new Error('İstek 150 saniyede tamamlanmadı. Sunucu yeni uyanmış veya yoğun olabilir. Biraz bekleyip yeniden deneyebilirsin.');if(!navigator.onLine)throw new Error('İnternet bağlantısı görünmüyor. Bağlantını kontrol edip yeniden dene.');throw new Error(e.message||'Sunucuya ulaşılamadı. HTTPS adresini ve erişim kodunu kontrol et.');}
 finally{clearTimeout(timer)}
}
const savedGeminiModel=localStorage.getItem('songdna_ai_model')||'gemini-3.1-flash-lite';$('aiModel').value=[...$('aiModel').options].some(o=>o.value===savedGeminiModel)?savedGeminiModel:'gemini-3.1-flash-lite';
$('appToken').value=localStorage.getItem('songdna_app_token')||'';$('appToken').addEventListener('change',()=>localStorage.setItem('songdna_app_token',v('appToken')));
['apiBase','aiModel'].forEach(id=>$(id).addEventListener('change',()=>{localStorage.setItem('songdna_api_base',v('apiBase').trim());localStorage.setItem('songdna_ai_model',v('aiModel'))}));
function validBpm(raw){
  const value=String(raw??'').trim();
  if(!value)return '';
  if(!/^\d{1,3}$/.test(value))throw new Error('BPM yalnızca tam sayı olmalı.');
  const n=Number(value);
  if(n<40||n>240)throw new Error('BPM 40 ile 240 arasında olmalı.');
  return String(n);
}
function languageLabel(){return tr('language')}
function langShort(){return ['Turkish','Turkish','Turkish and English','Turkish and Arabic','Turkish and Spanish','multilingual'][+v('language')]||en('language')}
function context(){const d=dna[+v('dna')],p=pre(),si=p?selectedIntro():null;return {dna:d[0],style:d[1],fusion:en('fusion'),energy:en('energy'),bpm:validBpm(v('bpm'))||d[2],language:en('language'),languageLabel:languageLabel(),theme:v('theme').trim()||'a memorable personal story',mainVoice:en('mainVoice'),back:en('back'),adlib:en('adlib'),effects:en('effects'),region:p?(si?si.preset.region:en('region')):'none',regionLabel:p?(si?si.preset.family:tr('region')):'none',preVoice:p?(si?'preset vocal arrangement':en('preVoice')):'none',preLength:p?v('preLength'):'none',introId:si?si.id:'auto',introTitle:si?si.preset.title:'existing regional intro system (1–13)',introLyrics:si?si.preset.lyrics:'',introStyle:si?si.preset.style:'',preserveMode:p?v('preserveMode'):'none',preserveText:p&&si?preserveInstruction(si.preset,v('preserveMode')):'',localWords:$('localWords').value.trim(),notes:$('notes').value.trim()}}

// Curated Intro DNA presets 14–33. Instrumental directions belong to STYLE;
// only performable vocal material and English role labels belong to LYRICS.
const INTRO_DNA = {
14:{region:'Punjabi',family:'Pencap',title:'Punjabi Bhangra Call',style:'Energetic Punjabi bhangra opening, bold open-throat male call, group shout responses, dhol accents and tumbi texture.',lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nOyeee... hoye hoye...\n\n[Group Response]\nBalle balle... hey!\n\n[Male Lead Vocal]\nAa-haa... oye...\n\n[Group Response]\nBalle! Balle!\n\n[Male Lead Vocal]\nHoooye...',preserve:'male lead call, group shouts, bold open-throat delivery, dhol accents and the call-and-response order'},
15:{region:'Punjabi',family:'Pencap',title:'Punjabi Folk Long Phrase',style:'Punjabi female folk vocal, free-rhythm sustained opening, rustic ornamentation, tumbi drone, gradual dholak entry.',lyrics:'[Pre-Intro]\n[Female Lead Vocal]\nOoo... heyyy...\n\nAaaa... ni... aaa...\n\nOhhh...\n\nHeeey... ni...',preserve:'free opening, sustained notes, rustic ornamentation and gradual rhythmic entry'},
16:{region:'Bengali',family:'Bengal',title:'Bengali River Call · Bhatiali',style:'Bengali Bhatiali-inspired river-call phrasing, long sustained notes, gentle slides, sparse ektara and dotara atmosphere.',lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nOoo... re... majhi re...\n\nAaa... o... mon re...\n\nOhhh... re...\n\nAaa... ore...',preserve:'sustained river-call phrasing, gentle slides and sparse ektara atmosphere'},
17:{region:'Flamenco',family:'Flamenko',title:'Flamenco Cante Opening',style:'Flamenco cante jondo-inspired raw passionate male vocal, long ay melisma, free rhythm, palmas and nylon-string guitar rasgueado entering after the vocal call.',lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nAy... ay... ayayay...\n\nAaay... ay...\n\nAy... ay... ay...\n\nAyyy...',preserve:'raw cante delivery, ay melisma, free rhythm and gradual palmas entry'},
18:{region:'Flamenco',family:'Flamenko',title:'Flamenco Jaleo',style:'Flamenco jaleo atmosphere, rhythmic palmas, female lead cries, group shout responses and energetic handclaps.',lyrics:'[Pre-Intro]\n[Female Lead Vocal]\nAy... olé...\n\n[Group Response]\nOlé! Olé!\n\n[Female Lead Vocal]\nAy, ay, ay...\n\n[Group Response]\nOlé!',preserve:'female cry, group shouts, call-and-response and palmas rhythm'},
19:{region:'Balkan',family:'Balkanlar',title:'Balkan Female Folk Polyphony',style:'Balkan-inspired female folk polyphony, open-throat group harmony, close intervals and sustained drone-like vocal texture. Regional style should be selected or verified where possible.',lyrics:'[Pre-Intro]\n[Female Vocal Group A]\nOoo... lele...\n\n[Female Vocal Group B]\nEee... oj...\n\n[Female Vocal Group A]\nLele... lelo...\n\n[Female Vocal Group B]\nOj... oooj...',preserve:'two-group structure, open-throat harmony, close intervals and sustained phrasing'},
20:{region:'Balkan',family:'Balkanlar',title:'Balkan Dance Call',style:'Lively Balkan dance call, male vocal shouts, accordion and brass accents, driving 2/4 dance pulse.',lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nHej! Hej! Opa...\n\n[Group Response]\nHop! Hop! Hej!\n\n[Male Lead Vocal]\nAjde... hej!\n\n[Group Response]\nHej!',preserve:'male call, group shouts and driving dance energy'},
21:{region:'Mexican Mariachi',family:'Latin Amerika',title:'Mariachi Grito',style:'Mexican mariachi grito, bold male shout, passionate open-vowel melisma, trumpet fanfare and guitarrón entry.',lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nAy-ay-ay-ay-ayyyy...\n\nAaaa... ay...\n\nAy, ay, ay...',preserve:'grito vocal gesture, open-vowel melody and trumpet entry'},
22:{region:'Andean',family:'Latin Amerika',title:'Andean Wordless Vocal',style:'Andean-inspired airy high female wordless vocal, zampoña and quena flute echoes, charango strum. Avoid assigning one pan-Andean sound to every region.',lyrics:'[Pre-Intro]\n[Female Lead Vocal]\nAaa... ooo...\n\nAyyy... ooo...\n\nAaa... iii... aaa...',preserve:'airy high vocal tone, wordless phrasing and zampoña/quena echo'},
23:{region:'Afro-Cuban',family:'Latin Amerika',title:'Afro-Cuban Call & Response',style:'Afro-Cuban son-inspired lead-and-coro exchange, clear clave pulse and conga entry; keep the rhythmic call-and-response central.',lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nOye... ay... oye...\n\n[Group Coro]\nAy... ay... ay...\n\n[Male Lead Vocal]\nEh... ay...\n\n[Group Coro]\nOye... oye...',preserve:'lead call, coro answers, clave pulse and conga entry'},
24:{region:'Caribbean Jamaican',family:'Karayipler',title:'Reggae / Dancehall Call',style:'Relaxed Jamaican-style dancehall deejay call, dub echo, warm bass and one-drop drum entry.',lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nYow... ayy...\n\n[Group Response]\nOoh... ooh...\n\n[Male Lead Vocal]\nHeeey... yow!\n\n[Group Response]\nOoh... yeah...',preserve:'relaxed lead call, group responses and dub echo'},
25:{region:'Caribbean Soca',family:'Karayipler',title:'Soca / Calypso Call',style:'Joyful Caribbean soca and calypso call, female lead, group chant, lively steelpan flourish and festive percussion.',lyrics:'[Pre-Intro]\n[Female Lead Vocal]\nOh-ho... hey-ho...\n\n[Group Response]\nHey! Hey-ho!\n\n[Female Lead Vocal]\nAyy... ayy...\n\n[Group Response]\nOh-ho!',preserve:'joyful female call, group response and steelpan flourish'},
26:{region:'Japanese Minyo',family:'Japonya',title:"Japanese Min'yō Kakegoe",style:"Japanese min'yō-inspired folk vocal calls, shamisen accents and taiko hits. Traditional kakegoe phrasing should be checked against the specific regional song tradition.",lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nHaa... ee-ya...\n\n[Group Response]\nHai! Hai!\n\n[Male Lead Vocal]\nYoisho...\n\n[Group Response]\nYoisho!\n\n[Male Lead Vocal]\nHaaa...',preserve:'kakegoe-style calls, lead/group roles and taiko/shamisen entry'},
27:{region:'Japanese Enka',family:'Japonya',title:'Japanese Enka Kobushi',style:'Japanese enka-inspired female vocal, sustained notes, expressive kobushi ornamentation and shakuhachi-like breathy atmosphere.',lyrics:'[Pre-Intro]\n[Female Lead Vocal]\nAaa... aa-a-a...\n\nOoo... aaa...\n\nAaa...',preserve:'sustained notes, kobushi ornamentation and breathy shakuhachi atmosphere'},
28:{region:'Korean Pansori',family:'Doğu Asya',title:'Korean Pansori Chuimsae',style:'Korean pansori-inspired powerful raspy male voice, janggu rhythmic accompaniment and audience-style chuimsae responses.',lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nAaa... aigo... aaa...\n\n[Group Response]\nEolssigu!\n\n[Male Lead Vocal]\nAaa...\n\n[Group Response]\nJota!',preserve:'powerful raspy delivery, chuimsae responses and janggu rhythm'},
29:{region:'Chinese Folk',family:'Doğu Asya',title:'Chinese Folk Pentatonic',style:'Chinese folk-inspired bright female vocal, pentatonic melodic ornamentation, erhu and guzheng textures.',lyrics:'[Pre-Intro]\n[Female Lead Vocal]\nAaa... yi-ya...\n\nOoo... ei-ya...\n\nAaa... lai... lai...\n\nEi-yaaa...',preserve:'bright vocal tone, pentatonic ornamentation and erhu/guzheng atmosphere'},
30:{region:'Zulu Isicathamiya',family:'Güney Afrika',title:'Zulu Isicathamiya Harmony',style:'South African Zulu isicathamiya-inspired soft male choir a cappella, deep bass bed, gentle swaying harmony and clear lead/group blend.',lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nMmm... ho-ho...\n\n[Male Choir]\nHo... ho-ho...\n\n[Male Lead Vocal]\nYebo... yebo...\n\n[Male Choir]\nOoo... ei-ya...',preserve:'soft a cappella blend, deep bass bed and lead/choir roles'},
31:{region:'South African Amapiano',family:'Güney Afrika',title:'South African Amapiano Call',style:'South African amapiano-inspired airy female call, soft group response, log drum and shaker entering after the vocal phrase.',lyrics:'[Pre-Intro]\n[Female Lead Vocal]\nYebo... heyy...\n\n[Group Response]\nOoh... ooh...\n\n[Female Lead Vocal]\nAaay... yebo...\n\n[Group Response]\nHeyy...',preserve:'airy female call, soft group response and log drum entry'},
32:{region:'Persian Avaz',family:'İran',title:'Persian Avaz Tahrir',style:'Persian avaz-inspired free-meter female vocal, expressive tahrir ornamentation, santur and ney drone. Keep the opening spacious and unmetered.',lyrics:'[Pre-Intro]\n[Female Lead Vocal]\nAaa... ey... jaan...\n\nAaa-a-a-ah... ey...\n\nOoo... yaar... aaa...\n\nAaa... jaan...',preserve:'free-meter phrasing, tahrir ornamentation and santur/ney atmosphere'},
33:{region:'Greek Amanes',family:'Yunan',title:'Greek Amanes',style:'Greek amanes-inspired free-form male lament, deep emotional ornamentation. Bouzouki and oud are an optional fusion color, not a universal traditional requirement.',lyrics:'[Pre-Intro]\n[Male Lead Vocal]\nAaa... aman...\n\nAaa-man... aaa...\n\nAh... ah... aman...\n\nOoo... aman, aman...',preserve:'free-form lament phrasing, deep ornamentation and the spacious instrumental response'}
};
Object.entries(INTRO_DNA).forEach(([id,preset])=>$('introPack').append(new Option(String(id)+' · '+preset.title,id)));
function selectedIntro(){
  const id=v('introPack');
  return INTRO_DNA[id] ? {id,preset:INTRO_DNA[id]} : null;
}
function introLyricsForPrompt(){
  const selected=selectedIntro();
  return selected ? selected.preset.lyrics : '';
}
function preserveInstruction(preset,mode){
  if(!preset || mode==='none')return '';
  if(mode==='long')return '[IMPORTANT – PRESERVE THIS INTRO]\nKeep this intro exactly as written. Perform it before the main song begins. Preserve '+preset.preserve+'. Do not replace, simplify, rearrange, or remove the intro. Transition naturally from this intro into the main song.';
  return 'Preserve the selected pre-intro exactly, including its vocal roles, phrasing and order; perform it before the main song and transition naturally.';
}

function makeLyricsPrompt(c){return `You are an award-winning songwriter and vocal producer. Write a complete, original, performance-ready song. Do not write instructions or placeholders.

CREATIVE BRIEF
Main DNA: ${c.dna} — ${c.style}
Fusion: ${c.fusion||'none'}
Energy: ${c.energy}; tempo: ${c.bpm} BPM
Main song language: ${c.language}
Story/theme: ${c.theme}
Lead vocal: ${c.mainVoice}
Backing vocals: ${c.back}
Ad-libs: ${c.adlib}
Vocal effects: ${c.effects}
Cultural pre-intro: ${c.region==='none'?'disabled':`${c.regionLabel} (${c.region}), ${c.preVoice}, ${c.preLength}`}
Selected Intro DNA: ${c.introTitle||'existing regional intro system'}
Exact selected pre-intro vocal text (must be reproduced exactly once, before the main song):
${c.introLyrics||'No fixed intro template; create a short regional pre-intro only if enabled and use only verified expressions or wordless vocalise.'}
Intro preservation instruction: ${c.preserveText||'No additional preserve instruction.'}
Local words/phrases supplied by user: ${c.localWords||'none'}
Additional creative direction: ${c.notes||'none'}

WRITING RULES
- Write the actual song lyrics in the selected language: ${c.language}. Do not translate, paraphrase, or replace user-supplied lyrics or local phrases.
- The application interface language is Turkish, but ALL Suno-facing section labels and technical performance cues MUST be in English.
- Use square-bracket labels only for section and production/performance instructions. Use standard English labels such as [Pre-Intro], [Intro], [Verse 1], [Pre-Chorus], [Chorus], [Verse 2], [Bridge], [Final Chorus], [Outro], [Female Lead Vocal], [Male Backing Vocals], [Whispered Vocals], [Vocal Build-Up], [Instrumental Break], [Ad-libs], [Fade Out].
- Never put Turkish words inside section-label or technical-cue brackets. Do not use Turkish labels such as [Kıta], [Nakarat], [Giriş], [Köprü] or [Çıkış].
- Do not put explanatory technical directions in ordinary parentheses. Keep actual sung ad-libs/vocalizations (for example: ah, hey, oh) as performable lyric text, not as instructions.
- Include [Pre-Intro] only when enabled. Do not create a second pre-intro.
- If an exact selected Intro DNA vocal template is supplied above, reproduce its vocal text and English role tags exactly once at the beginning. Do not translate, rewrite, expand or replace it.
- Do not place instrument descriptions or production notes in LYRICS; those belong in STYLE. Keep vocal role labels in English square brackets.
- Include a concise culturally authentic pre-intro only if enabled. Use the selected region's language and only verified, meaningful expressions; do not invent pseudo-language. If uncertain, use a wordless vocalise. Transition naturally into the selected main song language.
- EVERY song section must explicitly identify its singer in the SAME section tag. Use labels such as [Verse 1 – Male Vocal], [Verse 2 – Female Vocal], [Chorus – Male & Female Duet], [Bridge – Female Vocal], and [Outro – Male Vocal].
- Never leave a Verse, Chorus, Pre-Chorus, Bridge, Final Chorus or Outro without an explicit Male Vocal, Female Vocal, or Male & Female Duet identity.
- Respect the selected lead vocal. For a solo selection, apply that singer consistently to every main section. For a duet, deliberately assign male and female sections and mark shared sections [Male & Female Duet]. Do not let Suno infer the singer's gender.
- Intro and pre-intro vocal identities must also be explicit in their opening tags. Preserve the selected Intro DNA's existing vocal-role tags.
- Keep the selected musical DNA audible in phrasing, syllable density, emotional arc and hook shape.
- Write vivid, coherent storytelling; avoid clichés, forced rhymes, filler lines and generic AI phrases.
- Create a memorable, singable chorus with a distinctive short hook. Do not over-repeat.
- Avoid explanatory prose, analysis, title commentary, markdown fences, and placeholders.
- Output a short original title on the first line prefixed with TITLE:, then the complete lyrics only.`}

// Only recognized standalone bracket-tag lines are normalized; lyric lines remain untouched.
const SUNO_TAG_MAP = {
  'giriş':'Intro','ön giriş':'Pre-Intro','ön nakarat':'Pre-Chorus','nakarat':'Chorus',
  'kıta':'Verse','kıta 1':'Verse 1','kıta 2':'Verse 2','köprü':'Bridge',
  'son nakarat':'Final Chorus','çıkış':'Outro','enstrümantal ara':'Instrumental Break',
  'kadın vokal':'Female Lead Vocal','erkek vokal':'Male Lead Vocal',
  'kadın arka vokal':'Female Backing Vocals','erkek arka vokal':'Male Backing Vocals',
  'fısıltılı vokal':'Whispered Vocals','duygusal geçiş':'Emotional Transition',
  'güçlü nakarat':'Powerful Chorus','yükselen vokal':'Vocal Build-Up',
  'yavaşça sönümlen':'Gradual Fade Out'
};
function normalizeSunoLyrics(input){
  const changed=[];
  const output=String(input||'').split(/\r?\n/).map(line=>{
    const m=line.match(/^(\s*)\[([^\]]+)\](\s*)$/);
    if(!m)return line;
    const raw=m[2].trim(),parts=raw.split(':');
    const key=parts.shift().trim().toLocaleLowerCase('tr-TR');
    const mapped=SUNO_TAG_MAP[key];
    if(!mapped)return line;
    changed.push(raw+' → '+mapped);
    const suffix=parts.length?': '+parts.join(':').trim():'';
    return m[1]+'['+mapped+suffix+']'+m[3];
  }).join('\n');
  return {text:output,changed};
}
function auditSunoLyrics(lyrics,normalized){
  if(!String(lyrics||'').trim())return 'Henüz LYRICS içeriği yok. Söz eklendiğinde etiket denetimi yapılır.\n\nKural: Türkçe sözler korunur; Suno bölüm etiketleri ve teknik komutlar İngilizce köşeli parantezlerle yazılır.';
  const tags=String(normalized||'').split(/\r?\n/).filter(x=>/^\s*\[[^\]]+\]\s*$/.test(x));
  const nonEnglish=tags.filter(x=>/[çğıöşüÇĞİÖŞÜ]/.test(x));
  const details=['Arayüz dili: Türkçe','Şarkı sözleri: Seçilen dilde korunur; metin satırları otomatik çevrilmez.','Etiket satırı sayısı: '+tags.length];
  if(nonEnglish.length)details.push('Uyarı: Türkçe karakter içeren etiket satırları var:\n'+nonEnglish.join('\n'));
  else details.push('Etiket kontrolü: Köşeli parantezli etiket satırlarında Türkçe karakter tespit edilmedi.');
  if(normalized && normalized.changed && normalized.changed.length)details.push('Otomatik düzeltilen etiketler:\n'+normalized.changed.join('\n'));
  details.push('Not: İngilizce etiketler Suno tarafından her üretimde kesin uygulanmayı garanti etmez; bu denetim biçim ve dil tutarlılığını kontrol eder.');
  return details.join('\n\n');
}

function build(options={}){
  let c;try{c=context()}catch(e){if(options.silent){$('aiStatus').textContent=e.message;}else alert(e.message);$('bpm').focus();return false;}
  const p=pre(),d=dna[+v('dna')];
  const selected= p?selectedIntro():null;
  const introStyle=selected?selected.preset.style:(p?`${c.region} traditional vocal pre-intro, ${c.preVoice}, ${c.preLength}`:'');
  const preserve=selected?preserveInstruction(selected.preset,v('preserveMode')):'';
  const parts=[d[1],c.fusion,c.energy,c.bpm+' BPM',langShort()+' lead vocals',c.mainVoice,c.back,c.adlib,c.effects,'memorable chorus hook','polished production'].filter(Boolean);
  let style='';for(const x of parts){const n=style?style+', '+x:x;if(n.length>1000)break;style=n}
  const ex=v('excl').trim(),my=v('myLyrics').trim();
  // Keep the LYRICS payload genuinely empty until real lyrics exist.
  const hasPre=/^\s*\[(?:Pre-Intro|Ön Giriş)\b/im.test(my);
  const selectedPreset=p?selectedIntro():null;
  const preTag=my&&p&&!hasPre?(selectedPreset?selectedPreset.preset.lyrics+'\n\n':`[Pre-Intro]\n[${c.region} ${c.preVoice}; ${v('preLength')}; culturally authentic local vocal phrase only if verified; regional instrumental response; transition into ${c.language} lead vocals]\n`) : '';
  const rawLyrics=my?(preTag+my):'';
  const normalized=normalizeSunoLyrics(rawLyrics);
  const lyrics=normalized.text;
  let audit=auditSunoLyrics(lyrics,normalized);
  if(p&&selectedPreset)audit+='\n\nSeçili Intro DNA: '+selectedPreset.id+' · '+selectedPreset.preset.title+'\nPRESERVE: '+v('preserveMode');
  if(p&&selectedPreset&&hasPre)audit+='\n\nNot: Hazır sözlerde zaten [Pre-Intro] bulunduğu için seçili Intro DNA şablonu ikinci kez eklenmedi. Seçili presetin tam uygulanması için hazır sözlerdeki mevcut pre-introyu kaldır.';
  const ask=makeLyricsPrompt(c);
  const brief=`VOCAL & PERFORMANCE PLAN\nMain language: ${c.languageLabel}\nLead: ${tr('mainVoice')}\nBacking: ${tr('back')}\nAd-lib density: ${tr('adlib')}\nEffects: ${tr('effects')}\nPre-intro: ${p?(c.introTitle+' · '+c.preLength):'disabled'}\nLocal phrase guidance: ${c.localWords||'Use only linguistically verified phrases; never invent words.'}\n\nKeep backing vocals below the lead. Place ad-libs at selected transitions and chorus gaps; avoid clutter.`;
  last={title:c.theme,style,exclude:ex,lyrics:lyrics,ask,brief,audit,sty:style,dna:d[0],created:new Date().toLocaleString('tr-TR'),context:c,introId:c.introId,introTitle:c.introTitle};show();
  if(options.scroll!==false)$('results').scrollIntoView({behavior:'smooth'});
  return true;
}
function show(){
  if(!last||!Object.prototype.hasOwnProperty.call(last,'style')){
    $('output').textContent='Seçimlerini yap, "Paketi oluştur"a dokun.';
    $('cnt').textContent='';$('copy').disabled=true;$('share').disabled=true;return;
  }
  const value=typeof last[tab]==='string'?last[tab]:'';
  const emptyMessages={style:'STYLE çıktısı henüz oluşturulmadı.',exclude:'Exclude alanı boş. İstemediğin stilleri 05 / Şarkı Hikâyesi bölümünden ekleyebilirsin.',lyrics:'Henüz şarkı sözü yok. AI ile söz üret veya kendi sözlerini ekle.',ask:'Söz üretim promptu henüz oluşturulmadı.',brief:'Vokal planı henüz oluşturulmadı.',audit:'Komut denetimi henüz oluşturulmadı.'};
  $('output').textContent=value||emptyMessages[tab]||'Bu alanda henüz içerik yok.';
  const c=$('cnt');if(tab==='style'){c.textContent=value.length+' / 1000 karakter';c.className='cnt'+(value.length>1000?' bad':'')}else c.textContent=value.length+' karakter';
  const hasContent=!!value.trim();
  $('copy').disabled=!hasContent;$('share').disabled=!hasContent;
}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));show()});
function copyText(t){try{if(window.Android){Android.copy(t);return true}}catch(e){}try{const a=document.createElement('textarea');a.value=t;a.style.position='fixed';a.style.opacity=0;document.body.append(a);a.select();const ok=document.execCommand('copy');a.remove();if(ok)return true}catch(e){}if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(t).catch(()=>{});return true}return false}
const flash=(id,t,o)=>{$(id).textContent=t;setTimeout(()=>$(id).textContent=o,1800)};
$('generate').onclick=build;
$('copy').onclick=()=>{const value=last&&typeof last[tab]==='string'?last[tab]:'';if(!value.trim())return;flash('copy',copyText(value)?'Kopyalandı ✓':'Kopyalanamadı','Kopyala')};
$('share').onclick=()=>{const value=last&&typeof last[tab]==='string'?last[tab]:'';if(!value.trim())return;try{if(window.Android)Android.share(value);else if(navigator.share)navigator.share({text:value})}catch(e){}};
$('suno').onclick=()=>{try{if(window.Android)Android.open('https://suno.com/create');else window.open('https://suno.com/create','_blank')}catch(e){}};
$('rand').onclick=()=>{for(const k of ['dna','fusion','energy','language','mainVoice','back','adlib','effects','region','preVoice'])$(k).value=Math.floor(Math.random()*(k==='dna'?dna.length:L[k].length));const enable=Math.random()<0.75;document.querySelector(`input[name=pre][value=${enable?'yes':'no'}]`).checked=true;$('preFields').classList.toggle('hidden',!enable);$('preLength').selectedIndex=Math.floor(Math.random()*$('preLength').options.length);$('bpm').value=Math.random()<0.5?'':String(dna[+v('dna')][2]);}
$('aiGenerate').onclick=async()=>{const base=v('apiBase').trim().replace(/\/+$/,'');if(!base){$('aiStatus').textContent='Önce HTTPS AI sunucu adresini gir. Backend kurulum dosyaları ZIP içindedir.';return}
let prompt;try{prompt=makeLyricsPrompt(context())}catch(e){$('aiStatus').textContent=e.message;$('bpm').focus();return}$('aiGenerate').disabled=true;$('aiStatus').textContent='Yapay zekâ sözleri oluşturuyor…';
try{const data=await postGemini('/api/lyrics',prompt);
const text=(data.lyrics||data.text||'').trim();if(!text)throw new Error('AI boş yanıt verdi.');
const titleMatch=text.match(/^TITLE:\s*(.+)$/mi);if(titleMatch)$('theme').value=titleMatch[1].trim();
$('myLyrics').value=text.replace(/^TITLE:\s*.+\n?/mi,'').trim();build();tab='lyrics';document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab==='lyrics'));show();$('aiStatus').textContent='Sözler üretildi'+(data.fallbackUsed?' (yedek model kullanıldı)':'')+' ve Suno Lyrics çıktısına aktarıldı.';$('results').scrollIntoView({behavior:'smooth'});
}catch(e){$('aiStatus').textContent='Üretim başarısız: '+e.message}finally{$('aiGenerate').disabled=false}};

$('styleGenerate').onclick=async()=>{const base=v('apiBase').trim().replace(/\/+$/,'');if(!base){$('aiStatus').textContent='Önce HTTPS sunucu adresini gir.';return}if(!build({scroll:false,silent:true})){return}const snapshot=last.context||{};const prompt="Create a polished Suno-ready STYLE prompt using ONLY the current selections below. Preserve the selected musical DNA, genre blend, fusion, energy, exact BPM, song language, lead/backing vocal roles, ad-lib and effects, instruments, cultural Intro DNA and PRESERVE mode. Never use stale settings. Do not write lyrics. Do not add excluded genres. Return only the STYLE text in English and keep it under 1000 characters.\\n\\nBASE STYLE: "+last.style+"\\nMUSIC DNA: "+(snapshot.dna||'')+"\\nFUSION: "+(snapshot.fusion||'none')+"\\nENERGY: "+(snapshot.energy||'')+"\\nBPM: "+(snapshot.bpm||'')+"\\nLANGUAGE: "+(snapshot.language||'')+"\\nLEAD VOCAL: "+(snapshot.mainVoice||'')+"\\nBACKING VOCAL: "+(snapshot.back||'')+"\\nAD-LIBS: "+(snapshot.adlib||'')+"\\nVOCAL EFFECTS: "+(snapshot.effects||'')+"\\nINTRO DNA: "+(snapshot.introTitle||'none')+"\\nINTRO STYLE: "+(snapshot.introStyle||'')+"\\nPRESERVE: "+(snapshot.preserveText||snapshot.preserveMode||'none')+"\\nREGION: "+(snapshot.regionLabel||'none')+"\\nEXCLUDE: "+(last.exclude||'None')+"\\nCREATIVE NOTES: "+(snapshot.notes||'None');$('styleGenerate').disabled=true;$('aiStatus').textContent='Gemini STYLE metnini oluşturuyor…';try{const data=await postGemini('/api/style',prompt);const text=(data.style||data.text||'').trim();if(!text)throw new Error('Gemini boş STYLE yanıtı verdi.');last.style=text;last.sty=text;tab='style';document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab==='style'));show();$('aiStatus').textContent='STYLE üretildi'+(data.fallbackUsed?' (yedek model kullanıldı)':'')+' ve ayrı STYLE alanına aktarıldı.';$('results').scrollIntoView({behavior:'smooth'});}catch(e){$('aiStatus').textContent='STYLE üretimi başarısız: '+e.message;}finally{$('styleGenerate').disabled=false;}};
const store=()=>{try{return JSON.parse(localStorage.getItem('songdna_saved')||'[]')}catch(e){return[]}};
function renderSaved(){const arr=store(),box=$('saved');box.innerHTML='';if(!arr.length){box.innerHTML='<p class="sub">Henüz kayıt yok.</p>';return}arr.map((x,i)=>[x,i]).reverse().forEach(([x,i])=>{const div=document.createElement('div');div.className='saved-item';const t=document.createElement('strong');t.textContent=x.title+' · '+x.dna;const m=document.createElement('div');m.style.cssText='color:#aaa6c2;font-size:11px';m.textContent=x.created;const b=document.createElement('button');b.className='btn small secondary';b.textContent='Yükle';b.onclick=()=>{last=x;tab='style';document.querySelectorAll('.tab').forEach(q=>q.classList.toggle('active',q.dataset.tab==='style'));show();$('results').scrollIntoView({behavior:'smooth'})};const d=document.createElement('button');d.className='btn small secondary';d.style.marginRight='6px';d.textContent='Sil';d.onclick=()=>{const a=store();a.splice(i,1);localStorage.setItem('songdna_saved',JSON.stringify(a));renderSaved()};div.append(t,b,d,m);box.append(div)})}
$('save').onclick=()=>{if(!last.style){alert('Önce paketi oluştur.');return}const a=store();a.push(last);try{localStorage.setItem('songdna_saved',JSON.stringify(a));renderSaved();flash('save','Kaydedildi ✓','Arşive kaydet')}catch(e){flash('save','Depolama alanı yetersiz','Arşive kaydet')}};
renderSaved();
show();

// 4.0 menu and settings interactions
$('preFields').classList.toggle('hidden',!pre());
const menuOpen=document.getElementById('menuOpen'),menuClose=document.getElementById('menuClose'),scrim=document.getElementById('drawerScrim');
function closeSettings(){document.body.classList.remove('drawer-open');document.querySelectorAll('.drawer-panel').forEach(p=>p.classList.remove('active'))}
menuOpen.addEventListener('click',()=>document.body.classList.add('drawer-open'));
menuClose.addEventListener('click',closeSettings);scrim.addEventListener('click',closeSettings);
document.querySelectorAll('[data-drawer-target]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.drawer-panel').forEach(p=>p.classList.toggle('active',p.id===b.dataset.drawerTarget));document.querySelector('.drawer-content').scrollIntoView({block:'start',behavior:'smooth'})}));
document.querySelector('[data-scroll="top"]').addEventListener('click',e=>{e.preventDefault();closeSettings();window.scrollTo({top:0,behavior:'smooth'})});
const themeMode=document.getElementById('themeMode');themeMode.value=localStorage.getItem('songdna_theme')||'dark';document.body.classList.toggle('light',themeMode.value==='light');
themeMode.addEventListener('change',()=>{document.body.classList.toggle('light',themeMode.value==='light');localStorage.setItem('songdna_theme',themeMode.value)});
const lyricsInput=$('myLyrics');if(lyricsInput){const updateLyricsCount=()=>{const el=$('lyricsCount');if(el)el.textContent=lyricsInput.value.length.toLocaleString('tr-TR')+' karakter · Suno sınırları hesap/özelliklere göre değişebilir.'};lyricsInput.addEventListener('input',updateLyricsCount);updateLyricsCount();}

