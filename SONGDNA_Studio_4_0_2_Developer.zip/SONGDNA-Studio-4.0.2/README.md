# SONGDNA Studio 4.0.2 — Gemini-first Android source

SONGDNA Studio prepares original lyrics and Suno-ready music-style prompts. It does **not** generate audio. Version 4.0.2 preserves the existing catalogues and separate Suno output areas.

## Preserved product features
- 18 Music DNA packages.
- Intro DNA catalogue 14–33, plus existing regional intro options.
- PRESERVE controls: short, long and disabled.
- Gemini-only AI workflow with separate `/api/lyrics` and `/api/style` endpoints.
- Separate STYLES and LYRICS outputs; EXCLUDE remains separate.
- Local archive, copy/share actions, settings and About screen.
- Exact About copyright: `© 2026 SONGDNA Studio – Tüm hakları saklıdır.`
- Stable Android application ID `com.songdna.studio` and monotonic versionCode 14.

## 4.0.2 reliability and safety changes
- Gemini model list is read from backend environment variables and filtered through a Flash-only allowlist. Paid-only model IDs cannot be configured.
- Default model is `gemini-3.1-flash-lite`; fallback models are explicitly configured. There is no automatic switch to a Pro or multimodal model. **Important:** the model name alone cannot guarantee zero cost. Google applies the billing tier configured on the Google Cloud project. To keep API use free, leave the project on Google AI Studio Free Tier and do not enable billing or attach a paid billing account. Free-tier quotas and availability remain subject to Google's account, region and rate limits.
- Backend generation has a shared 78-second budget and 24-second per-model timeout; frontend allows up to 150 seconds to accommodate host cold starts.
- If the app disconnects, the backend cancels its upstream Gemini request rather than continuing unnecessary work.
- Removed obsolete generation temperature settings.
- `/health` publishes the configured safe model list and default; the app updates its selector dynamically.
- Web JavaScript is maintained as `www/app.js`; Android WebView ships an identical copy.
- Android backup is disabled to reduce the chance of local archive and access-token data being included in device backups.
- Error messages distinguish network, timeout, authentication, quota and server failures without exposing API keys.

## Important deployment settings
Configure these variables on the backend host:
- `APP_ACCESS_TOKEN`: required, random and at least 12 characters; enter the same value in the app.
- `GEMINI_API_KEY`: Google AI Studio API key; server-side only. Never place it in the APK or repository.
- `GEMINI_MODEL`: preferred Flash model; default `gemini-3.1-flash-lite`.
- `GEMINI_MODELS`: comma-separated fallback list. The backend rejects model IDs outside its approved Flash-only allowlist; Pro and multimodal models are not accepted.
- `ALLOWED_ORIGIN=*`: required for this Android `file://` WebView build. The app token is also required. Do not replace this with the Render domain for this APK, because local file origins may send `null`.
- `TRUST_PROXY=false` by default. On Render, set `true` only after confirming the trusted proxy overwrites `X-Forwarded-For`; this affects per-IP throttling and failed-token lockouts.

The API uses standard Gemini Flash text generation only; it does not invoke search grounding, audio, video or image services. Flash models may still be billed if the Google project is on a paid billing tier. Free-tier use is not unlimited, and Google may enforce quotas. Avoid sending sensitive or confidential lyrics. Review Google's current [Gemini API pricing and data-use terms](https://ai.google.dev/gemini-api/docs/pricing) before deployment.

## Backend local test
```bash
cd backend
cp .env.example .env
# Set APP_ACCESS_TOKEN and GEMINI_API_KEY in .env.
node server.js
```

## Android build
The GitHub Actions workflow runs source validation and builds a debug APK with Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21 and Java 17. A signed release APK is produced only when all four signing secrets are configured: `SONGDNA_KEYSTORE_BASE64`, `SONGDNA_KEYSTORE_PASSWORD`, `SONGDNA_KEY_ALIAS`, `SONGDNA_KEY_PASSWORD`. Keep the keystore private and preserve it for all future app updates; never commit it to GitHub.

## Verification boundaries
Run `python3 scripts/verify-source.py` before committing. It checks source layout, Web/Android asset parity, Android XML, model policy, JS/backend syntax and retained features. A successful source check does **not** prove a remote APK build, physical-device behavior, Render deployment or live Gemini response. Those still require GitHub Actions and real-device/live-service tests.
