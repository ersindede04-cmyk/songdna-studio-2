'use strict';
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),source=fs.readFileSync(path.join(root,'app.js'),'utf8');
const start=source.indexOf('function auditSunoIdentityConsistency(');
const end=source.indexOf('function auditSunoLyricsDetailed(',start);
assert(start>=0&&end>start,'identity consistency audit function exists');
const box={};vm.runInNewContext(source.slice(start,end)+';this.audit=auditSunoIdentityConsistency;',box);
const audit=box.audit;

// Genuine contradictions still warn.
let r=audit('instrumental only, no vocals','[Verse 1]\nI walk through the night and sing for you');
assert.equal(r.level,'warning');
r=audit('female lead vocals','[Male Lead]\nI sing tonight');
assert.equal(r.level,'warning');
r=audit('male lead vocals','[Female Lead]\nI sing tonight');
assert.equal(r.level,'warning');

// Valid mixed arrangements must not be marked as contradictions.
r=audit('female lead vocals, male guest verse, melodic pop','[Female Lead]\n[Verse 1]\nShe sings tonight\n[Male Verse]\nHe answers');
assert.notEqual(r.level,'warning');
r=audit('female vocals, duet harmonies','[Male Verse]\nA guest answers\n[Female Verse]\nThe lead replies');
assert.notEqual(r.level,'warning');

// Instrumental directions and section tags alone are not sung lyrics.
r=audit('instrumental only, no vocals','[Instrumental Break]\n[Long bağlama solo with free ornamentation and soft percussion]');
assert.notEqual(r.level,'warning');
r=audit('instrumental only, no vocals','[Intro]\n(Extended instrumental passage with bağlama and percussion)');
assert.notEqual(r.level,'warning');

// Plain lyric text is still detected even without section labels.
r=audit('instrumental only, no vocals','Walking through the night I sing your name and remember every promise');
assert.equal(r.level,'warning');

// Empty inputs remain pending; identity audit must still be wired to UI.
assert.equal(audit('','[Verse 1]\ntext').level,'pending');
assert(source.includes('auditSunoIdentityConsistency'), 'UI refresh must run combined identity audit');
for(const rel of ['www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'])
 assert.equal(fs.readFileSync(path.join(root,rel),'utf8'),source,rel+' synchronized');

// Exercise neutral and valid guest-verse cases against every catalogue profile.
const catalogMatch=source.match(/const GLOBAL_MUSIC_DNA=(\{.*?\});/s);
assert(catalogMatch,'67-profile Music DNA catalogue must exist');
const catalog=JSON.parse(catalogMatch[1]);
assert.equal(catalog.music_dna_profiles.length,67);
for(const profile of catalog.music_dna_profiles){
  const context={musicIdentityProfile:{name:profile.name,profileId:profile.id}};
  const neutral=audit('genre-appropriate production, melodic vocals', '[Verse 1]\nWords carry the story through the night',context);
  assert.notEqual(neutral.level,'warning',profile.id+' neutral pair should not warn');
  const guest=audit('female lead vocals, male guest verse', '[Female Lead]\n[Verse 1]\nThe lead begins the song\n[Male Verse]\nA guest answers the lead',context);
  assert.notEqual(guest.level,'warning',profile.id+' valid guest verse should not warn');
}
console.log('PASS Stage 118: explicit contradictions retained; guest verses and instrumental cues avoid false positives; runtime copies synchronized.');
