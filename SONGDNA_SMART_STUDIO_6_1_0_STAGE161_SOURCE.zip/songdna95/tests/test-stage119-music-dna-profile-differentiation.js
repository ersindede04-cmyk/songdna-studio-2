'use strict';
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const match=app.match(/const GLOBAL_MUSIC_DNA=(\{.*?\});/s);
assert(match,'GLOBAL_MUSIC_DNA catalogue must exist');
const catalog=JSON.parse(match[1]);
const profiles=catalog.music_dna_profiles;
assert.equal(profiles.length,67,'expected 67 Music DNA profiles');
const engine=require(path.join(root,'three-layer-production-orchestrator.js'));
const ids=new Set(), slugs=new Map(), traitSignatures=new Set(), arrangementSignatures=new Set();
for(const p of profiles){
  assert(p.id&&p.slug&&p.name,p.id+' must have stable identity fields');
  assert(!ids.has(p.id),p.id+' duplicate profile ID'); ids.add(p.id);
  if(slugs.has(p.slug)) assert(p.slug==='turkish-pop' && p.name==='Turkish Pop' && slugs.get(p.slug)==='Turkish Pop',p.slug+' unexpected duplicate slug');
  else slugs.set(p.slug,p.name);
  assert(Array.isArray(p.musical_traits)&&p.musical_traits.length>0,p.id+' missing musical traits');
  assert(typeof p.arrangement_guidance==='string'&&p.arrangement_guidance.trim(),p.id+' missing arrangement guidance');
  assert((Array.isArray(p.instrument_guidance)?p.instrument_guidance.length>0:typeof p.instrument_guidance==='string'&&p.instrument_guidance.trim()),p.id+' missing instrument guidance');
  assert(typeof p.lyrics_guidance==='string'&&p.lyrics_guidance.trim(),p.id+' missing lyrics guidance');
  const traitSig=p.musical_traits.map(x=>String(x).trim().toLowerCase()).sort().join('|');
  const arrangementSig=p.arrangement_guidance.trim().toLowerCase();
  assert(!traitSignatures.has(traitSig),p.id+' duplicates another profile musical-trait signature');
  assert(!arrangementSignatures.has(arrangementSig),p.id+' duplicates another profile arrangement guidance');
  traitSignatures.add(traitSig); arrangementSignatures.add(arrangementSig);
  const result=engine.build({
    main:{id:p.id,name:p.name,family:p.primary_genre,promptText:[p.prompt_guidance,Array.isArray(p.instrument_guidance)?p.instrument_guidance.join('; '):p.instrument_guidance].filter(Boolean).join(' '),
      musicalTraits:p.musical_traits,arrangementGuidance:p.arrangement_guidance},
    identity:{profileId:p.id,name:p.name,primaryGenre:p.primary_genre,domain:p.music_domain,
      region:p.region_or_scene,definingTraits:p.musical_traits,profileGuidance:p.prompt_guidance,
      productionGuidance:Array.isArray(p.instrument_guidance)?p.instrument_guidance.join('; '):p.instrument_guidance,vocalGuidance:p.lyrics_guidance,
      arrangementGuidance:p.arrangement_guidance}
  });
  assert.equal(result.musicIdentityProfile.profileId,p.id,p.id+' identity binding');
  assert.equal(result.musicIdentityProfile.primaryGenre,p.primary_genre,p.id+' genre binding');
  assert.equal(result.musicIdentityProfile.region,p.region_or_scene,p.id+' region binding');
  assert.deepEqual(Array.from(result.musicIdentityProfile.definingTraits),p.musical_traits,p.id+' traits binding');
  assert.equal(result.stylesContext,result.lyricsContext,p.id+' shared Styles/Lyrics context');
  assert(result.sharedPrompt.includes(p.name),p.id+' profile name absent from shared prompt');
  assert(result.sharedPrompt.includes(p.arrangement_guidance.slice(0,30)),p.id+' arrangement guidance absent');
}
const nameCounts=profiles.reduce((m,p)=>(m[p.name]=(m[p.name]||0)+1,m),{});
assert(nameCounts['Turkish Pop']===2,'duplicate Turkish Pop labels are retained as distinct catalogue entries and not silently merged');
assert(profiles.filter(p=>p.slug==='turkish-pop').length===2,'known Turkish Pop slug duplication is explicitly documented and tested');
console.log('PASS Stage 119: 67/67 profiles have distinct IDs/slugs/trait and arrangement signatures; identity metadata reaches shared Styles/Lyrics context.');
