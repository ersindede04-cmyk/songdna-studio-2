'use strict';
const assert=require('assert');
const fs=require('fs');
const app=fs.readFileSync('app.js','utf8');
const start=app.indexOf('function auditManualVocalSectionPlacement');
const end=app.indexOf('\n(function initStage140ManualVocalSectionPlacement',start);
assert(start>=0&&end>start,'Stage 140 audit must exist');
const audit=new Function(app.slice(start,end)+'; return auditManualVocalSectionPlacement;')();
const match=app.match(/const GLOBAL_MUSIC_DNA=(\{[\s\S]*?\});\nconst TECHNIQUE_MODULES=/);
assert(match,'Music DNA catalog must exist');
const profiles=JSON.parse(match[1]).music_dna_profiles;
assert.strictEqual(profiles.length,67);
const assignments={section_assignments:[
 {role:'lead',section:'verse'},
 {role:'backing',section:'chorus'},
 {role:'guest',section:'guest verse'},
 {role:'duet',section:'bridge'}
]};
const good='[Verse 1 – Lead Vocal]\nLine one\n[Chorus – Backing Vocals]\nResponse\n[Guest Verse – Guest Vocal]\nFeature line\n[Bridge – Duet]\nTogether';
for(const p of profiles){
 const r=audit(assignments,{lyrics:good});
 assert.strictEqual(r.level,'ok',p.id+' selected vocal placements preserved');
 assert.strictEqual(r.assignmentCount,4);
 assert.strictEqual(r.automaticSectionCreation,false);
}
let r=audit({section_assignments:[{role:'backing',section:'chorus'}]},{lyrics:'[Verse 1]\nLead line'});
assert(r.missing.some(x=>x.code==='VOCAL_SECTION_MISSING'));
r=audit({section_assignments:[{role:'backing',section:'chorus'}]},{lyrics:'[Chorus]\nMain voice'});
assert(r.missing.some(x=>x.code==='VOCAL_ROLE_NOT_PLACED'));
r=audit({section_assignments:[{role:'guest',section:'bridge'}]},{lyrics:'[Bridge – Guest Vocal]\nFeature'});
assert(r.conflicts.some(x=>x.code==='GUEST_SECTION_ROLE_MISMATCH'));
r=audit({section_assignments:[{role:'backing',section:'instrumental'}]},{lyrics:'[Instrumental Break]\n'});
assert(r.conflicts.some(x=>x.code==='BACKING_ON_INSTRUMENTAL_SECTION'));
r=audit({}, {lyrics:'[Verse]\n[Chorus]'});
assert.strictEqual(r.level,'ok');
assert.strictEqual(r.assignmentCount,0);
assert.strictEqual(r.manualSelectionsChanged,false);
assert.strictEqual(r.automaticRewrite,false);
assert(app.includes('STAGE 140 — MANUAL VOCAL SECTION PLACEMENT'));
assert(app.includes('SongDnaManualVocalSectionPlacement'));
console.log('Stage 140 manual vocal section placement: 67 profile iterations + 8 focused assertions passed');
