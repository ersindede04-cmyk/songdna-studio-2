'use strict';
const fs=require('fs');
const path=require('path');
const assert=require('assert');
const root=path.resolve(__dirname,'..');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const match=app.match(/const GLOBAL_MUSIC_DNA=(\{.*?\});/);
assert(match,'Music DNA catalogue must exist');
const catalog=JSON.parse(match[1]);
const engine=require(path.join(root,'three-layer-production-orchestrator.js'));
assert.strictEqual(catalog.music_dna_profiles.length,67);
for(const p of catalog.music_dna_profiles){
 const asText=v=>Array.isArray(v)?v.join(' '):String(v||'');
 const result=engine.build({main:{id:p.id,name:p.name,family:p.primary_genre,promptText:[p.arrangement_guidance,p.instrument_guidance].map(asText).join(' '),elements:[...(p.musical_traits||[]),...(p.tags||[])],musicalTraits:p.musical_traits||[],arrangementGuidance:p.arrangement_guidance},identity:{profileId:p.id,name:p.name,primaryGenre:p.primary_genre,domain:p.music_domain||'unclassified',region:p.region_or_scene,language:'Turkish',definingTraits:p.musical_traits||[],productionGuidance:asText(p.instrument_guidance),vocalGuidance:asText(p.lyrics_guidance),arrangementGuidance:p.arrangement_guidance}});
 assert.strictEqual(result.musicIdentityProfile.profileId,p.id,`${p.id}: profile identity`);
 assert(result.sharedPrompt.includes(p.name),`${p.id}: shared prompt must retain profile name`);
 assert.strictEqual(result.stylesContext,result.lyricsContext,`${p.id}: Styles and Lyrics must share context`);
 assert(result.sharedPrompt.includes('Turkish'),`${p.id}: selected language must be preserved`);
 if(p.instrument_guidance)assert(result.sharedPrompt.includes(asText(p.instrument_guidance).slice(0,24)),`${p.id}: instrument guidance must transfer`);
 if(p.lyrics_guidance)assert(result.sharedPrompt.includes(asText(p.lyrics_guidance).slice(0,24)),`${p.id}: lyric guidance must transfer`);
}
assert(/p\.instrument_guidance/.test(app),'live layer mapping must transfer instrument guidance');
assert(/guidanceText\(mainProfile\?\.lyrics_guidance\)/.test(app),'live identity mapping must transfer lyric guidance');
assert(/makeLyricsPrompt=function\(c\).*?c\.threeLayerProductionPrompt/s.test(app),'Lyrics prompt must receive shared identity');
assert(/buildGeminiStylePrompt=function\(c,baseStyle,exclude\).*?c\.threeLayerProductionPrompt/s.test(app),'Styles prompt must receive shared identity');
for(const rel of ['www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'])
 assert.strictEqual(fs.readFileSync(path.join(root,rel),'utf8'),app,`${rel} must match root app.js`);
console.log('Stage 112 profile guidance live transfer: PASS (67/67 profiles; instrument and lyric guidance; same identity for Styles/Lyrics; selected language; runtime copies synchronized)');
