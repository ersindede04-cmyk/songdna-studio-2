# SONGDNA SMART STUDIO 7.0.0 — Derleme Kiti

Bu kit iki parçayı içerir:

1. `SONGDNA_SMART_STUDIO_7_0_0_STAGE173_KAYNAK.zip` — uygulamanın kaynak paketi.
2. `.github/workflows/build.yml` — GitHub Actions üzerinden test ve Android debug APK derlemesi.

## GitHub Actions ile APK oluşturma

1. Yeni/uygun bir GitHub deposu açın.
2. Kaynak ZIP dosyasını deponun kök dizinine yükleyin.
3. `.github/workflows/build.yml` dosyasını aynı yola, yani `.github/workflows/build.yml` konumuna yükleyin.
4. GitHub deposunda **Actions** sekmesine girin.
5. **SONGDNA SMART STUDIO 7.0.0 Stage173 Android Debug APK** iş akışını seçip **Run workflow** ile başlatın.
6. İş akışı önce kaynak doğrulaması ve regresyon testlerini çalıştırır; başarılı olursa debug APK ile SHA-256 dosyasını Actions artifact olarak sunar.

Bu iş akışı debug APK üretir; imzalı release APK üretmez. Canlı Gemini için sunucu tarafında `APP_ACCESS_TOKEN` ve `GEMINI_API_KEY` yapılandırılmalıdır. Gizli anahtarları uygulama kaynaklarına veya APK içine eklemeyin.
