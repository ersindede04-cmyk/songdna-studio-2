# SONGDNA SMART STUDIO 7.5.0 — Stage187

## Amaç
Stage186 GitHub Actions çalışmasında görülen `Stage180 verifier copy mismatch` hatasını gidermek.

## Yapılan düzeltme
- `scripts/verify-source.py` tek doğruluk kaynağı olarak alındı.
- `www/scripts/verify-source.py` ve Android WebView içindeki kopya bu dosyayla byte-byte eşitlendi.
- Stage186 kaynak yapısı ve ürün özellikleri korundu.
- Tema/konu kütüphaneleri, Music DNA kataloğu, otomatik seçim sırası ve normal üretim uç noktaları değiştirilmedi.

## Yerel doğrulama
- `python scripts/verify-source.py`: başarılı.
- GitHub Actions, Render, canlı Gemini, fiziksel Android ve Suno doğrulamaları henüz yapılmadı.
- APK bu pakette önceden oluşturulmuş değildir; GitHub Actions üretmelidir.
