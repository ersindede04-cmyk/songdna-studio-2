# Stage187 GitHub yükleme

Depo köküne `SONGDNA_SMART_STUDIO_7_5_0_STAGE187_KAYNAK_PAKETI.zip` dosyasını yükleyin.
`.github/workflows/build.yml` dosyasını Stage187 için verilen tam YAML içeriğiyle değiştirin.
ZIP'i açıp tek tek dosya yüklemeyin; workflow bu tam adlı arşivi doğrulayıp açar.
