'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const backend = fs.readFileSync(path.join(root, 'backend/server.js'), 'utf8');
const rootServer = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const app = fs.readFileSync(path.join(root, 'www/app.js'), 'utf8');
const render = fs.readFileSync(path.join(root, 'render.yaml'), 'utf8');
const checks = [
  ['Render entrypoint is the packaged backend', render.includes('rootDir: backend')],
  ['Story blend endpoint is allowlisted', backend.includes("'/api/story-blend'")],
  ['Story blend task is routed', backend.includes("url.pathname === '/api/story-blend'")],
  ['Story response contract is returned', backend.includes('story: result.text')],
  ['Client calls the matching endpoint', app.includes("postGemini('/api/story-blend',prompt)")],
  ['Client reads the story response field', app.includes('response.story||response.text')],
  ['Health reports Stage185', backend.includes("stage: 185")],
  ['Health advertises storyBlend', backend.includes('storyBlend: true')],
  ['Normal lyrics endpoint remains allowlisted', backend.includes("'/api/lyrics'")],
  ['Normal style endpoint remains allowlisted', backend.includes("'/api/style'")],
  ['Root and backend server copies are identical', rootServer === backend]
];
let failed = 0;
for (const [label, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} ${label}`);
  if (!ok) failed++;
}
console.log(`\n${checks.length - failed}/${checks.length} checks passed`);
if (failed) process.exit(1);
