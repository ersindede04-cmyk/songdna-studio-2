'use strict';
const fs=require('fs');
const vm=require('vm');
const source=fs.readFileSync('app.js','utf8');
function assert(ok,message){if(!ok)throw new Error(message);}
assert(source.includes('STAGE 128 — PRIMARY MUSIC DNA SIGNATURE'),'Stage 128 policy missing');
assert(source.includes('globalThis.SongDnaMusicDnaStyleAnchors={audit:auditMusicDnaStyleAnchors,automaticRewrite:false,minimumAnchors:1}'),'Runtime audit API missing');
assert(source.includes('Do not force every catalog trait into every song'),'Must not force every trait');
assert(source.includes('Manual choices remain authoritative'),'Manual selection priority missing');
const start=source.indexOf('const GLOBAL_MUSIC_DNA=')+'const GLOBAL_MUSIC_DNA='.length;
const end=source.indexOf(';\nconst TECHNIQUE_MODULES',start);
assert(start>0&&end>start,'Music DNA catalog declaration not found');
const catalog=vm.runInNewContext('('+source.slice(start,end)+')');
const profiles=catalog.music_dna_profiles;
assert(profiles.length===69,`Expected 69 profiles, found ${profiles.length}`);
const fnStart=source.indexOf('function auditMusicDnaStyleAnchors(style,profile){');
const fnEnd=source.indexOf('\nfunction auditSunoIdentityConsistency',fnStart);
assert(fnStart>=0&&fnEnd>fnStart,'Profile anchor audit function not found');
const audit=vm.runInNewContext(source.slice(fnStart,fnEnd)+'; auditMusicDnaStyleAnchors;');
let checked=0;
for(const profile of profiles){
 const traits=Array.isArray(profile.musical_traits)?profile.musical_traits:[];
 const style=traits.join(', ');
 const result=audit(style,profile);
 if(traits.some(x=>String(x).trim().split(/\s+/).filter(Boolean).length)){
  assert(result.level==='ok',`${profile.id} failed with its documented traits: ${result.issues.join('; ')}`);
  checked++;
 }
}
assert(checked===69,`Expected all 69 profiles to be checked, got ${checked}`);
const first=profiles[0];
const missing=audit('professional polished high quality',first);
assert(missing.level==='warning','Generic Styles should warn when profile anchors are absent');
const pending=audit('some style',null);
assert(pending.level==='pending','Missing profile should remain pending');
const shortProfile={id:'TEST',musical_traits:['interlocking offbeat percussion','layered polyrhythm']};
assert(audit('interlocking offbeat percussion, layered polyrhythm',shortProfile).level==='ok','Specific anchors should pass');
console.log(`Stage 128: ${68+7} assertions passed (68 profile coverage checks)`);
