# SONGDNA Studio 4.0.2 — GitHub kurulumu

1. ZIP'i açın ve içindeki proje dosyalarını GitHub deposunun kök dizinine yükleyin; `SONGDNA-Studio-4.0.2` klasörünü iç içe ikinci kez koymayın.
2. `android-wrapper`, `backend`, `www`, `scripts` ve `.github` klasörlerinin depo kökünde bulunduğunu doğrulayın.
3. GitHub → Actions bölümünü açın.
4. **SONGDNA Studio 4.0.2 - Android APK** iş akışını seçin ve **Run workflow** düğmesine basın.
5. İşlem başarılı olursa Artifacts bölümünden `SONGDNA-Studio-4.0.2-debug-APK` dosyasını indirin.
6. İmzalı Release APK yalnızca aşağıdaki dört GitHub Secret tanımlanmışsa ayrıca oluşturulur: `SONGDNA_KEYSTORE_BASE64`, `SONGDNA_KEYSTORE_PASSWORD`, `SONGDNA_KEY_ALIAS`, `SONGDNA_KEY_PASSWORD`.

## İmzalama güvenliği

- Keystore dosyasını GitHub deposuna yüklemeyin ve ZIP içine koymayın.
- Base64 keystore içeriğini ve parolaları yalnızca GitHub Actions Secrets alanında saklayın.
- Aynı uygulamanın sonraki sürümlerini güncelleyebilmek için aynı keystore ve alias korunmalıdır.
- Bu sırlar yoksa debug APK yine derlenir; workflow imzalı release APK üretmeden tamamlanabilir.

## Render / Gemini notları

- Render ortamında `APP_ACCESS_TOKEN`, `GEMINI_API_KEY`, `GEMINI_MODEL`, `GEMINI_MODELS`, `ALLOWED_ORIGIN=*` ve `TRUST_PROXY` değerlerini ayarlayın.
- `TRUST_PROXY=true` değerini yalnızca Render proxy'sinin `X-Forwarded-For` başlığını güvenli biçimde yenilediğini doğruladıktan sonra kullanın.
- Android WebView yerel dosya kaynağı kullandığından bu uygulama için `ALLOWED_ORIGIN=*` bırakılmalıdır.
- Ücret ödememek için Google AI Studio projesini Free Tier üzerinde tutun ve Google Cloud faturalandırmasını etkinleştirmeyin. Kod Pro/çok modlu modellere otomatik geçiş yapmaz; ancak Flash modelinin ücretli/ücretsiz tarifesi Google projesinin faturalandırma seviyesine bağlıdır.
