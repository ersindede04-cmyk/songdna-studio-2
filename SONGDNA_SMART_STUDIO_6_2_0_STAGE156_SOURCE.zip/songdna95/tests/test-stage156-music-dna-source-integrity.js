'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const catalog = JSON.parse(fs.readFileSync(path.join(root, 'data/music_dna_global_v1_1.json'), 'utf8'));
const profiles = catalog.music_dna_profiles;
assert.equal(profiles.length, 67, 'Music DNA catalogue must retain all 67 profiles');
assert.equal(new Set(profiles.map(p => p.id)).size, 67, 'Music DNA IDs must remain unique');
const sourceIds = new Set(catalog.sources.map(s => s.id));
const required = ['id','slug','name','primary_genre','region_or_scene','tags','musical_traits','mood_atmosphere','arrangement_guidance','prompt_guidance','evidence_status','source_refs','classic_arrangement_guidance','modern_arrangement_guidance','hybrid_arrangement_guidance'];
for (const p of profiles) {
  for (const key of required) assert.ok(p[key] !== undefined && p[key] !== null, `${p.id} missing ${key}`);
  for (const ref of p.source_refs) assert.ok(sourceIds.has(ref), `${p.id} has unresolved source ref ${ref}`);
}
const folk = profiles.find(p => p.id === 'MDNA-067');
assert.deepEqual(folk.source_refs, [], 'General curated Turkish folk identity must not claim a nonexistent external source');
assert.match(folk.evidence_status, /Editorially curated general Turkish folk identity/);
assert.match(folk.evidence_status, /Regional details require user selection/);
const runtimeCopies = ['app.js','www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'];
for (const rel of runtimeCopies) {
  const source = fs.readFileSync(path.join(root, rel), 'utf8');
  assert.ok(source.includes('"source_refs":[]'), `${rel} must carry corrected embedded catalogue`);
  assert.ok(source.includes('Editorially curated general Turkish folk identity; not an externally sourced regional claim. Regional details require user selection.'), `${rel} must carry corrected evidence status`);
}
console.log('Stage156 Music DNA source integrity: 67 profiles, unique IDs, complete required fields, all source refs resolved, MDNA-067 corrected, four runtime copies aligned.');
