# SONGDNA Studio 5.0.0 — Gemini-first Android source

SONGDNA Studio prepares original lyrics and Suno-ready music-style prompts. It does **not** generate audio. Version 4.6.1 preserves the existing catalogues and separate Suno output areas, and adds Gemini-powered natural-language command interpretation.

## Preserved product features
- 18 Music DNA packages.
- Intro DNA catalogue 14–33, plus existing regional intro options.
- PRESERVE controls: short, long and disabled.
- Gemini AI workflow with separate `/api/command`, `/api/lyrics` and `/api/style` endpoints.
- Separate STYLES and LYRICS outputs; EXCLUDE remains separate.
- Local archive, copy/share actions, settings and About screen.
- Exact About copyright: `© 2026 SONGDNA Studio – Tüm hakları saklıdır.`
- Stable Android application ID `com.songdna.studio` and monotonic versionCode 21.

## 4.3.0 reliability and safety changes (retained)
- Gemini model list is read from backend environment variables and filtered through a Flash-only allowlist. Paid-only model IDs cannot be configured.
- Default model is `gemini-3.1-flash-lite`; fallback models are explicitly configured. There is no automatic switch to a Pro or multimodal model. **Important:** the model name alone cannot guarantee zero cost. Google applies the billing tier configured on the Google Cloud project. To keep API use free, leave the project on Google AI Studio Free Tier and do not enable billing or attach a paid billing account. Free-tier quotas and availability remain subject to Google's account, region and rate limits.
- Backend generation has a shared 78-second budget and 24-second per-model timeout; frontend allows up to 150 seconds to accommodate host cold starts.
- If the app disconnects, the backend cancels its upstream Gemini request rather than continuing unnecessary work.
- Removed obsolete generation temperature settings.
- `/health` publishes the configured safe model list and default; the app updates its selector dynamically.
- Web JavaScript is maintained as `www/app.js`; Android WebView ships an identical copy.
- Android backup is disabled to reduce the chance of local archive and access-token data being included in device backups.
- Error messages distinguish network, timeout, authentication, quota and server failures without exposing API keys.

## Important deployment settings
Configure these variables on the backend host:
- `APP_ACCESS_TOKEN`: required, random and at least 12 characters; enter the same value in the app.
- `GEMINI_API_KEY`: Google AI Studio API key; server-side only. Never place it in the APK or repository.
- `GEMINI_MODEL`: preferred Flash model; default `gemini-3.1-flash-lite`.
- `GEMINI_MODELS`: comma-separated fallback list. The backend rejects model IDs outside its approved Flash-only allowlist; Pro and multimodal models are not accepted.
- `ALLOWED_ORIGIN=*`: required for this Android `file://` WebView build. The app token is also required. Do not replace this with the Render domain for this APK, because local file origins may send `null`.
- `TRUST_PROXY=false` by default. On Render, set `true` only after confirming the trusted proxy overwrites `X-Forwarded-For`; this affects per-IP throttling and failed-token lockouts.

The API uses standard Gemini Flash text generation only; it does not invoke search grounding, audio, video or image services. Flash models may still be billed if the Google project is on a paid billing tier. Free-tier use is not unlimited, and Google may enforce quotas. Avoid sending sensitive or confidential lyrics. Review Google's current [Gemini API pricing and data-use terms](https://ai.google.dev/gemini-api/docs/pricing) before deployment.

## Backend local test
```bash
cd backend
cp .env.example .env
# Set APP_ACCESS_TOKEN and GEMINI_API_KEY in .env.
node server.js
```

## Android build
The GitHub Actions workflow runs source validation and builds a debug APK with Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21 and Java 17. A signed release APK is produced only when all four signing secrets are configured: `SONGDNA_KEYSTORE_BASE64`, `SONGDNA_KEYSTORE_PASSWORD`, `SONGDNA_KEY_ALIAS`, `SONGDNA_KEY_PASSWORD`. Keep the keystore private and preserve it for all future app updates; never commit it to GitHub.

## Verification boundaries
Run `python3 scripts/verify-source.py` before committing. It checks source layout, Web/Android asset parity, Android XML, model policy, JS/backend syntax and retained features. A successful source check does **not** prove a remote APK build, physical-device behavior, Render deployment or live Gemini response. Those still require GitHub Actions and real-device/live-service tests.

## 4.3.2 complete interface localization
- Added a shared Turkish/English interface dictionary for the main creation, template, results, settings, intro, vocal, AI configuration and About screens.
- English is the default interface language. Automatic follows the device language (Turkish when the device locale is Turkish; English for other/unsupported locales). Manual Turkish/English selection is saved and applied after reload.
- Dynamically inserted UI labels and options are localized as they are added. User-entered lyrics, themes, custom instructions and generated output areas are deliberately excluded from translation.
- Kept song-language selection independent from interface language.
- Updated web and Android WebView JavaScript assets in lockstep.


## 4.5.0 Birleştirilmiş müzik kütüphanesi

- Tam katalog: `data/SONGDNA_4_5_0_Complete_Research_Catalog.json`
- Geriye dönük uyumluluk kopyası: `data/music_dna_global_v1_1.json`
- İki JSON dosyası aynı birleştirilmiş içeriği taşır. Web uygulamasındaki `GLOBAL_MUSIC_DNA` nesnesi de aynı katalogla eşleştirilmiştir.
- Katalogda 66 Music DNA profili, 47 enstrüman/teknik, 16 ritim, 14 vokal, 12 intro modülü ve 50 kaynak kaydı bulunur.
- Araştırma profilleri MDNA-041–MDNA-066 aralığında; önceki 001–040 profilleri korunmuştur.


## 4.8.0 Natural-language command interpreter

- The new command box accepts a free-form song brief in the user's own language.
- `/api/command` asks Gemini to return structured JSON containing only clearly specified settings.
- The app applies recognized genre, song language, fusion, energy, vocal, ad-lib, effect, technique, BPM, theme and creative-note settings.
- Unmentioned settings remain unchanged. Interface language and song language remain independent.
- The user reviews the applied choices and then starts the existing Lyrics/Styles generation flow.
- Deploy the updated `backend/server.js` to Render as well as publishing the Android/Web source; the new endpoint is not available on an older backend deployment.


## 4.8.0 Editable natural-language command templates
- Added 12 optional starter commands for common language/genre/vocal combinations.
- Selecting a template fills the existing Gemini natural-language command field; the user can freely edit or replace any wording before submission.
- Existing `/api/command` interpretation remains the only command endpoint. Explicitly mentioned settings are applied; omitted settings remain unchanged.
- Existing two Suno output fields (STYLES and LYRICS), Music DNA catalogue, regional/intro modules and generation flow are retained.


## 4.8.0 creative modes
- Automatic Template, Gemini Free Creativity and Hybrid Creativity modes.
- Manual Favorites archive; automatic rolling lyric memory removed.
- Only a small recent-topic diversity list is retained locally; no lyrics or Styles are stored in it or sent back to Gemini.
