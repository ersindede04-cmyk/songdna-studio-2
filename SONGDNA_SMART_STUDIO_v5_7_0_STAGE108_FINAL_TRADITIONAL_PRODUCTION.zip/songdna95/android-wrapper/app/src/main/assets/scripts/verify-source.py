#!/usr/bin/env python3
"""Static source integrity checks for SONGDNA Studio 5.7.0."""
from pathlib import Path
import json, re, shutil, subprocess, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ["index.html", "app.js", "saved-library.js", "production-history.js",
           "adlib-catalog.js", "scene-jargon-catalog.js", "global-cultural-adlib.js", "genre-adlib-engine.js", "integrated-production-engine.js"]
REQUIRED = [
    ".github/workflows/build.yml", "BUILD_MANIFEST.json", "README.md",
    "android-wrapper/settings.gradle.kts", "android-wrapper/build.gradle.kts",
    "android-wrapper/gradle.properties", "android-wrapper/app/build.gradle.kts",
    "android-wrapper/app/src/main/AndroidManifest.xml",
    "android-wrapper/app/src/main/java/com/songdna/studio/MainActivity.kt",
    "backend/server.js", "backend/package.json", "backend/.env.example",
    "scripts/test-stage29-client-api-contract.js", "tests/test-stage29-api-contract.js",
    "scripts/test-stage28-cultural-routing.js", "scripts/test-global-cultural-adlib.js",
    "tests/test-saved-library.js", "tests/test-production-history.js",
]
for folder in ("www", "android-wrapper/app/src/main/assets/www"):
    REQUIRED.extend(f"{folder}/{name}" for name in RUNTIME)
missing = [x for x in REQUIRED if not (ROOT / x).is_file()]
if missing:
    raise SystemExit("FAIL missing files:\n- " + "\n- ".join(missing))
print("PASS required Android, backend, test and runtime files")

web_dir = ROOT / "www"
android_dir = ROOT / "android-wrapper/app/src/main/assets/www"
for name in RUNTIME:
    if (web_dir / name).read_bytes() != (android_dir / name).read_bytes():
        raise SystemExit(f"FAIL web/Android asset mismatch: {name}")
html = (web_dir / "index.html").read_text(encoding="utf-8")
for src in re.findall(r'<script[^>]+src="([^"]+)"', html):
    if not (web_dir / src).is_file():
        raise SystemExit(f"FAIL missing HTML script dependency: {src}")
print("PASS all runtime Web/Android assets and HTML script dependencies")

for path in (ROOT / "android-wrapper/app/src/main").rglob("*.xml"):
    ET.parse(path)
print("PASS Android XML parsing")

manifest = json.loads((ROOT / "BUILD_MANIFEST.json").read_text(encoding="utf-8"))
pkg = json.loads((ROOT / "backend/package.json").read_text(encoding="utf-8"))
gradle = (ROOT / "android-wrapper/app/build.gradle.kts").read_text()
settings = (ROOT / "android-wrapper/settings.gradle.kts").read_text()
workflow = (ROOT / ".github/workflows/build.yml").read_text()
checks = {
    manifest.get("version") == "5.7.0": "manifest version 5.7.0",
    manifest.get("android", {}).get("version_name") == "5.7.0": "manifest Android version name",
    manifest.get("android", {}).get("version_code") == 27: "manifest Android version code 31",
    'versionName = "5.7.0"' in gradle and "versionCode = 31" in gradle: "Gradle app version 5.7.0 / code 31",
    pkg.get("version") == "5.7.0" and pkg.get("engines", {}).get("node", "").startswith(">="): "backend package metadata",
    'applicationId = "com.songdna.studio"' in gradle: "stable Android application ID",
    'rootProject.name = "SONG-DNA-SMART-STUDIO-5.7.0"' in settings: "Gradle project name",
    "gradle-version: '8.9'" in workflow and "assembleDebug" in workflow: "GitHub Actions Android debug build",
    "SONGDNA_KEYSTORE_BASE64" in workflow and "assembleRelease" in workflow: "optional signed release build",
    "SONGDNA-Studio-5.7.0-current-source-debug-APK" in workflow: "5.7.0 APK artifact label",
}
failed = [label for ok, label in checks.items() if not ok]
if failed:
    raise SystemExit("FAIL build configuration: " + ", ".join(failed))
print("PASS 5.7.0 build metadata, versionCode 27 and GitHub workflow")

node = shutil.which("node")
if not node:
    raise SystemExit("FAIL Node.js required")
for path in [web_dir / name for name in RUNTIME if name.endswith(".js")] + [ROOT / "backend/server.js"]:
    result = subprocess.run([node, "--check", str(path)], capture_output=True, text=True)
    if result.returncode:
        raise SystemExit(f"FAIL JavaScript syntax {path.relative_to(ROOT)}:\n{result.stderr}")
print("PASS JavaScript syntax")

js = (web_dir / "app.js").read_text(encoding="utf-8")
backend = (ROOT / "backend/server.js").read_text(encoding="utf-8")
if "GEMINI_API_KEY" in js:
    raise SystemExit("FAIL Gemini API key reference in client")
for endpoint in ["/api/lyrics", "/api/style", "/api/command"]:
    if endpoint not in js or endpoint not in backend:
        raise SystemExit(f"FAIL API endpoint contract: {endpoint}")
if "APP_ACCESS_TOKEN" not in backend or "ALLOWED_FLASH_MODELS" not in backend:
    raise SystemExit("FAIL backend auth/model restrictions")
if "Styles" not in html or "Lyrics" not in html:
    raise SystemExit("FAIL two primary output areas missing")
if "audio-player" in html.lower() or "<audio" in html.lower():
    raise SystemExit("FAIL audio player found; product is a prompt/lyrics helper")
print("PASS API contract, backend safeguards, two output areas and generator-only identity")

# Legacy app-specific invariants retained from the 5.1.1 source.
for token in ["PRESERVE", "styleGenerate", "interpretCommand"]:
    if token not in js and token not in html:
        raise SystemExit(f"FAIL retained feature missing: {token}")
if "© 2026 SONGDNA Studio – Tüm hakları saklıdır." not in html:
    raise SystemExit("FAIL About copyright text missing")
print("ALL STATIC SOURCE CHECKS PASSED. Remote GitHub APK build, Render deployment, live Gemini and physical-device tests remain separate.")
