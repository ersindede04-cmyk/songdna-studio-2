/* SONGDNA SMART STUDIO — Stage 95: Three-Layer Production Orchestrator
 * Coordinates the three user-selected production roles through one shared context.
 * Advisory/prompt planning only. It does not process audio or silently alter selections.
 */
(function(root){
 'use strict';
 const ROLES = Object.freeze([
  {key:'main', label:'Ana Prodüksiyon', priority:'primary',
   instruction:'Establish the song’s main musical identity. This layer may stand alone and must remain the dominant identity.'},
  {key:'secondary', label:'Alt Katman 2', priority:'secondary',
   instruction:'Add only the explicitly selected second musical influence. Support the main identity; do not replace it.'},
  {key:'helper', label:'Yardımcı Prodüksiyon', priority:'support',
   instruction:'Add complementary production texture or elements. Do not introduce an unselected genre or compete with the lead identity.'}
 ]);
 const clean = v => String(v == null ? '' : v).trim();
 const copy = v => { try { return JSON.parse(JSON.stringify(v)); } catch (_) { return {}; } };
 const hasSelection = layer => !!(clean(layer?.id) || clean(layer?.name) || clean(layer?.profileName) || clean(layer?.promptText));
 function normalizeLayer(role, value){
  const layer = value && typeof value === 'object' ? copy(value) : {};
  const selected = hasSelection(layer);
  return {
   role: role.key, label: role.label, priority: role.priority,
   selected,
   id: clean(layer.id) || null,
   name: clean(layer.name || layer.profileName) || null,
   family: clean(layer.family) || null,
   promptText: clean(layer.promptText || layer.description || layer.styleText),
   elements: Array.isArray(layer.elements) ? layer.elements.map(clean).filter(Boolean) : [],
   musicalTraits: Array.isArray(layer.musicalTraits) ? layer.musicalTraits.map(clean).filter(Boolean) : [],
   genreTags: Array.isArray(layer.genreTags) ? layer.genreTags.map(clean).filter(Boolean) : [],
   arrangementGuidance: clean(layer.arrangementGuidance),
   source: clean(layer.source) || 'user-selection'
  };
 }
 function analyze(input={}){
  const built=build(input);
  const layers=built.layers;
  const main=layers.find(x=>x.role==='main');
  const secondary=layers.find(x=>x.role==='secondary');
  const helper=layers.find(x=>x.role==='helper');
  const notes=[];
  const alternatives=[];
  const selected=layers.filter(x=>x.selected);
  const identity=x=>clean(x?.id)||clean(x?.name).toLocaleLowerCase('tr-TR');
  // Extract only explicit, high-confidence musical characteristics from catalog text.
  const describe=x=>{
   const text=[x?.family,x?.name,x?.promptText,x?.arrangementGuidance,...(x?.elements||[]),...(x?.musicalTraits||[]),...(x?.genreTags||[])].join(' ').toLocaleLowerCase('tr-TR');
   const has=re=>re.test(text);
   return {
    pulse: has(/unmetered|free compositional|free[- ]time|unmeasured|serbest ritim|ölçüsüz/) ? 'free' :
     has(/four[- ]on[- ]the[- ]floor|four on floor/) ? 'four-on-floor' :
     has(/broken[- ]beat|breakbeat|break beats|shuffled|shuffle|swing pocket/) ? 'broken-or-shuffled' :
     has(/half[- ]time/) ? 'half-time' :
     has(/straight (?:4\/4|four|pulse)|rigid (?:4\/4|four)|steady dance pulse|fixed (?:meter|pulse)/) ? 'straight-pulse' : null,
    vocal: has(/multiple independent vocal lines|independent vocal lines|polyphonic vocal|four[- ]part.*vocal|three[- ]part.*vocal/) ? 'polyphonic' :
     has(/single lead vocalist|solo lead vocal|one lead vocalist|lead vocal(?:ist)? as the sole/) ? 'solo-lead' : null,
    bass: has(/sliding 808|808 glide/) ? 'sliding-808' : has(/log[- ]drum/) ? 'log-drum' : null
   };
  };
  const descriptors=Object.fromEntries(selected.map(x=>[x.role,describe(x)]));
  const compare=(left,right)=>{
   if(!left?.selected||!right?.selected)return;
   const a=descriptors[left.role]||{},b=descriptors[right.role]||{};
   const add=(code,message,alternative)=>{notes.push({code,severity:'warning',message,roles:[left.role,right.role]});alternatives.push(alternative);};
   if(a.pulse&&b.pulse&&a.pulse!==b.pulse){
    const pair=[a.pulse,b.pulse].sort().join('|');
    const known=[ 'broken-or-shuffled|four-on-floor','broken-or-shuffled|straight-pulse','free|straight-pulse','free|half-time','four-on-floor|free','four-on-floor|half-time' ];
    if(known.includes(pair))add('RHYTHMIC_FOUNDATION_DIFFERENCE',`${left.label} ve ${right.label} farklı ritmik temel/pulse yaklaşımları taşıyor (${a.pulse} / ${b.pulse}); bunlar aynı anda tek ana groove gibi uygulanırsa yön belirsizleşebilir.`, 'Ana katmanın pulse kimliğini koru; farklı ritmik yaklaşımı ayrı bölüm, geçiş veya kontrollü kontrast olarak kullan.');
   }
   if(a.vocal&&b.vocal&&a.vocal!==b.vocal)add('VOCAL_ARRANGEMENT_ROLE_DIFFERENCE',`${left.label} ve ${right.label} farklı vokal düzeni beklentileri içeriyor (${a.vocal} / ${b.vocal}); vokal rolleri üst üste bindirilmeden düzenlenmeli.`, 'Ana vokal düzenini koru; diğer vokal yaklaşımını cevap, arka plan veya ayrı bölüm olarak konumlandır.');
   if(a.bass&&b.bass&&a.bass!==b.bass)add('BASS_IDENTITY_OVERLAP',`${left.label} ve ${right.label} farklı belirgin bas karakterleri içeriyor (${a.bass} / ${b.bass}); iki bas motifi aynı anda baskınlaşabilir.`, 'Bir bas karakterini ana taşıyıcı yap; diğerini seyrek cevap veya ayrı bölümde kullan.');
  };
  compare(main,secondary); compare(main,helper); compare(secondary,helper);
  if(secondary.selected&&helper.selected&&identity(secondary)===identity(helper)){
   notes.push({code:'DUPLICATE_LAYER_PROFILE',severity:'conflict',message:'Alt Katman 2 ve Yardımcı Prodüksiyon aynı profili kullanıyor; iki katmanda aynı kimlik tekrar ediyor.'});
   alternatives.push('Yardımcı katmanda farklı ve tamamlayıcı bir profil seçilebilir.');
  }
  if(main.selected&&secondary.selected&&identity(main)===identity(secondary)){
   notes.push({code:'MAIN_SECONDARY_DUPLICATE',severity:'warning',message:'Ana Prodüksiyon ve Alt Katman 2 aynı profili kullanıyor; ikinci katman yeni bir katkı sağlamayabilir.'});
   alternatives.push('Alt Katman 2 için farklı bir müzikal etki değerlendirilebilir.');
  }
  if(main.selected&&helper.selected&&identity(main)===identity(helper)){
   notes.push({code:'MAIN_HELPER_DUPLICATE',severity:'warning',message:'Yardımcı Prodüksiyon ana profili tekrar ediyor; tamamlayıcı katman işlevi zayıflayabilir.'});
   alternatives.push('Yardımcı katmanda ana kimliği destekleyen farklı bir profil veya doku kullanılabilir.');
  }
  if(!main.selected&&selected.length>1){
   notes.push({code:'MISSING_PRIMARY_IDENTITY',severity:'warning',message:'Ana Music DNA seçilmedi; yalnızca açıkça seçilmiş geleneksel teknik kimliği ana dayanak olarak kullanılabilir. Alt ve yardımcı katmanlar kendiliğinden ana kimliğe dönüşmez.'});
  }
  const level=notes.some(n=>n.severity==='conflict')?'conflict':notes.length?'experimental':'compatible';
  const uniqueNotes=notes.filter((n,i,a)=>a.findIndex(x=>x.code===n.code&&JSON.stringify(x.roles||[])===JSON.stringify(n.roles||[]))===i);
  const finalLevel=uniqueNotes.some(n=>n.severity==='conflict')?'conflict':uniqueNotes.length?'experimental':'compatible';
  return {level:finalLevel,label:finalLevel==='conflict'?'ÇATIŞMA':finalLevel==='experimental'?'DİKKAT':'UYUMLU',notes:uniqueNotes,alternatives:[...new Set(alternatives)].slice(0,5),characteristics:descriptors,canProceed:true,advisoryOnly:true,selectionChanged:false,selectedRoles:built.selectedRoles};
 }
 function build(input={}){
  const layers = ROLES.map(role => normalizeLayer(role, input[role.key]));
  const main = layers[0];
  const selected = layers.filter(x => x.selected);
  const warnings = [];
  if(!main.selected && selected.length){
   warnings.push({code:'MISSING_MAIN',severity:'warning',message:'Ana Prodüksiyon seçilmeden alt katmanlar tek başına ana kimlik olarak yorumlanmaz.'});
  }
  if(!selected.length){
   warnings.push({code:'NO_SELECTION',severity:'info',message:'Henüz prodüksiyon katmanı seçilmedi; hiçbir katman otomatik eklenmedi.'});
  }
  const identity = main.selected ? (main.name || main.id || 'Kullanıcının ana prodüksiyonu') : null;
  const sharedContext = {
   version:'1.0', primaryIdentity:identity,
   selectedRoles:selected.map(x=>x.role),
   selectedLayers:selected.map(x=>({role:x.role,id:x.id,name:x.name,family:x.family,elements:[...x.elements]})),
   manualSelectionWins:true,
   autoFilled:false,
   blankLayersRemainBlank:true
  };
  const promptSections = layers.filter(x=>x.selected).map(layer=>{
   const role=ROLES.find(r=>r.key===layer.role);
   const content=[role.instruction, layer.name ? `Selected profile: ${layer.name}.` : '',
    layer.family ? `Profile family: ${layer.family}.` : '',
    layer.promptText, layer.elements.length ? `Selected production elements: ${layer.elements.join(', ')}.` : ''
   ].filter(Boolean).join(' ');
   return {role:layer.role,label:layer.label,text:content};
  });
  const sharedPrompt = [
   'THREE-LAYER PRODUCTION CONTEXT:',
   main.selected ? `Primary musical identity: ${identity}. Preserve this identity as the dominant foundation.` : 'No main production identity was selected. Do not invent one.',
   ...promptSections.map(x=>`${x.label}: ${x.text}`),
   'All selected layers share one production context. Resolve overlaps and contradictions through advisory compatibility checks; never silently replace, delete, or rewrite a user selection.',
   'Keep unselected layers empty. Do not auto-fill missing layers.',
   'Styles and Lyrics must use this same final production context while retaining their own output purpose.'
  ].join(' ');
  return {
   version:'1.0', layers, selectedRoles:sharedContext.selectedRoles,
   sharedContext, promptSections, sharedPrompt,
   stylesContext:sharedPrompt,
   lyricsContext:sharedPrompt,
   warnings, canProceed:true
  };
 }
 root.SongDnaThreeLayerProductionOrchestrator={version:'1.1',roles:ROLES,build,analyze};
 if(typeof module!=='undefined'&&module.exports) module.exports=root.SongDnaThreeLayerProductionOrchestrator;
})(typeof globalThis!=='undefined'?globalThis:this);
