plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.songdna.studio"
    compileSdk = 35

    // Keep Java and Kotlin bytecode targets aligned (prevents the 1.8 vs 17 failure).
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    val releaseStoreFile = System.getenv("SONGDNA_KEYSTORE_FILE")
    val releaseStorePassword = System.getenv("SONGDNA_KEYSTORE_PASSWORD")
    val releaseKeyAlias = System.getenv("SONGDNA_KEY_ALIAS")
    val releaseKeyPassword = System.getenv("SONGDNA_KEY_PASSWORD")

    signingConfigs {
        if (!releaseStoreFile.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() &&
            !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()) {
            create("release") {
                storeFile = file(releaseStoreFile)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        getByName("release") {
            if (!releaseStoreFile.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() &&
                !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
            isMinifyEnabled = false
        }
    }

    defaultConfig {
        applicationId = "com.songdna.studio"
        minSdk = 23
        targetSdk = 35
        versionCode = 34
        versionName = "6.2.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
