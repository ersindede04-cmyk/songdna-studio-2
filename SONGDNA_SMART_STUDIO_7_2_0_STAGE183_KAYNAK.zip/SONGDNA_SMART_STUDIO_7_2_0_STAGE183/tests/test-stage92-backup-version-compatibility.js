const assert=require('node:assert/strict');
const backup=require('../data-backup.js');
function storage(seed={}){const m=new Map(Object.entries(seed));return{getItem:k=>m.has(k)?m.get(k):null,setItem(k,v){m.set(k,String(v))},removeItem:k=>m.delete(k),dump:()=>Object.fromEntries(m)}}
const payload=backup.create(storage({songdna_history:'[]',songdna_saved:'[]'}));
assert.equal(payload.appVersion,'7.2.0');
assert.equal(backup.validate(payload).songdna_history,'[]');
// Older application backups remain importable.
const older={...payload,appVersion:'5.1.9'};older.checksum=backup.checksum(older.data);
assert.equal(backup.validate(older).songdna_saved,'[]');
// Stage91 version-2 files without appVersion remain backward compatible.
const stage91={...payload};delete stage91.appVersion;
assert.equal(backup.validate(stage91).songdna_history,'[]');
// Stage90 version-1 backups remain importable.
const legacy={format:'songdna-local-backup',version:1,createdAt:'2026-11-20T00:00:00.000Z',data:{songdna_history:'legacy'}};
assert.equal(backup.validate(legacy).songdna_history,'legacy');
// A backup from a newer app must not be silently downgraded.
assert.throws(()=>backup.validate({...payload,appVersion:'7.3.0'}),/daha yeni/);
assert.throws(()=>backup.validate({...payload,appVersion:'5.x'}),/sürümü geçersiz/);
// Unknown fields must be reported instead of silently discarded.
const unknown={...payload,data:{...payload.data,songdna_future_feature:'important'}};
assert.throws(()=>backup.validate(unknown),/tanımadığı/);
// A failed restore leaves existing data untouched.
const target=storage({songdna_history:'keep'});
const invalid={...payload,data:{songdna_history:'replace',unknown_key:'x'}};
assert.throws(()=>backup.restore(target,invalid));
assert.equal(target.getItem('songdna_history'),'keep');
console.log('Stage92 backup version compatibility tests passed.');
