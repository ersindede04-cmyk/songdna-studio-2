# QA Report — Stage 127: Styles Information Density

## Scope
Improve the useful musical information carried by each Styles character without silently rewriting output.

## Changes
- Added Gemini guidance to use compact role-and-behavior descriptors.
- Prefer audible instructions over generic praise and adjective chains.
- Added advisory audit for repeated comma/semicolon segments, generic-only praise fragments, and low lexical diversity.
- Audit is non-destructive: no automatic rewrite, deletion, or substitution of user/model text.
- Preserved the primary Music DNA, manual choices, existing 1000-character validation, two output fields, and Lyrics flow.

## Validation
- Stage 127 focused assertions: 14/14 passed.
- Stage 126 regression assertions: 10/10 passed.
- JavaScript test files: 58/58 passed.
- Python test files: 6/6 passed.
- `scripts/verify-source.py`: passed; root, web and Android WebView runtime assets/manifests synchronized; HTML dependencies, Android XML and JavaScript syntax passed.
- Live Gemini/Render, Android APK build/install, and actual Suno audio are not covered by source-level tests.
