# SONGDNA SMART STUDIO 6.1.0 — Stage 166 Changelog

## Amaç
Stage 165 sonrası ürün öncesi arayüz eksiklerini tamamlamak; mobil kullanım, dil varsayılanı ve mevcut üretim akışını korumak.

## Uygulanan değişiklikler
- Geleneksel Müzik ve Modern Müzik alanları, mevcut checkbox durum mantığı korunarak erişilebilir telefon tipi açma-kapama anahtarlarına dönüştürüldü.
- Saf Geleneksel İcra seçeneği aynı görsel ve erişilebilir anahtar standardına taşındı. Mevcut doğrulama, depolama ve prompt davranışı değiştirilmedi.
- Uygulama dili için ilk açılış varsayılanı `auto` yapıldı. Türkçe cihazda Türkçe, diğer cihaz dillerinde İngilizce arayüz otomatik seçilir. Kullanıcının daha önce kaydettiği dil tercihi korunur.
- ABD ve Birleşik Krallık bölgesel prodüksiyon referanslarının arayüz etiketleri İngilizce dil sözlüğüne eklendi; şehir/sahne adları kültürel kimlik veya otomatik enstrüman seçimi olarak yorumlanmaz.
- Menü sırası Genel Ayarlar → Temalar → … → Hakkında → Çıkış olacak şekilde düzenlendi.
- Düğme anahtarlarında klavye odak görünümü ve azaltılmış hareket tercihi desteği eklendi.
- Root, www ve iki Android WebView varlığı arasındaki `app.js` ve `index.html` kopyaları eşitlendi.
- Eski testlerdeki 67 profil sayısı ve eski kaynak yolları güncel 69 profilli katalog ve mevcut dizin yapısıyla uyumlu hale getirildi.

## Korunanlar
- Styles ve Lyrics iki ana çıktı alanı olarak kaldı.
- Intro ayrı çıktı alanına dönüştürülmedi; Lyrics başlangıcına eklenme davranışı korundu.
- Gemini üretim, fallback, API uç noktaları ve kimlik doğrulama kodu değiştirilmedi.
- Music DNA kimlikleri, sıralaması ve mevcut üretim seçim öncelikleri korunmuştur.
- Android uygulama kimliği, sürüm adı ve versionCode değiştirilmedi.

## Kapsam dışı / henüz doğrulanmayanlar
- Canlı Gemini ve Render bağlantısı
- Gerçek Android cihazda WebView testi
- APK derlemesi ve dağıtım paketi
- Suno üzerinde ses sonucu doğrulaması

Paketleme ve APK oluşturma kullanıcı onayına kadar bekletilir.

- Menü son sıralaması: Hakkında hemen ardından Çıkış; Çıkış son menü öğesidir.
