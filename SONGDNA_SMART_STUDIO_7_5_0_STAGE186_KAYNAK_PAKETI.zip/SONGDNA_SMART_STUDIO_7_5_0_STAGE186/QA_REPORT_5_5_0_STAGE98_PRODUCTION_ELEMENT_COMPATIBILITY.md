# Stage 98 QA — Production Element Compatibility

## Changes
- Added seven advisory pair checks to the Stage 97 production-element library.
- Connected these checks to the existing compatibility result during the Stage 96 context integration.
- Production-element notes merge with the existing BPM/traditional/vocal/fusion compatibility notes.
- Styles prompt receives the advisory context and is instructed to separate competing roles in time or reduce overlap.
- No selected element is deleted, rewritten, or silently replaced; generation remains allowed.
- Existing compatibility engine source is unchanged.

## Checks performed
- `node --check app.js`: PASS.
- `node --check production-element-library.js`: PASS.
- Stage 97 catalog regression (71 entries, Deep House mapping, traditional-style non-injection): PASS.
- Browser-like VM test (data + library load without CommonJS): PASS.
- Stage 98 pair-advisory contract test (conflict label, notes, canProceed=true, selectionChanged=false): PASS.
- Web and Android HTML load data and library scripts before app.js: PASS.
- ZIP integrity: verified after packaging.

## Not tested
- Live Gemini/Render request.
- APK build, signing, install or upgrade.
- Physical Android device.
- Suno audio generation/output quality.
