# Stage 101 — Otomatik Yapımcı Kararları

- Music DNA'ya göre manuel girilmemiş prodüksiyon ayrıntılarının otomatik tamamlanması ortak Styles–Lyrics sözleşmesinde açıkça tanımlandı.
- Otomatik kararların Styles ve Lyrics arasında tutarlı olması şartı eklendi.
- Manuel seçim yalnızca kendi alanında önceliklidir; diğer alanlar otomatik kalır.
- Otomatik ve manuel ad-lib katalog seçimleri Gemini seçim özetinde ayrıştırıldı.
- Doğrulanmış kültürel ifade yoksa uydurma kelime yerine wordless vocalise veya sessizlik korunur.
- Yeni arayüz kontrolü eklenmedi.
