# SONGDNA SMART STUDIO 7.1.0 — Stage180

## Amaç
Stage179 özelliklerini koruyarak Hikâyeyi Harmanla işleminin Render backend dağıtımını 7.1.0 sürüm kimliğiyle eşitlemek ve uygulamanın Hakkında/telif bilgilerini güncellemek.

## Değişiklikler
- `backend/server.js` ve kök `server.js` aynı kaynak olacak şekilde güncellendi.
- `POST /api/story-blend` ayrı Gemini görevi ve `story` yanıt alanıyla korunup regresyon denetimine alındı.
- Backend sağlık yanıtı ve başlangıç kaydı 7.1.0 sürümünü bildiriyor.
- Hakkında ekranı ve alt bilgi `7.1.0` ve `© 2027 SONGDNA Studio – Tüm hakları saklıdır.` olarak güncellendi.
- Android `versionCode` 40, `versionName` 7.1.0 yapıldı.
- Root, Web, Android kök varlıkları ve Android WebView kopyaları eşitlendi.
- API anahtarları ve `APP_ACCESS_TOKEN` değiştirilmedi; pakete gizli bilgi eklenmedi.

## Doğrulama sınırları
Yerel kaynak/regresyon kontrolleri bu pakette çalıştırılacaktır. Render dağıtımı, canlı Gemini, GitHub Actions APK derlemesi, fiziksel Android ve Suno ses üretimi bu paket oluşturma ortamında gerçekleştirilmez. Render'ın güncellenmesi için paketin GitHub deposuna aktarılması ve Render dağıtımının tamamlanması gerekir.
