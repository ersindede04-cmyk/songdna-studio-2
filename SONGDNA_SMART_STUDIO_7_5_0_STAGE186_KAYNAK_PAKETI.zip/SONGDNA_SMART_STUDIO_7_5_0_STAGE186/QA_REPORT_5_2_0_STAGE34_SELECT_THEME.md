# Stage 34 — Select theme styling QA

- Updated root, web and Android WebView index.html copies.
- Dark theme option surface: anthracite; selected option: yellow with white text.
- Light theme option surface: white; selected option: blue with white text.
- Static synchronization check: pending.
- Android physical-device popup rendering: not tested.
- Limitation: Android WebView may render native select popup outside normal CSS painting; if it ignores option styles, a custom in-app dropdown component is required for pixel-perfect control.
