# SONGDNA SMART STUDIO 6.1.0 — Stage170

## Yapılan düzeltmeler

- Modern Üretim ve Geleneksel Üretim sekmeleri yalnızca çalışma alanını değiştirir; Geleneksel Müzik, Modern Müzik ve Saf Geleneksel İcra anahtarlarını birbirinden bağımsız bırakır.
- Geleneksel Üretim içindeki bölge, alt bölge, vokal ve hazır kombinasyon seçenekleri modern stüdyo/şehir, Pop, Trap, Drill ve rap-hype seçimlerinden ayrıldı. Hazır kombinasyonlar katalogdaki geleneksel Music DNA profillerine bağlandı; modern Music DNA kataloğundan hiçbir profil silinmedi.
- Yerel enstrümanlar çoklu seçimli, bağımsız telefon tipi anahtarlara dönüştürüldü. Açık durum sarı, kapalı durum koyu ve belirgindir.
- Geleneksel çalışma alanında ortak üretim ayarları varsayılan olarak daraltılır; Modern Üretim'de açık kalır. Ayarlar silinmedi.
- Üst alan ve menü için güvenli alan boşluğu düzenlendi; dar telefonlarda logo satır kırılması giderildi; tablet dikey/yatay enstrüman ızgarası doğrulandı.
- Gemini sunucu tarafında 400, 401, 403, 404, 429, 500 ve 503 durumları için sabit, kullanıcıya uygun hata kodları ve mesajları eklendi. Ham Google hata metni ve sırlar istemciye aktarılmaz.
- Styles ve Lyrics üretim uçları, 75 Music DNA profili ve mevcut uyumluluk denetimi korunmuştur.

## Test durumu

- JavaScript: 129/129 test geçti.
- Python/Playwright: 7/7 test betiği geçti.
- Stage170 çalışma alanı: 52/52 gerçek Chromium etkileşim kontrolü geçti.
- Canlı Gemini servisi ve fiziksel Android cihaz doğrulaması yapılmadı.
- APK veya kaynak ZIP üretilmedi; paketleme onay bekliyor.


## Kaynak paketleme

- Stage170 kaynak ZIP arşivi GitHub Actions Android derlemesi için hazırlandı.
- APK bu çalışma ortamında üretilmedi; sağlanan iş akışı tarafından debug APK olarak derlenecek.
- Canlı Gemini servisi ve fiziksel Android cihaz doğrulaması kullanıcı ortamında ayrıca yapılmalıdır.
