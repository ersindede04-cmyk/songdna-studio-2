# SONGDNA SMART STUDIO 5.2.0 — Aşama 54

## Birleşik menü ve açılır liste standardı

- Birinci ekran görüntüsündeki menü görünümü ortak referans alındı.
- Tüm tekli seçim alanları aynı özel açılır menü bileşenine bağlandı; native Android popup farklılıkları azaltıldı.
- Çoklu seçim alanları (multiple select) çoklu seçim davranışları bozulmaması için yerel liste olarak bırakıldı.
- Gece teması: koyu lacivert/antrasit yüzeyler, sarı seçili seçenek ve koyu yazı.
- Gündüz teması: kırık beyaz yüzeyler, lacivert metin ve açık mavi/mavi seçili seçenek.
- Sonradan DOM'a eklenen tekli seçim alanları da aynı bileşene otomatik bağlanır.
- Web, kök kaynak ve Android WebView dosyaları eşitlendi.

## Görsel referanslardan tespit edilen neden

Önceki sürümde yalnızca `musicDnaMode` ve `commandTemplate` özel menüye dönüştürülüyordu. Diğer tekli seçimler Android'in yerel popup menüsünü kullanıyordu. Bu nedenle açılır menüler farklı görünüyordu. Ayrıca eski tema CSS'inde gündüz temasını koyu renge çeviren çelişkili bir `body.light` kuralı bulunuyordu. Aşama 54 ortak bileşen ve son öncelikli tema kurallarıyla bu tutarsızlığı giderir.

## Test sınırları

Kaynak eşitliği, JavaScript sözdizimi ve statik menü/tema kontrolleri yapılır. Fiziksel Android cihazda ekran görüntüsü karşılaştırması henüz kullanıcı cihazında doğrulanmalıdır. Çoklu seçim listeleri ayrı tutulur.
