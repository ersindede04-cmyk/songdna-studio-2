# SONGDNA Studio 5.2.0 – Stage60.1 Üretim İstemi Düzeltmesi

- Profil snapshot nesnesinin tamamı Gemini talimat zarfına eklenmiyor; yalnızca sürüm ve kimlik bilgisi gönderiliyor. Tam snapshot uygulama belleğinde Styles/Lyrics eşleşmesi ve geçmiş kaydı için korunuyor.
- Gemini isteği gönderilmeden önce istemin boş ve 100.000 karakter sınırını aşıp aşmadığı kontrol ediliyor.
- Çalışan APK'daki `/api/lyrics`, POST, `model`/`prompt` gövdesi ve `X-App-Token` gönderim yöntemi değiştirilmedi.
- Yeni özellik eklenmedi; değişiklik yalnızca üretim isteminin boyutunu ve hata teşhisini hedefler.
