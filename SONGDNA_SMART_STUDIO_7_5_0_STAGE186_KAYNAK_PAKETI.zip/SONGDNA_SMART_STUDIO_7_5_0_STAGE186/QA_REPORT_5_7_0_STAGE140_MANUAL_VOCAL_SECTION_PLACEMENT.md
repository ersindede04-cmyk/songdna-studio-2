# Stage 140 QA — Manuel Vokal Bölüm Yerleşimi

## Kapsam
Açıkça girilmiş `section_assignments` kayıtları, Lyrics içindeki mevcut köşeli parantezli bölüm etiketlerine karşı denetlenir. Denetim danışma amaçlıdır; otomatik söz düzenlemesi veya yeni bölüm üretimi yapmaz.

## Odak testleri
- 67 Music DNA profili üzerinde ana vokal/geri vokal/konuk/düet bölüm eşleşmesi.
- Bölüm etiketi eksikliği.
- Bölüm etiketi var ancak vokal rolü etikette belirtilmemiş durumu.
- Konuk vokalin yanlış bölüm türüne atanması.
- Geri vokalin enstrümantal bölüme atanması.
- Atama yokken mevcut Lyrics yapısının değiştirilmemesi.

## Sınırlar
Bu statik denetim, gerçek Gemini'nin her istekte talimatı uyguladığını veya Suno'nun ses çıktısında vokalleri doğru yerleştirdiğini kanıtlamaz. Canlı Gemini/Render, APK kurulumu ve gerçek Suno ses üretimi bu aşamada test edilmemiştir.

## Tamamlanan otomatik doğrulamalar
- Stage 140 odak testi: 67 profil iterasyonu + 8 odak kontrolü başarılı.
- Stage 139 vokal rolü gerileme testi: başarılı.
- Tüm JavaScript test dosyaları: 112/112 başarılı.
- Python test dosyaları: 5/5 başarılı.
- `scripts/verify-source.py`: başarılı; root, web ve Android WebView kaynakları eşit, dört manifest aynı, HTML/Android XML ve JavaScript sözdizimi kontrolleri geçti.
