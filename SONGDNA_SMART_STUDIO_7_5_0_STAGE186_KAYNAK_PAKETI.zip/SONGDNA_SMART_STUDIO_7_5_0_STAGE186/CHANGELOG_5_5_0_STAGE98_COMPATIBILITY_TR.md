# Stage 98 — Prodüksiyon Öğeleri Uyumluluk Denetimi

## Yapılan çalışma
Stage 97'de eklenen 71 öğelik prodüksiyon kütüphanesine, öğe çiftleri arasındaki olası ritim/bas/vokal/ön plan çakışmalarını belirleyen danışmanlık kontrolleri eklendi.

## Denetlenen örnek eşleşmeler
- Four-on-the-floor ile broken-beat ana groove: ÇATIŞMA.
- Four-on-the-floor ile half-time pulse: DENEYSEL.
- 808 glide ile rolling bassline: DENEYSEL.
- Reese bass ile yoğun wobble modülasyonu: DENEYSEL.
- Supersaw lead ile mahrem/nefesli vokal: DENEYSEL.
- Trap hi-hat roll ile belirgin shuffle: DENEYSEL.
- Sub drop ile derin kick/sürekli sub bas: DENEYSEL.

## Çalışma ilkeleri
- Mevcut BPM, geleneksel icra, vokal/ad-lib ve füzyon kontrolleri korunur.
- Yeni notlar mevcut UYUMLU / DENEYSEL / ÇATIŞMA sonucuna eklenir.
- Hiçbir öğe otomatik silinmez veya değiştirilmez.
- Kullanıcı üretime devam edebilir; sonuçlar tavsiye niteliğindedir.
- Styles promptu çakışan rolleri farklı zamanlara ayırma veya üst üste binmeyi azaltma yönergesi alır.
- Gerçek ses işleme veya otomatik miks yapılmaz.
