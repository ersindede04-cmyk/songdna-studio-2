# SONGDNA Studio 5.2.0 — Stage 79

## Manuel yaratıcı alanların korunması

- Yeni fikir kombinasyonu / zorlamalı yenileme sırasında kullanıcı tarafından düzenlenmiş duygu, atmosfer, hikâye ve anlatım alanlarının üzerine otomatik değer yazılması engellendi.
- Otomatik alanlar yenilenmeye devam eder; kullanıcı düzenlemesi yapılmış alanlar korunur.
- Gemini üretim hattı, Styles/Lyrics aktarımı, Music DNA rotasyonu ve API katmanına müdahale edilmedi.

## Kapsam notu

Bu düzeltme, tema-konu bağımsız modlarının tamamlandığı anlamına gelmez. Şarkı teması ve özel konu için ayrı otomatik/manuel seçim kontrollerinin sonraki alt aşamada eklenmesi gerekir.
