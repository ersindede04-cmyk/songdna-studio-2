# SONGDNA SMART STUDIO — Stage164 Şarkı Sözü Editoryal Standardı

## Amaç
Stage163 evrensel müzik içerik standardını tamamlayan bu katman, şarkı sözü üretiminde kullanıcı iradesini, hikâye sadakatini ve asgari müdahaleyi güvenceye alır.

## Öncelik sırası
1. Açık kullanıcı talimatları ve manuel kilitler
2. Kullanıcının hikâyesi, anlamı, dili/lehçesi ve özel ifadeleri
3. Seçilen Music DNA, gelenek, vokal rolleri ve üretim bağlamı
4. Dil, doğallık, söylenebilirlik ve estetik iyileştirme

## Editoryal ilkeler
- Sorunsuz satırlar sırf süslemek için yeniden yazılmaz.
- Kafiye anlamı, dil bilgisini veya doğal sözdizimini bozamaz.
- Kullanıcının olayları, karakterleri ve anlatıcı bakış açısı korunur.
- Tür ve prodüksiyon, söz yoğunluğu ve vokal tavrını etkiler; hikâyeyi değiştirmez.
- Belirsiz kültürel/yöresel ayrıntılar uydurulmaz.
- Geleneksel müzikte izinsiz modern vokal kalıpları, düet ve füzyon eklenmez. Kullanıcının açık seçimi ve geleneğin meşru varyasyonları korunur.
- Üretim modunda yalnızca istenen çıktı; analiz modunda gerekçeli bulgular sunulur.

## Sekiz aşamalı sessiz denetim
1. Kullanıcı girdisi, alanlar ve manuel seçimleri kilitle.
2. Dil, lehçe ve geleneksel/modern/füzyon kapsamını belirle.
3. Hikâye mantığını ve bölümlerin katkısını kontrol et.
4. Söz yoğunluğu ve ritmi seçilen tür/prodüksiyonla eşleştir.
5. Vokal rolleri ve enstrüman-vokal ilişkisini doğrula.
6. Dil bilgisi, deyim, anlam ve klişe kontrolü yap.
7. Hece, vurgu, nefes, ritim ve söylenebilirliği değerlendir.
8. Yalnızca gerçek sorunları asgari müdahaleyle düzelt; tüm kullanıcı kilitlerini yeniden kontrol et.

## Sınırlar
Doğallık, özgünlük ve söylenebilirlik kısmen öznel ölçütlerdir. Sistem kusursuzluk veya ana dili konuşuru doğrulaması iddiasında bulunmaz. Bu standart, Stage105–163 kurallarını ve mevcut orkestrasyonu değiştirmez; onlarla birlikte uygulanır.
