# SONGDNA Stage 181 — Araştırma ve Mimari Karar Kaydı

## 1. Araştırma sonucu

### Hikâye üretim araştırmaları

- **Detailed Outline Control (Yang, Klein, Peng, Tian; ACL 2023):** Kısa bir önermeyi ayrıntılı ve hiyerarşik bir plana dönüştürüp metin üretimini bu plana bağlı tutmanın uzun anlatılardaki olay tutarlılığını, plana bağlılığı ve ilgi çekiciliği artırabildiğini gösteriyor. SONGDNA için uygulanacak fikir: Gemini'nin metni doğrudan doğaçlaması yerine, önce anlamı ve nedensel olay çizgisini sessizce planlaması.
- **Collective Critics for Creative Story Generation / CritiCS (Bae & Kim; EMNLP 2024):** Planın ve taslağın eleştiri/iyileştirme aşamalarından geçirilmesinin yaratıcılık, okuyucu ilgisi ve anlatı tutarlılığına katkısını inceliyor. SONGDNA için uygulanacak fikir: taslaktan sonra ayrı bir editoryal kontrol çağrısı; ancak çoklu ajan takımı kurmak yerine tek bir ikinci gözden geçirme çağrısı.
- **Large Language Models as Narrative Planning Search Guides (Farrell & Ware; IEEE Transactions on Games, 2025):** Dil modellerinin yaratıcı olay üretiminde güçlü, fakat tek başına küresel tutarlılıkta sınırlı olabileceğini; sembolik planlamayla birlikte kullanımın yararlı olabileceğini tartışıyor. SONGDNA için uygulanacak fikir: basit, küçük nedensel kontrol noktaları; ağır bir sembolik hikâye motoru değil.
- **Text-to-Text Automatic Story Generation: A Survey (2026):** Hikâye tutarlılığı, karakter sürekliliği, çeşitlilik ve kontrol edilebilirliğin hâlâ açık zorluklar olduğunu vurguluyor. Bu nedenle tek bir promptun kalite garantisi olarak görülmemesi gerekiyor.

### Türkçe NLP araçları

- **Zemberek-NLP:** Türkçe biçimbilim, sözcük çözümleme/üretme, belirteçleme ve normalleştirme gibi işlevler sunuyor. Ancak projenin kendi deposu bakım/slow-maintenance durumunu belirtiyor ve Java tabanlı. İlk sürümde Android/Web/Node akışına eklemek gereksiz bağımlılık ve dağıtım yükü oluşturur.
- **TurkicNLP:** Türkçe dâhil Türk dilleri için Python tabanlı belirteçleme, biçimbilim, POS ve bağımlılık çözümleme araçları sunuyor. Güçlü bir araştırma seçeneği olsa da SONGDNA'nın Node backend'ine ayrı Python servisi ve model dağıtımı eklemek ilk aşamada gereğinden karmaşık.
- **Karar:** İlk uygulamada harici NLP sunucusu veya büyük bir sözlük/veri tabanı eklenmeyecek. Gemini'nin seçilen dilde doğrudan üretimi, mevcut çok dilli şarkı sözü kalite standardı ve editoryal gözden geçirme kullanılacak. İleride ölçülen Türkçe dil hataları için Zemberek/Stanza/TurkicNLP ayrı bir doğrulama deneyi olarak değerlendirilebilir.

### Gemini API

- Google Gemini Developer API `generateContent` için `responseMimeType: application/json` ve `responseJsonSchema` destekli yapılandırılmış çıktı sunuyor.
- Bu nedenle hikâye yanıtının JSON biçimini yalnızca prompt talimatına bırakmak yerine API sözleşmesiyle sınırlandırmak daha güvenilir.
- Model kimlikleri ve kullanılabilirlik zamanla değişebilir. 2026-11-25 araştırmasında `gemini-3.1-flash-lite` mevcut model dokümantasyonunda listeleniyor; gerçek proje erişimi, kota ve anahtar geçerliliği canlı çağrı yapılmadan doğrulanamaz.

## 2. En basit uygulanabilir mimari

1. Uygulama mevcut otomatik tema/konu/hikâyeyi ve kullanıcının açıkça seçtiği yaratıcı girdileri JSON veri olarak sunucuya gönderir.
2. Ayrı `/api/story-blend` görevi girdinin anlamını çözümler; korunacak unsurları ve dönüştürülebilecek unsurları ayırır.
3. Gemini küçük bir nedensel hikâye taslağı planlayıp doğal, kısa, şarkıya yön verebilecek bir anlatı üretir.
4. İkinci Gemini çağrısı bağımsız editör gibi taslağı kontrol eder; yalnızca gerçek kusur varsa en az müdahaleyle düzeltir.
5. JSON şeması ve backend uzunluk/doğrulama kontrolleri uygulanır.
6. Son hikâye mevcut konu alanına aktarılır. Ana şarkı sözü üretimi mevcut `/api/lyrics` ve `/api/style` zinciriyle devam eder.

## 3. Neden ilk aşamada Türkçe sözlük motoru yok?

Kullanıcının hedefi yalnızca yazım hatalarını bulmak değil; insan davranışları, olaylar ve duygular arasında inandırıcı bağlar kuran hikâyeler elde etmek. Morfoloji aracı ek uyum ve yazım kontrolleri sağlayabilir, ancak tek başına anlatı doğallığını veya duygusal inandırıcılığı çözmez. İlk aşamada en büyük kalite kazanımı görev ayrımı, nedensel planlama, ayrı editoryal gözden geçirme ve gerçek örneklerle değerlendirmeden bekleniyor.

## 4. Kalite değerlendirme planı

Bir sabit test kümesi oluşturulmalı. En az şu farklı kaynak türleri bulunmalı: soyut tema, tek cümlelik konu, ayrıntılı hikâye, birbiriyle gerilimli iki kullanıcı girdisi, geleneksel/halk anlatımı, gündelik gerçekçi olay ve duygusal dönüşüm.

Her sonuç 1–5 aralığında ayrı ayrı değerlendirilmeli:
- Türkçenin doğallığı ve konuşulabilirliği
- Olayların neden-sonuç tutarlılığı
- Karakter ve ilişki inandırıcılığı
- Duygusal gerçeklik
- Kaynak girdiye sadakat
- Gerçekten yeni bir bakış açısı sunması
- Şarkı sözüne dönüştürülebilirlik
- Klişe/yapay anlatım bulunmaması

Otomatik puan tek başına kalite kanıtı sayılmamalı. İlk testlerde kör insan değerlendirmesi tercih edilmeli; aynı girdinin eski tek-aşamalı ve yeni iki-aşamalı sonuçları karşılaştırılmalı.

## 5. Güvenlik ve geriye dönük uyumluluk

- Story-blend endpoint ayrı kalır.
- Ana Lyrics/Styles endpoint'lerine ve promptlarına dokunulmaz.
- Otomatik tema/konu döngüleri harmanlama sırasında ilerletilmez veya sıfırlanmaz.
- Kullanıcının açık girdileri veri kabul edilir; prompt enjeksiyonu olarak izlenmez.
- Harici NLP kütüphanesi, yeni veritabanı, çok ajan altyapısı veya ek UI kontrolü ilk sürüme eklenmez.
- Canlı Gemini/Render/Android/Suno doğrulaması yapılmadan başarı iddiasında bulunulmaz.

## 6. Kaynaklar

- Yang et al., *Improving Long Story Coherence With Detailed Outline Control*, ACL 2023: https://nlp.cs.berkeley.edu/pubs/Yang-Klein-Peng-Tian_2023_DOC_paper.pdf
- Bae & Kim, *Collective Critics for Creative Story Generation*, EMNLP 2024: https://aclanthology.org/2024.emnlp-main.1046/
- Farrell & Ware, *Large Language Models as Narrative Planning Search Guides*, IEEE Transactions on Games, 2025: https://cs.uky.edu/~sgware/reading/papers/farrell2024large.pdf
- Ma et al., *Text-to-Text Automatic Story Generation: A Survey*, EACL 2026: https://aclanthology.org/2026.eacl-srw.39/
- Zemberek-NLP GitHub: https://github.com/ahmetaa/zemberek-nlp
- TurkicNLP GitHub: https://github.com/turkic-nlp/turkicnlp
- Gemini API structured output documentation: https://ai.google.dev/gemini-api/docs/migrate-to-interactions
- Gemini supported models: https://firebase.google.com/docs/ai-logic/models
