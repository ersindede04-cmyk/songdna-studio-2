# Stage 146 — Canlı Manuel Vokal Seçimi Güncellemesi

- Manuel vokal bölüm ataması değiştiğinde `songdna:manual-vocal-section-selection-change` olayı üzerinden en güncel atamalar alınır.
- Son üretim bağlamındaki eski atamalar yenileriyle değiştirilir; diğer bağlam alanları korunur.
- Açıkça boş atama listesi önceki manuel atamaları temizler; atama bilgisi hiç gönderilmezse mevcut seçim korunur.
- Güncel düzenleme alanındaki Lyrics metni hemen yeniden denetlenir; eski yerleşim uyarıları güncel seçime göre kalkar veya kalır.
- Yeni ekran/kontrol eklenmedi; sözler ve manuel seçimler otomatik değiştirilmez.
