# Stage 127 — Styles Bilgi Yoğunluğu

- Styles için her ifadenin ayrı ve duyulabilir bir müzikal bilgi taşımasını isteyen Gemini talimatı eklendi.
- Rol + davranış temelli kısa tanımlar önceliklendirildi; sıfat zincirleri ve eş anlamlı tekrarlar azaltılacak şekilde yönlendirildi.
- Styles denetimi artık yinelenen virgül/noktalı virgül parçalarını, yalnızca genel övgüden oluşan ifadeleri ve düşük kelime çeşitliliğini uyarı olarak gösterebilir.
- Denetim tavsiye niteliğindedir; üretilen veya kullanıcının düzenlediği Styles metni otomatik değiştirilmez.
- Ana Music DNA, manuel seçimler, 1000 karakter doğrulaması ve iki çıktı düzeni korunmuştur.
