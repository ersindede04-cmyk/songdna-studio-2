# Stage 144 — Vokal Yerleşimi Uyarılarını Güncel Tutma

- Vokal yerleşimi uyarıları yalnızca mevcut Lyrics metni üzerinde yapılan son denetimden gösterilir.
- Kullanıcının düzelttiği rol/bölüm uyuşmazlıkları güncel denetimde artık yoksa eski uyarı ekranda tutulmaz.
- Kalan uyarılar korunur; yeni ortaya çıkan uyarılar görünür.
- Lyrics alanını temizleme işlemi de denetimi hemen yeniler.
- Otomatik söz düzeltme, bölüm oluşturma veya manuel seçim değiştirme yapılmaz.
- Yeni ekran, çıktı alanı veya üçüncü çıktı eklenmedi.
