# Stage 130 — Styles ve Lyrics Ortak Music DNA Kimliği

- Styles ve Lyrics üretim yönergelerine aynı birincil Music DNA profil anlık görüntüsünü kullanma şartı eklendi.
- Profil kimliği mevcutsa iki üretim katmanı kimliği karşılaştırılıyor; farklı kimlikler uyarı veriyor.
- Profil bilgisi eksikse denetim bunu açıkça bildiriyor; eksik müzikal/kültürel özellikler uydurulmuyor.
- Lyrics metninin enstrüman veya prodüksiyon terimlerini aynen anması zorunlu tutulmuyor.
- Otomatik çıktı değiştirme, yeni ekran, üçüncü çıktı alanı veya yeni API uç noktası eklenmedi.
