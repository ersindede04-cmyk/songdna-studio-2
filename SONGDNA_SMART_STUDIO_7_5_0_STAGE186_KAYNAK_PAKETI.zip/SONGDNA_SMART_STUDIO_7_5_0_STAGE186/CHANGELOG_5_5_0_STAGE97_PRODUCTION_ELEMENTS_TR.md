# Stage 97 — Elektronik ve Modern Prodüksiyon Öğeleri Kütüphanesi

## Eklenenler
- `data/electronic_production_elements_v1.json`: 71 küratörlü öğe, 8 kategori.
- `production-element-library-data.js`: tarayıcı/Android için gömülü veri.
- `production-element-library.js`: seçili ana Music DNA'ya göre öğe öneren besteci.
- Ana Styles promptuna uygun üretim öğeleri aktarımı.

## Kategoriler
Ritim/groove, kick/davul, bas tasarımı, synth/melodi, perküsyon, elektronik vokal dokuları, efekt/geçişler, mix/mastering karakteri.

## Çalışma kuralları
- Elektronik/modern ana kimlik saptanmadıkça elektronik öğe otomatik eklenmez.
- Öneriler ana kimliği destekler; yeni tür kimliği olarak yorumlanmaz.
- Ana katman baskın kalır; öğeler kategori başına sınırlandırılır.
- Kick/bas ayrımı, mono uyumlu sub, stereo üst katmanlar ve dinamik alan gibi temel denge yönergeleri korunur.
- Üretim öğeleri Styles promptuna gider; şarkı sözlerinin içeriğini yönlendirmek için kullanılmaz.
- Gerçek ses işleme/DSP veya EQ uygulaması eklenmemiştir.
- Mevcut üç katman ve uyumluluk ekranı değiştirilmemiştir.

## Araştırma temeli
Ableton Live 12 resmi referansında filtre tipleri, LFO/modülasyon, sidechain, delay, reverb, compression ve stereo hareket gibi üretim kavramları açıklanır. Katalogdaki terimler bu teknik alanlara göre seçilmiş, Suno promptlarında kullanılabilecek kısa İngilizce yönlendirmelere dönüştürülmüştür.
