# SONGDNA Studio 5.2.0 — Stage84

- Kişisel tema ve konu için açık kullanıcı eylemine dayalı tek kayıt düğmesi eklendi.
- Yalnızca “Kendi Temam” ve “Kendi Konum” modundaki dolu alanlar saklanır.
- Kayıtlı kişisel içerik uygulama açılışında geri yüklenir ve ilgili mod kişisel moda alınır.
- Otomatik döngü ve hazır şablon seçimleri kişisel kayıtları değiştirmez.
- Kayıt `songdna_personal_theme_topic_v1` anahtarı altında sürümlü JSON olarak tutulur.
- Dört uygulama JS ve HTML kopyası eşitlendi.
