# SONGDNA SMART STUDIO 5.7.0 — Son üretim paketi

- Ana Music DNA seçimine “Yok · Ana Music DNA kullanma” seçeneği eklendi.
- Ana Music DNA kapalıyken yalnızca açıkça seçilmiş geleneksel teknik modül müzikal kimliğin dayanağı olabilir; teknik dayanak yoksa üretim durdurulur.
- İkincil ve yardımcı katmanlar isteğe bağlı kalır; boş katmanlar otomatik doldurulmaz.
- Teknik modül sınıflandırması yalnızca sabit modül numaralarına bağlı olmaktan çıkarıldı; katalogdaki alan/kategori ve müzikal adlandırma bilgisi esas alınır.
- Türkçe arayüz dili ve uluslararası müzik teknik terimlerinin özgün yazımı korunur.
- Android sürümü 5.7.0 / versionCode 31 olarak güncellendi.
- Yeni özellik eklenmedi; Gemini ve Styles/Lyrics iki alanlı üretim akışı değiştirilmedi.
