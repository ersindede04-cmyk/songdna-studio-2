# SONGDNA SMART STUDIO — Stage 95 QA

## Kapsam
Üç katmanlı prodüksiyon için merkezi orkestrasyon sözleşmesi eklendi:
- Ana Prodüksiyon
- Alt Katman 2
- Yardımcı Prodüksiyon

## Davranış güvenceleri
- Ana katman ana müzikal kimliği belirler; seçiliyse baskın kalır.
- Alt katman yalnızca kullanıcı seçtiğinde ikinci müzikal etki ekler.
- Yardımcı katman yalnızca kullanıcı seçtiğinde tamamlayıcı öğeler ekler.
- Boş katmanlar boş kalır; otomatik seçim yapılmaz.
- Ana katman boşken seçilmiş alt katman otomatik olarak ana katmana yükseltilmez.
- Kullanıcı girdileri değiştirilmez.
- Styles ve Lyrics aynı paylaşılan prodüksiyon bağlamını alabilecek şekilde aynı bağlam metni üretilir.
- Uyumluluk/çelişki çözümü tavsiye niteliğindedir; seçimleri sessizce değiştirme yetkisi yoktur.

## Test
Stage 95 özel testi: 5 senaryo.
Gerçek uygulama akışına bağlama ve mevcut seçim arayüzünden canlı veri aktarımı sonraki aşamadır.
Canlı Gemini, Render, APK derlemesi ve fiziksel Android cihaz testi bu aşamada yapılmadı.
