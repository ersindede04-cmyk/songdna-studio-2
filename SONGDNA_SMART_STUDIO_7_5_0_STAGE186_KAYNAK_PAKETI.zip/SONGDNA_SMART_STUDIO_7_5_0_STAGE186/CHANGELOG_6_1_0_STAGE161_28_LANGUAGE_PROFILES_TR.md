# Stage161 — 28 Ayrı Dil Profili

- Stage160 evrensel kalite katmanı korundu.
- Önceden genel/fallback olan diller, mevcut 28 profilli dil/ad-lib kayıt yapısıyla eşleşecek şekilde ayrı şarkı sözü profillerine ayrıldı.
- Arapça: Standart Arapça, Mısır Arapçası ve Levant Arapçası ayrı profiller.
- Portekizce: Brezilya ve Avrupa Portekizcesi ayrı profiller.
- Kürtçe: Kurmancî ve Soranî ayrı profiller.
- Türkçe ve Azerbaycan Türkçesi ayrı tutuldu; diğer dillerin yazım, dilbilgisi, deyim, vurgu, yazı sistemi ve bölgesel çeşitleri ayrıştırıldı.
- Ortak kalite motoru, Music DNA/tür uyarlaması, sessiz editoryal denetim ve Stage157 kullanıcı girdisi sadakati korundu.
- UI, Styles/Lyrics alanları, API uç noktaları, Gemini sağlayıcısı, üretim akışı ve Android kimliği değiştirilmedi.
