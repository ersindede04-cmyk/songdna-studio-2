# SONGDNA SMART STUDIO 5.7.0 — Stage 109: Ortak Music Identity Profile

## Amaç
Geleneksel ve modern bütün Music DNA profillerini, üç prodüksiyon katmanını ve iki Suno çıktısını tek bir ortak müzikal kimlik sözleşmesine bağlamak.

## Uygulama
- Üç katman orkestratörüne sürümlenmiş `SONGDNA_MUSIC_IDENTITY_1` profili eklendi.
- Profil; ana Music DNA kimliği, tür ailesi, müzik alanı, bölge/sahne, şarkı dili, tanımlayıcı özellikler, icra, prodüksiyon, vokal ve aranje rehberini taşır.
- Ana, ikincil ve yardımcı katmanların seçili rolleri aynı profil altında tutulur.
- Styles ve Lyrics aynı `identityPrompt` ve ortak prodüksiyon bağlamını kullanır.
- İkincil/yardımcı katmanlar ana tür kimliğini değiştiremez; manuel seçimler korunur.
- Katalogda bulunmayan kültürel veya teknik ayrıntılar uydurulmaz.
- Dört app.js ve dört orkestratör kopyası eşitlendi.
- Yeni arayüz, çıktı alanı, API çağrısı veya üretim turu eklenmedi.

## Sınırlar
Bu aşama ortak kimlik veri sözleşmesini kurar. Katalog kapsamını genişletmez; her tür için doğrulanmış teknik veri bulunduğunu iddia etmez. Canlı Gemini/Render, APK, fiziksel cihaz ve gerçek Suno ses çıktısı test edilmemiştir.
