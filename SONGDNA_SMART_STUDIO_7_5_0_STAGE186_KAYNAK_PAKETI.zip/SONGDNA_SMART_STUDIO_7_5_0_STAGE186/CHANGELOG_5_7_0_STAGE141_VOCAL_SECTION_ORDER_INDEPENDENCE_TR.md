# Stage 141 — Vokal Bölümü Sıra Bağımsızlığı

- Manuel vokal bölümü denetiminin kullanıcının mevcut şarkı bölüm sırasına bağlı olmadığı açıkça tanımlandı.
- Kıta, nakarat, konuk verse ve köprü bölümleri farklı sıralarda bulunabilir; seçilen vokal rolü kendi atanmış bölümünde aranır.
- Tekrarlanan kıta/nakarat bölümleri ve standart dışı bölüm akışları desteklenir.
- Eksik bölüm otomatik oluşturulmaz; denetim yalnızca uyarı verir.
- Manuel seçimler ve mevcut sözler otomatik değiştirilmez.
- Yeni arayüz, üçüncü çıktı veya yeni üretim alanı eklenmedi.
