# Stage 140 — Manuel Vokal Rollerinin Bölümlere Yerleştirilmesi

- Kullanıcının açıkça belirlediği vokal rolü/bölüm eşleşmeleri için danışma amaçlı denetim eklendi.
- Ana vokal, geri vokal, düet ve konuk vokal yerleşimleri yalnızca seçilen bölümlerde aranır.
- Eksik bölüm etiketi ve bölümde belirtilmeyen vokal rolü ayrı uyarılar üretir.
- Konuk vokalin verse dışındaki bölüme atanması ve geri vokalin enstrümantal bölüme atanması çelişki olarak işaretlenir.
- Var olan Lyrics bölümleri dışında otomatik bölüm oluşturulmaz; metin veya manuel seçim otomatik değiştirilmez.
- Yeni arayüz veya üçüncü çıktı alanı eklenmedi.
