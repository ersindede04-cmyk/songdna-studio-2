# QA — SONGDNA SMART STUDIO 5.2.0 Aşama 54

- [x] Tüm tekli select alanları ortak menü bileşenine bağlanıyor.
- [x] Çoklu select alanları özel tekli menüye dönüştürülmüyor.
- [x] Gece seçili menü rengi sarı, metin koyu.
- [x] Gündüz menü zemini kırık beyaz, seçili alan açık mavi, metin lacivert.
- [x] Dinamik eklenen tekli select alanları gözlemciyle yakalanıyor.
- [x] Web/kök/Android WebView kaynakları eşit.
- [ ] Fiziksel Android cihazda tüm menülerin ekran görüntüsüyle doğrulanması.
- [ ] Gündüz ve gece modlarında gerçek cihazda dokunma, kaydırma ve uzun liste kontrolü.

Not: Otomatik kaynak kontrolleri gerçek cihaz görsel doğrulamasının yerine geçmez.
