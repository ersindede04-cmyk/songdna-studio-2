# SONGDNA SMART STUDIO 6.1.0 — APK derleme ve kurulum

## 1. Kaynak kodunu GitHub'a yükleme

1. ZIP dosyasını açın.
2. İçindeki `songdna95/` klasörünün **içeriğini** GitHub deposunun kök dizinine yükleyin; klasörü ikinci kez iç içe bırakmayın.
3. `main` dalına gönderin.

## 2. APK derlemesini başlatma

1. GitHub deposunda **Actions** bölümünü açın.
2. **SONGDNA SMART STUDIO 6.1.0 - Current Source APK Build** iş akışını seçin.
3. **Run workflow** ile derlemeyi başlatın.
4. Başarılı çalıştırmanın Artifacts bölümünden `SONGDNA-Studio-6.1.0-current-source-debug-APK` dosyasını indirin.

İş akışı mevcut kaynak kodunu doğrular ve debug APK üretir. Bu ZIP içinde önceden derlenmiş APK yoktur; GitHub Actions başarıyla çalışmadan APK oluşmuş sayılmaz.

## 3. Telefona kurma

1. İndirilen artifact ZIP dosyasını açın.
2. `app-debug.apk` dosyasını Android telefona aktarın.
3. Android'in izin verdiği şekilde kurun.
4. Uygulamayı açıp ekranları, yerel kayıtları ve üretim akışını kontrol edin.

Debug APK ilk cihaz testi içindir; mağazaya dağıtılacak imzalı sürüm değildir.

## 4. Gemini / Render bağlantısı

APK oluşturmak Render sunucusunu dağıtmaz veya güncellemez. `backend/` klasörünü Render servisine dağıtın. Render ortamında `APP_ACCESS_TOKEN` ve `GEMINI_API_KEY` değerlerini tanımlayın.

Uygulamada **Ayarlar → AI ve API Bağlantısı** bölümüne gerçek Render HTTPS adresini ve aynı `APP_ACCESS_TOKEN` değerini girin. Gemini API anahtarı telefona veya APK'ya konulmaz; yalnızca sunucu ortamında tutulur. `/health` kontrolü ve uygulama içinden gerçek Lyrics/Styles üretimi yapılmadan canlı bağlantı doğrulanmış sayılmaz.

## 5. Sürüm bilgisi

- Uygulama sürümü: **6.1.0**
- Android versionCode: **32**
- Application ID: `com.songdna.studio`
- Minimum Android: API 23
- Hedef Android: API 35

Mevcut iş akışı yalnızca debug APK üretir. İmzalı release APK için keystore ve imzalama ayarları ayrıca hazırlanıp doğrulanmalıdır. Keystore, parolalar veya Gemini anahtarı kaynak ZIP'e ya da GitHub deposuna eklenmemelidir.

GitHub Actions başarılı derleme, APK dosyasının üretildiğini gösterir; fiziksel telefonda kurulum ve kullanım testi ayrıca yapılmalıdır.
