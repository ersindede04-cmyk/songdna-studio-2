# QA — Stage 157 Kullanıcı İçeriği Sadakati

## Kapsam
Gemini Lyrics talimatlarının kullanıcı tarafından girilen konu, anahtar kelimeler, yerel ifadeler ve ek yaratıcı yönlendirmelere bağlılığının güçlendirilmesi.

## Kaynak incelemesinde bulunan sorun
Önceki prompt kullanıcı konusuna saygı gösterilmesini istiyor, ancak konu içindeki somut kelimelerin her birinin kullanılmasını veya özel ifadenin aynen korunmasını açıkça zorunlu tutmuyordu. Lyrics çıktı denetimi de kullanıcı girdisiyle içerik eşleşmesini kontrol etmiyordu.

## Uygulanan değişiklik
- Kullanıcı konusu ve somut imgeler zorunlu hikâye malzemesi olarak tanımlandı.
- Kısa anahtar kelime listelerindeki anlamlı öğelerin doğal biçimde sözlere işlenmesi istendi.
- Özel ifade alanındaki metnin aynen korunması istendi.
- Gemini sistem talimatına aynı öncelik kuralı eklendi.
- Dört runtime app.js kopyası byte-byte eşitlendi.

## Sınırlar
Bu değişiklik prompt davranışını güçlendirir; Gemini'nin her üretimde bütün girdileri kusursuz kullanacağını garanti etmez. Canlı Gemini çağrısı, Render dağıtımı, APK derlemesi, fiziksel cihaz ve Suno ses çıktısı bu ortamda doğrulanmadı.
