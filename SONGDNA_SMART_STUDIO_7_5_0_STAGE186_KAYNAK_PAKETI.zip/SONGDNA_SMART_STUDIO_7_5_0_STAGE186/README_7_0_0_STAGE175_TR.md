# SONGDNA SMART STUDIO 7.0.0 — Stage 175

## GitHub yükleme
1. `SONGDNA_SMART_STUDIO_7_0_0_STAGE175_KAYNAK.zip` dosyasını depo köküne yükleyin.
2. Bu kaynak ZIP içindeki `.github/workflows/build.yml` dosyasını GitHub deposundaki aynı konuma kopyalayın.
3. Actions bölümünden **SONGDNA SMART STUDIO 7.0.0 Stage175 Android Debug APK** iş akışını `Run workflow` ile başlatın.
4. Başarılı çalıştırmada APK, Actions → Artifacts bölümünde bulunur.

## Render
Render servisinin Root Directory ayarı `backend` ise güncellenen `backend/server.js` dosyasının deploy edildiğini doğrulayın. `APP_ACCESS_TOKEN` ve `GEMINI_API_KEY` ortam değişkenleri Render'da ayrıca tanımlı olmalıdır.

## Sınırlar
Bu paket kaynak/derleme kitidir; APK içermez. Canlı Gemini, Render deploy, GitHub Actions ve fiziksel cihaz doğrulaması henüz yapılmış değildir.
