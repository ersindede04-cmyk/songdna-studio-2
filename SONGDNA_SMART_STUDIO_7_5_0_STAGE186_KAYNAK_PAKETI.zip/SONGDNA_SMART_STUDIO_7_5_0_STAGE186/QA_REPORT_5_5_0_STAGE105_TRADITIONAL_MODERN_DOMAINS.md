# SONGDNA SMART STUDIO 5.7.0 — Stage 105 QA

## Scope
- Split the expandable Music DNA catalogue into independently enabled Traditional Music and Modern Music domains.
- Added persistent, independent Traditional/Modern switches. Both default to enabled to preserve existing behaviour.
- Filtered the main Music DNA, secondary Music DNA, helper production and technique-module selectors by the enabled domains.
- Kept secondary and helper production layers optional with explicit “Yok” choices.
- Traditional-only mode suppresses modern fusion selection and adds a prompt-level traditional identity lock. Modern-only mode adds a modern identity lock. When both are enabled, cross-domain combination requires explicit profile selection.
- Added MDNA-067 Turkish Folk Music as a general traditional Turkish folk identity. Regional specifics remain user-selected; the profile does not invent a regional tradition.
- Added `music_domain` classification to every current profile in the embedded and JSON catalogues. The catalogue is now 67 profiles (27 traditional, 40 modern) and remains expandable.
- Updated genre/ad-lib mapping and production-preset classification for MDNA-067.
- Automatic rotation uses the current enabled catalogue; no fixed 66-profile count is treated as a rule.
- Existing Gemini request flow, Styles/Lyrics outputs, Intro placement and three-layer orchestrator are retained.

## Validation
- `node --check` passed for all four runtime `app.js` copies.
- All 39 root `scripts/test-*.js` tests passed after updating count-specific tests to treat the catalogue as expandable.
- New `scripts/test-stage105-music-domains.js` passed.
- Existing regression tests passed for Music DNA rotation, arrangement guidance, traditional vocal routing, ad-lib mapping, production presets, three-layer integration, Gemini instruction contract, Android/Web asset parity and backup/runtime safeguards.
- Root, web and Android WebView copies of `app.js` and `index.html` were synchronized.

## Not tested
- Live Gemini/Render generation.
- APK build/install or physical Android interaction.
- Actual Suno audio output and human listening evaluation.

## Important note
Traditional/modern classification is a curated catalogue taxonomy, not a claim that musical cultures are historically isolated. Profiles representing regional rhythm or vocal layers are assigned to the traditional domain when their documented function is traditional; contemporary popular and electronic production identities remain in the modern domain. New profiles should declare `music_domain` explicitly.
