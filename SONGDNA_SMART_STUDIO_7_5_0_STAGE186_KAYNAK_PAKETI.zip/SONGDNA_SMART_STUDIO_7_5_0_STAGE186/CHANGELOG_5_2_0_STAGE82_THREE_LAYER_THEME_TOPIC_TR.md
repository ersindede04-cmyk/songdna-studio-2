# Stage 82 — Üç Katmanlı Tema ve Konu Sistemi

- Şarkı Teması ve Şarkı Konusu için birbirinden bağımsız üç katman eklendi: Otomatik Döngü, Hazır Şablon ve Kişisel İçerik.
- Tema için özel kullanıcı metni alanı eklendi.
- Konu için hazır şablon seçimi eklendi; seçilen metin düzenlenince mod kişisel içeriğe geçer.
- Otomatik tema döngüsü yalnızca boş olmayan Lyrics yanıtından sonra ilerler.
- Dört uygulama kopyası eşitlendi.
