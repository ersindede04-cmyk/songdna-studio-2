# SONGDNA SMART STUDIO 5.7.0 — Stage 108

## Saf Geleneksel Prodüksiyon

- Added an optional **Saf Geleneksel Prodüksiyon / Pure Traditional Production** switch.
- Enabling it automatically enables Traditional Music and disables Modern Music.
- The generation prompts now prioritize the selected country's, region's and tradition's own documented instruments, playing techniques, rhythms, melodic language, tuning/modal practice and vocal conventions.
- The system is instructed not to mix unrelated cultures or add modern pop/electronic production elements while this mode is active.
- Unsupported cultural details must not be invented; if the catalogue lacks verified detail, the arrangement must remain conservative.
- Existing two-field output (Styles and Lyrics), Gemini flow, and 5.7.0 product version are preserved.

## Scope note

This is a global production rule, not a claim that every traditional music tradition in the world is already represented in the catalogue. Coverage remains limited to the profiles and technical modules actually present.
