# SONGDNA SMART STUDIO 6.1.0 — Stage 151: Sürüm Birleştirme

## Amaç

5.7.0 kaynak tabanındaki en son güncellemeleri ve Stage 150'de tamamlanan yerel doğrulama sonuçlarını koruyarak uygulamanın sürüm kimliğini 6.1.0 olarak birleştirmek.

## Yapılan düzenlemeler

- Uygulama sürümü `6.1.0` olarak güncellendi.
- Android `versionName` değeri `6.1.0`, `versionCode` değeri `32` yapıldı.
- Backend paket sürümü, sağlık yanıtı ve sunucu günlükleri 6.1.0 ile eşitlendi.
- Yedekleme metaverisi 6.1.0 olarak güncellendi; eski sürüm yedeklerinin içe aktarılma desteği korundu.
- Dört `BUILD_MANIFEST.json` kopyası aynı sürüm ve aşama bilgisine getirildi.
- GitHub Actions iş akışı, artifact adı, README ve Türkçe kurulum belgesi 6.1.0 ile eşitlendi.
- Android uygulama kimliği, minimum/hedef SDK ve mevcut derleme araç zinciri değiştirilmedi.
- Eski sürümlere ait tarihsel changelog ve QA kayıtları geçmiş kaydı olarak korundu.

## Korunan son güncellemeler

- Stage 145: açıkça manuel seçilmiş vokal rollerinin denetlenmesi.
- Stage 146: manuel vokal bölüm seçimi değişince denetimin yenilenmesi.
- Stage 147: kalite ve mimari denetim.
- Stage 148: tekrarlanan istem politikalarının sadeleştirilmesi.
- Stage 149: paketleme öncesi Android, Render, Gemini güvenliği ve APK otomasyonu denetimi.
- Stage 150: yerel kaynak doğrulaması ve regresyon testleri.

Styles ve Lyrics iki ayrı çıktı olarak kalır. Gemini'nin Lyrics üretimini uygulamadaki Lyrics alanına otomatik aktaran mevcut akışa müdahale edilmedi. Yeni üretim özelliği veya ek arayüz kontrolü eklenmedi.

## Sürüm bilgisi

- Uygulama: `6.1.0`
- Android versionCode: `32`
- Application ID: `com.songdna.studio`
- minSdk: `23`
- targetSdk / compileSdk: `35`
- Backend Node gereksinimi: `>=20`

## Doğrulama sınırları

Kaynak doğrulama ve otomatik regresyon testleri bu paket üzerinde yeniden çalıştırıldı. GitHub Actions uzaktan APK derlemesi, canlı Render dağıtımı, gerçek Gemini hesabıyla üretim ve fiziksel Android cihaz kurulumu bu ortamda gerçekleştirilmedi. Bu nedenle APK'nın üretildiği veya canlı bağlantıların doğrulandığı iddia edilmez.
