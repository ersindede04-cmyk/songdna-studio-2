# Stage90 QA — Data Backup / Restore

## Passed
- `node --check app.js`
- `tests/test-stage90-data-backup.js`
- All `tests/*.js` and root `test-*.js` scripts
- All `scripts/test-*.py` scripts
- Backup allowlist excludes API token and server URL keys
- Valid backup restore, unsupported format rejection, invalid value rejection
- Simulated write verification failure and rollback
- Four `app.js` copies byte-identical
- Four `index.html` copies byte-identical
- Four `data-backup.js` copies byte-identical

## Scope / limitations
- Backup and restore were tested with Node.js storage simulations; no physical Android device test was run.
- Browser download/file-picker behavior and Android WebView file access need device-level validation.
- Backup JSON is not encrypted. Users should store it in a private, secure location. API credentials are intentionally excluded.
- Live Gemini/Render and APK build were not tested.
