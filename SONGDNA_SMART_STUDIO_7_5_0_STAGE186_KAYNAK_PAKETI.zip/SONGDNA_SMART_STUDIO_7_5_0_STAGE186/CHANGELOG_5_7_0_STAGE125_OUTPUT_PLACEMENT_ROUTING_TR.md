# Stage 125 — Bölüm Yerleşim Önerilerinin Styles ve Lyrics'e Aktarılması

- Üç katmanlı uyumluluk denetimi artık mevcut bölüm aranjmanı içindeki uygun bölüm adlarını kullanır.
- Gerçekten eşleşen çakışma önerileri Styles promptuna aktarılır; ana Music DNA baskın kalır.
- Lyrics promptuna yalnızca vokal düzeni çakışmalarının bölüm yerleşimi aktarılır. Ritim/bas/enstrüman önerileri şarkı sözlerini yönlendirmez.
- Bölüm bulunamazsa yerleşim varsayımı yapılmaz; yeni bölüm oluşturulmaz.
- Manuel seçimler değiştirilmez; ek arayüz veya çıktı alanı eklenmez.
