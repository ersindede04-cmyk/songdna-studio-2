# Stage 120 — Styles ve Lyrics Kimlik Uyumu

- Tek Music Identity Profile iki çıktıda da ortak ve bağlayıcı kaynak olarak korunur.
- Styles talimatı yalnızca duyulabilir ses, ritim, enstrüman rolleri, vokal karakteri, düzenleme ve prodüksiyon tanımlarına odaklanır.
- Lyrics talimatı aynı kimliği söylenebilir söz, dil, konu, ifade, bölüm akışı ve vokal sunumuna dönüştürür.
- Enstrüman/prodüksiyon etiketlerinin şarkı sözüne; hikâye ve söz satırlarının Styles alanına taşınması engellenir.
- Katalogda desteklenmeyen BPM, enstrüman, teknik, lehçe veya kültürel ayrıntılar uydurulmaz.
- Yeni ekran, ayar veya üçüncü çıktı alanı eklenmedi. Gemini üretim akışı değiştirilmedi.

Doğrulama: Stage 120 testi ve tam otomatik test paketi çalıştırıldı. Canlı Gemini/Render, APK ve Suno ses üretimi bu aşamada test edilmedi.
