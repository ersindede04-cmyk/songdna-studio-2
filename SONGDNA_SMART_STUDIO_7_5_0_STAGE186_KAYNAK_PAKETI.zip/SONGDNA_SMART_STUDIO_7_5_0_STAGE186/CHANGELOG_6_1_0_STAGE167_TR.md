# SONGDNA SMART STUDIO 6.1.0 — Stage167

## Üretim arayüzü
- Ekranın üstüne yan yana iki sabit sekme eklendi: STANDART ÜRETİM ve GLOBAL ÜRETİM.
- Sekmeler aynı ekranda mevcut içeriklerin görünürlüğünü değiştirir; ayrı pencere veya kopya ekran oluşturmaz.
- Standart üretim arayüzü ve mevcut seçenekleri korunur.
- Mevcut Dünya Müziği paneli Global Üretim olarak yeniden adlandırıldı.
- Global sekmede bölgesel müzik paneli ile ortak üretim kontrolleri birlikte görünür.
- ŞARKI SÖZÜ ÜRET düğmesi eklendi; mevcut Gemini Lyrics ve Styles akışını kullanır.
- Hamburger menüsündeki Dünya Müziği bağlantısı Global Üretim sekmesini açar; menünün diğer seçenekleri korunur.

## Görsel düzen
- Açık tema daha ferah, pastel yüzeylerle yenilendi.
- Enstrüman seçimleri kompakt ve erişilebilir anahtar kartlarına dönüştürüldü; 4 sütun, dar ekranda 3 ve geniş ekranda 5 sütun.
- Aktif anahtar sarı zemin ve sağda beyaz düğme; pasif anahtar gri zemin ve solda gri düğme kullanır.
- Üst menü düğmesi yaklaşık 10 CSS piksel aşağı taşındı.

## Müzik DNA kataloğu
- Global Pop, US Pop, UK Pop, K-Pop, J-Pop ve Latin Pop profilleri ayrı kimliklerle eklendi.
- Turkish Pop ve Turkish Electronic Pop birbirinden ayrı tutuldu; füzyon açıkça seçilen katman olarak kalır.

## Korunan sistemler
- Gemini üretim hattı, Styles + Lyrics çıktıları, API/fallback, mevcut üretim geçmişi, kataloglar ve manuel seçim önceliği korunmuştur.
