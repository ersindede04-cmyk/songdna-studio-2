# Stage 106 — Türkçe / İngilizce Arayüz Dili

- Geleneksel Müzik ve Modern Müzik alanı kontrolleri Türkçe arayüzde Türkçe teknik ifadelerle gösterilir.
- İngilizce arayüzde aynı alanlar standart İngilizce karşılıklarıyla gösterilir.
- Dinamik durum ve katalog açıklamaları da arayüz diline göre üretilir.
- Müzik türü/profil adları, enstrüman adları, Music DNA kimlikleri, Styles etiketleri ve şarkı sözleri çevrilmez.
- Arayüz dili ile şarkı dili birbirinden bağımsız kalır.
- Gemini akışı, Styles/Lyrics alanları ve müzik alanı seçme mantığı değiştirilmemiştir.
