# SONGDNA SMART STUDIO 6.1.0 — Stage156 Kaynak Onarım Raporu

## Tespit edilen sorunlar
- Stage155 GitHub Actions kaydı, `playwright.__version__` erişiminde duruyordu. Kurulu Playwright dağıtımının sürümü Python modülünden değil dağıtım metaverisinden okunmalıdır.
- Kaynak paketinde dört adet build manifesti Stage151 olarak kalmıştı; kaynak paketin aşama kimliği güncel değildi.
- Kaynak doğrulama betiğinin Web ve Android varlık ağaçlarında eski 5.7.0/Stage60.1 beklentili kopyaları bulunuyordu. Bunlar uygulama çalışma zamanı dosyaları değil CI yardımcılarıdır ve yanlış yerde tutuluyordu.
- Android Gradle kimliği ile manifest sürüm/aşama bilgilerinin tek doğrulama adımında birlikte kontrol edilmesi gerekiyordu.

## Yapılan düzeltmeler
- `scripts/ci-preflight.py` eklendi. Playwright sürümünü `importlib.metadata.version("playwright")` ile okur ve `requirements-test.txt` içindeki sabit sürümle karşılaştırır.
- Tek kanonik kaynak doğrulayıcı `scripts/verify-source.py` Stage156 manifestlerini, dört manifest eşitliğini, Android applicationId/versionCode/versionName değerlerini ve beş Python test dosyasını denetleyecek şekilde güçlendirildi.
- Eski ve hatalı konumlandırılmış üç CI doğrulayıcı kopyası WebView varlıklarından çıkarıldı.
- Dört `BUILD_MANIFEST.json` dosyası aynı Stage156 içeriğine getirildi.

## Sınırlar
Bu paket yerel kaynak testlerinden geçirilecektir. Bu çalışma ortamında Android SDK/Gradle bulunmadığından gerçek APK derlemesi yapılamaz. GitHub Actions üzerinde APK oluşturulması, artifact yüklenmesi ve fiziksel Android kurulumu henüz doğrulanmış değildir. Bunlar başarılıymış gibi raporlanmayacaktır.
