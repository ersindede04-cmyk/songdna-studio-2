# SONGDNA Studio 5.2.0 — Stage 32.1 Hotfix QA

## Issue observed
The app displayed `adlibSceneForCultureSource is not defined` during the production flow. The Gemini instruction builder referenced this helper from script scope, while its only declaration was nested inside `initCreativeStudio480`, making it inaccessible to the prompt builder.

## Fix
- Added the culture-source resolver at top-level script scope before `buildGeminiInstructionEnvelope`.
- Kept the nested UI helper for the creative studio's own catalog-selection logic.
- Synchronized `app.js`, `www/app.js`, and the Android WebView `app.js` byte-for-byte.
- No API keys, backend routes, provider allowlists, or model routing were changed.

## Verification
- `node --check` passed for all three runtime copies.
- `python3 scripts/verify-source.py` passed all static source checks.
- `node scripts/test-stage32-arrangement-adlib.js` passed.
- `node scripts/test-adlib-catalog.js` passed.
- `node scripts/test-stage32-hotfix-scope.js` passed: global scope, 10 culture-source mappings, and three-way source parity.

## Not verified by this source-level hotfix
- Live Gemini API request and API key validity.
- Render deployment / backend environment variables.
- GitHub Actions APK build and physical Android device test.

The hotfix removes the confirmed JavaScript ReferenceError. If live generation still fails after installing this source, the next step is to inspect the API response/status and backend logs separately.
