# Stage 117 — STYLES / LYRICS Kimlik Tutarlılığı

- STYLES ve LYRICS birlikte incelenerek açık vokal/aranje çelişkileri aranır.
- Enstrümantal/vokalsiz Styles ile sözlü Lyrics çelişkisi uyarılır.
- Açık erkek/kadın ana vokal etiketi uyuşmazlıkları uyarılır.
- Denetim danışma niteliğindedir; tür, bölge veya kültürel doğruluk otomatik olarak kanıtlanmış sayılmaz.
- Mevcut iki çıktı alanı ve üretim akışı korunur.
