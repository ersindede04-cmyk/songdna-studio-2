# Stage 113 — Ana Music DNA Profil Rehberinin Üretime Aktarımı

- Ana Music DNA profilinin `prompt_guidance` alanı ortak Music Identity Profile içine `profileGuidance` olarak eklendi.
- Aynı rehber ana prodüksiyon katmanının prompt metninde de korundu.
- Enstrüman, söz yazımı, düzenleme ve performans rehberleriyle birlikte Styles ve Lyrics ortak bağlamına taşınır.
- Manuel seçim önceliği, iki çıktı alanı ve mevcut Gemini üretim akışı değiştirilmedi.
- Katalogda bulunmayan ayrıntılar üretilmez.
