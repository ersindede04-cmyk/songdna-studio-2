# Stage 129 — Music DNA Lyrics Kimlik Rehberi

- Seçili ana Music DNA profilinin `lyrics_guidance` bilgisi doğrudan Lyrics üretim istemine eklendi.
- Profilin `arrangement_guidance` bilgisi, sözlerin bölüm akışı ve vokal ifade alanını desteklemek üzere Lyrics istemine aktarıldı.
- 67/67 Music DNA profilinde belgelenmiş `lyrics_guidance` alanı bulunduğu doğrulandı.
- Kullanıcının seçtiği dil, konu, özel ifadeler, ana/arka vokal kimliği ve manuel talimatlar öncelikli kalır.
- Profil, dil/diyalekt/öykü/ritüel metni veya bölgesel argo uydurmak için gerekçe oluşturmaz.
- Eksik profil rehberliği için temkinli geri dönüş metni kullanılır; yeni kültürel bilgi uydurulmaz.
- Lyrics çıktısı otomatik olarak yeniden yazılmaz; üçüncü çıktı alanı veya yeni arayüz eklenmedi.

## Doğrulama

- Stage 129 odaklı test: 76/76 kontrol.
- Stage 128/127/126 gerileme testleri: 74 + 14 + 10 kontrol.
- Tüm JavaScript test dosyaları: 60/60 başarılı.
- Python doğrulama betikleri: 6/6 başarılı.
- `scripts/verify-source.py`: başarılı; dört uygulama kopyası ve dört manifest eşit.
- Canlı Gemini/Render, APK kurulumu ve gerçek Suno ses üretimi bu aşamada test edilmedi.
