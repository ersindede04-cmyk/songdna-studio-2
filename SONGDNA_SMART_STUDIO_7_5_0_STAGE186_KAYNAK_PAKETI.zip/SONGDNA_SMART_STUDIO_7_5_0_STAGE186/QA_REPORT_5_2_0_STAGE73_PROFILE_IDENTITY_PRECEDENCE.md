# SONGDNA SMART STUDIO 5.2.0 — Stage 73 Profile Identity Precedence

## Purpose
Ensure the shared production-preset families support, rather than overwrite, the distinctive musical identity authored for each selected Music DNA profile.

## Audit finding
The Stage 72 report explicitly noted that 66 profiles still use a smaller set of shared preset-family parameter sheets. In the production-profile integration, generic family bass, melody, atmosphere and form values were being assigned over profile-derived values. That could flatten distinct profile instructions even though profile-specific arrangement guidance was also sent to Gemini.

## Changes
- Kept the selected profile's existing drum, bass, melodic, atmosphere and arrangement descriptions intact.
- Reframed family preset groove/bass/melody/form/effects as supporting references only.
- Added an explicit precedence instruction: profile-specific arrangement, prompt guidance, vocal practice, instruments and user selections outrank generic family references.
- Preserved mixer dimensions, cross-balance notes and manual parameter overrides.
- Synchronized all four app.js runtime copies.
- No UI, API, server, catalog, Music DNA rotation, or output-field changes.

## Automated verification
- Added `scripts/test-stage73-profile-identity-precedence.js`.
- Verified generic family preset no longer overwrites profile bass, melody, atmosphere or arrangement fields.
- Verified precedence instruction and manual override context remain present.
- Verified root, web and Android app.js copies are byte-identical.

## Boundaries
- This does not claim 66 individually hand-authored numeric preset sheets.
- No new regional musical facts were invented or added.
- Live Gemini, Render, physical Android/APK and Suno audio listening tests were not performed.
