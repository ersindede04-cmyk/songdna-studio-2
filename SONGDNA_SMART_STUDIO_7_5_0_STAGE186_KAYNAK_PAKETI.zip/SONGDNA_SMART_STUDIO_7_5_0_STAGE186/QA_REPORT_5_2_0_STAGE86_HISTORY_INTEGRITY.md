# SONGDNA Studio 5.2.0 — Stage86 QA Raporu

## Kapsam
Üretim geçmişi ve kayıtlı Lirik arşivi arasındaki ayrım korunarak geçmiş kayıtlarının kimlik kararlılığı denetlendi.

## Bulgu ve düzeltme
Eski `songdna_history` kayıtlarında `id` alanı yoksa normalizasyon her okumada yeni rastgele kimlik oluşturabiliyordu. Bu durum eski kaydın kimliğine bağlı silme/yükleme işlemlerini kararsız hâle getirebilirdi. Kimliksiz eski kayıtlar için içerik ve sıra temelli kararlı kimlik üretimi eklendi. Kaynak kayıt nesneleri değiştirilmez; bilinmeyen metadata korunur. Normalleştirilmiş biçim ilk okumada depoya yazılmaya çalışılır.

## Testler
- Stage86 eski kayıt kimlik kararlılığı testi: PASS.
- Mevcut tüm JavaScript testleri: PASS.
- Mevcut tüm Python testleri: PASS.
- `node --check app.js`: PASS.
- Dört `app.js` kopyası SHA256 eşit: PASS.
- Dört `production-history.js` kopyası SHA256 eşit: PASS.

## Sınırlar
Tarayıcı/Node testleri gerçek Android cihaz depolamasını, APK paketini veya uygulama yükseltme senaryosunu doğrulamaz. Canlı Gemini/Render testi yapılmadı.
