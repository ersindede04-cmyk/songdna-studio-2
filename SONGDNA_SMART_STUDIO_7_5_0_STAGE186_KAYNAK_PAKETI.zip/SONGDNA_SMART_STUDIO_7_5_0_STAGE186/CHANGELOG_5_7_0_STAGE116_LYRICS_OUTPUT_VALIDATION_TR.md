# Stage 116 — LYRICS Çıktı Doğrulaması

- Gemini LYRICS yanıtı uygulamaya aktarılmadan önce kontrol edilir.
- Boş veya 5000 karakterlik planlama sınırını aşan yanıt reddedilir.
- Eşleşmeyen köşeli parantezler reddedilir.
- Şarkı sözü dışı açıklama ve STYLES/EXCLUDE/prodüksiyon alanlarının karışması reddedilir.
- Mevcut şarkı dili seçimi ve etiket normalizasyonu korunur.
- Dilin semantik doğruluğu otomatik olarak garanti edilmez.
