# Stage 124 — Bölüm Bazlı Katman Yerleşimi

- Stage 123'teki zamansal ayırma önerileri, artık yalnızca mevcut şarkı bölümleriyle eşleştirilir.
- Kullanıcı/aranje tarafından sağlanan `existingSections` listesi; ritim, vokal, bas ve tekrar türündeki çakışmalara göre değerlendirilir.
- Her çakışma türü için uygun bölüm türleri öneri olarak belirtilir; yalnızca listede gerçekten bulunan uygun bölümler `matchedExistingSections` alanına yazılır.
- Uygun mevcut bölüm yoksa yerleşim varsayımı yapılmaz. Yeni bölüm oluşturulmaz veya otomatik atama yapılmaz.
- Uyumlu katmanlara gereksiz yerleşim önerisi verilmez; manuel seçimler korunur.
- Arayüze yeni kontrol veya çıktı alanı eklenmedi.
