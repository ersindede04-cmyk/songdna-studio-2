# SONGDNA Studio 5.2.0 — Stage86

- Üretim geçmişindeki eski/kimliksiz kayıtların her okumada farklı kimlik alması riski giderildi.
- Eski kayıtlar için içerik ve sıra temelli kararlı kimlik üretimi eklendi; kayıtlar değiştirilmeden normalize ediliyor.
- Geçmiş ilk okunduğunda gerekli eski kayıt dönüşümü kalıcılaştırılıyor; yazma başarısız olursa kararlı kimlikler tekrar kullanılabiliyor.
- Dört üretim geçmişi modülü ve dört uygulama JavaScript kopyası eşitlendi.
