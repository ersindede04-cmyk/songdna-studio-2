# SONGDNA SMART STUDIO 5.7.0 — Stage 112

## Music DNA rehberlerinin canlı üretim aktarımı

- Seçilen Music DNA profilinin `instrument_guidance` alanı ortak üretim bağlamına aktarıldı.
- Seçilen profilin `lyrics_guidance` alanı ortak vokal/söz kimliği rehberine aktarıldı.
- Aynı Music Identity Profile hem Styles hem Lyrics isteminde kullanılır; her çıktı kendi amacına uygun ayrıntıyı işler.
- Kullanıcının seçtiği şarkı dili korunur; türden dil veya lehçe çıkarılmaz.
- İki çıktı alanı, manuel seçim önceliği, üç katmanlı prodüksiyon ve mevcut Gemini akışı korunmuştur.
- Arayüz, API, yeni üretim aşaması veya ek çıktı alanı eklenmemiştir.

## Kapsam

67 profil için enstrüman ve söz yazımı rehberlerinin ortak kimlik istemine aktarımı sınandı. Dört uygulama `app.js` kopyası eşitlendi.
