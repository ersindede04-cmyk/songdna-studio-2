# Stage 139 — Manuel Vokal Rollerinin Ayrıştırılması

- Ana vokal, geri vokal, düet, konuk vokal/konuk verse, çağrı-cevap ve vokal söyleyiş rolleri ayrı ayrı korunur.
- Konuk verse ana vokalin yerini almaz; düet yalnızca açıkça seçildiğinde iki ana vokal olarak ele alınır.
- Geri vokaller ana vokali destekler; kendiliğinden ortak ana vokale dönüştürülmez.
- Styles ve Lyrics yönergelerinde seçilen vokal rolleri tutarlı tutulur.
- Çelişki denetimi uyarı üretir; seçimleri otomatik değiştirmez.
- Yeni arayüz, çıktı alanı veya üçüncü çıktı eklenmedi.
