# Stage 102 — Doğal Şarkı Sözü Zekâsı

- Mevcut tema, konu, Story DNA ve dinamik yaratıcılık motorları korundu.
- Gemini Lyrics talimatları; ana tema, özel konu ve alt konuların ayrı ve tutarlı işlenmesi için geliştirildi.
- Doğal duygusal akış, sahici ayrıntılar, seçilen dilde idiomatik anlatım ve söylenebilirlik güçlendirildi.
- Zoraki kafiye, klişe imgeler, yapay cümle kalıpları ve gereksiz tekrarlar için açık kaçınma kuralları eklendi.
- Manuel seçim önceliği ve diğer alanların otomatik kalması korundu.
- Web/Android WebView kaynak kopyaları eşitlendi; eksik HTML script bağlantısı parity düzeltmesi yapıldı.
- Yeni ekran, düğme veya üçüncü çıktı alanı eklenmedi.
