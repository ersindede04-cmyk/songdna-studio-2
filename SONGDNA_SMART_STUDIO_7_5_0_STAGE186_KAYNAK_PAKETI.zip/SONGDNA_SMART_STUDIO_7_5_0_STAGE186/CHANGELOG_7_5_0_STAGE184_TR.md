# SONGDNA SMART STUDIO 7.5.0 — Stage184

## Tek hedef: Hikâye harmanlama endpoint'inin doğru backend'e ulaşması

- Stage183'te mevcut olan `/api/story-blend` istemci ve backend sözleşmesi korundu.
- Render'ın çalıştırdığı backend için `backend/server.js` tek kaynak kabul edildi; kök `server.js` aynı dosyayla eşitlendi.
- `/health` yanıtına sürüm, aşama ve desteklenen API yetenekleri eklendi. Böylece Render'ın gerçekten Stage184 backend'ini çalıştırıp çalıştırmadığı doğrulanabilir.
- `render.yaml` içindeki `rootDir: backend`, `npm install`, `npm start` ve `/health` sağlık kontrolü korundu.
- `/api/story-blend` için mevcut yapılandırılmış girdi doğrulaması, özel Türkçe anlatı talimatı, JSON yanıt doğrulaması ve Gemini tek-istek akışı korundu.
- Normal `/api/lyrics`, `/api/style`, `/api/command` ve `/api/lyrics-audit` endpoint'leri değiştirilmedi.
- Uygulama sürümü 7.5.0, Stage 184; Android versionCode 42 olarak güncellendi.

## Dağıtım notu

Render, GitHub deposuna yüklenmiş ZIP dosyasını kendiliğinden açıp çalıştırmaz. Render servisinin bağlı olduğu GitHub deposunda `backend/server.js`, `backend/package.json` ve `render.yaml` gerçek dosya olarak bulunmalıdır. Yalnızca kaynak ZIP'i depoda bulunuyorsa Render eski backend sürümünü çalıştırmaya devam edebilir.
