# Stage91 — Yedek Dosyası Bütünlüğü

- Yedek biçimi sürüm 2'ye yükseltildi ve içerik checksum doğrulaması eklendi.
- Stage90 sürüm 1 yedekleri geriye dönük uyumlu olarak içe aktarılmaya devam ediyor.
- Bozuk/değiştirilmiş içerik, geçersiz tarih ve aşırı büyük tekil/toplam kayıt boyutları geri yükleme öncesinde reddediliyor.
- Checksum yalnızca kazara bozulmayı tespit eder; şifreleme veya dosyanın kaynağını doğrulama sağlamaz.
- Dört Android/web yedek modülü kopyası eşitlendi.
