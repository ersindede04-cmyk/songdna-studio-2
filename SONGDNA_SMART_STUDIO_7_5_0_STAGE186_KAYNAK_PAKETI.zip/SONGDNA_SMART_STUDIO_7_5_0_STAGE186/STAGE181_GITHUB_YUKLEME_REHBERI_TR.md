# SONGDNA SMART STUDIO 7.1.0 — Stage181 Kaynak Paketi

Bu arşiv, GitHub Actions üzerinden Android debug APK üretmek için hazırlanmış tam kaynak paketidir.

## GitHub'a yükleme

1. ZIP dosyasını açmadan, GitHub deposunun ana dizinine şu adla yükleyin:
   `SONGDNA_SMART_STUDIO_7_1_0_STAGE181_KAYNAK.zip`
2. Bu arşivin içindeki `.github/workflows/build.yml` dosyasının içeriğini GitHub deposunda `.github/workflows/build.yml` konumuna ekleyin veya mevcut dosyanın içeriğini bununla değiştirin.
3. Değişiklikleri `main` dalına gönderin. ZIP ve workflow dosyası gönderildiğinde iş akışı otomatik tetiklenir. İsterseniz Actions sekmesinden `workflow_dispatch` ile elle de başlatabilirsiniz.
4. İşlem tamamlandığında Actions çalışmasının Artifacts bölümünden `SONGDNA-SMART-STUDIO-7.1.0-STAGE181-ANDROID-DEBUG` adlı çıktıyı indirin.

## Arşiv yapısı

ZIP açıldığında tek bir ana klasör oluşur:
`SONGDNA_SMART_STUDIO_7_1_0_STAGE181/`

GitHub Actions bu klasör adını bekler. Klasörün adını değiştirmeyin ve ZIP'i başka bir klasörün içine tekrar sarmalamayın.

## Otomatik kontroller

- Kaynak ve Android WebView dosya bütünlüğü
- Backend JavaScript sözdizimi
- 141 JavaScript regresyon dosyası
- 7 Python/tarayıcı regresyon dosyası
- Android debug APK derlemesi
- APK SHA-256 özeti

## Önemli sınırlar

Bu paket API anahtarı veya `APP_ACCESS_TOKEN` içermez. Render dağıtımı otomatik olarak bu ZIP tarafından yapılmaz; backend kaynak kodunun GitHub/Render dağıtım akışı ayrıca çalışmalıdır. GitHub Actions APK üretimi, canlı Gemini/Render testi veya fiziksel cihaz testi yapılmış olduğu anlamına gelmez.
