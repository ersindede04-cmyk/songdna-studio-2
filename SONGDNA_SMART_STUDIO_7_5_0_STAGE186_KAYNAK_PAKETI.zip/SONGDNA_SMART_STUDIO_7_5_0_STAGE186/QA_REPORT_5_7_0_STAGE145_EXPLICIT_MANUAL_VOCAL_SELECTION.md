# Stage 145 QA — Explicit manual vocal selection

## Scope
Ensure vocal placement warnings are generated only for explicitly selected manual vocal-role assignments, not for profile suggestions, disabled assignments, or absent selections.

## Changes
- Added an explicit manual-assignment gate to the live Lyrics placement audit.
- Ignores disabled/unselected entries and profile/default/automatic/suggested records.
- Removed ambiguous generic `section_assignments` as a source of manual assignments.
- Retains explicitly selected assignment arrays and the dedicated manual assignment field.
- No role selection means no placement warning.
- No automatic lyric rewrite, section creation, or selection mutation; no new UI/output.

## Validation
- Focused Stage 145 test: 14/14 assertions passed.
- Stage 143 live re-audit regression: 12/12 passed.
- Stage 144 warning reconciliation regression: 11/11 passed.
- JavaScript test files: 76/76 passed.
- Canonical Python test files: 5/5 passed.
- `scripts/verify-source.py`: passed; root, web and Android WebView assets and all four manifests are synchronized; JavaScript syntax, HTML dependencies and Android XML checks passed.
- Live Gemini, Render, APK installation and real Suno audio are not tested.
