# Stage 96 — Canlı Üç Katman Bağlantısı

- Ana Music DNA, mevcut Fusion ikincil Music DNA ve yeni isteğe bağlı Yardımcı Prodüksiyon seçimi tek orkestrasyon bağlamında birleştirildi.
- Ortak bağlam Gemini LYRICS ve STYLES istemlerine eklendi.
- Boş yardımcı katman otomatik doldurulmaz; aynı Music DNA iki alt rolde tekrar seçilemez.
- Web ve Android WebView dosyaları eşitlendi.
