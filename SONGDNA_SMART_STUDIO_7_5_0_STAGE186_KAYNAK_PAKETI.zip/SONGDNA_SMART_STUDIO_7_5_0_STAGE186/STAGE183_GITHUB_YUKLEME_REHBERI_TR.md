# Stage183 GitHub Yükleme Rehberi

1. `SONGDNA_SMART_STUDIO_7_2_0_STAGE183_KAYNAK.zip` dosyasını GitHub deposunun köküne yükle. ZIP'i açmadan yükle.
2. Paketin içindeki `.github/workflows/build.yml` dosyasını depodaki aynı yola koy.
3. Değişiklikleri `main` dalına gönder.
4. GitHub Actions içindeki `Stage183 Android Build` iş akışını çalıştır.
5. APK ve SHA-256 çıktısını indirip Stage177 çalışan APK ile gerçek cihazda karşılaştır.

Bu iş akışı APK üretir; Render backend dağıtımı yapmaz. Backend değişiklikleri için ayrıca mevcut Render hizmetine Stage183 `backend/server.js` dağıtılmalıdır. Canlı Gemini testi yapılmadan hikâye motorunun gerçek API başarısı doğrulanmış sayılmaz.
