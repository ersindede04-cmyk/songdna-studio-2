# QA — Stage 81 Independent Theme / Topic Modes

## Scope

Separate the general song-theme selector from the specific song-topic input and give the topic its own automatic/manual mode.

## Implemented

- Existing `songTheme` remains the general theme selector; `auto` keeps automatic theme inference.
- Added `topicMode` with `auto` and `manual` options.
- Automatic topic is chosen independently and does not read a manually typed topic value.
- Manual mode uses the entered topic and blocks empty submissions with a clear status message.
- Clicking a generated topic recommendation explicitly switches to manual mode and copies that choice into the topic field.
- Automatic topic history is committed after successful Lyrics generation, not when choosing a candidate or starting a request.

## Validation

- Stage 81 targeted test: PASS
- Stage 79 manual creative lock test: PASS
- Stage 80 theme/topic separation test: PASS
- Stage 47 responsive theme and asset synchronization: PASS (13 checks)
- Gemini instruction engine: PASS
- `node --check` for synchronized app.js copies: PASS
- Full test sweep: see delivery notes; one test initially exposed stale Android assets, then all copies were synchronized and the affected test passed.

## Not covered

Live Gemini/Render and physical Android device tests were not run.
