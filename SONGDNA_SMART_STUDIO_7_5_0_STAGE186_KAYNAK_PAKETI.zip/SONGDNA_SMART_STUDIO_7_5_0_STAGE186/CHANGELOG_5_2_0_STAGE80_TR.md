# SONGDNA Studio 5.2.0 — Stage 80

## Şarkı Teması ve Şarkı Konusu ayrımı

- Genel içerik alanı için bağımsız `songTheme` seçicisi eklendi.
- Özel olay/hikâye alanı `theme` olarak korunup arayüzde Şarkı Konusu adıyla netleştirildi.
- Gemini Lyrics talimatında genel tema ile somut konu ayrı ayrı aktarılıyor.
- Seçilen genel tema ortak çıktı kimlik sözleşmesine dahil edildi.
- Mevcut `theme` alanı, otomatik konu önerileri ve Gemini entegrasyonu geriye dönük uyumluluk için korundu.
- Styles üretim akışı ve Music DNA sıralaması değiştirilmedi.

## Sınırlama

Bu aşama veri ve istem ayrımını sağlar. Tema için bağımsız otomatik/manuel döngü ve konu için bağımsız otomatik/manuel döngü kontrolü sonraki aşamada tamamlanacaktır.
