# Stage 118 QA

- Regression tests cover genuine contradictions and valid mixed lead/guest arrangements.
- Instrumental-only cue blocks and parenthetical instrumental notes do not trigger vocal mismatch warnings.
- Plain lyric text without section labels is still detected against instrumental-only Styles.
- Four app.js runtime copies are identical.
- Not tested: live Gemini/Render, APK build/install, or actual Suno audio.
