# SONGDNA SMART STUDIO 5.2.0 — Stage 76 Engine and Feature Deduplication

## Scope
A source-level audit of the Stage 75 ZIP focused on overlapping production features and repeated prompt payloads. No UI feature was removed and no engine calculation was disabled.

## Findings and corrections
- `context()` was appending emotion, atmosphere, energy, section-arrangement, fusion and integrated-production prompt bodies into `productionProfile.promptText` even though each engine result was also retained in its own context property and included separately in task prompts. This made the core Production DNA field act as a second container for other engines' full instructions.
- The personal production model wrapper appended its full model prompt to Production DNA, while Styles and the instruction envelope also carried model information.
- The canonical Styles–Lyrics identity contract serialized full section-arrangement, production and integrated-production prompt bodies. Those same detailed bodies were already included in the task-specific prompt, creating another duplicate copy.
- The compact Gemini envelope repeated the complete shared identity contract even though it was already in the task prompt.

Changes:
- Production DNA now retains its own core profile text. Emotion, atmosphere, energy, section arrangement, fusion and integrated-production prompt guidance remain in their own engine context objects rather than being concatenated into Production DNA.
- Styles and Lyrics each receive the relevant engine guidance once in separately named sections.
- Personal production model text remains a separate authoritative block; the compact envelope carries only a boolean presence marker.
- The canonical shared identity contract now carries compact IDs, selected values, arrangement mode and manual locks, not full prompt bodies.
- The Gemini envelope no longer serializes a second copy of the shared identity contract.
- Synchronized all four `app.js` runtime copies.

## Preserved behavior
- No engine, UI feature, catalog, Music DNA profile or production control was removed.
- Manual selections and production-model protection rules remain authoritative.
- Music DNA identity, section arrangement, vocal/ad-lib guidance, fusion, BPM, emotion, energy and atmosphere remain represented in the task prompts.
- Styles and Lyrics continue to use the same canonical production snapshot and the two-output contract.
- Gemini endpoint, API key handling, access token, model selection and 100,000-character preflight limit were not changed.

## Verification
- `node --check app.js`: passed.
- `python3 scripts/verify-source.py`: passed.
- Stage 76 targeted regression: passed.
- Full JavaScript regression suite: 52/52 test files passed.
- Live Gemini, Render, physical Android/APK installation and Suno audio listening were not performed as part of this source audit.

## Important limitation
The precise character count depends on selected profiles and user options. The expected reduction is structural, but the device must be rebuilt and tested to confirm the actual request falls below 100,000 characters for the user's real selection set. If it remains over the limit, the next step is to inspect the largest remaining individual engine payloads rather than delete musical detail indiscriminately.
