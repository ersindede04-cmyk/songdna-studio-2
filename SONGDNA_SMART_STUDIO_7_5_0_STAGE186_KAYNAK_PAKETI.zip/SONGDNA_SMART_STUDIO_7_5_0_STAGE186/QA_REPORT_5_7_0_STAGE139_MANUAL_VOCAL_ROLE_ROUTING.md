# Stage 139 QA — Manual Vocal Role Routing

Scope: distinguish and preserve lead, backing, duet, guest vocal/verse, call-and-response and delivery roles across Styles and Lyrics.

Validation:
- Focused Stage 139 test: 67 profile iterations + 8 assertions passed.
- Stage 138 manual Styles budget regression test passed.
- JavaScript syntax check passed.
- Automatic rewrite: disabled.
- Manual selections changed: false.
- Guest verse may coexist with lead vocal: true.
- Live Gemini, APK installation and Suno audio: not tested.
