# SONGDNA SMART STUDIO 7.0.0 — Stage 176

## Stage175 tabanı üzerinde yapılan değişiklikler

- Şarkı sözü üretim yönergesine nakarat tekrar kontrolü eklendi: art arda tam nakarat kopyalama ve sırf süreyi doldurmak için tekrar engellenir; türün, formun ve anlatının gerektirdiği tekrarlar korunur.
- Geleneksel müziklerde kavuştak, döngüsel tekrar, katılımcı çağrı-cevap ve türün doğal formu için açık istisna tanımlandı.
- Ad-lib kataloğuna kullanıcı tarafından seçilebilen `vocable` türü eklendi: taka taka, paka paka, taka tuka, papi papi, ram papapam, la la la, ta ta ta, ya ya ya, a ya ya ya, bam bam, dan dan ve prrr.
- Vocable öğeleri kültürel köken iddiası olmadan sınıflandırılır; otomatik eklenmez, seçilmedikçe üretim metnine sokulmaz. Seçilen biçimler korunur ve ana şarkı dilinden bağımsız vokal motifleri olarak değerlendirilir.
- Katalog arayüzünde vocable kalıpları ayrı tür etiketiyle gösterilir.
- Stage176 için hedefli regresyon testi eklendi.
- GitHub Actions iş akışı Stage176 kaynak ZIP'ini açacak ve JavaScript testlerini sabit sayıya kilitlemeden çalıştıracak şekilde güncellendi.

## Korunan sistemler

- Gemini → Lyrics / Styles üretim akışı, Music DNA katalogları, mevcut tema/hikâye motoru, ad-lib kültür seçimi, geleneksel müzik kuralları ve Android WebView sarmalayıcısı korunmuştur.
- Android `versionCode` ve `versionName` değiştirilmemiştir; bu kaynak paketi derleme öncesi test/derleme kitidir.

## Doğrulama sınırları

- Yerel JavaScript sözdizimi ve Stage176 hedefli test bu çalışma ortamında çalıştırılır.
- GitHub Actions, Android APK derlemesi, fiziksel cihaz, canlı Render/Gemini ve Suno ses üretimi bu yerel paketleme işleminde doğrulanmış sayılmaz.
