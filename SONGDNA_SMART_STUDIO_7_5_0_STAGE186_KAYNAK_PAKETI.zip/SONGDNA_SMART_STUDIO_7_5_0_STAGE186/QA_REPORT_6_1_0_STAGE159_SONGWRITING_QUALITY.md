# Stage159 QA — Söz Yazımı Kalitesi

## Kontroller
- Stage157 kullanıcı girdisi sadakati testi, Stage159 kalite talimatlarını da doğrulayacak şekilde genişletildi.
- Dört uygulama `app.js` kopyasının aynı olması kontrol edildi.
- Backend sunucu dosyalarının eşitliği ve Gemini Lyrics sistem talimatındaki kalite standardı kontrol edildi.
- Mevcut Lyrics endpoint ve iki alanlı Styles/Lyrics üretim sözleşmesi korunuyor.
- `node --check`, tüm JavaScript regresyon testleri, Python testleri ve `scripts/verify-source.py` çalıştırılacaktır.

## Beklenen davranış
Gemini; kullanıcı konusunu ve özel ifadeleri koruyarak doğal, tutarlı, söylenebilir, klişelerden arındırılmış sözler ve güçlü bir nakarat üretmeye yönlendirilir. Prompt talimatları model davranışını garanti etmez; canlı örneklerle ayrıca değerlendirilmelidir.

## Henüz doğrulanmayanlar
Canlı Gemini/Render, GitHub Actions APK derlemesi, gerçek cihaz etkileşimi ve Suno ses çıktısı.
