/* SONGDNA Stage 53: immutable identity for the final shared Styles/Lyrics profile. */
(function(root){
  function stable(value){
    if(Array.isArray(value))return value.map(stable);
    if(value&&typeof value==='object')return Object.keys(value).sort().reduce((o,k)=>{o[k]=stable(value[k]);return o;},{});
    if(typeof value==='number'&&!Number.isFinite(value))return null;
    return value===undefined?null:value;
  }
  function canonical(value){return JSON.stringify(stable(value));}
  function hash(text){let h=0x811c9dc5;for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,0x01000193);}return (h>>>0).toString(16).padStart(8,'0');}
  function build(context){
    const c=context||{};
    const snapshot={
      dna:c.dna||'',style:c.style||'',theme:c.theme||'',exclude:c.exclude||'',musicDnaRotation:c.musicDnaRotation||'',
      topicMode:c.topicMode||'auto',songThemeMode:c.songThemeMode||'auto',songTheme:c.songTheme||'',
      globalProfile:c.globalProfile||null,technique:c.technique||null,fusion:c.fusion||'',
      fusionProfile:c.fusionProfile||null,bpm:c.bpm??null,language:c.language||'',
      mainVoice:c.mainVoice||'',back:c.back||'',adlib:c.adlib||'',effects:c.effects||'',
      introId:c.introId||'',introTitle:c.introTitle||'',introLyrics:c.introLyrics||'',introStyle:c.introStyle||'',
      region:c.region||'',regionLabel:c.regionLabel||'',localWords:c.localWords||'',notes:c.notes||'',
      productionProfile:c.productionProfile||null,musicIdentityProfile:c.musicIdentityProfile||c.threeLayerProduction?.musicIdentityProfile||null,
      threeLayerProduction:c.threeLayerProduction||null,threeLayerProductionPrompt:c.threeLayerProductionPrompt||'',
      productionModelPrompt:c.productionModelPrompt||'',emotionProfile:c.emotionProfile||null,
      energyProfile:c.energyProfile||null,atmosphereProfile:c.atmosphereProfile||null,
      sectionArrangementProfile:c.sectionArrangementProfile||null,vocalProfile:c.vocalProfile||null,
      vocalIdentityProfile:c.vocalIdentityProfile||null,integratedProductionProfile:c.integratedProductionProfile||null,
      compatibility:c.compatibility||null,adlibScene:c.adlibScene||'',adlibPhraseIds:c.adlibPhraseIds||[],
      adlibJargonIds:c.adlibJargonIds||[],adlibCultureSources:c.adlibCultureSources||[],
      adlibCustom:c.adlibCustom||'',personalAdlibs:c.personalAdlibs||'',adlibSource:c.adlibSource||'',adlibDiversity:c.adlibDiversity||'',
      adlibPlacement:c.adlibPlacement||'',adlibArrangementMode:c.adlibArrangementMode||'',adlibAdaptationMode:c.adlibAdaptationMode||'',
      vocalDelivery:c.vocalDelivery||'',vocalTexture:c.vocalTexture||'',regionalVocalMode:c.regionalVocalMode||'',
      productionArrangementMode:c.productionArrangementMode||'',manualLocks:c.manualLocks||c.productionModelLocks||null,preserveMode:c.preserveMode||'',preserveText:c.preserveText||'',preLength:c.preLength||''
    };
    const serialized=canonical(snapshot);
    return {version:'SONGDNA_PROFILE_SNAPSHOT_1',id:'sdprof-'+hash(serialized),snapshot};
  }
  function matches(a,b){return !!a&&!!b&&a.version==='SONGDNA_PROFILE_SNAPSHOT_1'&&b.version==='SONGDNA_PROFILE_SNAPSHOT_1'&&a.id===b.id&&canonical(a.snapshot)===canonical(b.snapshot);}
  root.SongDnaProfileSnapshot={build,matches,canonical};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaProfileSnapshot;
})(typeof globalThis!=='undefined'?globalThis:this);
