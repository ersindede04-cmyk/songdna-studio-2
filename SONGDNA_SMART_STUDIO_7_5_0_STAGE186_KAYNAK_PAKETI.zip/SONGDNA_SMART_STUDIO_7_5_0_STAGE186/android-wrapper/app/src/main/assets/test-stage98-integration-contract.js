const fs=require('fs');
const app=fs.readFileSync('app.js','utf8');
const html=fs.readFileSync('index.html','utf8');
if(!app.includes('c.productionElementCompatibility=elementEngine?elementEngine.analyze(c.productionElementProfile)'))throw Error('context integration missing');
if(!app.includes('PRODUCTION ELEMENT COMPATIBILITY ADVISORY'))throw Error('style prompt advisory missing');
if(!(html.indexOf('production-element-library-data.js')<html.indexOf('production-element-library.js')&&html.indexOf('production-element-library.js')<html.indexOf('src="app.js"')))throw Error('script load order wrong');
console.log('Stage 98 integration contract PASS');
