/* SONGDNA Stage 56 — personal production model library. */
(function(root){'use strict';
 const KEY='songdna_personal_production_models_v1';
 const safe=x=>{try{return JSON.parse(JSON.stringify(x||{}))}catch(_){return{}}};
 function list(){try{const x=JSON.parse(root.localStorage.getItem(KEY)||'[]');return Array.isArray(x)?x.filter(v=>v&&v.id&&v.snapshot):[]}catch(_){return[]}}
 function save(title,snapshot){const name=String(title||'').trim();if(!name)throw new Error('Model adı gerekli.');const rows=list();const id='prod-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7);const model={id,title:name,snapshot:safe(snapshot),createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};rows.push(model);root.localStorage.setItem(KEY,JSON.stringify(rows));return model}
 function get(id){return list().find(x=>x.id===id)||null}
 function remove(id){const rows=list().filter(x=>x.id!==id);root.localStorage.setItem(KEY,JSON.stringify(rows));return rows}
 function rename(id,title){const name=String(title||'').trim();if(!name)return list();const rows=list().map(x=>x.id===id?{...x,title:name,updatedAt:new Date().toISOString()}:x);root.localStorage.setItem(KEY,JSON.stringify(rows));return rows}
 // Return a defensive copy; applying a model must never mutate the saved original.
 function snapshot(id){const model=get(id);return model?safe(model.snapshot):null}
 function buildApplication(id,mode){const model=get(id);if(!model)return null;const snap=safe(model.snapshot);const allowed=['bpm','energy','fusion','dna','style','globalProfile','productionProfile','energyProfile','atmosphereProfile','emotionProfile','sectionArrangementProfile','integratedProductionProfile','vocalProfile','vocalIdentityProfile','fusionProfile','mainVoice','back','effects','adlib','technique','productionArrangementMode'];const parameters={};allowed.forEach(k=>{if(snap[k]!==undefined&&snap[k]!==null&&snap[k]!=='')parameters[k]=safe(snap[k])});return {id:model.id,title:model.title,mode:['faithful','smart','experimental'].includes(mode)?mode:'faithful',parameters,sourceUpdatedAt:model.updatedAt||model.createdAt||null,appliedAt:new Date().toISOString()}}
 root.SongDnaProductionModelLibrary={list,save,get,remove,rename,snapshot,buildApplication};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaProductionModelLibrary;
})(typeof globalThis!=='undefined'?globalThis:this);
