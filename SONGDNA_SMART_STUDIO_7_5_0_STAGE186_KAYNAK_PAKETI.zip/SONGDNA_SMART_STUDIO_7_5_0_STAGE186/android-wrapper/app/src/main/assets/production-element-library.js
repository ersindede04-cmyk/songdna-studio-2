/* SONGDNA Stage 97 — curated production-element composer. Prompt guidance only; no audio DSP. */
(function(root){
 'use strict';
 const DATA=typeof require==='function'?require('./data/electronic_production_elements_v1.json'):root.SONGDNA_ELECTRONIC_PRODUCTION_ELEMENTS;
 const items=DATA&&Array.isArray(DATA.items)?DATA.items:[];
 const ELECTRONIC=/house|techno|trance|garage|drum.?and.?bass|jungle|dubstep|bass.?music|edm|electronic|synthwave|amapiano|breakbeat|future.?bass|disco|electro|dancehall|trap|drill/i;
 const clean=x=>String(x||'').toLowerCase();
 function profileText(p){return [p?.name,p?.primary_genre,p?.genre,p?.genre_family,p?.region_or_scene,...(p?.tags||[]),...(p?.musical_traits||[])].filter(Boolean).join(' ');}
 function build(input={}){
  const layers=(input.layers||[]).filter(x=>x&&x.selected);
  const main=layers.find(x=>x.role==='main');
  const mainText=clean([main?.name,main?.family,main?.promptText].join(' '));
  const profile= input.profile||{};
  const baseText=clean(profileText(profile)+' '+(input.dna||'')+' '+(input.style||''));
  const electronic=ELECTRONIC.test(mainText||baseText);
  if(!electronic)return {enabled:false,reason:'Ana kimlik elektronik/modern prodüksiyon sınıfında değil; otomatik elektronik öğe eklenmedi.',items:[],promptText:''};
  const layerText=layers.map(x=>clean([x.role,x.name,x.family,x.promptText].join(' ')));
  const scored=items.map(it=>{
   const tags=it.genre_tags.map(clean);
   let score=0;
   const source=it.roles.includes('main')?mainText:baseText;
   tags.forEach(t=>{if(t&&source.includes(t.replace(/-/g,' ')))score+=3; if(t&&baseText.includes(t))score+=1;});
   if(it.roles.includes('main'))score+=2;
   if(it.category==='mix')score+=1;
   if(it.category==='rhythm'&&/house|techno|disco/.test(source)&&it.name.toLowerCase().includes('four-on-the-floor'))score+=2;
   return {...it,_score:score};
  }).filter(x=>x._score>0);
  const chosen=[];
  const caps={rhythm:2,drums:2,bass:2,synth:2,percussion:1,vocal:1,fx:1,mix:2};
  Object.keys(caps).forEach(cat=>{
   scored.filter(x=>x.category===cat).sort((a,b)=>b._score-a._score).slice(0,caps[cat]).forEach(x=>chosen.push(x));
  });
  const ordered=chosen.sort((a,b)=>['rhythm','drums','bass','synth','percussion','vocal','fx','mix'].indexOf(a.category)-['rhythm','drums','bass','synth','percussion','vocal','fx','mix'].indexOf(b.category));
  const lines=ordered.map(x=>x.suno_prompt);
  const promptText=lines.length?'CURATED PRODUCTION ELEMENTS (support the selected electronic identity; do not treat as extra genres): '+lines.join('; ')+'. Keep kick and bass separated, preserve headroom, and use effects selectively.':'';
  return {enabled:true,items:ordered.map(({id,category,name,suno_prompt,roles,compatibility_note})=>({id,category,name,suno_prompt,roles,compatibility_note})),promptText};
 }
 const PAIR_RULES=[
  {a:/four-on-the-floor kick pulse/i,b:/broken-beat syncopation/i,kind:'conflict',reason:'Düz dört vuruşlu kick ile broken-beat ana groove aynı anda ana ritim rolüne yerleşiyor.',alternative:'Ana ritim kimliğini seç; diğerini ancak kısa geçiş veya ayrı bölüm kontrastı olarak kullan.'},
  {a:/four-on-the-floor kick pulse/i,b:/half-time pulse/i,kind:'experimental',reason:'Dört vuruşlu dans pulse hissi ile half-time hissi farklı ana vuruş algıları oluşturabilir.',alternative:`Kick ana pulse'u taşısın; half-time hissini snare/vokal bölümlendirmesinde kullan veya bilinçli kontrast olarak koru.`},
  {a:/808 glide bass/i,b:/rolling bassline/i,kind:'experimental',reason:'Kaymalı 808 ile sürekli rolling bassline aynı anda iki baskın bas melodisi oluşturabilir.',alternative:'Birini ana bas motifi seç; diğerini seyrek cevap veya ayrı bölümde kullan.'},
  {a:/reese bass/i,b:/wobble bass modulation/i,kind:'experimental',reason:'Reese karakteri ve yoğun wobble modülasyonu bas katmanında gereksiz yoğunluk yaratabilir.',alternative:'Tek baskın bas karakteri seç veya modülasyonu yalnızca geçişlerde kullan.'},
  {a:/supersaw lead/i,b:/intimate soulful vocal|airy breathy vocal texture/i,kind:'experimental',reason:'Geniş ve baskın supersaw lead ile yakın/mahrem vokal aynı frekans ve ön plan alanı için yarışabilir.',alternative:'Lead synth ve vokali farklı anlarda öne çıkar; synth yoğunluğunu vokal cümlelerinde azalt.'},
  {a:/trap hat rolls/i,b:/shuffle and swing/i,kind:'experimental',reason:`Yoğun trap hi-hat roll'leri ile belirgin shuffle aynı ritmik alt bölümlerde karmaşa yaratabilir.`,alternative:'Swing miktarını hafiflet veya hızlı roll ifadelerini bölüm sonlarına taşı.'},
  {a:/sub drop impact/i,b:/deep rounded kick|warm sub-bass foundation/i,kind:'experimental',reason:'Sub drop, kick ve sürekli sub bas ile aynı anda düşük frekansları aşırı yoğunlaştırabilir.',alternative:`Sub drop'u yalnızca geçişte kullan; kick ve basın düşük frekans alanını açık tut.`}
 ];
 function analyze(result={}){
  const chosen=Array.isArray(result.items)?result.items:[];
  const notes=[];
  PAIR_RULES.forEach(rule=>{
   const left=chosen.find(x=>rule.a.test(x.name||''));
   const right=chosen.find(x=>rule.b.test(x.name||''));
   if(left&&right)notes.push({id:'production-pair:'+left.id+':'+right.id,kind:rule.kind,reason:rule.reason,alternative:rule.alternative,elements:[left.id,right.id]});
  });
  const seen=new Set();
  const unique=notes.filter(n=>{if(seen.has(n.id))return false;seen.add(n.id);return true;});
  const level=unique.some(n=>n.kind==='conflict')?'conflict':unique.length?'experimental':'compatible';
  return {level,label:level==='conflict'?'ÇATIŞMA':level==='experimental'?'DENEYSEL':'UYUMLU',notes:unique,alternatives:unique.map(n=>n.alternative),canProceed:true,advisoryOnly:true,selectionChanged:false};
 }
 root.SONGDNAProductionElementLibrary={data:DATA,list:()=>items.slice(),build,analyze};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.SONGDNAProductionElementLibrary;
})(typeof globalThis!=='undefined'?globalThis:this);
