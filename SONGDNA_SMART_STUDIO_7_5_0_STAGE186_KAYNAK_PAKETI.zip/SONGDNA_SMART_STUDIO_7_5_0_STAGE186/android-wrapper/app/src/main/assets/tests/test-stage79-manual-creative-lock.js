const fs=require('fs');
const source=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const expected="ids.slice(1).forEach((id,i)=>{const el=$(id);if(el&&!el.dataset.userEdited){el.value=vals[i+1];el.dataset.userEdited='0';}});";
if(!source.includes(expected)) throw new Error('Stage 79: manual creative fields can still be overwritten by forced refresh.');
if(source.includes("if(el&&(!el.dataset.userEdited||force))")) throw new Error('Stage 79: unsafe force override remains.');
console.log('Stage 79 manual creative lock: PASS');
