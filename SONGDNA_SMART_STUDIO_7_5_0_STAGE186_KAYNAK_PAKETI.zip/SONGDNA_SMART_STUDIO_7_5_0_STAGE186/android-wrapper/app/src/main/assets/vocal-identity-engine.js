/* SONGDNA Vocal Identity Engine v1.0
 * Converts the user's explicit lead/backing voice selection into actionable,
 * gender-aware performance direction without assuming a fixed vocal range.
 */
(function(root){
 const text=v=>String(v||'').toLowerCase();
 function classify(value){
  const s=text(value);
  if(/male rap with female melodic|erkek rap.*kadın/.test(s))return {lead:'male',support:'female',mode:'dual-role'};
  if(/female rap with male melodic|kadın rap.*erkek/.test(s))return {lead:'female',support:'male',mode:'dual-role'};
  if(/male lead vocal with female support|erkek ana.*kadın/.test(s))return {lead:'male',support:'female',mode:'lead-support'};
  if(/female lead vocal with male support|kadın ana.*erkek/.test(s))return {lead:'female',support:'male',mode:'lead-support'};
  if(/male and female duet|kadın-erkek düet|duet/.test(s))return {lead:'both',support:'both',mode:'duet'};
  if(/female solo|kadın solo|female/.test(s))return {lead:'female',support:'none',mode:'solo'};
  if(/male solo|erkek solo|male/.test(s))return {lead:'male',support:'none',mode:'solo'};
  if(/group choir|group|koro|chorus/.test(s))return {lead:'ensemble',support:'ensemble',mode:'ensemble'};
  return {lead:'unspecified',support:'unspecified',mode:'auto'};
 }
 function voiceDirection(gender,role){
  if(gender==='male')return `${role}: male voice identity; direct the selected singer with a natural, comfortable register, clear diction, genre-appropriate phrasing and expressive dynamics. Do not impose an assumed low pitch or stereotyped timbre.`;
  if(gender==='female')return `${role}: female voice identity; direct the selected singer with a natural, comfortable register, clear diction, genre-appropriate phrasing and expressive dynamics. Do not impose an assumed high pitch or stereotyped timbre.`;
  if(gender==='both')return `${role}: distinct male and female voices; assign complementary phrases or harmonies, preserve intelligible separation and avoid blending both identities into one anonymous voice.`;
  if(gender==='ensemble')return `${role}: ensemble identity; specify unison, harmony or responsorial roles only where compatible with the selected Music DNA.`;
  if(gender==='none')return `${role}: no additional voice layer; keep the arrangement instrumental or lead-only as selected.`;
  return `${role}: retain the user's selected or automatic voice identity without inventing a gender.`;
 }
 function build(c={}){
  const lead=classify(c.mainVoice),back=classify(c.back),folk=/folk|zeybek|mugham|flamenco|baul|pansori|urtiin|polyphon|canto a tenore|ahellil|gnawa|raï|rai|son jarocho|hindustani|carnatic|makam|min'yō|minyo|avaz|gamelan/.test(text(c.dna));
  const leadText=voiceDirection(lead.lead,'Lead vocal');
  const supportText=voiceDirection(back.lead==='unspecified'?lead.support:back.lead,'Backing vocal');
  const duetRule=lead.mode==='duet'||lead.mode==='dual-role'?'For duet/dual-role delivery, identify which singer carries each line, alternate or overlap intentionally, and reserve shared harmony/unison for selected hook moments.': '';
  const traditionRule=folk?'TRADITIONAL VOCAL IDENTITY: preserve the selected tradition’s documented vocal role, register practice, ornamentation and ensemble form. Gender selection identifies the requested singer; it does not authorize changing the tradition or inventing a vocal technique.':'';
  const promptText=[leadText,supportText,duetRule,traditionRule,'VOCAL GENDER CONSISTENCY: keep the same selected voice identity throughout Styles and Lyrics section tags. Use [Male Lead Vocal], [Female Lead Vocal], [Male Backing Vocals], [Female Backing Vocals], or [Male and Female Duet] only when they match the selected roles. Do not switch singer identity between sections without an explicit arrangement reason.'].filter(Boolean).join(' ');
  return {lead,back,leadText,supportText,duetRule,traditionalIdentity:folk,promptText};
 }
 root.SongDnaVocalIdentityEngine={build,classify};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaVocalIdentityEngine;
})(typeof window!=='undefined'?window:globalThis);
