const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const backing = new Map();
function makeRuntime() {
  const localStorage = {
    getItem(key) { return backing.has(key) ? backing.get(key) : null; },
    setItem(key, value) { backing.set(String(key), String(value)); },
    removeItem(key) { backing.delete(key); }
  };
  const context = { localStorage, console, Date, Math, JSON, Map, Set, Error };
  context.globalThis = context;
  context.window = context;
  vm.createContext(context);
  for (const file of ['production-history.js', 'production-history-storage.js', 'saved-library.js']) {
    vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, { filename: file });
  }
  return context;
}

// First app process: persist a generated history record, saved lyric, and personal theme/topic.
let app = makeRuntime();
const history = app.SongDnaProductionHistory;
const historyStorage = app.SongDnaProductionHistoryStorage;
const savedCore = app.SongDnaSavedLibrary;
const historyRecord = history.add([], { title: 'Restart testi', lyrics: 'Kalıcı sözler', style: 'Melodic Trap' });
assert.equal(historyStorage.write(app.localStorage, 'songdna_history', historyRecord).ok, true);
const savedLyrics = savedCore.add([], { title: 'Arşiv kaydı', lyrics: 'Arşivde kalmalı', style: 'Anatolian Rock' });
app.localStorage.setItem('songdna_saved', JSON.stringify(savedLyrics));
app.localStorage.setItem('songdna_personal_theme_topic_v1', JSON.stringify({ version: 1, theme: 'Kişisel tema', topic: 'Kişisel konu' }));

// Simulate process death and a fresh JavaScript/WebView runtime over the same persistent store.
app = makeRuntime();
const restoredHistory = app.SongDnaProductionHistoryStorage.read(app.localStorage, 'songdna_history', app.SongDnaProductionHistory);
assert.equal(restoredHistory.ok, true);
assert.equal(restoredHistory.items[0].lyrics, 'Kalıcı sözler');
assert.equal(restoredHistory.items[0].style, 'Melodic Trap');
const restoredSaved = app.SongDnaSavedLibrary.normalize(JSON.parse(app.localStorage.getItem('songdna_saved')));
assert.equal(restoredSaved[0].lyrics, 'Arşivde kalmalı');
assert.ok(restoredSaved[0].id);
const personal = JSON.parse(app.localStorage.getItem('songdna_personal_theme_topic_v1'));
assert.equal(personal.theme, 'Kişisel tema');
assert.equal(personal.topic, 'Kişisel konu');

// Ensure history remains capped at the documented 20 records after a fresh runtime.
let twenty = [];
for (let i = 0; i < 22; i++) twenty = app.SongDnaProductionHistory.add(twenty, { title: `Şarkı ${i}`, lyrics: `Söz ${i}` });
assert.equal(twenty.length, 20);
assert.equal(twenty[0].title, 'Şarkı 2');
console.log('Stage89 runtime restart persistence tests passed.');
