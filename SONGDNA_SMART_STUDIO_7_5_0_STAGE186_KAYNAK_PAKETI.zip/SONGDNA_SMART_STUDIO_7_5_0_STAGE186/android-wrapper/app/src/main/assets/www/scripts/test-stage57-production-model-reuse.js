const fs=require('fs');const vm=require('vm');const assert=require('assert');
const src=fs.readFileSync('production-model-library.js','utf8');
const store={};const ctx={localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v},Date,Math,JSON};vm.runInNewContext(src,ctx);
const lib=ctx.SongDnaProductionModelLibrary;
const saved=lib.save('Test Model',{bpm:124,energy:'High',dna:'DNA-X',productionProfile:{promptText:'locked bass and rhythm'},mainVoice:'Male'});
const before=JSON.stringify(lib.get(saved.id));
for(const mode of ['faithful','smart','experimental']){const app=lib.buildApplication(saved.id,mode);assert.equal(app.title,'Test Model');assert.equal(app.parameters.bpm,124);assert.equal(app.parameters.productionProfile.promptText,'locked bass and rhythm');}
assert.equal(JSON.stringify(lib.get(saved.id)),before,'Applying model descriptors must not mutate the saved model');
assert.equal(lib.snapshot(saved.id).bpm,124);
assert.equal(lib.buildApplication('missing','faithful'),null);
const app=fs.readFileSync('app.js','utf8'),html=fs.readFileSync('index.html','utf8');
assert(app.includes("$('applyProductionModel')?.addEventListener('click',applySelectedProductionModel)"));
assert(app.includes('MANUAL OVERRIDES: explicit current user selections take priority'));
assert(app.includes('personalProductionModel:c.productionModelPrompt||\'\''));
assert(app.includes('PERSONAL PRODUCTION MODEL (authoritative reference)'));
assert(html.includes('id="productionModelMode"')&&html.includes('id="applyProductionModel"'));
console.log('Stage 57 PASS: explicit apply, three adaptation modes, defensive snapshots, immutable saved model, manual override priority and shared Styles/Lyrics context.');
