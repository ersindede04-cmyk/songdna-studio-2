/* SONGDNA Atmosphere Engine v1.0
 * Explicit atmosphere choice + emotion-aware defaults; Music DNA identity stays primary.
 */
(function(root){
 'use strict';
 const PROFILES={
  auto:{label:'Otomatik / müziğe göre',tags:[],prompt:'Infer atmosphere from the selected Music DNA, emotion and user brief; do not impose a generic cinematic layer.'},
  dark:{label:'Karanlık',tags:['shadowed depth','restrained low-mid texture','controlled tension'],prompt:'Create a dark, focused atmosphere with controlled harmonic tension and shadowed depth; keep transients and lead vocal clear.'},
  romantic:{label:'Romantik',tags:['warm harmonic color','intimate space','soft depth'],prompt:'Create an intimate romantic atmosphere with warm harmonic color, gentle spatial depth and expressive melodic support; avoid excessive sweetness.'},
  melancholic:{label:'Melankolik',tags:['spacious phrasing','soft haze','reflective depth'],prompt:'Create a reflective melancholic atmosphere with spacious phrasing, restrained haze and emotional depth; preserve the selected groove and cultural identity.'},
  airy:{label:'Ferah / havadar',tags:['open stereo image','light texture','breathing space'],prompt:'Keep the atmosphere open, airy and uncluttered, with breathing space and light supporting textures; never blur the lead.'},
  aggressive:{label:'Agresif',tags:['focused impact','tense texture','sharp transitions'],prompt:'Use a focused aggressive atmosphere with controlled impact, tense texture and decisive transitions; avoid uncontrolled distortion or loudness.'},
  cinematic:{label:'Sinematik',tags:['layered depth','dramatic transitions','wide dynamics'],prompt:'Build cinematic scale through purposeful layering, dynamic contrast and dramatic transitions; avoid adding orchestral or electronic instruments unless compatible with the selected Music DNA.'},
  warm:{label:'Sıcak / samimi',tags:['warm tone','close presence','gentle ambience'],prompt:'Favor warm tone, close presence and gentle ambience, keeping the arrangement human and inviting.'},
  epic:{label:'Epik / görkemli',tags:['wide scale','rising layers','strong arrivals'],prompt:'Create a sense of scale with rising layers and strong section arrivals, while preserving headroom and the primary genre.'},
  intimate:{label:'Yakın / minimal',tags:['close vocal','minimal ambience','negative space'],prompt:'Keep the sound intimate and minimal, with close vocal presence, restrained ambience and intentional negative space.'},
  ethereal:{label:'Ethereal / düşsel',tags:['soft diffusion','floating texture','gentle spatial motion'],prompt:'Create a floating, dreamlike atmosphere with soft diffusion and gentle spatial motion; maintain rhythmic definition and vocal intelligibility.'}
 };
 const EMOTION_DEFAULT={melancholy:'melancholic',grief:'melancholic',longing:'melancholic',love:'romantic',hope:'airy',anger:'aggressive',confidence:'dark',joy:'warm',anxiety:'dark',triumph:'epic'};
 function build(choice='auto',emotion={},custom='',family=''){
  const key=PROFILES[choice]?choice:'auto',inferred=key==='auto'?(EMOTION_DEFAULT[emotion.type]||'auto'):key,p=PROFILES[inferred]||PROFILES.auto;
  const level=Number(emotion.intensity)||2,scale=level>=4?'pronounced':level===3?'clear':level===1?'subtle':'balanced';
  const traditional=String(family).toLowerCase()==='traditional';
  const guard=traditional?'For traditional/acoustic Music DNA, express atmosphere through authentic room character, ensemble balance, dynamics, phrasing and acoustic texture; do not add pads, synths, orchestral layers or electronic sound design unless explicitly selected.':'Do not replace the selected Music DNA instrumentation, rhythm, regional character or arrangement identity.';
  const customText=String(custom||'').trim();
  const promptText=[`ATMOSPHERE ENGINE — ${p.label}.`,p.prompt,`Atmosphere intensity follows emotional intensity (${scale}) but remains distinct from energy and BPM.`,guard,customText?`User's additional atmosphere description: ${customText}. Preserve this description without overriding the selected genre.`:''].filter(Boolean).join(' ');
  return {choice:key,effective:inferred,label:p.label,tags:p.tags,intensity:level,custom:customText,promptText};
 }
 root.SongDnaAtmosphereEngine={version:'1.0',build,profiles:PROFILES};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaAtmosphereEngine;
})(typeof globalThis!=='undefined'?globalThis:this);
