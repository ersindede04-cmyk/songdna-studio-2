/* SONGDNA Music Compatibility Engine v2
 * Advisory cross-domain checks. Never mutates user selections or blocks generation.
 * Tempo ranges are starting points, not hard genre laws; intentional half/double-time
 * and cross-cultural fusions remain available to the user.
 */
(function(root){
 'use strict';
 const RULES=[
  {id:'tech-house-tempo',match:/tech\s?house/,range:[120,130],label:'Tech House'},
  {id:'dnb-tempo',match:/drum\s*&?\s*bass|\bdnb\b|jungle/,range:[160,180],label:'Drum & Bass / Jungle'},
  {id:'house-tempo',match:/\bhouse\b|afro.?house/,range:[115,130],label:'House'},
  {id:'techno-tempo',match:/\btechno\b/,range:[120,140],label:'Techno'},
  {id:'amapiano-tempo',match:/amapiano/,range:[108,116],label:'Amapiano'},
  {id:'uk-garage-tempo',match:/uk garage|2.?step|speed garage/,range:[128,140],label:'UK Garage / 2-step'},
  {id:'trap-tempo',match:/\btrap\b|\bdrill\b/,range:[130,150],label:'Trap / Drill'}
 ];
 const text=v=>String(v??'').toLowerCase();
 const has=(s,re)=>re.test(s);
 function analyze(context,baseAnalyzer){
  const base=typeof baseAnalyzer==='function'?baseAnalyzer(context):{level:'compatible',label:'UYUMLU',notes:[],alternatives:[],canProceed:true};
  const notes=[...(base.notes||[])];
  let level=base.level||'compatible';
  const add=(kind,reason,alternative)=>{
   if(notes.some(n=>n.id===kind+':'+reason))return;
   notes.push({id:kind+':'+reason,kind,reason,alternative});
   if(kind==='conflict')level='conflict'; else if(kind==='experimental'&&level!=='conflict')level='experimental';
  };
  const profile=context.globalProfile||context.musicDnaProfile||{};
  const identity=text([context.dna,context.style,profile.name,profile.primary_genre,profile.subgenre_or_scene,...(profile.tags||[]),...(profile.musical_traits||[])].filter(Boolean).join(' '));
  const bpm=Number(context.bpm);
  const explicitBpm=Number.isFinite(bpm)&&bpm>0;
  const notesText=text(context.notes);
  const explicitHalfDouble=/half[ -]?time|double[ -]?time|yarı zaman|çift zaman/.test(notesText);
  let tempoInterpretation='direct';
  const fusion=text(context.fusion)+' '+text(context.fusionProfile?.promptText);
  const instruments=[...(context.instruments||[]),...(context.technique?.instruments||[])].join(' ');
  const vocal=text(context.mainVoice)+' '+text(context.back)+' '+text(context.vocalProfile?.promptText)+' '+text(context.vocalIdentityProfile?.promptText);
  const adlib=text(context.adlib)+' '+text(context.adlibPlacement)+' '+text(context.adlibArrangementMode);
  const mood=text(context.emotion)+' '+text(context.productionProfile?.mood)+' '+text(context.theme);
  const family=RULES.find(r=>r.match.test(identity));
  if(family&&explicitBpm){
   const [lo,hi]=family.range;
   const halfTimeEquivalent=bpm<lo && bpm*2>=lo && bpm*2<=hi;
   const doubleTimeEquivalent=bpm>hi && bpm/2>=lo && bpm/2<=hi;
   if(halfTimeEquivalent||doubleTimeEquivalent){
    tempoInterpretation=halfTimeEquivalent?'half-time':'double-time';
    add('compatible',`${family.label} için ${bpm} BPM, ${tempoInterpretation==='half-time'?'yaklaşık '+(bpm*2)+' BPM çift zamanlı alt bölünme':'yaklaşık '+(bpm/2)+' BPM ana pulse'} üzerinden doğal bir groove hissi oluşturabilir. Bu nedenle tempo farkı tek başına uyumsuzluk sayılmadı.`,`Mevcut BPM'yi koruyup ${tempoInterpretation} hissini düzenlemede açıkça belirt; doğrudan aralıkta bir tempo istiyorsan ${lo}–${hi} BPM aralığını da deneyebilirsin.`);
   }else if((bpm<lo-25||bpm>hi+25)&&!explicitHalfDouble){
    add('experimental',`${family.label} için ${bpm} BPM, yaygın başlangıç aralığı olan ${lo}–${hi} BPM'den belirgin biçimde uzak. Bu tek başına yanlış değildir; farklı pulse algısı veya deneysel tempo tercihi olabilir.`,`Bu türün alışılmış hareketini hedefliyorsan ${lo}–${hi} BPM aralığını dene. Mevcut BPM bilinçli tercihinse half-time/double-time veya deneysel groove niyetini belirt.`);
   }else if((bpm<lo||bpm>hi)&&!explicitHalfDouble){
    add('experimental',`${family.label} için ${bpm} BPM alışılmış ${lo}–${hi} BPM aralığının dışında; groove hissi farklılaşabilir.`,`İstersen ${lo}–${hi} BPM aralığını dene veya mevcut tempoyu bilinçli farklı groove olarak koru.`);
   }
  }
  if(has(identity,/ambient|drone|soundscape/)&&has(notesText,/four.?on.?the.?floor|four on the floor|sürekli dört vuruş/)){
   add('experimental','Ambient/Drone atmosferi ile sürekli dört vuruşlu dans altyapısı belirgin bir estetik kontrast oluşturabilir.','Dört vuruşu arka planda sade tut veya ritmi bölümlere göre seyrekleştir; kontrast bilinçliyse koru.');
  }
  if(has(identity,/traditional|folk|min.?yo|āvāz|avaz|urtiin duu|pansori|mugham|maqam/)&&has(notesText,/strict grid|quantiz|metronom|sabit dört|rigid beat/)){
   add('experimental','Seçilen geleneksel/free-time ifade ile katı grid veya sabit vuruş talimatı arasında icra gerilimi olabilir.','Geleneksel serbest zamanlı cümleleri koru; ritmik altyapı gerekiyorsa yalnızca seçilen füzyon katmanında kullan.');
  }
  const vocalOff=has(vocal,/instrumental only|no vocals|vocals off|enstrümantal|vokalsiz/);
  const introVocal=text(context.introStyle)+' '+text(context.introLyrics)+' '+text(context.preVoice);
  if(vocalOff&&(has(adlib,/ad.?lib|chant|shout|crowd|vocal response/)||has(introVocal,/lead vocal|group response|wordless vocal|sung|spoken|vocal pickup|vokal/))){
   add('experimental','Enstrümantal/vokalsiz tercih ile seçili ad-lib veya vokalli intro talimatı birbiriyle çelişebilir.','Enstrümantal tercihi koruyup vokalli intro/ad-libleri kapat veya yalnızca enstrümantal motiflerle değiştir.');
  }
  if(has(mood,/intimate|mahrem|minimal|sakin/)&&has(adlib,/crowd|festival|hype|kalabalık|yoğun bağır/)){
   add('experimental','Mahrem ve sakin atmosfer ile yoğun festival/kalabalık ad-libleri arasında belirgin kontrast var.','Ad-libleri seyrekleştirip yalnızca nakarat veya geçişlerde kullan; kontrastı bilinçli istiyorsan koru.');
  }
  if(has(fusion,/traditional|folk|regional|ethnic/)&&has(identity,/trap|drill|techno|house/)&&!has(instruments,/bağlama|baglama|kemençe|kemence|ney|oud|ud|koto|shamisen|tulum|zurna|sitar|duduk|qanun|kanun/)){
   add('experimental','Modern ana tür ile geleneksel/bölgesel füzyon seçilmiş ancak belirgin bir bölgesel enstrüman veya icra rolü görünmüyor.','Füzyonun hangi katmanda duyulacağını seç: ritim, melodi, enstrüman, vokal veya atmosfer. Belirli bir çalgı istemiyorsan genel bölgesel klişeler ekleme.');
  }
  const labels={compatible:'UYUMLU',experimental:'KONTROL GEREKLİ',conflict:'UYUMSUZ'};
  const alternatives=[...new Set(notes.map(n=>n.alternative).filter(Boolean))].slice(0,5);
  return {...base,level,label:labels[level]||base.label,notes,alternatives,canProceed:true,engineVersion:'2.3',tempoInterpretation,advisoryOnly:true};
 }
 root.SongDnaCompatibilityEngine={analyze,version:'2.3',tempoRules:RULES.map(r=>({id:r.id,label:r.label,range:[...r.range]}))};
})(typeof window!=='undefined'?window:globalThis);
