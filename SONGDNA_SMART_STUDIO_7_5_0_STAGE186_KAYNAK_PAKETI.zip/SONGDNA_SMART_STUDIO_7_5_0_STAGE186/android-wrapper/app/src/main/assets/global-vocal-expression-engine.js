/* SONGDNA Global Vocal Expression Engine v1.0
 * Cross-culture phrase selection is independent of the lead lyric language.
 * Producer tags are classified separately and never treated as lyric ad-libs.
 */
(function(root){'use strict';
 const CATEGORIES=[
  {id:'classic',label:'Classic Ad-libs'},
  {id:'trap',label:'Trap Ad-libs'},
  {id:'melodic',label:'Melodic Ad-libs'},
  {id:'rhythmic',label:'Rhythmic Vocal Hits'},
  {id:'chants',label:'Vocal Chants'},
  {id:'textures',label:'Vocal Textures'},
  {id:'signature',label:'Signature Phrases'},
  {id:'producer',label:'Producer Tags (ayrı kategori)'}
 ];
 const text=x=>[x?.id,x?.phrase,x?.term,x?.function,x?.meaning,x?.kind,x?.category].filter(Boolean).join(' ').toLowerCase();
 function classify(item={}){
  const s=text(item),id=String(item.id||'').toLowerCase();
  if(/producer.?tag|producer tag|tag drop|producer shout/.test(s))return 'producer';
  if(/user.?signature|personal.?phrase|signature phrase|personal adlib/.test(s))return 'signature';
  if(/chant|group response|crowd|call.?and.?response|toplu koro|topluluk cevab/.test(s))return 'chants';
  if(/breath|whisper|hum|humming|wordless|vocal texture|nefes|fısıltı|kelimesiz/.test(s))return 'textures';
  if(/phonetic_pattern|vocable|rhythmic|percussive|ritmik|vokal perküsyon|hece dizisi/.test(s)||id.startsWith('voc-'))return 'rhythmic';
  if(/melodic|sustain|echo|harmony|melisma|duygusal|melodik|uzatılmış/.test(s)||/(^|[-_])(mmh|la-la|a-ya|oh|ah)([-_]|$)/.test(id))return 'melodic';
  if(/trap|skrrt|brr|ayy|sheesh|drill|hype/.test(s)||id.startsWith('us-'))return 'trap';
  return 'classic';
 }
 function group(items){const out=Object.fromEntries(CATEGORIES.map(x=>[x.id,[]]));for(const item of items||[]){const id=classify(item);if(id!=='producer')out[id].push(item);}return CATEGORIES.filter(x=>x.id!=='producer').map(x=>({...x,items:out[x.id]})).filter(x=>x.items.length);}
 function producerTags(items){return (items||[]).filter(x=>classify(x)==='producer');}
 root.SongDnaGlobalVocalExpressionEngine={version:'1.0',categories:CATEGORIES,classify,group,producerTags};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaGlobalVocalExpressionEngine;
})(typeof globalThis!=='undefined'?globalThis:this);
