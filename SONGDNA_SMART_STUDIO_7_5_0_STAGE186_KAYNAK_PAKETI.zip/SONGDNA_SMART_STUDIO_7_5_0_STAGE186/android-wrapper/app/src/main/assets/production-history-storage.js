/* Safe storage boundary for production history. Never treat a failed read as an empty history. */
(function(root){
  function read(storage,key,core){
    try{
      const rawText=storage.getItem(key);
      const raw=rawText==null||rawText===''?[]:JSON.parse(rawText);
      if(!Array.isArray(raw))return {ok:false,items:[],error:new Error('Geçmiş verisi beklenen liste biçiminde değil.')};
      const items=core.normalize(raw);
      if(JSON.stringify(raw)!==JSON.stringify(items)){
        const saved=write(storage,key,items);
        if(!saved.ok)return {ok:false,items,error:saved.error};
      }
      return {ok:true,items};
    }catch(error){return {ok:false,items:[],error};}
  }
  function write(storage,key,items){
    try{
      const payload=JSON.stringify(items);
      storage.setItem(key,payload);
      if(storage.getItem(key)!==payload)throw new Error('Geçmiş kaydı doğrulanamadı.');
      return {ok:true};
    }catch(error){return {ok:false,error};}
  }
  root.SongDnaProductionHistoryStorage={read,write};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaProductionHistoryStorage;
})(typeof globalThis!=='undefined'?globalThis:this);
