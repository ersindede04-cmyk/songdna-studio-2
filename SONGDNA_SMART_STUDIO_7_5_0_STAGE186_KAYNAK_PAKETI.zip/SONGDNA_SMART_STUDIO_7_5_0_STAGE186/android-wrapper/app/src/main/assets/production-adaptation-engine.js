/* SONGDNA Emotion-aware Production Adaptation Engine v1.
 * Applies signed emotion priorities to an existing Music DNA preset.
 * Explicit user mixer overrides always win; Music DNA identity is never replaced.
 */
(function(root){
 const clamp=n=>Math.max(0,Math.min(100,Math.round(n)));
 const labels={rhythm:'ritim ve perküsyon',bass:'bas ve düşük frekans',melody:'melodi ve motif',vocal:'vokal performansı',energy:'enerji eğrisi',atmosphere:'atmosfer ve derinlik',structure:'bölüm dinamikleri',effects:'mekânsal ve geçiş efektleri'};
 const descriptors={
  rhythm:{low:'daha seyrek vuruşlar, geniş boşluklar ve kontrollü artikülasyon',mid:'dengeli vuruş yoğunluğu ve doğal groove',high:'daha belirgin artikülasyon, ritmik hareket ve bölüm vurguları'},
  bass:{low:'hafif ve kontrollü düşük frekans; melodik/vokal alana boşluk',mid:'dengeli bas gövdesi ve kick ayrımı',high:'daha güçlü bas desteği ve kontrollü transient ayrımı'},
  melody:{low:'sade motifler ve daha fazla melodik boşluk',mid:'belirgin ama vokalle dengeli motifler',high:'daha geniş melodik hareket, armonik renk ve akılda kalıcı motif'},
  vocal:{low:'yakın, ölçülü ve doğal vokal nüansları',mid:'ifade gücü belirgin, dengeli vokal dinamiği',high:'geniş ifade aralığı, güçlü vurgu ve belirgin bölüm geçişleri'},
  energy:{low:'düşük yoğunluklu, kontrollü enerji eğrisi',mid:'kademeli ve dengeli enerji akışı',high:'bölümler arasında belirgin enerji yükselişi ve kontrollü zirveler'},
  atmosphere:{low:'kuruya yakın, yakın ve sade atmosfer',mid:'ölçülü derinlik ve seçici ambiyans',high:'katmanlı, geniş ve karakterli atmosfer; netlik korunarak'},
  structure:{low:'daha sade geçişler ve uzun nefes alan bölümler',mid:'dengeli bölüm kontrastı ve doğal geçişler',high:'belirgin yükseliş, çözülme ve bölüm kontrastı'},
  effects:{low:'az ve doğal efekt kullanımı',mid:'seçici delay, reverb ve geçiş efektleri',high:'daha belirgin fakat kontrollü efekt hareketi ve otomasyon'}
 };
 function band(n){return n<34?'low':n<68?'mid':'high';}
 function apply(preset,emotion){
  if(!preset||!emotion)return {dimensions:{...(preset?.dimensions||{})},overrides:[],instructions:[],promptText:''};
  const values={...(preset.dimensions||{})},locked=new Set(preset.userOverrides||[]),deltas=emotion.dimensions||{},applied={},instructions=[];
  Object.keys(labels).forEach(k=>{
   const delta=Number(deltas[k]||0);
   if(!locked.has(k)&&Number.isFinite(delta)&&delta!==0){values[k]=clamp((Number(values[k])||0)+delta);applied[k]=delta;}
   const level=band(values[k]??50);
   instructions.push(`${labels[k]} (${values[k]??50}/100): ${descriptors[k][level]}`);
  });
  const intensity=emotion.intensityLabel||'Orta';
  const promptText=[`EMOTION-DRIVEN PRODUCTION ADAPTATION: ${emotion.label||'Otomatik duygu'} / ${intensity}.`,
   `Keep the selected Music DNA family, regional authenticity, instrumentation and groove identity intact. Emotion changes arrangement and performance nuance, never replaces the genre.`,
   ...instructions,
   `Apply intensity through dynamics, phrasing, harmonic tension/release, texture density and section contrast—not by automatically changing BPM or mastering loudness.`,
   `Where a user explicitly adjusted a mixer dimension, preserve that exact value.`,
   preset.family==='traditional'?'For traditional/acoustic profiles, express emotion through authentic phrasing, ornamentation, dynamics and acoustic ensemble balance; do not add modern electronic layers unless explicitly selected.':''
  ].filter(Boolean).join(' ');
  return {dimensions:values,appliedDeltas:applied,userOverrides:[...locked],instructions,promptText};
 }
 root.SongDnaProductionAdaptationEngine={apply,labels,descriptors};
})(typeof window!=='undefined'?window:globalThis);
