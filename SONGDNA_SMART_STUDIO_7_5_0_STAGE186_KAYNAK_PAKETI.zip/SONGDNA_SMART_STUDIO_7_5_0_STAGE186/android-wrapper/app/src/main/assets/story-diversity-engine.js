/* SONGDNA Stage178 — narrative-scene diversity memory. */
(function(root){'use strict';
 const KEY='songdna_story_diversity_v1', VERSION=1, MAX=18;
 const FAMILIES=[
  ['work_shift',/fabrika|vardiya|mesai|iş\s*çıkışı|iş\s*sonu|paydos|düdük|atölye|tezg[aâ]h|üniforma|işçi|servis\s*(e|a|ten|tan)?\b/i],
  ['commute',/otobüs|servis|minibüs|metro|tramvay|durak|istasyon|yolculuk|son\s*sefer|vapur/i],
  ['home_routine',/mutfak|salon|evin\s*içi|kapı\s*önü|apartman|komşu|anahtar|pencere/i],
  ['romance',/sevgili|aşk|öpücük|kalp|ayrılık|özlem|eski\s*sevgili|buluşma/i],
  ['family',/anne|baba|kardeş|çocuk|evlat|aile|büyükanne|dede/i],
  ['memory',/fotoğraf|eski\s*mektup|hatıra|anılar|geçmiş|kaset|ses\s*kayd/i],
  ['journey',/yolculuk|tren|uçak|sahil\s*kasabası|yol\s*kenarı|yabancı\s*şehir/i],
  ['friendship',/arkadaş|dost|yoldaş|eski\s*ekip/i],
  ['mystery',/sır|gizem|kayıp|iz|şifre|gölge|bilinmeyen/i],
  ['struggle',/mücadele|borç|geçim|yoksulluk|başarı|yenilgi|direniş/i]
 ];
 function read(){try{const x=JSON.parse(root.localStorage.getItem(KEY)||'{}');return x&&x.version===VERSION&&Array.isArray(x.items)?x.items.slice(-MAX):[]}catch(_){return[]}}
 function families(text){const s=String(text||'').toLocaleLowerCase('tr');return FAMILIES.filter(([,re])=>re.test(s)).map(([id])=>id)}
 function remember(topic,lyrics){const t=String(topic||'').trim(),l=String(lyrics||'').trim();if(!t&&!l)return;const items=read();const item={topic:t.slice(0,500),families:[...new Set([...families(t),...families(l)])],at:Date.now()};items.push(item);try{root.localStorage.setItem(KEY,JSON.stringify({version:VERSION,items:items.slice(-MAX)}))}catch(_){}}
 function choose(options){const list=[...new Set((options||[]).map(x=>String(x||'').trim()).filter(Boolean))];if(!list.length)return'';const recent=read().slice(-8);const blockedTopics=new Set(recent.map(x=>x.topic.toLocaleLowerCase('tr')));const recentFamilies=new Set(recent.slice(-5).flatMap(x=>x.families||[]));let candidates=list.filter(x=>!blockedTopics.has(x.toLocaleLowerCase('tr'))&&!families(x).some(f=>recentFamilies.has(f)));if(!candidates.length)candidates=list.filter(x=>!blockedTopics.has(x.toLocaleLowerCase('tr')));if(!candidates.length)candidates=list;return candidates[Math.floor(Math.random()*candidates.length)]}
 function guidance(topic){const recent=read().slice(-6);const blocked=[...new Set(recent.flatMap(x=>x.families||[]))];const recentTopics=recent.map(x=>x.topic).filter(Boolean);return [
  'NARRATIVE DIVERSITY MEMORY (use as anti-repetition guidance, not as a replacement for the user topic):',
  'Avoid repeating the recent concrete scene families: '+(blocked.join(', ')||'none recorded')+'.',
  'Recent story anchors to avoid reusing with cosmetic wording changes: '+(recentTopics.join(' | ')||'none recorded')+'.',
  'For this song, create a genuinely different place, event, character situation and central image. Do not default to factory/work shift/commute/tired-after-work scenes unless the user explicitly requested them. Do not merely swap nouns while retaining the same scene, sequence or emotional setup.',
  'Current selected topic remains authoritative and must be respected: '+String(topic||'automatic')+'.'
 ].join('\n')}
 root.SongDnaStoryDiversityEngine={version:VERSION,read,families,remember,choose,guidance};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.SongDnaStoryDiversityEngine;
})(typeof window!=='undefined'?window:globalThis);
