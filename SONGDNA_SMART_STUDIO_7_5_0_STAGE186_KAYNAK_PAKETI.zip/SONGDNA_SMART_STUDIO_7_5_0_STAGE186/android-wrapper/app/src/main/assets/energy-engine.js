/* SONGDNA Energy Engine v1 — independent from emotion type/intensity and BPM. */
(function(root){
 const LEVELS={
  low:{label:'Düşük',factor:-1,description:'Seyrek ve nefes alan düzenleme; kontrollü vurgu, düşük katman yoğunluğu ve yakın performans.'},
  medium:{label:'Orta',factor:0,description:'Music DNA tabanına sadık, dengeli groove ve bölüm dinamiği.'},
  high:{label:'Yüksek',factor:1,description:'Daha belirgin ritmik hareket, güçlü bölüm vurguları ve kontrollü katman artışı.'},
  veryHigh:{label:'Çok yüksek',factor:2,description:'Güçlü ve sürekli ileri itiş; yoğun fakat ayrışan ritim/bas, belirgin doruklar ve yüksek performans kararlılığı.'}
 };
 // Existing six UI choices are retained and mapped to four musical energy tiers.
 const INDEX_MAP={0:'low',1:'low',2:'medium',3:'high',4:'veryHigh',5:'veryHigh'};
 const DELTAS={
  low:{rhythm:-9,bass:-7,melody:-2,vocal:-2,energy:-16,atmosphere:7,structure:-5,effects:-7},
  medium:{rhythm:0,bass:0,melody:0,vocal:0,energy:0,atmosphere:0,structure:0,effects:0},
  high:{rhythm:7,bass:6,melody:2,vocal:5,energy:13,atmosphere:-2,structure:7,effects:3},
  veryHigh:{rhythm:12,bass:10,melody:3,vocal:8,energy:20,atmosphere:-5,structure:12,effects:6}
 };
 const DESCRIPTORS={
  low:{rhythm:'seyrek vuruşlar ve geniş ritmik boşluklar',bass:'kontrollü, yuvarlak ve vokale alan bırakan bas',melody:'az katmanlı ve nefes alan motifler',vocal:'yakın, ölçülü ve dinamik açıdan sakin performans',energy:'düşük ama canlı kalan enerji eğrisi',atmosphere:'daha geniş ve sakin atmosferik alan',structure:'uzun nefes alan geçişler ve küçük zirveler',effects:'az, doğal ve seçici efektler'},
  medium:{rhythm:'Music DNA groove’una uygun dengeli ritmik hareket',bass:'ritimle dengeli ve net ayrışan bas',melody:'vokal ve ana motif arasında dengeli katman',vocal:'doğal ifade aralığı ve dengeli vurgu',energy:'istikrarlı, orta seviyeli enerji akışı',atmosphere:'dengeli derinlik ve netlik',structure:'doğal bölüm kontrastı ve dengeli geçişler',effects:'seçici ve ölçülü efekt kullanımı'},
  high:{rhythm:'daha sık ve belirgin ritmik vurgular',bass:'daha güçlü fakat kick ile çakışmayan bas desteği',melody:'daha belirgin hook ve ritmik motif hareketi',vocal:'daha kararlı artikülasyon ve güçlü bölüm vurguları',energy:'yüksek hareket ve kontrollü yükseliş',atmosphere:'ritmi örtmeyen, daha sıkı atmosfer',structure:'daha belirgin build, geçiş ve bölüm zirveleri',effects:'bölüm geçişlerinde kontrollü efekt hareketi'},
  veryHigh:{rhythm:'yoğun fakat ayrışan perküsyon ve güçlü groove vurguları',bass:'güçlü, tanımlı ve ritimle kilitli düşük frekans',melody:'enerjik hook ve ritmik motif desteği; vokale alan korunur',vocal:'yüksek performans kararlılığı, güçlü vurgu ve geniş dinamik ifade',energy:'çok yüksek, sürekli ileri iten fakat kontrollü enerji eğrisi',atmosphere:'yoğunluğu destekleyen sıkı ve net atmosfer',structure:'büyük zirveler, belirgin build/drop veya türe uygun doruklar',effects:'yüksek hareketli fakat anlaşılabilir geçiş ve efekt otomasyonu'}
 };
 const KEYS=Object.keys(DESCRIPTORS.medium);
 const clamp=n=>Math.max(0,Math.min(100,Math.round(n)));
 function resolve(index){const key=INDEX_MAP[Number(index)]||'medium';return {key,...LEVELS[key],sourceIndex:Number(index)};}
 function apply(preset,index,bpmOverride=false){
  const level=resolve(index),values={...(preset?.dimensions||{})},locked=new Set(preset?.userOverrides||[]),delta=DELTAS[level.key],applied={};
  KEYS.forEach(k=>{if(!locked.has(k)&&Number.isFinite(Number(values[k]))&&delta[k]){values[k]=clamp(values[k]+delta[k]);applied[k]=delta[k];}});
  const instructions=KEYS.map(k=>`${k}: ${DESCRIPTORS[level.key][k]}`);
  const promptText=[`ENERGY ENGINE — ${level.label.toUpperCase()} ENERGY. ${level.description}`,
   `Energy is independent from emotional type and emotional intensity. Preserve the selected Music DNA genre, regional identity, authentic instruments, groove and arrangement family.`,
   ...instructions.map(x=>`Energy production direction — ${x}.`),
   bpmOverride?'The user explicitly set BPM: preserve that exact BPM; express energy through arrangement density, articulation, dynamics and section contrast, not tempo changes.':'Do not force a BPM change; express energy through rhythmic density, dynamics, performance and section contrast.',
   'Do not equate high energy with mastering loudness. Keep kick, bass, lead vocal and main motif intelligible. For traditional/acoustic profiles, increase performance drive and authentic rhythmic articulation rather than adding electronic drums or synth layers unless selected.'
  ].join(' ');
  return {level:level.key,label:level.label,sourceIndex:level.sourceIndex,dimensions:values,appliedDeltas:applied,userOverrides:[...locked],instructions,promptText};
 }
 root.SongDnaEnergyEngine={resolve,apply,levels:LEVELS,indexMap:INDEX_MAP,descriptors:DESCRIPTORS};
})(typeof window!=='undefined'?window:globalThis);
