/* SONGDNA SMART STUDIO — Manual Override & Auto Rebalance Controller v1
 * Manual values are persistent and authoritative. Resetting a key returns it to profile automation.
 * This controller stores intent; dependency engines may rebalance only non-overridden dimensions.
 */
(function(root){
 'use strict';
 const KEYS=['rhythm','bass','melody','vocal','energy','atmosphere','structure','effects'];
 const toFiniteNumber=value=>{if(typeof value==='number')return Number.isFinite(value)?value:null;if(typeof value==='string'&&value.trim()!==''){const n=Number(value);return Number.isFinite(n)?n:null;}return null;};
 const clamp=n=>Math.max(0,Math.min(100,Math.round(n)));
 function normalize(stored={}){
  const values={},userOverrides=[];
  KEYS.forEach(key=>{if(Object.prototype.hasOwnProperty.call(stored,key)){const n=toFiniteNumber(stored[key]);if(n!==null){values[key]=clamp(n);userOverrides.push(key);}}});
  return {values,userOverrides};
 }
 function resolve(base={},stored={}){
  const manual=normalize(stored);
  return {dimensions:{...base,...manual.values},userOverrides:manual.userOverrides,manualValues:{...manual.values},isCustomized:manual.userOverrides.length>0};
 }
 function set(stored={},key,value){if(!KEYS.includes(key))throw new Error('Unknown production dimension: '+key);const n=toFiniteNumber(value);if(n===null)throw new TypeError('Manual production value must be a finite number.');return {...normalize(stored).values,[key]:clamp(n)};}
 function reset(stored={},key){if(!KEYS.includes(key))throw new Error('Unknown production dimension: '+key);const next={...normalize(stored).values};delete next[key];return next;}
 function resetAll(){return {};}
 root.SongDnaManualOverrideEngine={version:'1.1',keys:KEYS,normalize,resolve,set,reset,resetAll};
})(typeof window!=='undefined'?window:globalThis);
