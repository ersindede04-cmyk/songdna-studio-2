const assert=require('node:assert/strict');
const fs=require('node:fs');
require('../production-preset-engine.js');
const engine=globalThis.SongDnaProductionPresetEngine;
const catalog=JSON.parse(fs.readFileSync('data/music_dna_global_v1_1.json','utf8'));
assert.ok(catalog.music_dna_profiles.length >= 67,'the Music DNA catalogue must remain expandable');
const profiles=catalog.music_dna_profiles;
const families=profiles.map(p=>[p.id,engine.classify(p)]);
assert.equal(new Set(families.map(x=>x[0])).size,catalog.music_dna_profiles.length,'every profile ID must be unique');
const expected={
 'MDNA-013':'pop','MDNA-014':'pop','MDNA-018':'general','MDNA-020':'amapiano',
 'MDNA-024':'traditional','MDNA-027':'traditional','MDNA-038':'general',
 'MDNA-046':'traditional','MDNA-053':'traditional','MDNA-054':'traditional',
 'MDNA-060':'amapiano','MDNA-062':'traditional','MDNA-063':'traditional'
};
for(const [id,family] of Object.entries(expected)){
 const profile=profiles.find(p=>p.id===id);
 assert(profile,`missing ${id}`);
 assert.equal(engine.classify(profile),family,`${id} should route to ${family}`);
 assert.equal(engine.build(profile,2,{}).family,family,`${id} preset family mismatch`);
}
for(const p of profiles){
 const result=engine.build(p,2,{});
 assert(result&&result.profileId===p.id,`${p.id} must build a preset`);
 assert(engine.dimensions.every(k=>Number.isFinite(result.dimensions[k])),`${p.id} has invalid production dimensions`);
}
console.log('Stage 72 PASS: all current profiles resolve; 13 reviewed misroutes corrected; every profile produces finite preset dimensions.');
