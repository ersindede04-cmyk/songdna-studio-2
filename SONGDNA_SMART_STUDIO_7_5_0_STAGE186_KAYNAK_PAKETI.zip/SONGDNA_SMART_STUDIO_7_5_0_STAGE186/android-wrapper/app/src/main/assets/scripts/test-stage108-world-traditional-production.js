'use strict';
const fs = require('fs');
const path = require('path');
const roots = [
  path.resolve(__dirname, '..', 'app.js'),
  path.resolve(__dirname, '..', 'www', 'app.js'),
  path.resolve(__dirname, '..', 'android-wrapper', 'app', 'src', 'main', 'assets', 'app.js')
].filter(fs.existsSync);
if (!roots.length) throw new Error('No app.js source found');
for (const file of roots) {
  const source = fs.readFileSync(file, 'utf8');
  for (const token of [
    'pureTraditionalProduction',
    'PURE TRADITIONAL PRODUCTION — WORLDWIDE CULTURAL AUTHENTICITY LOCK',
    'Modern Music',
    'Do not substitute generic'
  ]) {
    if (!source.includes(token)) throw new Error(`${path.basename(file)} missing ${token}`);
  }
}
console.log('Stage108 traditional production lock source checks passed.');
