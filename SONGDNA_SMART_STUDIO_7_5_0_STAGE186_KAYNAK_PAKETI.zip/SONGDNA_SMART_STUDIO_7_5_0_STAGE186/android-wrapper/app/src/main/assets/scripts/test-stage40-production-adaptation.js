const fs=require('fs'),vm=require('vm');
function load(file,name){const sandbox={globalThis:{}};vm.runInNewContext(fs.readFileSync(file,'utf8'),sandbox);return sandbox.globalThis[name];}
const emotion=load('emotion-engine.js','SongDnaEmotionEngine');
const adapt=load('production-adaptation-engine.js','SongDnaProductionAdaptationEngine');
const base={family:'traditional',dimensions:{rhythm:60,bass:30,melody:90,vocal:90,energy:55,atmosphere:85,structure:70,effects:20},userOverrides:['bass'],profileId:'test-trad'};
let cases=0;
for(const type of ['melancholy','anger','love','hope','longing','confidence','joy','anxiety','grief','triumph'])for(let level=1;level<=4;level++){
 const e=emotion.build(type,level,'');
 const r=adapt.apply(JSON.parse(JSON.stringify(base)),e);
 if(Object.keys(r.dimensions).length!==8||!r.promptText.includes('Music DNA'))throw Error(`${type}/${level}: missing adaptation output`);
 if(r.dimensions.bass!==30)throw Error('manual bass override was not preserved');
 if(r.dimensions.rhythm<0||r.dimensions.rhythm>100)throw Error('dimension out of range');
 if(!r.promptText.includes('traditional/acoustic'))throw Error('traditional identity guard missing');
 cases++;
}
const low=emotion.build('melancholy',1),high=emotion.build('melancholy',4);
if(!(Math.abs(high.dimensions.melody)>Math.abs(low.dimensions.melody)))throw Error('intensity scaling failed');
if(!(emotion.build('grief',4).dimensions.rhythm<0))throw Error('negative priority lost');
const auto=adapt.apply(base,emotion.build('auto',3));if(!auto.promptText.includes('Otomatik duygu'))throw Error('automatic emotion path missing');
const app=fs.readFileSync('app.js','utf8'),html=fs.readFileSync('index.html','utf8');
if(!app.includes('SongDnaProductionAdaptationEngine.apply')||!html.includes('production-adaptation-engine.js'))throw Error('runtime wiring missing');
console.log(`Stage 40 Production Adaptation PASS: ${cases} emotion/level combinations, signed priorities, manual override, traditional identity and automatic mode.`);
