'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const html = fs.readFileSync('www/index.html', 'utf8');
const app = fs.readFileSync('www/app.js', 'utf8');
const server = fs.readFileSync('server.js', 'utf8');
const backend = fs.readFileSync('backend/server.js', 'utf8');
const rootHtml = fs.readFileSync('index.html', 'utf8');
const rootApp = fs.readFileSync('app.js', 'utf8');
const android = 'android-wrapper/app/src/main/assets/www/';
const count = (s, re) => (s.match(re) || []).length;
assert.equal(count(html, /<style(?:\s|>)/g), count(html, /<\/style>/g), 'all CSS style blocks must be balanced');
assert.match(html, /songdna-520-stage38-preset-mixer/);
assert.match(html, /songdna-520-stage38-themed-selects/);
assert.match(html, /Otomatik · Etkin katalogda sırayla döndür/);
assert.doesNotMatch(html, /auto18|İlk 18 paketi/);
assert.match(app, /n%dna\.length/);
assert.match(app, /\(index\+1\)%dna\.length/);
assert.match(app, /songdna_music_dna_rotation_v1/); // migrate previous progress
assert.match(app, /v\('musicDnaMode'\)==='auto66'/);
assert.match(app, /commitMusicDnaRotation\(rotatedMusicDna\.index,rotationRevisionAtStart\)/);
const templateOptions = [...html.matchAll(/<option value="([^"]+)">([^<]+)<\/option>/g)].map(x => [x[1], x[2]]);
const labels = templateOptions.map(x => x[0]);
for (const family of ['fr-love-melodic','fr-love-modern','en-dark','en-rnb','es-reggaeton','tr-emotional','tr-anatolian','ko-pop','ar-melodic','pt-funk','it-cinematic']) {
  assert(labels.includes(`${family}-male`), `${family} male option missing`);
  assert(labels.includes(`${family}-female`), `${family} female option missing`);
}
for (const [file, expected] of [['www/index.html', html], ['index.html', rootHtml], [`${android}index.html`, fs.readFileSync(`${android}index.html`, 'utf8')]]) assert.equal(fs.readFileSync(file, 'utf8'), expected);
assert.equal(rootHtml, html);
assert.equal(rootApp, app);
assert.match(server, /prompt\.length > 150_000/);
assert.equal(backend, server);
console.log('Stage 38 PASS: CSS boundaries, themed selectors, expandable Music DNA cycle, manual override, success-only rotation, 22 gender-paired vocal templates, 150K limit and web/root source parity.');
