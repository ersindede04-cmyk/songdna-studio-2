const assert=require('node:assert/strict');
require('../production-preset-engine.js');
require('../integrated-production-engine.js');
require('../manual-override-engine.js');
const manual=globalThis.SongDnaManualOverrideEngine;
const presetEngine=globalThis.SongDnaProductionPresetEngine;
const integrated=globalThis.SongDnaIntegratedProductionEngine;
const keys=['rhythm','bass','melody','vocal','energy','atmosphere','structure','effects'];

// Empty, null, boolean, object and non-numeric legacy values must never become manual zeroes.
for(const bad of ['', '   ', null, undefined, true, false, {}, [], 'not-a-number', NaN, Infinity]){
  const normalized=manual.normalize({bass:bad});
  assert.deepEqual(normalized.values,{},`invalid stored value ${String(bad)} is ignored`);
  assert.deepEqual(normalized.userOverrides,[],`invalid stored value ${String(bad)} is not marked manual`);
}
assert.deepEqual(manual.normalize({bass:'0'}).values,{bass:0},'explicit numeric string zero remains valid');
assert.deepEqual(manual.normalize({bass:0}).userOverrides,['bass'],'explicit numeric zero remains a manual choice');
assert.throws(()=>manual.set({},'bass',''),/finite number/,'empty manual input is rejected');
assert.throws(()=>manual.set({},'bass',null),/finite number/,'null manual input is rejected');

const profile={id:'MDNA-STAGE52',name:'Stage 52 Test DNA',tags:['trap','deep bass','melodic'],musical_traits:['syncopated','call and response']};
const values={rhythm:91,bass:92,melody:93,vocal:94,energy:95,atmosphere:96,structure:97,effects:98};
const stored={...values};
const normalized=manual.normalize(stored);
const preset=presetEngine.build(profile,5,normalized.values);
for(const key of keys)assert.equal(preset.dimensions[key],values[key],`preset preserves manual ${key}`);
assert.deepEqual(new Set(preset.userOverrides),new Set(keys),'all eight dimensions are marked manual');
const final=integrated.build({preset,dnaName:profile.name,bpm:137,bpmManual:true,manualOverrides:normalized.userOverrides});
for(const key of keys)assert.equal(final.dimensions[key],values[key],`integrated engine preserves manual ${key}`);
assert.equal(final.bpm,137,'manual BPM remains exact');
assert.equal(final.manualBpm,true);

// Resetting one dimension unlocks only that dimension; all remaining manual locks survive.
const afterReset=manual.reset(stored,'melody');
assert.equal(Object.hasOwn(afterReset,'melody'),false);
for(const key of keys.filter(k=>k!=='melody'))assert.equal(afterReset[key],values[key],`reset melody preserves ${key}`);
const afterResetPreset=presetEngine.build(profile,5,afterReset);
assert.notEqual(afterResetPreset.dimensions.melody,values.melody,'reset dimension returns to profile automation');
for(const key of keys.filter(k=>k!=='melody'))assert.equal(afterResetPreset.dimensions[key],values[key],`preset keeps remaining ${key} lock`);

// Corrupt values are ignored by both manual storage normalization and preset resolution.
const corrupted=presetEngine.build(profile,5,{bass:null,rhythm:'',melody:'invalid',vocal:0});
assert.notEqual(corrupted.dimensions.bass,0,'null is not interpreted as manual zero');
assert.notEqual(corrupted.dimensions.rhythm,0,'empty string is not interpreted as manual zero');
assert.notEqual(corrupted.dimensions.melody,0,'non-numeric text is not interpreted as manual zero');
assert.equal(corrupted.dimensions.vocal,0,'explicit numeric zero is preserved');
assert.deepEqual(corrupted.userOverrides,['vocal']);
console.log('PASS: Stage 52 strict manual-value validation, all 8 dimension locks, reset isolation, corrupt storage and BPM');
