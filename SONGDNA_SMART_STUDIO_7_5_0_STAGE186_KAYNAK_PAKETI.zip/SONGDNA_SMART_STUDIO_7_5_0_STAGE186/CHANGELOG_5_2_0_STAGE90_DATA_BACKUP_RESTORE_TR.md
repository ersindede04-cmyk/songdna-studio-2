# Stage90 — Kullanıcı Verileri Yedekleme ve Geri Yükleme

- Genel Ayarlar bölümüne açık kullanıcı kontrollü yedek dışa aktarma ve geri yükleme eklendi.
- Yedek yalnızca izin verilen SONGDNA kullanıcı verisi anahtarlarını içerir: üretim geçmişi, kayıtlı sözler, kişisel tema/konu, kişisel ad-lib, kişisel prodüksiyon modelleri, yaratıcılık tekrar hafızası ve ilgili tercih/döngü verileri.
- API anahtarı, uygulama erişim token'ı ve sunucu adresi yedeğe dahil edilmez.
- Geri yükleme öncesi biçim/sürüm doğrulaması ve kullanıcı onayı vardır.
- Geri yükleme yazma/doğrulama hatasında daha önce dokunulan anahtarlar geri alınır.
- Başarılı geri yükleme sonrasında uygulama yeniden yüklenir.
- Yeni modül ve UI dört web/Android kopyasında eşitlendi.
