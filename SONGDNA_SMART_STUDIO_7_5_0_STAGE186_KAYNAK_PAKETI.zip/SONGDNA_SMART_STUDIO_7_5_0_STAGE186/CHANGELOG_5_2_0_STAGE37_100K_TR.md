# Stage 37 — 100.000 karakter istem sınırı

- Sunucu istem doğrulaması 20.000'den 100.000 karaktere çıkarıldı.
- İstek gövdesi koruması 40.000'den 500.000 karaktere çıkarıldı. Bu pay, 100.000 karakterlik Unicode istemlerin JSON kodlama/taşıma payını karşılamak içindir.
- Kök `server.js` ve `backend/server.js` eşitlendi.
- Gemini model/token bağlam sınırları değişmez; bu güncelleme yalnızca uygulamanın HTTP ve istem uzunluğu doğrulamasını değiştirir.
