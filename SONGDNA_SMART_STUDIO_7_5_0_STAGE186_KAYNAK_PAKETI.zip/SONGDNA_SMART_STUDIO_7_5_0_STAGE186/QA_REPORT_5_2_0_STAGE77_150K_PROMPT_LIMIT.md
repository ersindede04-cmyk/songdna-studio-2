# SONGDNA SMART STUDIO 5.2.0 — Stage 77: 150,000 Character Prompt Limit

## Decision
Raised the application and backend prompt character ceiling from 100,000 to 150,000 after checking the selected Gemini model family and server transport limits.

## Source inspection
- Client `postGemini()` previously rejected prompts above 100,000 JavaScript characters before sending a request.
- Backend `/api/lyrics`, `/api/style`, and `/api/command` independently rejected prompts above 100,000 characters.
- Backend JSON body reader was capped at 500,000 characters. This was increased to 1,000,000 so a 150,000-character Unicode prompt plus JSON encoding overhead can be transported safely.
- Backend model allowlist in this source: `gemini-3.1-flash-lite`, `gemini-3.6-flash`, `gemini-3.8-flash`.

## Gemini/API assessment
Google's Gemini documentation describes model context in tokens, not JavaScript characters, and provides a `countTokens` method / model metadata (`inputTokenLimit`, `outputTokenLimit`) to inspect exact model limits. Google's current documentation for Gemini 3-generation models describes a 1,048,576-token input budget for standard models; 150,000 characters of ordinary prompt text is materially below that in typical tokenization. This is not a guarantee for every text distribution or every project quota. Exact model metadata and account-specific RPM/TPM/RPD quota were not queried from the user's live API key/project.

A 150,000-character prompt may increase input-token billing, latency, and token-per-minute usage compared with a shorter prompt. The existing 78-second server generation budget and 24-second per-model timeout were intentionally not changed. The Gemini API may still return quota, timeout, or model-specific context errors.

## Changes
- Client preflight guard: 100,000 -> 150,000 characters in all four synchronized `app.js` copies.
- Backend prompt guard: 100,000 -> 150,000 characters.
- Backend JSON request-body ceiling: 500,000 -> 1,000,000 to accommodate UTF-8/JSON overhead.
- Gemini model allowlist, API key handling, access token, endpoint, fallback order, generation timeouts, and lyric-to-app insertion flow unchanged.
- Added `scripts/test-stage77-150k-prompt-limit.js`.

## Validation results
- 53/53 JavaScript regression test files passed.
- Backend `npm run check` passed.
- `scripts/verify-source.py` passed; runtime assets and four manifests remain synchronized.
- Targeted Stage77 150,000-character checks passed.

## Validation boundaries
- Targeted Stage77 regression test and syntax/source checks are run locally.
- No live Gemini API call, user's Google project quota inspection, Render deployment check, physical Android APK test, or end-to-end lyric insertion test was performed.
- The 150,000 setting removes the app's former local cap; it does not promise that every request will succeed. Actual token usage is reported by Gemini in `usageMetadata` after generation.
