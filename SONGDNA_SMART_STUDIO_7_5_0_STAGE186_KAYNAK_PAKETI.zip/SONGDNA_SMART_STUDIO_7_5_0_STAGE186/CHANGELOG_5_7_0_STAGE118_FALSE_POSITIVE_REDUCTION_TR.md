# Stage 118 — Tutarlılık Denetiminde Yanlış Uyarıların Azaltılması

- Enstrümantal bölüm etiketleri ve parantez içindeki icra notları sözlü vokal içeriği sayılmaz.
- STYLES vokalsiz üretim isterken gerçek söz bölümü veya yeterli düz metin bulunursa uyarı sürer.
- Kadın/erkek konuk verse, farklı ana vokal kimliğiyle otomatik olarak çelişki sayılmaz.
- Yalnızca açık ana vokal etiketi çelişkileri uyarılır.
- Tür ve kültür kimliğinin anlamsal doğruluğu konusunda kesinlik iddia edilmez.
