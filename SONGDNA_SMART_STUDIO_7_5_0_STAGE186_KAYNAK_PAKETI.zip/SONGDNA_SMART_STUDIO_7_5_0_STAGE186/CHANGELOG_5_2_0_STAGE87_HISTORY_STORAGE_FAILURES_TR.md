# SONGDNA Studio 5.2.0 — Stage87

## Üretim geçmişi depolama hata güvenliği
- Üretim geçmişi için ayrı güvenli depolama katmanı eklendi.
- Okuma hatası artık boş geçmiş olarak yorumlanmıyor; böylece yeni üretim, erişilemeyen eski geçmişin üzerine yazmıyor.
- Yazma işlemi hata yakalama ve geri okuma doğrulamasıyla kontrol ediliyor.
- Depolama hatasında kullanıcıya durum bildiriliyor.
- Geçmiş silme ve tüm geçmişi temizleme işlemleri, önce geçmişin başarıyla okunmasını şart koşuyor.
- Dört uygulama kopyası eşitlendi; kayıtlı Lirik arşivi ve üretim geçmişinin 20 kayıt sınırı değiştirilmedi.
