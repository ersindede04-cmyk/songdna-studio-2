# Stage160 — Çok Dilli Şarkı Sözü Kalite Standardı

- Evrensel şarkı sözü kalite katmanı eklendi.
- İngilizce, Mandarin Çincesi, Hintçe, İspanyolca, Standart Arapça, Fransızca, Bengalce, Portekizce, Türkçe ve Azerbaycan Türkçesi için ayrı dil profilleri eklendi.
- Diğer desteklenen diller için kendi dilbilgisi, deyimleri, söyleyiş, şiir ve vurgu özelliklerine dayalı ölçeklenebilir profil kuralı eklendi.
- Dil profilinden sonra seçilen Music DNA / tür / gelenek özelliklerini uygulayan ayrı katman tanımlandı.
- Dil doğallığı, anlam, kullanıcı girdisi, hikâye devamlılığı, tür uyumu, söylenebilirlik ve nakaratı kontrol eden sessiz çok aşamalı editoryal denetim eklendi.
- Stage157 kullanıcı girdisi sadakati, Stage158 geleneksel düzenleme yaklaşımı ayrımı ve Stage159 kalite kuralları korundu.
- Arayüz, Styles/Lyrics alanları, API uç noktaları, Gemini sağlayıcısı ve Android uygulama kimliği değiştirilmedi.

## Sınırlamalar
Bu değişiklik istem/prompt standardıdır; her dilde ana dili konuşan seviyesinde sonuç garantisi değildir. Canlı Gemini testleri ve ana dili konuşan değerlendirmeleri ayrıca yapılmalıdır.
