# Stage 145 — Yalnızca açık manuel vokal seçimlerini denetleme

- Vokal bölüm yerleşimi denetimi artık yalnızca açık manuel seçim kaynağından gelen atamaları değerlendirir.
- `selected: false`, `enabled: false`, `active: false`, `manual: false` olarak işaretlenen kayıtlar denetim dışında kalır.
- `default`, `profile`, `automatic`, `auto`, `suggested` ve `suggestion` kaynaklı öneriler manuel seçim sayılmaz.
- Belirsiz genel `section_assignments` alanı tek başına manuel seçim kabul edilmez.
- Hiçbir manuel vokal rolü seçilmediyse yerleşim uyarısı üretilmez.
- Açıkça seçilen roller mevcut Lyrics metnine karşı denetlenmeye devam eder.
- Sözler, bölüm sıralaması ve kullanıcı seçimleri otomatik değiştirilmez; yeni UI veya çıktı alanı eklenmez.
