# SONGDNA SMART STUDIO 7.0.0 — Stage 175

- Stage 173 kaynak özellikleri korunarak Stage 175 kaynak/derleme kiti düzenlendi.
- Gemini → Lyrics ve Styles üretim akışı, 150.000 karakter sunucu istem sınırı ve mevcut üretim sistemleri korundu.
- Beş dakikalık IP-geneli başarısız erişim kodu kilidi kaldırılmış AUTH HOTFIX korundu; hatalı kod anında 401 döndürür. Kimlik doğrulama sonrası istek sınırı ve sabit zamanlı token karşılaştırması korunur.
- Geleneksel/modern/ortak teknik modülü sınıflandırması katalog ailelerine göre düzenlendi.
- Android WebView açılır menüsünde uyumsuz teknik seçenekler yalnızca gizlenmek yerine seçenek listesinden çıkarılır.
- Ubuntu 24.04 GitHub Actions derleme ortamı korundu.
- Android versionName 7.0.0; versionCode 38 olarak yükseltildi.
- Yeni Stage175 teknik alan filtreleme regresyon testi eklendi.

## Doğrulama sınırları

Kaynak doğrulaması ve regresyon testleri bu pakette yeniden çalıştırılacaktır. Canlı Gemini, Render dağıtımı, GitHub Actions APK derlemesi ve fiziksel Android cihaz testi bu çalışma ortamında doğrulanmış değildir. Bu dosya APK değildir; kaynak/derleme kitidir.
