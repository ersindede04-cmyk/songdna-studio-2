# SONGDNA SMART STUDIO — Evrensel Müzik İçeriği ve Sanatsal Kalite Standardı (Stage163)

## Amaç
Bu standart yalnızca örnek olarak incelenen Şelpe, Tech House, Mugham veya Türk Sanat Müziği için değil; katalogdaki ve ileride eklenecek bütün müzik türleri, alt türler, sahneler, gelenekler, füzyonlar, enstrümanlar, icra teknikleri, ritimler, vokal biçimleri, intro motifleri ve prodüksiyon öğeleri için geçerlidir.

## Temel ilkeler
1. Kimlik önce gelir: Tür, alt tür, sahne, gelenek, form, ritim, icra tekniği ve prodüksiyon tekniği birbirinin yerine kullanılmaz.
2. Kanıt düzeyi açık tutulur: Belgelenmiş bilgi, editoryal/derlenmiş yönlendirme ve deneysel öneri birbirinden ayrılır.
3. Kültürel özgüllük korunur: Bölgesel varyantlar tek bir klişeye indirgenmez; topluluk ve icra bağlamı önemsenir.
4. İşlev dekorasyondan önce gelir: Her enstrüman, vokal, ritim veya efektin müzikal görevi açıklanır.
5. Kullanıcı seçimi önceliklidir: Manuel seçim ve dışlamalar otomatik varsayımları geçersiz kılar.
6. Uyumluluk danışma niteliğindedir: Uyarılar seçimleri sessizce değiştirmez ve üretimi engellemez.
7. Tempo aralıkları mutlak yasa değildir: Groove, usul, free-time, half-time/double-time ve deneysel niyet birlikte değerlendirilir.
8. Anlam ve sanatsal bütünlük önceliklidir: Kafiye, süsleme, vokal yoğunluğu veya prodüksiyon gösterişi anlamı bozmaz.
9. Bilinmeyen ayrıntı uydurulmaz: Enstrüman, lehçe, ritüel metin, vokal cinsiyeti, form, makam veya tarihsel iddia tahminle eklenmez.
10. Kategoriye özgü denetim: Her içerik kendi doğasına uygun alanlarla denetlenir; bütün kategorilere tek tip form zorlanmaz.

## Kategori bazlı zorunlu denetimler

### Music DNA / tür profilleri
- Kimlik, kapsam, alt tür/sahne ve kültürel bağlam
- Ayırt edici müzikal özellikler ve düzenleme davranışı
- Enstrüman, ritim ve vokal rolleri
- Form/bölüm davranışı ve geleneksel varyantlar
- Dil ve söz yazımı sınırları
- Uyumluluk koşulları, istisnalar ve kanıt düzeyi

### Enstrüman ve icra tekniği
- Enstrüman kimliği ve ses üretme yöntemi
- Teknik tanımı, artikülasyon ve icra rolü
- Birbirine karıştırılmaması gereken teknikler
- Bölgesel/kişisel varyantlar için kanıt sınırı

### Ritim ve usul
- Pulse/döngü, alt bölümler, aksan ve salınım
- Sabit zaman, serbest zaman ve ritmik esneklik
- Bas, davul, perküsyon ve melodiyle ilişkisi
- Tempo tavsiyesinin kesin kural olmadığının belirtilmesi

### Vokal ve ad-lib
- Lead, destek, koro, karşılıklı söyleyiş ve topluluk rolleri
- Artikülasyon, süsleme, anlatım ve vokal aralığı
- Dil/lehçe ve söz sınırları
- Cinsiyet veya düet varsayımı yapılmaması
- Kullanıcı seçimi ve geleneğin desteklediği vokal düzeni

### Form ve bölüm yapısı
- Formun sözlü, saz, dans, ritüel veya sahne bağlamı
- Tekrarlama, gelişme, doğaçlama ve geçiş davranışı
- Pop kıta/nakarat yapısının otomatik dayatılmaması
- Söz üretimi uygun olmayan saz formlarında otomatik güfte üretilmemesi

### Intro DNA ve motif
- Açılışın müzikal işlevi ve ana bölüme geçişi
- Enstrüman/vokal giriş sırası
- Ana sözlerin geciktirilmemesi yönündeki kullanıcı tercihi
- İstenmeyen söz, vokal veya kültürel ifade eklenmemesi

### Prodüksiyon öğeleri
- Tekniğin işitsel/ yapısal amacı
- Uygun bağlam, olası yan etki ve diğer öğelerle uyum
- Geleneksel kimliğin modern efektlerle silinmemesi
- Manuel ayarların otomatik üretime üstünlüğü

### Dil, anlam ve sanatsal kalite
- Ana dilde doğal kompozisyon ve doğru lehçe
- Anlatıcı, zaman, bakış açısı ve hikâye tutarlılığı
- Somut ve özgün imge, klişe temizliği
- Vurgu, nefes, dize uzunluğu ve söylenebilirlik
- Kafiye anlamı ve doğal dilbilgisini bozamaz

## Kanıt düzeyi
- `documented`: Kaynakla doğrudan desteklenen tanım.
- `curated`: Kaynaklardan hareketle hazırlanmış editoryal üretim rehberliği.
- `experimental`: Bilinçli yaratıcı deneme; geleneksel otantiklik iddiası değildir.
- `needs_specialist_review`: Ayrıntılı teknik veya repertuvar doğrulaması bekliyor.

## Stage163 uygulama kapsamı
- 67 mevcut Music DNA profiline ortak kalite şeması eklendi.
- 70 enstrüman/icra tekniği, 16 ritim, 14 vokal ve 12 intro modülüne kategoriye özgü denetim alanları eklendi.
- 71 elektronik prodüksiyon öğesine prodüksiyon denetim şeması eklendi.
- `MDNA-068` Türk Sanat Müziği profili append-only olarak eklendi.
- Şelpe ve tezene ayrımı daha açık hâle getirildi.
- Tech House için genel House eşleşmesinden önce çalışan, danışma niteliğinde ayrı tempo/groove kuralı eklendi.
- Gemini Styles ve Lyrics talimatlarına evrensel standart eklendi.

## Sınırlar
Bu standart katalog şemasını ve üretim talimatlarını güçlendirir; tüm kültürel varyantların uzmanlarca doğrulandığı veya modelin her üretimde kusursuz sonuç vereceği anlamına gelmez. Uzman/repertuvar doğrulaması gereken kayıtlar açıkça işaretlenmelidir.
