# Stage92 — Yedek Sürüm Uyumluluğu

- Yeni oluşturulan yedeklere uygulama sürümü (`5.2.0`) bilgisi eklendi.
- Daha eski uygulama sürümlerinden gelen yedeklerin içe aktarımı korundu.
- Stage90 sürüm 1 ve Stage91 sürüm 2 yedekleri geriye dönük uyumlu bırakıldı.
- Daha yeni uygulama sürümünde oluşturulan yedekler eski uygulamada geri yüklenmeden önce güncelleme uyarısıyla reddediliyor.
- Uygulamanın tanımadığı veri alanları sessizce atılmak yerine açık hata ile bildiriliyor.
- Dört `data-backup.js` kopyası eşitlendi.
