# Stage186 GitHub yükleme notu

1. Bu ZIP dosyasını bilgisayar/telefon üzerinden GitHub deposunun ana dizinine, adı değiştirilmeden yükleyin: `SONGDNA_SMART_STUDIO_7_5_0_STAGE186_KAYNAK_PAKETI.zip`.
2. `.github/workflows/build.yml` dosyasını depodaki aynı konumda, aşağıda ayrıca verilen Stage186 tam YAML içeriğiyle değiştirin.
3. Actions sekmesinden `SONGDNA SMART STUDIO 7.5.0 — Stage186 Android Build` iş akışını çalıştırın.
4. İş akışı ZIP'i önce doğrular. ZIP bozuksa APK üretmeye çalışmaz; açık hata verir.
5. Başarılı olursa Actions çalıştırmasının Artifacts bölümünden APK ve SHA-256 dosyası alınır.

Not: GitHub'a yalnızca ZIP yüklemek, Render'a kaynak kodu açılmış şekilde dağıtım yapmaz. Render dağıtımı için depo kökünde gerçek proje dosyalarının bulunması gerekir.
