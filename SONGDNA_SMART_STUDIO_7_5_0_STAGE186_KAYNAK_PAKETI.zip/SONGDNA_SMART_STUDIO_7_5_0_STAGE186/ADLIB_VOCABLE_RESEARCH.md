# SONGDNA — Ad-lib vocables and repeated phonetic patterns

## Scope
This is an improvement to the existing international ad-lib catalog, not a free-form nonsense-syllable generator. Only catalogued, evidence-backed repeated vocables may be suggested automatically. User-supplied spellings remain verbatim and can be used manually even when not independently verified.

## Evidence-backed examples added to the existing US rap/trap scene catalog
- `Woo, woo, woo!` — a repeated vocal motif documented in hip-hop music coverage (Ric Wilson's 2021 track and Uncle Murda's 2016 ad-lib feature); treated as one documented example, not a universal genre rule or an invitation to imitate an artist's signature delivery.
- `Skrrt-skrrt!` — documented as a recurring ad-lib in contemporary hip-hop, especially some US Southern and Latinx trap variations; kept scene-qualified rather than generalized to all rap.

## Usage constraints
- Keep the main lyric language unchanged; the selected ad-lib source language remains independent.
- Use the repeated vocable as a short rhythmic/percussive accent or call-and-response, not as a substitute for the lyric.
- Preserve line-end, off-beat and beat-gap placement; do not cover the lead vocal.
- Do not force the same pattern into every section or song.
- Do not auto-suggest user examples such as “rampa papam”, “taka taka”, “toka toka”, “papi papi”, “bam bam”, “dan dan” or “prrr” until their relevant scene usage is independently supported. They may be entered manually and preserved verbatim.
- Do not copy an individual artist's distinctive signature vocable/timbre.

## Research references
- Salvatore Maicki, “Ric Wilson hurdles over judgement on new single ‘Woo Woo Woo’,” *The FADER*, March 25, 2021. https://www.thefader.com/2021/03/25/ric-wilson-woo-woo-woo
- Dame, “Uncle Murda – ‘Woo Woo Woo WHOA!’,” *Def Pen*, July 18, 2016. https://defpen.com/uncle-murda-woo-woo-woo-whoa/
- Zachary Wallmark, “Analyzing Vocables in Rap: A Case Study of Megan Thee Stallion,” *Music Theory Online* 28, no. 2 (2022), especially the discussion of common rap vocables, call-and-response, percussive vocables and rhythmic groupings. https://www.mtosmt.org/issues/mto.22.28.2/mto.22.28.2.wallmark.html
- Ren Ellis Neyra, “Queer Poetics: Deviant Swerves, in Three,” in *The Cambridge Companion to Queer Studies* (Cambridge University Press, 2020), pp. 125–28, discussion of “skrrt” / “skrt skrt” in contemporary hip-hop and some US Southern/Latinx trap variations. https://doi.org/10.1017/9781108699396
