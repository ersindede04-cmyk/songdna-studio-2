# SONGDNA SMART STUDIO 6.1.1 — Stage172

SONGDNA SMART STUDIO, Suno için özgün şarkı sözleri ve Styles komutları hazırlayan bir yardımcı uygulamadır. Ses oynatıcı veya ses üretim motoru değildir. Suno akışı iki çıktı alanını korur: **Styles** ve **Lyrics**.

## Proje yapısı
- `www/`: web çalışma zamanı.
- `android-wrapper/`: Android WebView uygulaması ve Gradle projesi.
- `backend/`: Node.js Gemini API servisi.
- `scripts/` ve `tests/`: kaynak doğrulama ve regresyon testleri.
- `BUILD_MANIFEST.json`: sürüm ve derleme metaverisi.

## Sürüm
- Uygulama: **6.1.1 · Stage172**
- Android versionCode: **34**
- Application ID: `com.songdna.studio`
- Minimum SDK: 23 · Hedef SDK: 35

Stage172, yüklenen Stage171 kaynağını temel alır. Gemini HTTP 404 model bulunamadı hatasında, sıradaki izinli Flash modeline geçişi düzeltir. HTTP 400, 401 ve 403 hataları terminal kalır. Mevcut 75 Music DNA profili, Intro DNA kataloğu, Styles/Lyrics akışı, Müzik Uyumluluğu denetimi ve modern/geleneksel seçim kuralları korunmuştur.

## APK derleme
Depoya `SONGDNA_SMART_STUDIO_6_1_1_STAGE172_KAYNAK.zip` dosyasını ekleyin. Bu kaynakla birlikte verilen YAML dosyasını `.github/workflows/build.yml` yoluna koyun. GitHub Actions içinden **SONGDNA SMART STUDIO Stage172 Android Debug APK** iş akışını çalıştırın. Başarılı derleme sonrası `SONGDNA-SMART-STUDIO-6.1.1-STAGE172-DEBUG-APK` artifact'ini indirin. İş akışı debug APK üretir; imzalı release APK değildir.

## Gemini / Render
Backend Render üzerinde ayrı dağıtılır. `GEMINI_API_KEY` yalnızca sunucuda tutulur; uygulama `APP_ACCESS_TOKEN` ile backend'e erişir. Canlı Gemini/Render bağlantısı ve fiziksel Android kurulumu bu kaynak paketi oluşturulurken doğrulanmış değildir.

## Yerel doğrulama
```bash
python3 scripts/verify-source.py
npm --prefix backend run check
```
JavaScript ve Python/tarayıcı regresyonları GitHub Actions iş akışında çalıştırılır.
