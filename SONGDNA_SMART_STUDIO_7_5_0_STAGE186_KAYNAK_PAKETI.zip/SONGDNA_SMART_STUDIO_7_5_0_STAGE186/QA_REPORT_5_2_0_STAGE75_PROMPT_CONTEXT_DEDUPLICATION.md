# SONGDNA SMART STUDIO 5.2.0 — Stage 75 Prompt Context Deduplication

## Root cause
The 142,091-character client-side preflight error was caused by repeated transmission of detailed engine guidance in the Gemini instruction envelope. The envelope's `selected` object serialized full production, integrated-production, section-arrangement, vocal, vocal-identity, fusion and shared-identity prompt text while the same detailed guidance was already included in the `basePrompt` for Styles and Lyrics. The production profile itself also retains coordinated engine guidance.

## Change
- Kept all engine calculations and shared production context intact.
- Kept the full coordinated production profile and module prompt text available in the generated task prompt.
- Reduced the envelope's `selected` object to compact authoritative selections and profile identifiers.
- Removed duplicated long prompt-text payloads from the envelope.
- Added integrated-production coordination explicitly once to the Styles task prompt, since it is no longer duplicated in the envelope.
- Preserved user-selection priority, Music DNA identity, section arrangement, vocal/ad-lib guidance, fusion role and profile snapshot reference.

## Why this approach
This is payload deduplication, not disabling or separating the engines. Each engine still computes and contributes its guidance; the same long text is no longer serialized a second time in the shared envelope. This follows Google's prompt-design guidance to structure complex prompts and break down repeated/context-heavy content rather than indiscriminately adding more instructions.

## Verification
- Stage 75 targeted prompt-envelope regression: passed.
- JavaScript regression suite: 51/51 passed.
- `python3 scripts/verify-source.py`: passed; runtime assets synchronized, manifests match, JavaScript syntax and Android XML checks passed.
- Stage 72 profile-classification regression: passed.
- Stage 73 profile-identity-precedence regression: passed.
- Production preset engine regression: passed.
- Exact live character count depends on selected profile and UI choices; it must be checked on device after installing the rebuilt APK.

## Boundaries
- This source change does not prove live Gemini quality or Suno audio quality.
- No Gemini API key, server URL, access token, model, backend endpoint, or 100,000-character safety limit was changed.
- No UI controls or optional features were added.
