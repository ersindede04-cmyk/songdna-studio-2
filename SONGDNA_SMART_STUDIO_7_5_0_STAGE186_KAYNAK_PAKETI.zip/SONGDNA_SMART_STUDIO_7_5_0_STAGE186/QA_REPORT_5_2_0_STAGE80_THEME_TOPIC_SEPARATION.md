# QA — Stage 80

- Independent broad-theme UI field: covered by regression test.
- Specific topic field remains distinct: covered by regression test.
- Lyrics prompt transmits both fields separately: covered by regression test.
- Shared output identity includes broad theme: covered by regression test.
- Existing specific-topic state retained for backward compatibility.
