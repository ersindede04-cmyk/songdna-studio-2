# Stage177 QA — 6.2.0 API Referansı

## Kaynakta doğrudan doğrulananlar
- Kullanıcı tarafından yüklenen APK paket metadata: applicationId `com.songdna.studio`, versionName `6.2.0`, versionCode `34`.
- APK içindeki `assets/app.js` ve `assets/www/app.js` aynı dosyadır.
- APK istemcisi `postGemini(path, prompt)` üzerinden `/api/lyrics` ve `/api/style` çağrılarını yapar.
- İstek `Content-Type: application/json` ve `X-App-Token` başlığını taşır; gövdede model ve prompt bulunur.
- İstem sınırı 150.000 karakter, istemci zaman aşımı 150 saniyedir.
- Ana üretim akışı önce Lyrics üretir, ardından Styles üretir. Styles hatası Lyrics sonucunu silmez.
- Stage177 istemcisindeki `postGemini` fonksiyonu, APK'dan çıkarılan fonksiyonla bayt düzeyinde aynıdır.

## Yerel doğrulama
- Kaynak doğrulama betiği: geçti.
- Stage177 API referans sözleşmesi: geçti.
- Backend `node --check`: geçti.
- CI ön kontrolü: geçti.
- JavaScript regresyonları: 133/133 geçti.
- Python/tarayıcı testleri: bu çalışma ortamında tamamlanamadı. Playwright sürücü iletişiminde `EPIPE` hatası oluştu ve çalıştırma zaman aşımına uğradı. GitHub Actions workflow'u 7 Python/tarayıcı testini yeniden çalıştıracak.

## Doğrulama sınırları
APK içinde backend kaynak kodu yoktur. Bu nedenle APK'nın kullandığı canlı sunucu kodu, model listesi, kota/fallback davranışı veya Render dağıtımı APK'dan doğrulanamaz. Stage176 backend'inin mevcut uç noktaları, token kontrolü ve 150.000 karakter sınırı kendi kaynak kodundan doğrulanmıştır; eski APK sunucusuyla birebir aynı olduğu varsayılmamıştır.

## Harici doğrulama bekliyor
Canlı Gemini / Render, GitHub Actions Android APK derlemesi, gerçek cihaz kurulumu ve Suno ses üretimi.
