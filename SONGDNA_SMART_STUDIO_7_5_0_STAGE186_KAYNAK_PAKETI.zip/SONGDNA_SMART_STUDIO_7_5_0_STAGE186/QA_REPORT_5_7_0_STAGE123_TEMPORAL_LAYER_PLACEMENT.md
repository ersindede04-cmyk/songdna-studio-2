# Stage 123 QA — Temporal Layer Placement

## Scope
Advisory-only temporal placement guidance for genuine three-layer conflicts.

## Checks
- Real rhythm/vocal/bass/repeated-element conflicts receive a conditional temporal separation plan.
- Compatible layers do not receive a forced separation plan.
- Plans refer only to existing contrast sections, transitions, or response gaps.
- No section is invented, no selection is reassigned, and manual selections remain unchanged.
- A missing main layer is never fabricated.
- Mirrored orchestrator files are byte-identical.

## Not tested
- Live Gemini/Render behavior
- Android APK build/install
- Actual Suno audio or whether Suno follows temporal prompts exactly
