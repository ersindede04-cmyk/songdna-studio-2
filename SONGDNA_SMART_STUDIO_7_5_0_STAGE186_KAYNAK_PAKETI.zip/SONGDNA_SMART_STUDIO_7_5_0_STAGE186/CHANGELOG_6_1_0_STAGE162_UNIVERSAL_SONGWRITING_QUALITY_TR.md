# Stage162 — Evrensel Gemini Şarkı Sözü Kalite Motoru

## Amaç
Gemini'nin tüm desteklenen dillerde ve müzik türlerinde daha doğal, özgün, anlamlı ve söylenebilir sözler üretmesini güçlendirmek. Geleneksel müziklerde kültürel icra ve vokal rollerinin modern pop/trap varsayımlarıyla bozulmasını önlemek.

## Uygulama
- Komut sırası: brief kilidi → ana dilde yazım → hikâye mimarisi → tür/gelenek uyarlaması → geleneksel vokal güvenliği → söylenebilirlik → özgünlük → yapı/vokal kontrolü → sessiz editoryal denetim → çıktı sözleşmesi.
- Geleneksel profillerde, seçili gelenek veya kullanıcı talebi desteklemiyorsa kadın destek vokali, düet, koro, pop armonisi ve otomatik ad-lib eklenmez.
- Kullanıcının açık vokal tercihi korunur; gelenekle çelişiyorsa geleneksel otantiklik iddiası yapılmaz.
- Dil, lehçe, anlatıcı, zaman, bakış açısı, konu, özel kelimeler ve dışlamalar korunur.
- Kafiye anlamı ve doğal dilbilgisini bozamaz.

## Korunanlar
Uygulama sürümü 6.1.0, Android versionCode 32, 28 dil profili, mevcut Gemini sağlayıcısı/fallback, API uçları, Styles/Lyrics iki alanı, UI ve üretim akışı değiştirilmedi. Yalnızca backend lyrics system instruction genişletildi.

## Sınırlamalar
Bu paket istem talimatlarını güçlendirir; Gemini'nin her üretimde kusursuz sonuç vereceğini garanti etmez. Canlı Gemini, Render, APK, Suno ses çıktısı ve ana dili konuşan kişilerce değerlendirme bu kaynak paketinde yapılmamıştır.
