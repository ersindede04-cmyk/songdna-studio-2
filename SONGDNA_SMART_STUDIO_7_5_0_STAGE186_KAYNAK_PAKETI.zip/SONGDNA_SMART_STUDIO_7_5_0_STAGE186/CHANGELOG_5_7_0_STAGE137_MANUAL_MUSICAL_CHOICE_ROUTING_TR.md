# Stage 137 — Manuel Müzikal Seçimlerin Çıktılara Aktarımı

- Manuel ritim, groove, enstrüman, prodüksiyon ve miks seçimlerinin Styles alanına aktarımını denetleyen kontrol eklendi.
- Vokal tavrı ve vokal düzeni seçimleri, vokal performansını etkilediğinde Lyrics tarafında da denetleniyor.
- Enstrümantal/prodüksiyon seçimlerinin yalnızca Lyrics'e sızması ayrıca raporlanıyor.
- Denetim yalnızca uyarı üretir; seçimleri değiştirmez, silmez veya otomatik yeniden yazmaz.
- Gemini Styles ve Lyrics istemlerine manuel seçimlerin korunması ve doğru çıktı alanına yönlendirilmesi talimatı eklendi.
- Yeni ekran, kontrol veya üçüncü çıktı alanı eklenmedi.
