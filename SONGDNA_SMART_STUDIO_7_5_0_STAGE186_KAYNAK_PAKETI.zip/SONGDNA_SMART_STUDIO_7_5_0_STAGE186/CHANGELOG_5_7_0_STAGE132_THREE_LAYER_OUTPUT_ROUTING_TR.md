# Stage 132 — Üç Katmanlı Üretim Çıktı Yönlendirmesi

- Ana Prodüksiyonun tek ana müzikal kimlik olarak kalması açıkça denetlenir.
- Alt Katman 2 ve Yardımcı Prodüksiyon yalnızca seçilmiş ikincil/destekleyici rollerinde Styles'a katkı verir.
- Lyrics tarafında ikincil/yardımcı katmanlar yalnızca katalogda açıkça vokal, söyleyiş, phrasing, chant veya call-and-response rehberliği varsa etkili olur.
- Enstrümantal, ritim, bas, synth, perküsyon ve miks odaklı katmanlar söz dilini, konusunu veya vokal davranışını değiştirmez.
- Seçilmemiş katmanlar boş kalır; ana katman yoksa ikincil katman ana kimliğe yükseltilmez.
- Katman yönlendirme denetimi uyarı üretir; seçimleri değiştirmez ve çıktıları otomatik yeniden yazmaz.
- Mevcut iki çıktı alanı ve Gemini üretim akışı korunur.
