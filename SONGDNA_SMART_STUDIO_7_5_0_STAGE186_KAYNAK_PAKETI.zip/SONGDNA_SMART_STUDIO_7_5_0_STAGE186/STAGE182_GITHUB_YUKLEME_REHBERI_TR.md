# SONGDNA SMART STUDIO 7.1.0 — Stage182 Kaynak Paketi

Bu ZIP, Stage181'de doğrulanan uygulama ve hikâye harmanlama iyileştirmelerini korur. Bu aşamadaki değişiklik sürüm/derleme kimliğini Stage182 olarak yükseltmek ve tüm kaynak/yükleme yollarını buna uyarlamaktır.

## GitHub'a yükleme

1. `SONGDNA_SMART_STUDIO_7_1_0_STAGE182_KAYNAK.zip` dosyasını ZIP'ten çıkarmadan GitHub deposunun ana dizinine yükleyin.
2. Arşivdeki `.github/workflows/build.yml` dosyasının içeriğini GitHub deposunda aynı yola (`.github/workflows/build.yml`) kopyalayın.
3. Değişiklikleri `main` dalına gönderin veya Actions sekmesinden elle çalıştırın.
4. Başarılı çalışmanın Artifacts bölümünden `SONGDNA-SMART-STUDIO-7.1.0-STAGE182-ANDROID-DEBUG` çıktısını indirin.

## Arşiv yapısı

ZIP açıldığında tek ana klasör oluşur: `SONGDNA_SMART_STUDIO_7_1_0_STAGE182/`. GitHub Actions bu klasör adını bekler.

## Otomatik kontroller

- Kaynak ve Android WebView dosya bütünlüğü
- Backend JavaScript sözdizimi
- 141 JavaScript regresyon dosyası
- 7 Python/tarayıcı regresyon dosyası
- Android debug APK derlemesi ve SHA-256 özeti

## Sınırlar

Paket API anahtarı veya `APP_ACCESS_TOKEN` içermez. Render dağıtımı yapılmaz. GitHub Actions başarısı canlı Gemini/Render, fiziksel Android veya Suno ses doğrulaması anlamına gelmez.
