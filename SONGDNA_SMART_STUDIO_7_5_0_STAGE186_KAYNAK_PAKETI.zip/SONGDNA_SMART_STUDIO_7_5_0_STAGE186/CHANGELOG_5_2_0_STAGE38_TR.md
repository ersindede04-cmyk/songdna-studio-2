# Stage 38 — Tema, Music DNA 66 ve Vokal Şablonları

- Sayfada CSS metni görünmesine yol açan hatalı style kapanışları düzeltildi.
- Music DNA otomatik sıralaması ilk 18 yerine katalogdaki 66 profilin tamamını döndürecek şekilde güncellendi.
- Elle seçim otomatik döngüyü devre dışı bırakır; sayaç yalnızca başarılı şarkı sözü üretiminden sonra ilerler.
- Eski 18'li sayaç konumu yeni 66'lı sayaç anahtarına taşınır.
- Hazır vokal şablonlarının her biri için erkek ve kadın seçenekleri eklendi.
- Music DNA modu ve hazır komut şablonu seçimleri Android'de temalı özel açılır liste olarak gösterilir.
- Web, kök çalışma zamanı ve Android WebView varlıkları eşitlendi.
- Stage 37'deki 100.000 karakter istem sınırı ve 500.000 bayt istek gövdesi sınırı korundu.
- GitHub Actions iş akışı Stage 38 ZIP dosyasını önce bulup açar, gerçek proje kökünü tespit eder, doğrular ve APK oluşturur.
