# QA — Stage 132

## Kapsam
Üç katmanın Styles ve Lyrics çıktılarına görev sınırları içinde aktarılması; ana kimliğin korunması; boş katmanların boş kalması; vokal olmayan ikincil katmanların Lyrics'e sızmaması.

## Odaklı test
`tests/test-stage132-three-layer-output-routing.js`: 16/16 assertion passed.

Kontroller:
- Styles yalnızca seçilmiş katmanları içerir.
- Ana Prodüksiyon seçiliyse tek birincil roldür.
- Ana Prodüksiyon yoksa ikincil/yardımcı katman yükseltilmez.
- Vokal rehberliği olmayan ikincil katman Lyrics kapsamı dışında kalır.
- Açık vokal/call-and-response rehberliği olan katman Lyrics'e dahil olabilir.
- Seçilmemiş katmanlar boş kalır.
- Hatalı veya eksik yönlendirme denetimde uyarı üretir.
- Denetim seçimleri değiştirmez ve otomatik metin düzeltmesi yapmaz.

## Sınırlar
Bu testler uygulama kaynak kodu ve üretim orkestratörünün yönlendirme planını doğrular. Canlı Gemini/Render, APK kurulumu ve gerçek Suno ses çıktısı bu aşamada test edilmemiştir. Katalogdaki her kültürel/müzikal bilginin gerçek dünyada doğruluğunu kanıtlamaz.
