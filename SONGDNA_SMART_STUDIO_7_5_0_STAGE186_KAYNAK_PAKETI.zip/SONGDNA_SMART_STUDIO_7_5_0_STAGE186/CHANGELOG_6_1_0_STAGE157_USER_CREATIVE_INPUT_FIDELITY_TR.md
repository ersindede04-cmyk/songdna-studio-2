# Stage 157 — Kullanıcı Yaratıcı İçeriği Sadakati

- Kullanıcının yazdığı şarkı konusu ve somut imgeler Lyrics üretiminde zorunlu yaratıcı kaynak olarak tanımlandı.
- Kısa anahtar kelime listelerindeki anlamlı öğelerin sözlere doğal biçimde yerleştirilmesi istendi; liste gibi sıralama engellendi.
- Kültürel yerel ifade / özel söz alanındaki kullanıcı metninin en az bir kez aynen korunması talimatı eklendi.
- Ek yaratıcı talimatların otomatik tema ve şablonlardan üstün olması güçlendirildi.
- Gemini talimat zarfına kullanıcı konusu, özel ifadeleri ve yaratıcı talimatları açıkça eklendi.
- Üretim öncesi/sonrası kullanıcı girdisi sadakati için sessiz öz-denetim talimatı eklendi.
- Arayüz, Styles üretimi, geleneksel müzik kimliği, Gemini model seçimi, API ve iki alanlı çıktı akışı değiştirilmedi.
- Dört uygulama JavaScript kopyası eşitlendi.
