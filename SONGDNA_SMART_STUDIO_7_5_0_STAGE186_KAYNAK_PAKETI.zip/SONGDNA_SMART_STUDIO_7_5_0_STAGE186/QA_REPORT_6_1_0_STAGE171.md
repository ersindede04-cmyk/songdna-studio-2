# Stage171 QA Report

## Paket kimliği

- Application version: `6.1.0`
- Stage: `171`
- Android applicationId: `com.songdna.studio`
- Android versionCode: `33`
- Android versionName: `6.1.0`

## Korunan Stage170 doğrulamaları

- JavaScript regression inventory: 129 test files.
- Python/Playwright inventory: 7 test files.
- Stage170 Chromium workspace suite: 52/52 previously recorded checks passed across phone, tablet portrait and tablet landscape.
- Root, web and Android WebView runtime synchronization is checked by `scripts/verify-source.py`.
- Modern/Traditional workspace separation, independent music-domain switches, traditional preset filtering, instrument switches, responsive layout and safe Gemini error mapping remain in the source.

## Stage171 workflow corrections

- Source archive lookup expects `SONGDNA_SMART_STUDIO_6_1_0_STAGE171_KAYNAK.zip`.
- JavaScript count is checked against 129; Python count is checked against 7.
- Workflow runs source integrity checks, regression tests and Android debug APK build.

## Not verified

- Live Gemini service requires the deployed backend configuration and server-side API key.
- Physical Android phone/tablet interaction has not been tested here.
- Stage171 APK has not yet been built or installed.
