# SONGDNA SMART STUDIO 6.1.0 — Stage151 Android derleme düzeltmesi

Bu paket, Stage151 uygulama kaynaklarını ve mevcut Music DNA / üretim davranışlarını korur. Uygulama kaynak kodunda işlevsel değişiklik yapılmamıştır; düzeltme Android paketleme iş akışındadır.

## Stage151 paketinden doğrulanan yapı

- ZIP kök klasörü: `songdna95/`
- Android proje klasörü: `songdna95/android-wrapper/`
- Android Gradle yapılandırması: `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`
- `gradlew` ve `gradle/wrapper/` dosyaları ZIP içinde bulunmamaktadır.
- Android Gradle Plugin: `8.7.3`
- Kotlin Android plugin: `2.0.21`
- Android compile/target SDK: `35`
- Java hedefi: `17`

## Derleme düzeltmesi

Önceki iş akışı ZIP'i `_source/` altına çıkardıktan sonra doğrudan `_source/android-wrapper/gradlew` arıyordu. Gerçek paket yapısı ise `_source/songdna95/android-wrapper/` biçimindedir ve Gradle Wrapper mevcut değildir.

Yeni `build.yml`:

1. Tek bir Stage151 ZIP dosyası arar ve ZIP bütünlüğünü kontrol eder.
2. Android projesini sabit bir ZIP yolu varsaymak yerine `android-wrapper/settings.gradle.kts` üzerinden bulur.
3. Gradle Wrapper gerektirmez; Gradle 8.9'u GitHub Actions üzerinde kurup doğrudan kullanır.
4. Android SDK 35 ve Build Tools 35.0.0 kurar.
5. Kaynak doğrulamasını ve 120 JavaScript + 5 Python regresyon testini çalıştırır.
6. Debug APK'yı üretir, SHA256 hesaplar ve GitHub Actions Artifact olarak yükler.

## GitHub kullanımı

Bu dosyayı depodaki `.github/workflows/build.yml` ile değiştirin. Stage151 ZIP dosyasını depo ana dizinine ekleyin; dosya adında `Stage151` ifadesi bulunmalı ve depoda yalnızca bir eşleşen ZIP olmalıdır. Ardından Actions sekmesinden workflow'u çalıştırın.

## Bilinen sınırlar

- Bu ortamda Android SDK/Gradle dağıtımı üzerinden gerçek APK derlemesi çalıştırılmadı; APK başarısı GitHub Actions çalışmasında doğrulanacaktır.
- Render canlı dağıtımı, canlı Gemini çağrısı, fiziksel Android kurulumu ve imzalı release APK testi bu paket incelemesinin kapsamı dışındadır.
- Debug APK, yayın imzalı release APK değildir.
