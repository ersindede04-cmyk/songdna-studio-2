# Stage92 QA — Backup Version Compatibility

## Kapsam
- Yeni yedeklerde uygulama sürümü metadatası
- Daha eski uygulama sürümünden yedek geri yükleme
- Stage90 v1 ve Stage91 v2 yedekleriyle geriye dönük uyumluluk
- Daha yeni sürümde üretilmiş yedeği eski uygulamada reddetme
- Geçersiz sürüm metadatası ve tanınmayan veri alanlarında açık hata
- Reddedilen yedekte mevcut verilerin korunması

## Sınırlar
- Sürüm metadatası tek başına kriptografik güvence değildir; yedek dosyası şifrelenmez ve imzalanmaz.
- Gerçek Android dosya seçici/indirme, APK yükseltme, Gemini ve Render testleri yapılmadı.

## Test sonucu
- Stage90, Stage91 ve Stage92 yedek testleri: PASS
- Tüm JavaScript ve Python testleri: PASS
- `node --check app.js`: PASS
- Dört `data-backup.js`, dört `app.js` ve dört `index.html` kopyası SHA-256 ile birebir aynı.
- ZIP bütünlük kontrolü: PASS
