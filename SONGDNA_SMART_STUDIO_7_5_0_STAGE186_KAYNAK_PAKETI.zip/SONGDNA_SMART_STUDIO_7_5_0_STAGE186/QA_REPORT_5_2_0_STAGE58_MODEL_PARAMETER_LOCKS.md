# QA — Stage 58 Model Parameter Locks

- [x] Parametre paneli HTML'de mevcut.
- [x] Model uygulandığında parametreler listelenir.
- [x] Parametreler varsayılan olarak kilitli başlar.
- [x] Kilit değişikliği etkin uygulama örneğine yazılır.
- [x] Prompt kilitli ve uyarlanabilir parametreleri ayrı aktarır.
- [x] Manuel seçim önceliği korunur.
- [x] Kaydedilmiş model snapshot'ı değiştirilmez (Stage 57 library test).
- [x] Root / www / Android WebView kaynakları senkronize edilir.
- [ ] Gerçek Android cihaz testi.
- [ ] Canlı Gemini API üretim testi.
- [ ] APK derleme ve yükleme testi.
