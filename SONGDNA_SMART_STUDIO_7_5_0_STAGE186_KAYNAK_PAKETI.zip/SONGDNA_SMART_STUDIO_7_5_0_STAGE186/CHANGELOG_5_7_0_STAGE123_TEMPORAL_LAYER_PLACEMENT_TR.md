# Stage 123 — Katmanların Bölümler Arasında Zamansal Yerleşimi

- Üç katman arasında gerçek ritim, vokal düzeni, bas karakteri veya birebir öğe tekrarına dayalı çakışma bulunduğunda zamansal ayırma önerisi üretilir.
- Öneri yalnızca mevcut karşıtlık bölümü, geçiş veya vokal cevap boşluğu gibi zaten var olan alanları kullanmayı söyler.
- Yeni bölüm oluşturulmaz; katman otomatik taşınmaz, silinmez veya değiştirilmez.
- Ana katman seçiliyse şarkı boyunca temel kimliğini korur. Ana katman yoksa yeni bir ana kimlik uydurulmaz.
- Uyumlu katmanlar için gereksiz bölüm ayırma önerisi verilmez.
- Arayüze yeni kontrol veya çıktı alanı eklenmedi.
