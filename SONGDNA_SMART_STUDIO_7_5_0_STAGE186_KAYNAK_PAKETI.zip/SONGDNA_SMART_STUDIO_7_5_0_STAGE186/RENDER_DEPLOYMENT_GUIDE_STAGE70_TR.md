# SONGDNA SMART STUDIO 5.2.0 — Stage 70 Render Kurulum Rehberi

Bu paket Render için bir Blueprint (`render.yaml`) içerir. Dosyanın bulunması veya yerel testlerin geçmesi, servisin Render hesabında oluşturulduğu ya da dağıtıldığı anlamına gelmez.

## Render servis ayarları

Blueprint şu yapılandırmayı kullanır:

- Servis: `songdna-ai-api` (Web Service, Node.js)
- Servis kök dizini: `backend`
- Node sürümü: 20
- Derleme komutu: `npm install`
- Başlatma komutu: `npm start`
- Sağlık kontrolü: `GET /health`
- Dinleme portu: Render'ın verdiği `PORT`; uygulama `0.0.0.0` üzerinde dinler.

## Gizli ortam değişkenleri

Render Dashboard / Blueprint ilk kurulumunda şu iki gizli değeri gir:

1. `APP_ACCESS_TOKEN`: Blueprint Render tarafından rastgele üretilir. Dağıtım sonrasında Render Environment ekranından değerini kopyala; uygulamadaki erişim kodu alanına aynen gir.
2. `GEMINI_API_KEY`: Google AI Studio API anahtarı; Render Environment ekranında gizli değer olarak gir.

Bu değerleri GitHub'a, `render.yaml` dosyasına veya Android uygulamasına yazma. `backend/.env.example` yalnızca örnek adları içerir; gerçek `.env` dosyası `.gitignore` kapsamındadır.

Diğer ayarlar Blueprint'te tanımlıdır: `GEMINI_MODELS`, `GEMINI_MODEL`, `ALLOWED_ORIGIN=*` ve `TRUST_PROXY=true`. Render, proxy arkasındaki gerçek istemci IP'sini `X-Forwarded-For` başlığında iletir; mevcut sunucu kodu listenin ilk adresini kullanır. Bu ayarı başka bir hosting sağlayıcısına taşırken o sağlayıcının proxy davranışını ayrıca doğrula.

## Mevcut Render servisini kullanıyorsan

Aynı isimde çalışan bir servisin varsa Blueprint'i senkronize etmeden önce Render'ın göstereceği değişiklik planını incele. Mevcut servisi yanlışlıkla ikinci kez oluşturma veya çalışan ayarlarını istemeden değiştirme. İstersen mevcut servisin Settings bölümünde yukarıdaki root directory, build/start command ve health-check değerlerini elle karşılaştır.

## Android uygulamasına bağlantı

1. Render dağıtımı tamamlandığında Dashboard'da görünen gerçek HTTPS servis adresini kopyala. Adres örneği uydurma; kendi servisine ait URL'yi kullan.
2. SONGDNA uygulamasında **Ayarlar → AI ve API Bağlantısı** bölümünü aç.
3. **AI sunucu adresi (HTTPS)** alanına Render URL'sini gir. Sondaki `/` işaretini yazmak zorunda değilsin.
4. **Uygulama erişim kodu** alanına Render'ın ürettiği `APP_ACCESS_TOKEN` değerini gir.
5. Gemini modelini seç ve ayarları kaydet.

Android uygulamasına `GEMINI_API_KEY` girilmez. İstemci yalnızca sunucu URL'sini, model tercihini ve uygulama erişim kodunu kullanır.

## Dağıtım sonrası kontrol listesi

- `https://GERCEK-SERVIS-ADRESI/health` adresi HTTP 200 dönmeli. Yanıtta `ok: true` ve `providers.gemini: true` görülmeli.
- Uygulama içinden Lyrics ve Styles üretimi ayrı ayrı denenmeli.
- Yanlış erişim kodunun 401 ile reddedildiği kontrol edilmeli.
- Render Logs bölümünde başlangıç hatası veya Gemini kota/model hatası bulunmadığı incelenmeli.
- Canlı test yapılmadan `deployed` veya `live-verified` olarak işaretleme.

## GitHub Actions APK derlemesi

`.github/workflows/build.yml` Stage 70 ZIP dosyasını izler ve ZIP'in kök dizininden kaynakları çıkarır. Önceki iş akışı Stage 60.1 ZIP adını ve artık mevcut olmayan `stage58_work` alt dizinini bekliyordu; bu iki eşleşme Stage 70 için düzeltildi.

GitHub deposuna `SONGDNA_Studio_5_2_0_Stage70_Render_Deployment_Preparation.zip` dosyasını `main` dalının köküne koyup gönderdiğinde workflow tetiklenir. Bu sohbet ortamında GitHub'a push yapılmadığı için uzaktan APK derlemesi henüz çalıştırılmış sayılmaz.
