# QA — SONGDNA SMART STUDIO 5.7.0 / Stage 143

## Kapsam

Elle düzenlenen Lyrics ve Gemini tarafından gösterilen yeni Lyrics metni için vokal bölüm yerleşimi denetiminin güncel içerikle yeniden çalıştırılması.

## Uygulama

- `auditManualVocalSectionPlacementLive()` güncel Lyrics metnini ve açık manuel atamaları alır.
- Denetim her çağrıda yeni Lyrics imzasıyla damgalanır.
- `refreshSunoAudit()` bu denetimi çalıştırır ve varsa uyarıları mevcut Lyrics denetim metnine ekler.
- Lyrics alanındaki `input` olayı `refreshSunoAudit()` çağırır.
- `show()` üretim/gösterim akışı da `refreshSunoAudit()` çağırdığı için yeni Gemini çıktısı güncel metinle denetlenir.
- Manuel atama yoksa sistem atama uydurmaz; otomatik düzeltme veya bölüm oluşturma yapılmaz.

## Odak testleri

- Stage 143: 12/12 assertion geçti.
- Stage 142 freshness: 11 assertion geçti.
- Stage 141 sıra bağımsızlığı: 67 profil × 24 sıralama + 3 odak kontrolü geçti.
- Stage 140 bölüm yerleşimi: 67 profil iterasyonu + 8 odak kontrolü geçti.

## Sınırlar

Kaynak ve otomatik testler uygulama içi bağlam bağlantısını doğrular. Gerçek cihaz, canlı Gemini/Render ve Suno ses çıktısı testi yapılmadı.
