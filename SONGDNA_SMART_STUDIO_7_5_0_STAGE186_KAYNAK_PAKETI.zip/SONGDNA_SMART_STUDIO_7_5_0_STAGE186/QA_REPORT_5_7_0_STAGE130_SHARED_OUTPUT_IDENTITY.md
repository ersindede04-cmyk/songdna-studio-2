# Stage 130 QA — Shared Music DNA Output Identity

## Scope
Styles and Lyrics prompt policies now explicitly share one primary Music DNA profile snapshot. A non-destructive audit checks profile IDs when both the shared identity snapshot and three-layer identity are available. Missing identity context is disclosed; it is not guessed.

## Focused checks
- Matching profile IDs: advisory/pass.
- Mismatched profile IDs: warning.
- Missing profile snapshot: warning/disclosed.
- Empty output: pending.
- Empty defining-trait list: no fabricated traits and no forced failure.
- No automatic rewrite and no extra output field.

## Limitations
This check validates shared profile context and explicit ID agreement. It does not semantically prove that generated lyrics or Styles are culturally authentic or musically correct. Live Gemini/Render, APK installation, and real Suno audio generation are not tested here.
