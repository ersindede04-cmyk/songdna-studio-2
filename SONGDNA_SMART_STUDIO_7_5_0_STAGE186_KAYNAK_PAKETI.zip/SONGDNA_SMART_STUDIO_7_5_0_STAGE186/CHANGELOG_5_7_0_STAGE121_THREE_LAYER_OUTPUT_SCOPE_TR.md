# Stage 121 — Üç Katmanın Çıktı Bazında Rol Sınırları

- Ana Prodüksiyon, Styles ve Lyrics için temel müzikal kimlik olarak kalır.
- Alt Katman 2 ve Yardımcı Prodüksiyon, seçildiklerinde Styles içinde yalnızca ikincil/yardımcı ses rolleriyle temsil edilir.
- İkincil veya yardımcı katman Lyrics'i ancak kendi seçili profilinde açık vokal, söyleyiş, ifade, vokal düzeni veya karşılıklı söyleyiş rehberi varsa etkileyebilir.
- Enstrümantal, ritmik, bas, synth, perküsyon ve miks odaklı katmanlar Lyrics'in dilini, hikâyesini veya vokal davranışını değiştirmez.
- Katman seçimi olmayan alanlar boş kalır; manuel seçim önceliği korunur.
- Yeni ekran, ayar, çıktı alanı veya üretim geçişi eklenmedi.

Doğrulama: Stage 121 rol kapsamı testi ve mevcut otomatik test paketi çalıştırıldı. Canlı Gemini/Render, APK kurulumu ve gerçek Suno ses çıktısı test kapsamı dışındadır.
