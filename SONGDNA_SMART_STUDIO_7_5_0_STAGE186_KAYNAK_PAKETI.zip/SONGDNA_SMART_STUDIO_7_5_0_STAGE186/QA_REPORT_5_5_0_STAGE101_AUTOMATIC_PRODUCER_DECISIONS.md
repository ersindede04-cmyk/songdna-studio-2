# SONGDNA SMART STUDIO 5.7.0 — Stage 101 QA

## Amaç
Kullanıcının temel mimari kuralını üretim istemlerinde açık ve ortak bir sözleşme hâline getirmek: Music DNA seçildiğinde, manuel olarak belirtilmeyen prodüksiyon kararları sistem tarafından tür ve kültür bağlamına uygun biçimde otomatik tamamlanır.

## İncelenen mevcut altyapı
- `buildProductionProfile` ve ilgili üretim motorları groove, tempo yaklaşımı, davul/bas, melodi, prodüksiyon ve aranjman varsayılanlarını oluşturuyor.
- `buildVocalProfile` vokal tavrı, destek vokal, ad-lib yerleşimi ve bölüm davranışını oluşturuyor.
- `recommendAdlibPhrases` tür/kültür eşleşmesi, enerji, vokal tavrı, yoğunluk ve yakın geçmişe göre katalog ifadelerini sıralıyor.
- Manuel ad-lib ifadeleri varsa otomatik öneriler yerine manuel ifadeler kullanılıyor.
- Güvenli ve doğrulanmış katalog ifadesi yoksa kelime uydurmak yerine wordless vocalise veya sessizlik yönergesi kullanılıyor.
- Styles ve Lyrics aynı `buildSharedOutputIdentityContract` sözleşmesini kullanıyor.

## Stage 101 değişikliği
- Ortak Styles–Lyrics sözleşmesine açık bir **AUTOMATIC PRODUCER DECISION POLICY** eklendi.
- Manuel olarak belirtilmeyen groove, ritmik bölünme, davul/perküsyon, bas, armoni/melodi, enstrüman, vokal, destek vokal, ad-lib, efekt, geçiş ve bölüm aranjmanı kararlarının otomatik tamamlanması talimatı netleştirildi.
- Otomatik kararların iki çıktıda tutarlı kalması şartı eklendi.
- Bir alandaki manuel seçimin yalnızca o alanın otomatik kararını geçersiz kılması, diğer boş alanların otomatik kalması açıkça belirtildi.
- Gemini'nin ortak seçim özetine otomatik ve manuel ad-lib katalog kimlikleri eklendi.
- Yeni ekran, düğme veya kullanıcıya ek seçim yükü eklenmedi.

## Testler
- `node --check` — dört uygulama giriş dosyası: PASS
- Stage 101 automatic producer contract: PASS
- Stage 99 three-layer compatibility regression: PASS
- Stage 100 musical characteristics regression: PASS
- Stage 96 three-layer live-integration contract regression: PASS
- ZIP integrity: verified

## Sınırlar
Bu testler kod sözleşmesini ve mevcut motorların entegrasyon noktalarını doğrular. Canlı Gemini/Render çağrısı, APK derleme/kurulum, fiziksel Android testi ve gerçek Suno ses çıktısı bu aşamada yapılmamıştır. Otomatik seçimlerin gerçek üretimdeki müzikal kalitesi canlı uçtan uca testle ayrıca değerlendirilmelidir.
