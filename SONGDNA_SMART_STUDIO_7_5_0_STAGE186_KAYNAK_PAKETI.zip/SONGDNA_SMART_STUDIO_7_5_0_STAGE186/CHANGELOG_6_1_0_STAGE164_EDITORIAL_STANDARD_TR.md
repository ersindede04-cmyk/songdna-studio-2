# Stage164 — Şarkı Sözü Editoryal Standardı

- Backend Gemini Lyrics sistem talimatına Stage164 kullanıcı sadakati ve asgari müdahale standardı eklendi.
- Kullanıcı talimatları, hikâye/anlam sadakati, geleneksel müzik koruması, belirsizlik yönetimi ve görev modu ayrımı açıklaştırıldı.
- Sekiz aşamalı arka plan denetimi tanımlandı.
- Styles üretimi, katalog sıraları, Music DNA kimlikleri, API sağlayıcısı ve uygulama sürüm bilgileri değiştirilmedi.
- Bu kaynak paketi uluslararası pop prodüksiyon seçimi için yeni bir kullanıcı arayüzü içermez; bu özellik ayrı entegrasyon ve cihaz testi gerektirir.
- Canlı Gemini, Render, Android cihaz ve Suno ses çıktısı testleri bu paket kapsamında çalıştırılmadı.
