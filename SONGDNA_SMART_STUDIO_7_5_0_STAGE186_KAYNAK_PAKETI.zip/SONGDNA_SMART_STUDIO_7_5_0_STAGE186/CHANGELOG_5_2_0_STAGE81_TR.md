# SONGDNA Studio 5.2.0 — Stage 81

## Tema ve konu için bağımsız seçim modu

- `songTheme` genel şarkı teması seçicisi korunarak otomatik/manuel kullanım ayrımı netleştirildi.
- Yeni `topicMode` seçicisi eklendi: Otomatik Konu / Elle Seçim.
- Otomatik konu üretiminde `theme` alanına yazılmış fakat otomatik modda kullanılmaması gereken manuel metin dikkate alınmaz.
- Elle seçim modunda konu alanı boşsa üretim başlamaz ve kullanıcıya açıklayıcı mesaj gösterilir.
- Elle seçilen öneri butonu, konu modunu açıkça Elle Seçim'e geçirir.
- Otomatik konu geçmişi yalnızca başarılı Lyrics üretiminden sonra güncellenir; seçim/istek başlatma anında kaydedilmez.
- Gemini Styles/Lyrics iki çıktılı akışı, Music DNA rotasyonu ve mevcut prodüksiyon profilleri korunmuştur.
- Root, www ve Android WebView asset kopyaları senkronize edilmiştir.

## Test

- Stage 81 bağımsız konu modu testi
- Stage 79 manuel yaratıcı alan kilidi testi
- Stage 80 tema/konu ayrımı testi
- Stage 47 tema ve asset senkronizasyon testi
- Gemini instruction engine testi
- JavaScript sözdizimi kontrolleri
