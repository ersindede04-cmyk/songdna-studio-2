# Stage 143 — Canlı Vokal Yerleşimi Yeniden Denetimi

- Lyrics alanı her elle düzenlendiğinde mevcut metin üzerinden vokal bölüm yerleşimi denetimi yeniden çalışır.
- Gemini üretimi veya mevcut çıktı gösterildiğinde `show()` akışındaki `refreshSunoAudit()` aynı denetimi güncel Lyrics metnine uygular.
- Denetim, yalnızca bağlamda açıkça bulunan manuel bölüm atamalarını kullanır; atama yoksa rol veya bölüm varsaymaz.
- Denetim sonucu güncel Lyrics imzasıyla damgalanır; eski metne ait sonuç yeni metin için kullanılmaz.
- Eksik bölüm/rol bilgisi mevcut Lyrics denetim alanında uyarı olarak gösterilir.
- Sözler, manuel seçimler ve bölüm yapısı otomatik değiştirilmez; yeni bölüm oluşturulmaz.
- İki çıktı alanı ve mevcut Gemini akışı korunur.

## Sınırlar

Bu aşama uygulama içi denetim bağlantısını ve otomatik yeniden denetim davranışını kaynak/test düzeyinde doğrular. Canlı Gemini/Render çağrısı, APK kurulumu ve Suno ses üretimi bu testlerin kapsamı dışındadır.
