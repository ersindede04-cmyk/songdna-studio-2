# SONGDNA SMART STUDIO 6.1.1 — Stage172

## Yapılan değişiklik
- Gemini API bir model için HTTP 404 (model bulunamadı / kullanılamıyor) döndürdüğünde istek artık izin verilen sıradaki Flash modeline aktarılır.
- 401/403 kimlik doğrulama ve 400 hatalı istek durumları model değiştirerek gizlenmez; terminal hata olarak kalır.
- Mevcut model izin listesi, toplam süre bütçesi, Styles/Lyrics üretim akışı ve API güvenlik sınırları korunur.
- Android versionCode 34, versionName 6.1.1 olarak güncellendi.

## Korunanlar
75 Music DNA profili, Intro DNA kataloğu, modern/geleneksel ayrımı, manuel seçim önceliği, Müzik Uyumluluğu denetimi ve Gemini'nin Lyrics alanına üretim akışı korunmuştur.

## Kapsam notu
Tüm uzun menülere akordiyon uygulanması ve 2–8 temalı çoklu Story DNA birleştirmesi bu pakette tamamlanmış özellikler olarak sunulmamaktadır. Bu kontrollerin mevcut işleyişi değiştirilmemiştir.
