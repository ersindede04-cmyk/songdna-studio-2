# Stage177 — GitHub'a ZIP yükleme ve Android derleme

## GitHub deposuna yüklenecekler
1. `SONGDNA_SMART_STUDIO_7_0_0_STAGE177_KAYNAK.zip` dosyasını deponun ana dizinine yükle. ZIP'i açıp dosyaları tek tek yükleme; workflow ZIP'i kendisi açar.
2. `SONGDNA_STAGE177_GITHUB_BUILD.yml` dosyasını `.github/workflows/songdna-stage177.yml` konumuna yerleştir. `.github/workflows` klasörü yoksa oluştur.
3. Değişiklikleri `main` dalına gönder. Workflow, kaynak ZIP veya YAML değişince çalışır. İstersen GitHub Actions sayfasından `workflow_dispatch` ile elle de başlatabilirsin.

## Derleme
- Workflow Java 17, Node.js 20, Python 3.11 ve Gradle 8.9 kurar.
- Kaynak bütünlüğünü ve Android/WebView kopyalarını doğrular.
- 133 JavaScript ve 7 Python/tarayıcı regresyon dosyasını çalıştırır.
- Android Debug APK üretir ve SHA-256 dosyasıyla birlikte Actions Artifact olarak yükler.

## Çıktı
GitHub deposunda **Actions → ilgili Stage177 çalıştırması → Artifacts** bölümünden `SONGDNA-SMART-STUDIO-7.0.0-STAGE177-ANDROID-DEBUG` paketini indir.

## Önemli
Bu YAML Debug APK üretir. Canlı Gemini/Render bağlantısı için uygulamadaki API sunucu adresi, uygulama erişim kodu ve sunucudaki `GEMINI_API_KEY` ayrı olarak yapılandırılmalıdır. Gizli anahtarları kaynak ZIP'e veya GitHub'a düz metin olarak ekleme. Gerçek cihaz, canlı Gemini ve Suno ses testi derleme sonrasında ayrıca yapılmalıdır.
