# Stage185 — Tek Paket Render Dağıtım Rehberi

Bu pakette uygulamanın tam kaynak ağacı bulunur. Hikâye harmanlama düzeltmesi ayrıca dosya aratmadan `backend/server.js` içine gömülüdür.

## GitHub deposuna aktarım
1. ZIP'i aç.
2. İçindeki `SONGDNA_SMART_STUDIO_7_5_0_STAGE185` klasörünün **içeriğini** GitHub deposunun köküne aktar. Klasörün kendisini bir alt klasör olarak koyma.
3. GitHub deposunda şu yolların gerçek dosya olarak bulunduğunu doğrula:
   - `render.yaml`
   - `backend/server.js`
   - `backend/package.json`
   - `www/app.js`
4. `backend/server.js` dosyası Stage185 paketindeki dosyayla aynı olmalı.

## Render
`render.yaml` şu ayarları tanımlar:
- Root Directory: `backend`
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check Path: `/health`

Mevcut Render servisini kullanıyorsan Blueprint değişikliklerini onaylamadan önce Render'ın göstereceği planı incele; yanlışlıkla ikinci servis oluşturma.

## Dağıtım sonrası doğrulama
Render servisinin gerçek adresinin sonuna `/health` ekleyerek aç. Beklenen yanıt:
- `ok: true`
- `apiVersion: "7.5.0"`
- `stage: 185`
- `capabilities.storyBlend: true`
- `providers.gemini: true` (GEMINI_API_KEY doğru tanımlıysa)

Bunlar görünmeden canlı düzeltme tamamlandı sayılmaz. Sonra uygulamada hikâye harmanlama, normal Lyrics ve Styles üretimini ayrı ayrı dene.

## Gizli anahtarlar
`APP_ACCESS_TOKEN` ve `GEMINI_API_KEY` değerlerini GitHub'a koyma. Bunlar Render Environment ekranında tutulmalıdır. Android uygulamasına Gemini API anahtarı girilmez.

## Kapsam dışı
Bu paket APK oluşturmaz ve canlı Render/Gemini/Android/Suno testlerinin yapıldığını iddia etmez.
