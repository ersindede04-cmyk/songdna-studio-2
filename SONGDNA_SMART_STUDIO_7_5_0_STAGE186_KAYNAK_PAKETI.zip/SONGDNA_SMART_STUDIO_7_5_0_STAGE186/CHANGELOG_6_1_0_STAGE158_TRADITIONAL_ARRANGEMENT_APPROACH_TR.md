# Stage 158 — Geleneksel Düzenleme Yaklaşımının Ayrıştırılması

- Geleneksel müzik ve Modern müzik kontrolleri yalnızca müzik alanı / müzikal kimlik seçimi olarak bırakıldı.
- Saf Geleneksel Prodüksiyon seçeneği müzik alanları grubundan çıkarılarak ayrı bir “Düzenleme yaklaşımı” alanına taşındı.
- Kullanıcı arayüzündeki ifade “Saf Geleneksel İcra” olarak sadeleştirildi; bunun bir tür değil, seçilen geleneksel müzik kimliğine uygulanan düzenleme kuralı olduğu açıklandı.
- Mevcut üretim kilidi, kültürel doğruluk kuralları, geleneksel alanı etkinleştirme ve modern alanı kapatma davranışı korundu.
- Styles, Lyrics, Gemini API, üretim akışı ve uygulama sürümü 6.1.0 değiştirilmedi. Android versionCode 32 olarak korundu.
- Dört HTML ve dört JavaScript çalışma kopyası eşitlendi; Stage158 arayüz testi eklendi.
