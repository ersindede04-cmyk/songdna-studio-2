# Stage91 QA — Backup Integrity

## Kapsam
- Sürüm 2 checksum üretimi ve doğrulaması
- Stage90 sürüm 1 yedeklerinin geriye dönük içe aktarımı
- İçerik değişikliği/truncated veri reddi
- Tarih, tekil kayıt ve toplam veri boyutu kontrolleri
- Hassas kimlik bilgileri allowlist dışında kalır

## Sınırlar
- Checksum kriptografik imza değildir; kötü niyetli değişikliğe karşı güvenlik sağlamaz.
- Gerçek Android dosya seçici/indirme, APK, Gemini ve Render testleri yapılmadı.

## Test sonucu
- `node --check app.js`: PASS
- `tests/test-stage90-data-backup.js`: PASS
- `tests/test-stage91-backup-integrity.js`: PASS
- Tüm `tests/*.js` ve kök `test-*.js` testleri: PASS
- Tüm `scripts/test-*.py` testleri: PASS
- Dört `data-backup.js`, dört `app.js` ve dört `index.html` kopyası SHA-256 ile birebir aynı.
- Paketleme sonrası ZIP bütünlük kontrolü: PASS
