# QA — Stage 121

## Kapsam
Üç prodüksiyon katmanının Styles ve Lyrics üzerindeki etkileri çıktı amacına göre sınırlandırıldı.

## Beklenen davranış
- Styles: seçili ana, ikincil ve yardımcı katmanları duyulabilir ses rolleri olarak alır.
- Lyrics: ana kimliği korur; ikincil/yardımcı katmanı yalnızca açık vokal veya performans rehberi mevcutsa kullanır.
- Enstrümantal ikincil/yardımcı katmanlar sözlerin dilini, anlatısını veya vokal davranışını değiştirmez.
- Ana katman yoksa ikincil/yardımcı katmanlar kendiliğinden ana kimliğe yükseltilmez.
- Manuel seçimler ve boş katmanlar korunur.

## Test
`tests/test-stage121-layer-output-scope.js` doğrular:
1. Üç katmanın Styles planına dahil edilmesi.
2. Vokal rehberi olmayan ikincil katmanın Lyrics planından çıkarılması.
3. Açık vokal rehberi bulunan yardımcı katmanın Lyrics planına dahil edilmesi.
4. Ana katman yokken otomatik ana kimlik oluşturulmaması.
5. Web ve Android kopyalarının eşitlenmesi.

Canlı Gemini/Render, APK derlemesi/kurulumu ve Suno ses çıktısı bu QA kapsamına dahil değildir.

## Sonuç
- JavaScript testleri: **93/93 başarılı**
- Python testleri: **6/6 başarılı**
- Toplam: **99/99 başarılı**, sıfır hata.
- Dört uygulama kopyası ve dört BUILD_MANIFEST.json dosyası eşitlendi.
- JavaScript sözdizimi kontrolü başarılı.
