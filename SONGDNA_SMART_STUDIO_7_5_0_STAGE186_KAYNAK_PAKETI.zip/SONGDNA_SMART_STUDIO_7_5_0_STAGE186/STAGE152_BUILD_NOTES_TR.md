# SONGDNA SMART STUDIO 6.1.0 — Stage152

## Amaç
Stage151 kaynak paketini değiştirmeden koruyarak, Stage152 adıyla benzersiz bir kaynak arşivi ve yalnızca bu arşivi hedefleyen Android derleme akışı oluşturmak.

## Kaynak temeli
- Kaynak: Stage151 tabanlı 6.1.0 tam proje
- Android proje yolu: `android-wrapper/`
- Android Gradle Plugin: `8.7.3`
- Kotlin Android plugin: `2.0.21`
- Java hedefi: `17`
- Compile / target SDK: `35`
- Gradle: `8.9` (CI ortamında doğrudan çağrılır; ZIP içinde Gradle Wrapper aranmaz)

## Doğrulama
Stage152 paketi hazırlanırken aşağıdaki kontroller çalıştırıldı:
- `python scripts/verify-source.py`
- `node --check app.js`
- `node --check www/app.js`
- `node --check backend/server.js`
- `npm --prefix backend run check`
- 120 JavaScript regresyon test dosyası
- 5 Python regresyon test dosyası

Sonuç: 125 regresyon test dosyasının tamamı başarılı.

## Stage152 derleme davranışı
- Workflow yalnızca `SONGDNA_SMART_STUDIO_6_1_0_STAGE152_SOURCE.zip` adlı dosyayı arar.
- Stage151 adlı arşivleri aramaz; aynı depoda eski Stage151 ZIP'i bırakılabilir.
- Android projesi `android-wrapper/settings.gradle.kts` üzerinden bulunur.
- Gradle Wrapper dosyası zorunlu değildir.
- APK ve SHA256 özeti ayrı bir GitHub Actions Artifact olarak yayımlanır.

## Koruma sınırı
Bu aşamada Music DNA profilleri, üretim mantığı, Gemini akışı, Styles/Lyrics çıktıları ve uygulama arayüzü değiştirilmemiştir. Yalnızca derleme iş akışı Stage152 için ayrıştırılmıştır.

## Manifest aşama politikası
- Dört `BUILD_MANIFEST.json` kopyası Stage151 olarak kalır; bu bilinçlidir.
- Stage152, Stage151 uygulama kaynaklarını değiştirmeden koruyan paketleme ve Android derleme aşamasıdır.
- Bu nedenle `scripts/verify-source.py` içindeki Stage151 manifest doğrulaması değiştirilmez.
- Stage152 kimliği kaynak manifestine zorla yazılmaz; arşiv adı, build notları ve APK artifact adıyla taşınır.

## Sürüm doğrulama durumu
Kaynak ve regresyon testleri yerel ortamda doğrulandı. Gerçek Android APK derlemesi GitHub Actions üzerinde çalıştırılınca doğrulanacaktır. Bu nedenle APK henüz başarılı üretilmiş kabul edilmez.
