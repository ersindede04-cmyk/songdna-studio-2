# Stage172 QA kapsamı

- Yeni regresyon: `tests/test-stage172-gemini-404-fallback.js`
- Beklenen: HTTP 404 sonraki izinli Flash modelini dener.
- Beklenen: HTTP 400, 401 ve 403 model fallback tetiklemez.
- Koruma: 75 Music DNA, mevcut Intro DNA, Styles/Lyrics, uyumluluk denetimi ve modern/geleneksel seçim kuralları.
- Canlı Gemini, Render servisi, fiziksel Android cihaz ve APK henüz bu yerel kaynak paketi içinde doğrulanmış değildir. GitHub Actions debug APK üretimi kullanıcı tarafından çalıştırılacaktır.
