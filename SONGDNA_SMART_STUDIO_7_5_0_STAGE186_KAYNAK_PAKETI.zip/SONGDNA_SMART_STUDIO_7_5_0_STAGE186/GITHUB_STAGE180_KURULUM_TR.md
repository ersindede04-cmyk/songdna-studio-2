# SONGDNA SMART STUDIO 7.1.0 — Stage180 GitHub ve Render Güncellemesi

## 1. Kaynak paketi
- `SONGDNA_SMART_STUDIO_7_1_0_STAGE180_KAYNAK.zip` dosyasını GitHub deposunun ana dizinine yükle.
- `.github/workflows/songdna-stage180.yml` dosyasını depo içinde aynı konumda (`.github/workflows/songdna-stage180.yml`) bulundur.
- Workflow ZIP içindeki Stage180 kaynağını açar, kaynak doğrulamasını ve regresyonları çalıştırır, ardından Android Debug APK üretir.

## 2. Render backend güncellemesi — Hikâyeyi Harmanla
Render servisi `rootDir: backend` kullandığı için GitHub deposunun kökündeki `backend/` klasörünün de Stage180 kaynağıyla güncellenmesi gerekir. Özellikle şu dosyaları Stage180 paketinden depodaki aynı konumlarına aktar:
- `backend/server.js`
- `backend/package.json`

`render.yaml` içindeki mevcut servis ayarlarını koru. Render'da `APP_ACCESS_TOKEN` ve `GEMINI_API_KEY` ortam değişkenlerini silme veya yeniden oluşturma. API anahtarlarını ZIP'e ya da GitHub'a ekleme.

Değişiklikleri bağlı GitHub dalına gönderdiğinde Render otomatik dağıtım açıksa yeniden dağıtım başlar. Değilse Render Dashboard → `songdna-ai-api` → Manual Deploy → Deploy latest commit yolunu kullan.

## 3. Dağıtım sonrası kontrol
- Render servisinin `/health` yanıtında `SONGDNA Studio 7.1.0 AI` görünmeli.
- Uygulamanın kayıtlı sunucu adresi aynı kalabilir; adresin sonuna ayrıca `/api` ekleme.
- Uygulamadaki mevcut uygulama erişim kodu, Render'daki `APP_ACCESS_TOKEN` ile aynı kalmalı.
- Ardından Hikâyeyi Harmanla butonunu dene. Başarılı yanıtın `story` alanı konu kutusunu doldurur.

## 4. Android APK
GitHub → Actions → Stage180 çalıştırması → Artifacts bölümünden `SONGDNA-SMART-STUDIO-7.1.0-STAGE180-ANDROID-DEBUG` paketini al. Bu kaynak paketi yerel olarak APK içermez; APK GitHub Actions tarafından oluşturulur.

## Önemli doğrulama sınırı
Yerel testler Render dağıtımının, canlı Gemini isteğinin veya fiziksel Android cihazın başarıyla çalıştığını kanıtlamaz. Bunlar dağıtım sonrasında ayrıca kontrol edilmelidir.
