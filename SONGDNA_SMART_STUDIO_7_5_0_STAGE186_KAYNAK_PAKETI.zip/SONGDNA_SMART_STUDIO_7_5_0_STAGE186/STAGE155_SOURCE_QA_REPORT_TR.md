# SONGDNA SMART STUDIO 6.1.0 — Stage155 Kaynak Paketi QA Raporu

## Amaç
Stage152–Stage154 denemelerinde ortaya çıkan kaynak paketi, regresyon testleri ve GitHub Actions bağımlılıkları arasındaki uyumsuzlukları kaynak paketi seviyesinde gidermek. Bu aşama uygulamanın müzik üretim davranışını değiştirmez; kaynak bütünlüğünü, testlerin çalıştırılabilirliğini ve Android derleme önkoşullarını düzenler.

## Tespit edilen ve giderilen sorunlar

1. Dört Python tarayıcı testi `playwright.sync_api` kullanıyordu; ancak kaynak paketi bu bağımlılığı tanımlamıyordu. `requirements-test.txt` içinde Playwright 1.55.0 sabitlendi.
2. Testler Playwright'ın kendi Chromium ikilisini varsayıyordu. Paylaşılan `scripts/browser_test_utils.py`, CI ortamında Playwright tarafından kurulan Chromium'u; kontrollü yerel ortamlarda ise `SONGDNA_CHROMIUM_EXECUTABLE` veya PATH üzerindeki Chromium'u kullanabiliyor.
3. Stage70 JavaScript testi, kaynak ZIP'in içinde bulunmayan GitHub Actions YAML dosyasını okuyordu ve Stage153 dosya adına bağlıydı. Test yeniden düzenlendi: kaynak paketi kendi başına doğrulanıyor; YAML doğrulaması ayrı bir iş akışı kontrolü olarak ele alınacak.
4. Stage153/Stage154'e ait eski ve artık kullanılmayan derleme YAML/dokümanları Stage155 kaynak paketinden çıkarıldı.
5. Dört uygulama `BUILD_MANIFEST.json` kopyası birbirleriyle aynı bırakıldı. Bunlar uygulama kaynak kimliği olan Stage151'i koruyor; Stage155 ayrı paketleme/derleme revizyonudur.

## Doğrulama

- Kaynak ve Android WebView eşleşmesi: `scripts/verify-source.py` ile doğrulanır.
- JavaScript regresyonları: 120 test dosyası.
- Python regresyonları: 5 test dosyası; 4 Playwright tabanlı tarayıcı testi ve 1 kaynak/arayüz testi.
- Android proje: `android-wrapper/settings.gradle.kts` üzerinden `:app` modülü; AGP 8.7.3, Kotlin 2.0.21, Java 17, compile/target SDK 35, min SDK 23, versionCode 32, versionName 6.1.0.
- Python tarayıcı testleri yerel ortamda sistem Chromium kullanılarak yürütülebilir; GitHub Actions için Playwright Chromium kurulumu gereklidir.

## Sınırlar

Bu rapor kaynak testlerinin ve statik yapılandırmanın doğrulanmasını kaydeder. GitHub Actions üzerinde gerçek Android APK üretimi, imzalı release APK ve fiziksel Android cihaz testi bu kaynak paketi QA'sının dışında kalır ve ayrı CI/Yayın doğrulaması gerektirir.
