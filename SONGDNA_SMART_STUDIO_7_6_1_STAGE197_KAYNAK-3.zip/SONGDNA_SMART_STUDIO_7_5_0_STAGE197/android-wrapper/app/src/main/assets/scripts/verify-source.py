#!/usr/bin/env python3
"""Strict Stage 60.1 source and Android asset integrity checks."""
from pathlib import Path
import json, re, shutil, subprocess, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
WEB=ROOT/"www"
ANDROID=ROOT/"android-wrapper/app/src/main/assets/www"
ANDROID_ROOT=ROOT/"android-wrapper/app/src/main/assets"
RUNTIME=["index.html","app.js","saved-library.js","production-history.js","adlib-catalog.js","scene-jargon-catalog.js","global-cultural-adlib.js","genre-adlib-engine.js","production-preset-engine.js","emotion-engine.js","production-adaptation-engine.js","energy-engine.js","adlib-intelligence-engine.js","lyrics-coherence-engine.js","atmosphere-engine.js","section-arrangement-engine.js","vocal-identity-engine.js","music-compatibility-engine.js","integrated-production-engine.js","manual-override-engine.js","profile-snapshot-engine.js","production-model-library.js","dynamic-creativity-engine.js","story-diversity-engine.js", "global-vocal-expression-engine.js","production-history-storage.js","three-layer-production-orchestrator.js","production-element-library-data.js","production-element-library.js"]
REQUIRED=["BUILD_MANIFEST.json","index.html","app.js","backend/server.js","backend/package.json","android-wrapper/app/build.gradle.kts","android-wrapper/app/src/main/AndroidManifest.xml","android-wrapper/app/src/main/java/com/songdna/studio/MainActivity.kt","scripts/test-stage29-client-api-contract.js","tests/test-stage29-api-contract.js","CHANGELOG_5_2_0_STAGE60_1_PRODUCTION_PROMPT_HOTFIX_TR.md","QA_REPORT_5_2_0_STAGE60_1_SOURCE_SYNC.md"]
for folder in [WEB,ANDROID]:
    REQUIRED += [str(Path(folder.relative_to(ROOT))/n) for n in RUNTIME]
missing=[x for x in REQUIRED if not (ROOT/x).is_file()]
if missing: raise SystemExit("FAIL missing files: "+", ".join(missing))
for name in RUNTIME:
    a=(WEB/name).read_bytes(); b=(ANDROID/name).read_bytes()
    if a!=b: raise SystemExit(f"FAIL WebView asset mismatch: {name}")
    if name.endswith(".js") and (ROOT/name).exists() and (ROOT/name).read_bytes()!=a:
        raise SystemExit(f"FAIL root runtime mismatch: {name}")
    if name.endswith(".js") and (ANDROID_ROOT/name).exists() and (ANDROID_ROOT/name).read_bytes()!=a:
        raise SystemExit(f"FAIL Android root asset mismatch: {name}")
if (ROOT/"index.html").read_bytes()!=(WEB/"index.html").read_bytes(): raise SystemExit("FAIL root index.html mismatch")
if (ANDROID_ROOT/"index.html").read_bytes()!=(WEB/"index.html").read_bytes(): raise SystemExit("FAIL Android root index.html mismatch")
print("PASS: root, web and Android WebView runtime assets are synchronized")
manifest_paths=[ROOT/"BUILD_MANIFEST.json",WEB/"BUILD_MANIFEST.json",ANDROID_ROOT/"BUILD_MANIFEST.json",ANDROID/"BUILD_MANIFEST.json"]
manifests=[json.loads(p.read_text(encoding="utf-8")) for p in manifest_paths]
if any(m!=manifests[0] for m in manifests[1:]): raise SystemExit("FAIL BUILD_MANIFEST.json copies differ")
m=manifests[0]
if m.get("version")!="7.6.1" or m.get("stage")!=197: raise SystemExit("FAIL expected SONGDNA 7.6.1 Stage 197 manifest")
if not any(str(x).startswith("Stage 60.1:") for x in m.get("completed_stages",[])): raise SystemExit("FAIL Stage 60.1 completion marker missing")
print("PASS: all four manifests match and identify SONGDNA 7.6.1 Stage 197")
# Music DNA provenance must remain complete and identical across the canonical,
# embedded web-app and Android WebView catalog copies.
catalog_path=ROOT/"data/music_dna_global_v1_1.json"
catalog=json.loads(catalog_path.read_text(encoding="utf-8"))
embedded_match=re.search(r"(?m)^const GLOBAL_MUSIC_DNA=(\{.*\});$",(ROOT/"app.js").read_text(encoding="utf-8"))
if not embedded_match: raise SystemExit("FAIL embedded Music DNA catalog declaration missing")
if json.loads(embedded_match.group(1))!=catalog: raise SystemExit("FAIL embedded Music DNA catalog differs from canonical JSON")
for copy_path in [WEB/"data/music_dna_global_v1_1.json",ANDROID/"data/music_dna_global_v1_1.json"]:
    if not copy_path.is_file() or json.loads(copy_path.read_text(encoding="utf-8"))!=catalog:
        raise SystemExit("FAIL Music DNA catalog runtime copy mismatch: "+str(copy_path))
source_ids={item.get("id") for item in catalog.get("sources",[])}
missing_refs=[(profile.get("id"),ref) for profile in catalog.get("music_dna_profiles",[]) for ref in profile.get("source_refs",[]) if ref not in source_ids]
missing_refs += [(module.get("id"),ref) for module in catalog.get("instrument_technique_modules",[]) for ref in module.get("source_refs",[]) if ref not in source_ids]
missing_refs += [(record.get("id"),ref) for record in catalog.get("legacy_expansion_records",[]) for ref in record.get("source_refs",[]) if ref not in source_ids]
if missing_refs: raise SystemExit("FAIL unresolved Music DNA / instrument-technique provenance references: "+repr(missing_refs))
techniques={item.get("id"):item for item in catalog.get("instrument_technique_modules",[])}
if not techniques.get("TECH-TR-001",{}).get("source_refs") or not techniques.get("TECH-TR-002",{}).get("source_refs"):
    raise SystemExit("FAIL Turkish bağlama tezene/şelpe technique provenance missing")
print(f"PASS: {len(catalog.get('music_dna_profiles',[]))} Music DNA profiles, profile, instrument-technique and legacy provenance refs plus canonical/web/Android catalog copies")
# Android Gradle identity must agree with the canonical application manifest.
gradle=(ROOT/"android-wrapper/app/build.gradle.kts").read_text(encoding="utf-8")
settings=(ROOT/"android-wrapper/settings.gradle.kts").read_text(encoding="utf-8")
if 'applicationId = "com.songdna.studio"' not in gradle or 'versionName = "7.6.1"' not in gradle or "versionCode = 46" not in gradle:
    raise SystemExit("FAIL Android Gradle application identity/version mismatch")
if 'include(":app")' not in settings: raise SystemExit("FAIL Android Gradle settings does not include :app")
if not (ROOT/"requirements-test.txt").is_file() or not (ROOT/"scripts/ci-preflight.py").is_file():
    raise SystemExit("FAIL Stage161 Python CI preflight files missing")
print("PASS: Android Gradle identity and Stage161 Python CI preflight files")
js=(WEB/"app.js").read_text(encoding="utf-8")
for token in ["SONGDNA_GEMINI_INSTRUCTIONS_2","profileSnapshot:c.profileSnapshot?{version:c.profileSnapshot.version,id:c.profileSnapshot.id}:null","Üretim istemi "]:
    if token not in js: raise SystemExit("FAIL Stage 60.1 prompt hotfix marker missing: "+token)
if "prompt=buildGeminiInstructionEnvelope('lyrics',currentContext,makeLyricsPrompt(currentContext))" not in js: raise SystemExit("FAIL lyrics production envelope route missing")
print("PASS: Stage 60.1 compact profile metadata and prompt preflight markers present")
html=(WEB/"index.html").read_text(encoding="utf-8")
for src in re.findall(r'<script[^>]+src="([^"]+)"',html):
    if not (WEB/src).is_file(): raise SystemExit("FAIL missing HTML script dependency: "+src)
for p in (ROOT/"android-wrapper/app/src/main").rglob("*.xml"): ET.parse(p)
print("PASS: HTML dependencies and Android XML")
node=shutil.which("node")
if not node: raise SystemExit("FAIL Node.js is required")
for p in [WEB/n for n in RUNTIME if n.endswith(".js")]+[ROOT/"backend/server.js"]:
    r=subprocess.run([node,"--check",str(p)],capture_output=True,text=True)
    if r.returncode: raise SystemExit(f"FAIL JS syntax {p}: {r.stderr}")
print("PASS: JavaScript syntax")
backend=(ROOT/"backend/server.js").read_text(encoding="utf-8")
for endpoint in ["/api/lyrics","/api/style","/api/command","/api/lyrics-audit"]:
    if endpoint not in js or endpoint not in backend: raise SystemExit("FAIL API endpoint contract: "+endpoint)
if "APP_ACCESS_TOKEN" not in backend: raise SystemExit("FAIL backend auth contract")
if "Styles" not in html or "Lyrics" not in html: raise SystemExit("FAIL Styles/Lyrics output fields missing")
print("ALL STAGE197 SOURCE CHECKS PASSED. Live Gemini, Render, external APK build and physical Android tests remain pending.")

# Ensure browser-test dependencies use distribution metadata, not removed module attributes.
preflight=(ROOT/"scripts/ci-preflight.py").read_text(encoding="utf-8")
if "importlib.metadata" not in preflight or "playwright.__version__" in preflight:
    raise SystemExit("FAIL Playwright version check must use importlib.metadata")
if len(list((ROOT/"scripts").glob("test-*.py"))) != 7:
    raise SystemExit("FAIL expected exactly seven Python regression test files")
print("PASS: Playwright metadata check and seven Python regression test files")

# Stage184 current source package manifest.
package196=json.loads((ROOT/"BUILD_PACKAGE_MANIFEST_STAGE197.json").read_text(encoding="utf-8"))
if package196.get("package_stage")!=197 or package196.get("application_version")!="7.6.1":
    raise SystemExit("FAIL Stage197 package manifest identity")
if package196.get("android_version_code")!=46:
    raise SystemExit("FAIL Stage197 Android package identity")
print("PASS: Stage197 package manifest")

# Stage182 is retained as a historical package record.
package182=json.loads((ROOT/"BUILD_PACKAGE_MANIFEST_STAGE182.json").read_text(encoding="utf-8"))
if package182.get("package_stage")!=182 or package182.get("application_version")!="7.1.0":
    raise SystemExit("FAIL historical Stage182 package manifest")
print("PASS: historical Stage182 package manifest retained")

# Stage161 multilingual songwriting regression and package manifest.
package=json.loads((ROOT/"BUILD_PACKAGE_MANIFEST_STAGE180.json").read_text(encoding="utf-8"))
if package.get("package_stage")!=180 or package.get("application_version")!="7.1.0":
    raise SystemExit("FAIL Stage180 package manifest identity")
if package.get("javascript_test_files")!=139 or package.get("python_test_files")!=7:
    raise SystemExit("FAIL Stage180 package regression test counts")
if not (ROOT/"scripts/test-stage163-universal-content-standard.js").is_file() or not (ROOT/"MUSIC_CONTENT_QUALITY_STANDARD_STAGE163_TR.md").is_file() or not (ROOT/"tests/test-stage165-pop-regional-production.js").is_file():
    raise SystemExit("FAIL Stage163 standard or Stage165 focused regression missing")
if not (ROOT/"tests/test-stage157-user-creative-input-fidelity.js").is_file() or not (ROOT/"tests/test-stage160-multilingual-songwriting-standard.js").is_file() or not (ROOT/"tests/test-stage161-28-language-profiles.js").is_file():
    raise SystemExit("FAIL Stage161 multilingual songwriting regression test missing")
if not (ROOT/"CHANGELOG_6_1_0_STAGE166_INTERFACE_COMPLETION_TR.md").is_file() or not (ROOT/"QA_REPORT_6_1_0_STAGE166_INTERFACE_COMPLETION.md").is_file() or not (ROOT/"tests/test-stage166-interface-completion.js").is_file():
    raise SystemExit("FAIL Stage166 interface completion evidence missing")
print("PASS: Stage180 package manifest, UI regression and catalog standard")

if not (ROOT/"tests/test-stage172-gemini-404-fallback.js").is_file(): raise SystemExit("FAIL Stage172 Gemini 404 fallback regression missing")
print("PASS: inherited Stage172 Gemini 404 fallback regression present")

if not (ROOT/"tests/test-stage175-technique-domain-filter.js").is_file(): raise SystemExit("FAIL inherited Stage175 technique-domain filter regression missing")
print("PASS: inherited Stage175 technique-domain filter regression present")
if not (ROOT/"tests/test-stage177-reference-api-contract.js").is_file() or not (ROOT/"reference/SONGDNA_6_2_0_POSTGEMINI_REFERENCE.js").is_file(): raise SystemExit("FAIL Stage177 reference API contract regression or fixture missing")
print("PASS: Stage177 6.2.0 reference API contract fixture and regression present")


for rel in ["tests/test-stage178-story-diversity.js","tests/test-stage179-traditional-world-identity-preflight.js","tests/test-stage179-global-vocal-expression-engine.js","tests/test-stage179-story-lyrics-alignment.js"]:
    if not (ROOT/rel).is_file(): raise SystemExit("FAIL Stage180 regression missing: "+rel)
if not (ROOT/"CHANGELOG_7_1_0_STAGE180_TR.md").is_file() or not (ROOT/"QA_REPORT_7_1_0_STAGE180.md").is_file(): raise SystemExit("FAIL Stage180 changelog or QA report missing")
print("PASS: Stage178/179 story diversity, traditional identity and global vocal-expression regressions present")

# Stage197 ZIP-based Render deployment contract.
for rel in ["tests/test-stage195-narrative-engine.js", "tests/test-stage197-zip-deployment.js", "CHANGELOG_7_5_0_STAGE197_TR.md", "QA_REPORT_7_5_0_STAGE197.md"]:
    if not (ROOT/rel).is_file(): raise SystemExit("FAIL Stage197 required source artifact missing: "+rel)
backend_source=(ROOT/"backend/server.js").read_text(encoding="utf-8")
if "GEMINI_API_KEY_2" in backend_source or "story-blend" in backend_source or "storyBlend" in backend_source:
    raise SystemExit("FAIL removed second-key/story-blend backend dependency remains")
if "GEMINI_API_KEY" not in backend_source:
    raise SystemExit("FAIL single Gemini API key contract missing")
if (ROOT/"server.js").read_bytes()!=(ROOT/"backend/server.js").read_bytes():
    raise SystemExit("FAIL root/backend server source copies differ")
if "stage: 197" not in backend_source or "Stage197 AI" not in backend_source:
    raise SystemExit("FAIL Stage197 health identity missing")
if "22.x" != json.loads((ROOT/"backend/package.json").read_text(encoding="utf-8")).get("engines",{}).get("node"):
    raise SystemExit("FAIL Stage197 backend runtime must be Node 22.x")
print("PASS: Stage197 single-key backend, health identity and synchronized server copies")


render_guide=(ROOT/"backend/DEPLOY_TR.md").read_text(encoding="utf-8")
if "SONGDNA_SMART_STUDIO_7_5_0_STAGE197_KAYNAK.zip" not in render_guide or "NODE_VERSION" not in render_guide or "Root Directory: **boş bırakın**" not in render_guide:
    raise SystemExit("FAIL Stage197 ZIP-based Render deployment guide")
print("PASS: Stage197 ZIP-only Render deployment guide")

# Stage197 Render startup contract.
backend_pkg=json.loads((ROOT/"backend/package.json").read_text(encoding="utf-8"))
if backend_pkg.get("engines",{}).get("node")!="22.x": raise SystemExit("FAIL backend must pin Node.js 22.x")
if "let systemText = task === 'lyrics-audit'" not in backend_source or "STAGE160 MULTILINGUAL SONGWRITING STANDARD" not in backend_source:
    raise SystemExit("FAIL multilingual songwriter instruction block missing")
if "GEMINI_API_KEY_2" in backend_source or "story-blend" in backend_source or "storyBlend" in backend_source:
    raise SystemExit("FAIL Stage197 legacy second-key/story-blend dependency detected")
workflow=(ROOT/".github/workflows/build.yml").read_text(encoding="utf-8")
if "android-actions/setup-android@v4" not in workflow or "--refresh-dependencies" in workflow or "WAIT_TIME=$((ATTEMPT * 45))" not in workflow or "test-stage70-deployment-config.js" not in workflow:
    raise SystemExit("FAIL Stage197 Android workflow contract")
print("PASS: Stage197 Node 22, songwriter prompt and Android workflow contract")

# Stage179 verifier copies must stay byte-identical across distribution roots.
for verifier_copy in [ROOT/"www/scripts/verify-source.py", ROOT/"android-wrapper/app/src/main/assets/scripts/verify-source.py"]:
    if not verifier_copy.is_file() or verifier_copy.read_bytes()!=(ROOT/"scripts/verify-source.py").read_bytes():
        raise SystemExit("FAIL Stage180 verifier copy mismatch: "+str(verifier_copy))
print("PASS: canonical, web and Android source verifier copies synchronized")
