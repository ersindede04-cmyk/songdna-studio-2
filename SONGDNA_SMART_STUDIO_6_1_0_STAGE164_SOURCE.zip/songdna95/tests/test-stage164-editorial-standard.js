'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const server = fs.readFileSync('backend/server.js', 'utf8');
const manifest = JSON.parse(fs.readFileSync('BUILD_PACKAGE_MANIFEST_STAGE164.json', 'utf8'));
const standard = fs.readFileSync('SONGDNA_STAGE164_SONGWRITING_EDITORIAL_STANDARD_TR.md', 'utf8');
for (const marker of [
  'STAGE164 SONGWRITING EDITORIAL STANDARD',
  'USER AUTHORITY', 'STORY AND MEANING FIDELITY',
  'MINIMAL EDITORIAL INTERVENTION', 'CULTURAL UNCERTAINTY',
  'TRADITIONAL MUSIC SAFEGUARD', 'TASK MODE',
  'EIGHT-PASS SILENT REVIEW ORDER', 'SUBJECTIVE QUALITY LIMIT'
]) assert.ok(server.includes(marker), `Missing backend rule: ${marker}`);
assert.match(standard, /Sekiz aşamalı sessiz denetim/);
assert.equal(manifest.stage, 164);
assert.equal(manifest.base_stage, 163);
assert.ok(manifest.limitations.some(x => x.includes('not yet wired')));
assert.equal(fs.readFileSync('server.js', 'utf8'), server);
console.log('PASS: Stage164 editorial policy, manifest, limitations and backend deployment copy');
