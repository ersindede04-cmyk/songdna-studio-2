'use strict';
const assert=require('assert');
const fs=require('fs');
const engine=require('../three-layer-production-orchestrator.js');
const app=fs.readFileSync('app.js','utf8');
const match=app.match(/const GLOBAL_MUSIC_DNA=(\{[\s\S]*?\});\nconst TECHNIQUE_MODULES=/);
assert(match,'Global Music DNA catalogue source not found');
const catalog=JSON.parse(match[1]);
const profiles=catalog.music_dna_profiles;
assert.strictEqual(profiles.length,68,'Expected all 67 Music DNA profiles');
assert.strictEqual(new Set(profiles.map(p=>p.id)).size,68,'Profile IDs must be unique');
let profileChecks=0, layerChecks=0;
for(const p of profiles){
  assert(p.id&&p.name&&p.primary_genre,'Every profile needs an explicit identity');
  assert(Array.isArray(p.musical_traits)&&p.musical_traits.length,'Every profile needs catalogued musical traits');
  const traits=p.musical_traits.slice(0,3);
  const built=engine.build({
    identity:{profileId:p.id,name:p.name,primaryGenre:p.primary_genre,domain:p.music_domain||'unclassified',region:p.region_or_scene||null,definingTraits:traits,profileGuidance:p.prompt_guidance||'',performanceGuidance:p.performance_guidance||'',productionGuidance:p.production_guidance||'',vocalGuidance:p.vocal_guidance||'',arrangementGuidance:p.arrangement_guidance||''},
    main:{id:p.id,name:p.name,family:p.primary_genre,promptText:p.prompt_guidance||'',musicalTraits:traits,genreTags:p.tags||[],arrangementGuidance:p.arrangement_guidance||''},
    secondary:{id:'QA-SECONDARY',name:'QA instrumental support',promptText:'Complementary instrumental texture only',elements:['support texture']},
    helper:{id:'QA-HELPER',name:'QA mix support',promptText:'Subtle mix support only',elements:['mix support']}
  });
  assert.strictEqual(built.musicIdentityProfile.profileId,p.id,`${p.id}: primary identity changed`);
  assert.strictEqual(built.musicIdentityProfile.name,p.name,`${p.id}: primary name changed`);
  assert.deepStrictEqual(built.selectedRoles,['main','secondary','helper']);
  assert.deepStrictEqual(built.outputPlans.styles.includedRoles,['main','secondary','helper']);
  assert.deepStrictEqual(built.outputPlans.lyrics.includedRoles,['main']);
  assert.deepStrictEqual(built.outputPlans.lyrics.excludedRoles,['secondary','helper']);
  assert(built.sharedPrompt.includes(p.name),`${p.id}: shared prompt lost profile name`);
  for(const trait of traits)assert(built.sharedPrompt.includes(trait),`${p.id}: shared prompt lost trait ${trait}`);
  assert.strictEqual(built.sharedContext.manualSelectionWins,true);
  assert.strictEqual(built.sharedContext.autoFilled,false);
  profileChecks++;
  layerChecks+=3;
}
// A secondary layer with explicit vocal guidance may affect delivery, but not replace identity.
const vocal=engine.build({identity:{profileId:'MDNA-001',name:'Primary'},main:{id:'MDNA-001',name:'Primary'},secondary:{id:'VOCAL-TEST',name:'Vocal response',promptText:'Call and response backing vocals'},helper:{}});
assert.deepStrictEqual(vocal.outputPlans.lyrics.includedRoles,['main','secondary']);
assert.strictEqual(vocal.musicIdentityProfile.profileId,'MDNA-001');
// Missing optional guidance stays missing; the engine must not fabricate it.
const sparse=engine.build({identity:{profileId:'QA-SPARSE',name:'Sparse profile'},main:{id:'QA-SPARSE',name:'Sparse profile'},secondary:{},helper:{}});
assert.strictEqual(sparse.musicIdentityProfile.region,null);
assert.strictEqual(sparse.musicIdentityProfile.profileGuidance,'');
assert.deepStrictEqual(sparse.selectedRoles,['main']);
console.log(`Stage 133: ${profileChecks}/68 profiles; ${layerChecks} layer routes; 10 additional assertions passed.`);
