'use strict';
const fs=require('fs');
const path=require('path');
const assert=require('assert');
const root=path.resolve(__dirname,'..');
const source=fs.readFileSync(path.join(root,'app.js'),'utf8');
const match=source.match(/const GLOBAL_MUSIC_DNA=(\{.*?\});/);
assert(match,'GLOBAL_MUSIC_DNA catalog must exist');
const catalog=JSON.parse(match[1]);
assert.strictEqual(catalog.music_dna_profiles.length,68,'all 67 profiles must remain');
const ids=new Set();
for(const p of catalog.music_dna_profiles){
 assert(!ids.has(p.id),`duplicate profile ${p.id}`); ids.add(p.id);
 assert(p.primary_genre&&p.region_or_scene,`${p.id} must retain genre and scene identity`);
 assert(Array.isArray(p.musical_traits)&&p.musical_traits.length,`${p.id} needs defining traits`);
 assert(p.arrangement_guidance,`${p.id} needs arrangement guidance`);
 const instrumentText=Array.isArray(p.instrument_guidance)?p.instrument_guidance.join(' '):p.instrument_guidance;
 const lyricText=Array.isArray(p.lyrics_guidance)?p.lyrics_guidance.join(' '):p.lyrics_guidance;
 assert(instrumentText&&instrumentText.length>20,`${p.id} needs instrument guidance`);
 assert(lyricText&&lyricText.length>20,`${p.id} needs lyric guidance`);
 assert(Array.isArray(p.source_refs)&&p.source_refs.length,`${p.id} must retain provenance`);
 if(typeof p.instrument_guidance==='string'&&p.instrument_guidance.startsWith('Build the instrument palette')) assert(/do not invent culturally specific instruments/i.test(p.instrument_guidance),`${p.id} must prohibit invented instrument details`);
 if(typeof p.lyrics_guidance==='string'&&p.lyrics_guidance.startsWith("Keep the user's selected lyric language")){ assert(/do not infer a language, dialect, identity or fixed lyrical theme/i.test(p.lyrics_guidance),`${p.id} must not infer language/theme from genre`); assert(/Avoid stereotypes/i.test(p.lyrics_guidance),`${p.id} must avoid stereotypes and fabricated cultural text`); }
}
for(const rel of ['www/app.js','android-wrapper/app/src/main/assets/app.js','android-wrapper/app/src/main/assets/www/app.js'])
 assert.strictEqual(fs.readFileSync(path.join(root,rel),'utf8'),source,`${rel} must match root app.js`);
console.log('Stage 111 catalog guidance coverage: PASS (68/68 profiles; provenance, identity, instrument and lyric safeguards; runtime copies synchronized)');
