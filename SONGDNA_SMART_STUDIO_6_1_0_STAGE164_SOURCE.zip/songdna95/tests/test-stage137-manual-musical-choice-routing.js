'use strict';
const assert=require('assert');
const fs=require('fs');
const app=fs.readFileSync('app.js','utf8');
const start=app.indexOf('function auditManualMusicalChoiceRouting');
const end=app.indexOf('\n(function initStage137ManualMusicalChoiceRouting',start);
assert(start>=0&&end>start,'Stage 137 manual choice audit must exist');
const audit=new Function(app.slice(start,end)+'; return auditManualMusicalChoiceRouting;')();
const match=app.match(/const GLOBAL_MUSIC_DNA=(\{[\s\S]*?\});\nconst TECHNIQUE_MODULES=/);
assert(match,'Music DNA catalog must be present');
const profiles=JSON.parse(match[1]).music_dna_profiles;
assert.strictEqual(profiles.length,68);
for(const p of profiles){
 const result=audit({
  rhythm:['syncopated pulse'],groove:['half-time groove'],instrument:['electric guitar'],
  production:['saturated production'],mix:['wide stereo image'],
  vocal_delivery:['restrained melodic phrasing'],vocal_arrangement:['call and response']
 },{
  styles:'syncopated pulse, half-time groove, electric guitar, saturated production, wide stereo image, restrained melodic phrasing, call and response',
  lyrics:'restrained melodic phrasing, call and response'
 });
 assert.strictEqual(result.level,'ok',p.id+': manual musical choices should reach correct outputs');
 assert.strictEqual(result.manualChoiceCount,7);
 assert.strictEqual(result.manualSelectionsChanged,false);
}
let result=audit({rhythm:['broken beat'],instrument:['oud'],vocal_delivery:['ornamented melisma']},{styles:'broken beat',lyrics:'ornamented melisma'});
assert(result.issues.some(x=>x.value==='oud'&&x.expectedOutput==='styles'));
assert.strictEqual(result.lyricOnlyInstrumentalLeak.length,0);
result=audit({instrument:['oud']},{styles:'',lyrics:'oud'});
assert(result.issues.some(x=>x.code==='MANUAL_CHOICE_NOT_ROUTED'));
assert.deepStrictEqual(result.lyricOnlyInstrumentalLeak,['oud']);
result=audit({vocal_arrangement:['group response']},{styles:'',lyrics:'group response'});
assert.strictEqual(result.level,'ok');
result=audit({production:['tape saturation']},{styles:'tape saturation',lyrics:'A song about home'});
assert.strictEqual(result.level,'ok');
result=audit({}, {styles:'',lyrics:''});
assert.strictEqual(result.manualChoiceCount,0);
assert(app.includes('STAGE 137 — MANUAL MUSICAL CHOICE ROUTING'));
assert(app.includes('manualSelectionsImmutable:true'));
console.log(`Stage 137: ${profiles.length}/68 profile matrix; 8 focused assertions passed.`);
