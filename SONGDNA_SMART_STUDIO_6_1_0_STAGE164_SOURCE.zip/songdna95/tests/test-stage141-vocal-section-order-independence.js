'use strict';
const assert=require('assert');
const fs=require('fs');
const app=fs.readFileSync('app.js','utf8');
const start=app.indexOf('function auditManualVocalSectionPlacement');
const end=app.indexOf('\n(function initStage140ManualVocalSectionPlacement',start);
assert(start>=0&&end>start,'Stage 140 placement audit must remain available');
const audit=new Function(app.slice(start,end)+'; return auditManualVocalSectionPlacement;')();
const catalog=app.match(/const GLOBAL_MUSIC_DNA=(\{[\s\S]*?\});\nconst TECHNIQUE_MODULES=/);
assert(catalog,'Music DNA catalog must remain available');
const profiles=JSON.parse(catalog[1]).music_dna_profiles;
assert.strictEqual(profiles.length,68);
const assignments={section_assignments:[
 {role:'lead',section:'verse'},
 {role:'backing',section:'chorus'},
 {role:'guest',section:'guest verse'},
 {role:'duet',section:'bridge'}
]};
const sections=[
 '[Verse 1 – Lead Vocal]\nLead line',
 '[Chorus – Backing Vocals]\nBacking response',
 '[Guest Verse – Guest Vocal]\nGuest line',
 '[Bridge – Duet]\nTwo voices'
];
function permutations(a){if(a.length<2)return [a];return a.flatMap((v,i)=>permutations(a.filter((_,j)=>j!==i)).map(rest=>[v,...rest]));}
const orders=permutations(sections);
assert.strictEqual(orders.length,24);
for(const profile of profiles){
 for(const order of orders){
  const result=audit(assignments,{lyrics:order.join('\n')});
  assert.strictEqual(result.level,'ok',profile.id+' should accept reordered existing sections: '+order.map(x=>x.split('\n')[0]).join(' | '));
  assert.strictEqual(result.assignmentCount,4);
  assert.strictEqual(result.manualSelectionsChanged,false);
  assert.strictEqual(result.automaticRewrite,false);
 }
}
// Repeated sections and nonstandard but explicitly selected ordering remain valid.
let result=audit({section_assignments:[{role:'lead',section:'verse'},{role:'backing',section:'chorus'}]}, {lyrics:['[Chorus 1 - Backing Vocal]','A','[Verse 1 - Lead Vocal]','B','[Chorus 2 - Backing Vocal]','C','[Outro]','D'].join('\n')});
assert.strictEqual(result.level,'ok');
// The auditor must not create a missing section to make the assignment pass.
result=audit({section_assignments:[{role:'guest',section:'guest verse'}]},'[Verse 1 – Lead Vocal]\nOnly lead');
assert(result.missing.some(x=>x.code==='VOCAL_SECTION_MISSING'));
assert.strictEqual(result.automaticSectionCreation,false);
assert(app.includes("order-independent"));
assert(app.includes('SongDnaManualVocalSectionPlacement'));
console.log(`Stage 141 vocal section order independence: ${profiles.length} profiles × ${orders.length} permutations + 3 focused checks passed`);
